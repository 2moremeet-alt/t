/* ============================================================
   MEEM | محرر التصميم — محرّك الرسم (Canvas 2D)
   ============================================================ */

/* ---------------------- كاش الصور ---------------------- */
const imgCache = new Map();
const patternCache = new Map();

export function ensureImage(src) {
  if (!src) return Promise.resolve(null);
  if (imgCache.has(src)) {
    const c = imgCache.get(src);
    return c.promise;
  }
  const entry = { img: null, promise: null };
  entry.promise = new Promise((resolve) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => { entry.img = img; resolve(img); };
    img.onerror = () => { resolve(null); };
    img.src = src;
  });
  imgCache.set(src, entry);
  return entry.promise;
}

export function getImage(src) {
  const c = imgCache.get(src);
  return c && c.img ? c.img : null;
}

export async function preloadLayers(layers) {
  const srcs = new Set();
  (layers || []).forEach((l) => {
    if (l.type === 'image' && l.src) srcs.add(l.src);
    if (l.imageFill && l.imageFill.src) srcs.add(l.imageFill.src);
  });
  await Promise.all([...srcs].map(ensureImage));
}

function getPattern(url) {
  if (patternCache.has(url)) return patternCache.get(url);
  const entry = { img: null, pattern: null, promise: null };
  entry.promise = ensureImage(url).then((img) => { entry.img = img; return img; });
  patternCache.set(url, entry);
  return entry;
}

/* ---------------------- أدوات ---------------------- */

function filterString(f) {
  if (!f) return 'none';
  const parts = [];
  if (f.brightness != null && f.brightness !== 100) parts.push(`brightness(${f.brightness}%)`);
  if (f.contrast != null && f.contrast !== 100) parts.push(`contrast(${f.contrast}%)`);
  if (f.saturate != null && f.saturate !== 100) parts.push(`saturate(${f.saturate}%)`);
  if (f.grayscale) parts.push(`grayscale(${f.grayscale}%)`);
  if (f.sepia) parts.push(`sepia(${f.sepia}%)`);
  if (f.hue) parts.push(`hue-rotate(${f.hue}deg)`);
  if (f.blur) parts.push(`blur(${f.blur}px)`);
  if (f.invert) parts.push(`invert(${f.invert}%)`);
  return parts.length ? parts.join(' ') : 'none';
}

function roundRectPath(ctx, x, y, w, h, r) {
  const rr = Math.max(0, Math.min(r, Math.min(w, h) / 2));
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.lineTo(x + w - rr, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + rr);
  ctx.lineTo(x + w, y + h - rr);
  ctx.quadraticCurveTo(x + w, y + h, x + w - rr, y + h);
  ctx.lineTo(x + rr, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - rr);
  ctx.lineTo(x, y + rr);
  ctx.quadraticCurveTo(x, y, x + rr, y);
  ctx.closePath();
}

function resolveFill(ctx, fill, x, y, w, h) {
  if (!fill) return null;
  if (typeof fill === 'string') return fill;
  if (fill.type === 'linear' || !fill.type) {
    const ang = ((fill.angle == null ? 90 : fill.angle) * Math.PI) / 180;
    const cx = x + w / 2, cy = y + h / 2;
    const len = Math.abs(w * Math.cos(ang)) + Math.abs(h * Math.sin(ang));
    const dx = Math.cos(ang) * len / 2, dy = Math.sin(ang) * len / 2;
    const g = ctx.createLinearGradient(cx - dx, cy - dy, cx + dx, cy + dy);
    (fill.stops && fill.stops.length ? fill.stops : [{ c: '#7c5cff', at: 0 }, { c: '#22d3ee', at: 1 }])
      .forEach((s) => g.addColorStop(Math.max(0, Math.min(1, s.at)), s.c));
    return g;
  }
  if (fill.type === 'radial') {
    const g = ctx.createRadialGradient(x + w / 2, y + h / 2, 0, x + w / 2, y + h / 2, Math.max(w, h) / 2);
    (fill.stops || [{ c: '#7c5cff', at: 0 }, { c: '#22d3ee', at: 1 }])
      .forEach((s) => g.addColorStop(Math.max(0, Math.min(1, s.at)), s.c));
    return g;
  }
  return '#000';
}

/* ---------------------- الأشكال ---------------------- */

export function shapePath(shape, w, h, sides) {
  const p = new Path2D();
  const cx = w / 2, cy = h / 2;
  switch (shape) {
    case 'ellipse':
      p.ellipse(cx, cy, w / 2, h / 2, 0, 0, Math.PI * 2);
      break;
    case 'triangle':
      p.moveTo(w / 2, 0); p.lineTo(w, h); p.lineTo(0, h); p.closePath();
      break;
    case 'diamond':
      p.moveTo(cx, 0); p.lineTo(w, cy); p.lineTo(cx, h); p.lineTo(0, cy); p.closePath();
      break;
    case 'pentagon':
    case 'hexagon': {
      const n = shape === 'pentagon' ? 5 : 6;
      for (let i = 0; i < n; i++) {
        const a = -Math.PI / 2 + (i * 2 * Math.PI) / n;
        const x = cx + Math.cos(a) * (w / 2);
        const y = cy + Math.sin(a) * (h / 2);
        i ? p.lineTo(x, y) : p.moveTo(x, y);
      }
      p.closePath();
      break;
    }
    case 'star5':
    case 'star6': {
      const n = shape === 'star5' ? 5 : 6;
      for (let i = 0; i < n * 2; i++) {
        const r = i % 2 === 0 ? 1 : 0.42;
        const a = -Math.PI / 2 + (i * Math.PI) / n;
        const x = cx + Math.cos(a) * (w / 2) * r;
        const y = cy + Math.sin(a) * (h / 2) * r;
        i ? p.lineTo(x, y) : p.moveTo(x, y);
      }
      p.closePath();
      break;
    }
    case 'burst': {
      const n = (sides || 12) * 2;
      for (let i = 0; i < n; i++) {
        const r = i % 2 === 0 ? 1 : 0.78;
        const a = (i * Math.PI) / (n / 2);
        const x = cx + Math.cos(a) * (w / 2) * r;
        const y = cy + Math.sin(a) * (h / 2) * r;
        i ? p.lineTo(x, y) : p.moveTo(x, y);
      }
      p.closePath();
      break;
    }
    case 'heart': {
      const s = Math.min(w, h) / 32;
      p.moveTo(w / 2, h);
      p.bezierCurveTo(w / 2 - 20 * s, h - 12 * s, 0, h - 22 * s, 0, h * 0.36);
      p.bezierCurveTo(0, h * 0.08, w * 0.22, 0, w / 2, h * 0.28);
      p.bezierCurveTo(w * 0.78, 0, w, h * 0.08, w, h * 0.36);
      p.bezierCurveTo(w, h - 22 * s, w / 2 + 20 * s, h - 12 * s, w / 2, h);
      p.closePath();
      break;
    }
    case 'arrow': {
      const bw = h * 0.45;
      const by = (h - bw) / 2;
      p.moveTo(0, by); p.lineTo(w * 0.62, by); p.lineTo(w * 0.62, 0);
      p.lineTo(w, h / 2); p.lineTo(w * 0.62, h); p.lineTo(w * 0.62, by + bw);
      p.lineTo(0, by + bw); p.closePath();
      break;
    }
    case 'chevron': {
      const t = Math.min(w * 0.35, h * 0.5);
      p.moveTo(0, 0); p.lineTo(t, 0); p.lineTo(w, h / 2); p.lineTo(t, h); p.lineTo(0, h); p.lineTo(w - t, h / 2); p.closePath();
      break;
    }
    case 'speech': {
      const r = Math.min(24, h * 0.18);
      const tail = h * 0.18;
      p.moveTo(r, 0);
      p.lineTo(w - r, 0); p.quadraticCurveTo(w, 0, w, r);
      p.lineTo(w, h - tail - r); p.quadraticCurveTo(w, h - tail, w - r, h - tail);
      p.lineTo(w * 0.42, h - tail); p.lineTo(w * 0.28, h); p.lineTo(w * 0.3, h - tail);
      p.lineTo(r, h - tail); p.quadraticCurveTo(0, h - tail, 0, h - tail - r);
      p.lineTo(0, r); p.quadraticCurveTo(0, 0, r, 0);
      p.closePath();
      break;
    }
    case 'ribbon': {
      const n = h * 0.28;
      p.moveTo(0, 0); p.lineTo(w, 0); p.lineTo(w - n, h / 2); p.lineTo(w, h); p.lineTo(0, h); p.lineTo(n, h / 2); p.closePath();
      break;
    }
    case 'cloud': {
      p.moveTo(w * 0.25, h);
      p.bezierCurveTo(w * 0.05, h, 0, h * 0.78, 0, h * 0.6);
      p.bezierCurveTo(0, h * 0.38, w * 0.14, h * 0.28, w * 0.3, h * 0.32);
      p.bezierCurveTo(w * 0.36, h * 0.1, w * 0.62, h * 0.02, w * 0.76, h * 0.2);
      p.bezierCurveTo(w * 0.94, h * 0.16, w, h * 0.4, w, h * 0.58);
      p.bezierCurveTo(w, h * 0.84, w * 0.84, h, w * 0.66, h);
      p.closePath();
      break;
    }
    case 'line':
      p.rect(0, h / 2 - Math.max(1, h * 0.06) / 2, w, Math.max(1, h * 0.06));
      break;
    case 'frame': {
      const t = Math.min(w, h) * 0.12;
      p.rect(0, 0, w, h);
      p.rect(t, t, w - t * 2, h - t * 2);
      break;
    }
    case 'tag': {
      const c = h * 0.5;
      p.moveTo(c, 0); p.lineTo(w, 0); p.lineTo(w, h); p.lineTo(c, h); p.lineTo(0, h / 2); p.closePath();
      break;
    }
    case 'badge': {
      const n = (sides || 10) * 2;
      for (let i = 0; i < n; i++) {
        const r = i % 2 === 0 ? 1 : 0.86;
        const a = (i * Math.PI) / (n / 2);
        const x = cx + Math.cos(a) * (w / 2) * r;
        const y = cy + Math.sin(a) * (h / 2) * r;
        i ? p.lineTo(x, y) : p.moveTo(x, y);
      }
      p.closePath();
      break;
    }
    case 'polygon': {
      const n = Math.max(3, sides || 5);
      for (let i = 0; i < n; i++) {
        const a = -Math.PI / 2 + (i * 2 * Math.PI) / n;
        const x = cx + Math.cos(a) * (w / 2);
        const y = cy + Math.sin(a) * (h / 2);
        i ? p.lineTo(x, y) : p.moveTo(x, y);
      }
      p.closePath();
      break;
    }
    case 'roundrect':
    case 'rect':
    default:
      p.rect(0, 0, w, h);
      break;
  }
  return p;
}

/* ---------------------- النص ---------------------- */

export function wrapText(ctx, text, maxWidth) {
  const out = [];
  const paragraphs = String(text == null ? '' : text).split('\n');
  for (const para of paragraphs) {
    if (!para.length) { out.push(''); continue; }
    const words = para.split(/(\s+)/);
    let line = '';
    for (const w of words) {
      if (/^\s+$/.test(w)) { line += w; continue; }
      const test = line + w;
      if (ctx.measureText(test).width > maxWidth && line.trim()) {
        out.push(line.trimEnd());
        line = w;
      } else {
        line = test;
      }
    }
    if (line.length) out.push(line.trimEnd());
  }
  // كسر الكلمات الأطول من العرض
  const final = [];
  for (const ln of out) {
    if (ctx.measureText(ln).width <= maxWidth || !ln) { final.push(ln); continue; }
    let cur = '';
    for (const ch of ln) {
      if (ctx.measureText(cur + ch).width > maxWidth && cur) { final.push(cur); cur = ch; }
      else cur += ch;
    }
    if (cur) final.push(cur);
  }
  return final;
}

function applyFont(ctx, l, scale = 1) {
  ctx.font = `${l.italic ? 'italic ' : ''}${l.fontWeight || 400} ${l.fontSize}px "${l.fontFamily}", 'Noto Sans Arabic', 'Segoe UI', Tahoma, sans-serif`;
}

export function textLayout(l) {
  const cv = textLayout._cv || (textLayout._cv = document.createElement('canvas'));
  const ctx = cv.getContext('2d');
  applyFont(ctx, l);
  const maxW = Math.max(10, l.w - (l.padding || 0) * 2);
  const lines = l.wrap === false ? String(l.text || '').split('\n') : wrapText(ctx, l.text, maxW);
  let fs = l.fontSize;
  if (l.autoFit) {
    const lineH = fs * (l.lineHeight || 1.3);
    while (lines.length * lineH > l.h && fs > 6) {
      fs -= 1;
      applyFont(ctx, Object.assign({}, l, { fontSize: fs }));
      const ls = l.wrap === false ? String(l.text || '').split('\n') : wrapText(ctx, l.text, maxW);
      lines.length = 0;
      lines.push(...ls);
      if (ls.length * fs * (l.lineHeight || 1.3) <= l.h) break;
    }
  }
  const lineHeight = fs * (l.lineHeight || 1.3);
  return { lines, fontSize: fs, lineHeight, total: lines.length * lineHeight };
}

export function computeTextHeight(l) {
  const { total } = textLayout(l);
  return Math.max(l.fontSize * 1.2, total + (l.padding || 0) * 2);
}

/* ---------------------- رسم الطبقة ---------------------- */

async function drawLayerContent(c, l, ox, oy) {
  const cx = ox + l.w / 2, cy = oy + l.h / 2;
  c.translate(cx, cy);
  if (l.rot) c.rotate((l.rot * Math.PI) / 180);
  if (l.flipX || l.flipY) c.scale(l.flipX ? -1 : 1, l.flipY ? -1 : 1);
  c.translate(-l.w / 2, -l.h / 2);

  const f = l.filters;
  c.filter = filterString(f);

  if (l.shadow && l.shadow.width !== 0) {
    c.shadowColor = l.shadow.color || 'rgba(0,0,0,.45)';
    c.shadowBlur = l.shadow.blur || 0;
    c.shadowOffsetX = l.shadow.x || 0;
    c.shadowOffsetY = l.shadow.y || 0;
  }

  try {
    if (l.type === 'text' || l.type === 'emoji') drawText(c, l);
    else if (l.type === 'image') await drawImageLayer(c, l);
    else drawShape(c, l);
  } finally {
    c.filter = 'none';
    c.shadowColor = 'transparent';
    c.shadowBlur = 0;
    c.shadowOffsetX = 0;
    c.shadowOffsetY = 0;
  }
}

let _layerScratch = null;
function getLayerScratch(w, h) {
  if (!_layerScratch) _layerScratch = document.createElement('canvas');
  if (_layerScratch.width !== w || _layerScratch.height !== h) { _layerScratch.width = w; _layerScratch.height = h; }
  const c = _layerScratch.getContext('2d');
  c.setTransform(1, 0, 0, 1, 0, 0);
  c.globalCompositeOperation = 'source-over';
  c.globalAlpha = 1;
  c.filter = 'none';
  c.clearRect(0, 0, w, h);
  return _layerScratch;
}

function applyPixelOps(o, f, w, h) {
  const img = o.getImageData(0, 0, w, h);
  const d = img.data;
  const sh = (f.sharpen || 0) / 100, dg = (f.dodge || 0) / 100, bu = (f.burn || 0) / 100;
  if (sh > 0) {
    const src = new Uint8ClampedArray(d);
    const a = sh;
    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        const i = (y * w + x) * 4;
        if (src[i + 3] === 0) continue;
        for (let c = 0; c < 3; c++) {
          const idx = i + c;
          const v = (1 + 4 * a) * src[idx] - a * (src[idx - 4] + src[idx + 4] + src[idx - w * 4] + src[idx + w * 4]);
          d[idx] = v < 0 ? 0 : v > 255 ? 255 : v;
        }
      }
    }
  }
  if (dg > 0 || bu > 0) {
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] === 0) continue;
      const lum = (0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]) / 255;
      if (dg > 0) { const k = dg * 0.9 * lum; for (let c = 0; c < 3; c++) d[i + c] += (255 - d[i + c]) * k; }
      if (bu > 0) { const k = bu * 0.9 * (1 - lum); for (let c = 0; c < 3; c++) d[i + c] -= d[i + c] * k; }
    }
  }
  o.putImageData(img, 0, 0);
}

export async function drawLayer(ctx, l) {
  if (l.visible === false) return;
  const f = l.filters || {};
  const needsPx = (f.sharpen > 0 || f.dodge > 0 || f.burn > 0);
  const hasMask = !!l.mask;

  if (!needsPx && !hasMask) {
    ctx.save();
    ctx.globalAlpha = l.opacity == null ? 1 : l.opacity;
    if (l.blend && l.blend !== 'source-over') ctx.globalCompositeOperation = l.blend;
    try {
      await drawLayerContent(ctx, l, l.x, l.y);
    } finally {
      ctx.restore();
    }
    return;
  }

  const w = Math.max(1, Math.ceil(l.w)), h = Math.max(1, Math.ceil(l.h));
  const off = getLayerScratch(w, h);
  const o = off.getContext('2d');
  await drawLayerContent(o, l, 0, 0);
  if (needsPx) applyPixelOps(o, f, w, h);
  if (hasMask) {
    const img = await ensureImage(l.mask);
    if (img) {
      o.globalCompositeOperation = 'destination-in';
      o.globalAlpha = 1;
      o.drawImage(img, 0, 0, w, h);
      o.globalCompositeOperation = 'source-over';
    }
  }
  ctx.save();
  ctx.globalAlpha = l.opacity == null ? 1 : l.opacity;
  if (l.blend && l.blend !== 'source-over') ctx.globalCompositeOperation = l.blend;
  ctx.drawImage(off, l.x, l.y, l.w, l.h);
  ctx.restore();
}

function drawShape(ctx, l) {
  const radius = l.shape === 'roundrect' ? Math.max(l.radius || 0, Math.min(l.w, l.h) * 0.08) : (l.radius || 0);
  const path = (l.shape === 'rect' && radius)
    ? (roundRectPath(ctx, 0, 0, l.w, l.h, radius), null)
    : shapePath(l.shape, l.w, l.h, l.sides);

  if (l.shape === 'frame') {
    const fill = resolveFill(ctx, l.fill, 0, 0, l.w, l.h);
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, l.w, l.h);
    const t = Math.min(l.w, l.h) * 0.12;
    ctx.rect(t, t, l.w - t * 2, l.h - t * 2);
    ctx.fill('evenodd');
    if (fill) { ctx.fillStyle = fill; ctx.fill('evenodd'); }
    ctx.restore();
    return;
  }

  const fill = resolveFill(ctx, l.fill, 0, 0, l.w, l.h);
  if (fill) { ctx.fillStyle = fill; ctx.fill(path); }
  if (l.stroke && l.stroke.width > 0) {
    ctx.shadowColor = 'transparent';
    ctx.lineWidth = l.stroke.width;
    ctx.strokeStyle = l.stroke.color;
    ctx.lineJoin = 'round';
    ctx.stroke(path);
  }
}

function drawText(ctx, l) {
  if (l.type === 'emoji') {
    ctx.font = `${l.fontSize}px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.direction = 'ltr';
    ctx.fillText(l.text || '⭐', l.w / 2, l.h / 2 + l.fontSize * 0.04);
    return;
  }

  const { lines, fontSize, lineHeight, total } = textLayout(l);
  const pad = l.padding || 0;
  const boxX = pad, boxW = l.w - pad * 2;

  // خلفية النص
  if (l.bgBox) {
    ctx.save();
    ctx.filter = 'none';
    ctx.shadowColor = 'transparent';
    ctx.globalAlpha = (l.opacity == null ? 1 : 1) * (l.bgBoxOpacity == null ? 0.5 : l.bgBoxOpacity);
    ctx.fillStyle = l.bgBoxColor || '#000';
    roundRectPath(ctx, 0, l.h / 2 - total / 2 - pad * 0.6, l.w, total + pad * 1.2, l.bgBoxRadius || 0);
    ctx.fill();
    ctx.restore();
  }

  applyFont(ctx, Object.assign({}, l, { fontSize }));
  ctx.direction = l.rtl ? 'rtl' : 'ltr';
  ctx.textBaseline = 'alphabetic';
  let x = boxX;
  if (l.align === 'center') { ctx.textAlign = 'center'; x = l.w / 2; }
  else if (l.align === 'right') { ctx.textAlign = 'right'; x = l.w - pad; }
  else { ctx.textAlign = 'left'; x = boxX; }

  const startY = l.h / 2 - total / 2 + fontSize * 0.82;

  let fillStyle = l.color || '#fff';
  if (l.gradientFill && l.gradientFill.on) {
    const ang = ((l.gradientFill.angle || 0) * Math.PI) / 180;
    const g = ctx.createLinearGradient(0, l.h / 2 - total / 2, Math.cos(ang) * l.w, l.h / 2 + total / 2);
    (l.gradientFill.stops || [{ c: '#7c5cff', at: 0 }, { c: '#22d3ee', at: 1 }]).forEach((s) => g.addColorStop(s.at, s.c));
    fillStyle = g;
  }

  if (l.letterSpacing) {
    try { ctx.letterSpacing = l.letterSpacing + 'px'; } catch (e) {}
  }

  const warped = !!(l.warp && l.warp.on && l.warp.amount);
  const fillImg = !warped && l.imageFill && l.imageFill.src ? getImage(l.imageFill.src) : null;

  for (let i = 0; i < lines.length; i++) {
    const y = startY + i * lineHeight;
    if (l.textStroke && l.textStroke.width > 0 && !warped) {
      ctx.lineWidth = l.textStroke.width;
      ctx.strokeStyle = l.textStroke.color;
      ctx.lineJoin = 'round';
      ctx.miterLimit = 2;
      ctx.strokeText(lines[i], x, y);
    }
    if (!warped && !fillImg) {
      ctx.fillStyle = fillStyle;
      ctx.fillText(lines[i], x, y);
    }
  }

  if (warped) {
    drawWarpedText(ctx, l, lines, fontSize, lineHeight, fillStyle);
  } else if (fillImg) {
    // تعبئة النص بصورة: قناع على كانفس جانبي ثم تركيب
    const off = drawText._off || (drawText._off = document.createElement('canvas'));
    off.width = Math.max(1, Math.ceil(l.w));
    off.height = Math.max(1, Math.ceil(l.h));
    const oc = off.getContext('2d');
    oc.setTransform(1, 0, 0, 1, 0, 0);
    oc.clearRect(0, 0, off.width, off.height);
    oc.filter = 'none';
    oc.font = ctx.font;
    oc.direction = ctx.direction;
    oc.textAlign = ctx.textAlign;
    oc.textBaseline = ctx.textBaseline;
    try { oc.letterSpacing = ctx.letterSpacing || '0px'; } catch (e) {}
    oc.fillStyle = '#ffffff';
    for (let i = 0; i < lines.length; i++) oc.fillText(lines[i], x, startY + i * lineHeight);
    oc.globalCompositeOperation = 'source-in';
    const iw = fillImg.naturalWidth || fillImg.width, ih = fillImg.naturalHeight || fillImg.height;
    const tr = l.w / l.h, sr = iw / ih;
    let sx = 0, sy = 0, sw = iw, sh = ih;
    if (sr > tr) { sw = ih * tr; sx = (iw - sw) / 2; } else { sh = iw / tr; sy = (ih - sh) / 2; }
    const sc = l.imageFill.scale || 1;
    const dw = l.w * sc, dh = l.h * sc;
    oc.drawImage(fillImg, sx, sy, sw, sh, (l.w - dw) / 2, (l.h - dh) / 2, dw, dh);
    ctx.save();
    ctx.shadowColor = 'transparent';
    ctx.drawImage(off, 0, 0);
    ctx.restore();
  }
  try { ctx.letterSpacing = '0px'; } catch (e) {}
}

/* ---------------------- نص منحني (Warp) ---------------------- */

function splitSegments(line) {
  const parts = String(line).split(/(\s+)/);
  const out = [];
  let buf = '';
  for (const p of parts) {
    if (!p) continue;
    buf += p;
    if (/\s$/.test(p)) { out.push(buf); buf = ''; }
  }
  if (buf) out.push(buf);
  return out;
}

function drawWarpedText(ctx, l, lines, fontSize, lineHeight, fillStyle) {
  const amt = Math.max(-100, Math.min(100, l.warp.amount || 0));
  const d = amt >= 0 ? 1 : -1;
  const totalAngle = (Math.abs(amt) / 100) * Math.PI * 0.9;
  const pad = l.padding || 0;
  const cx = l.w / 2;
  const blockH = lines.length * lineHeight;
  const startTop = l.h / 2 - blockH / 2;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'alphabetic';

  for (let li = 0; li < lines.length; li++) {
    const segs = splitSegments(lines[li]);
    const widths = segs.map((sg) => ctx.measureText(sg).width);
    const totalW = widths.reduce((a, b) => a + b, 0);
    if (!totalW) continue;
    const r = Math.max(20, totalW / totalAngle);
    const angPer = totalAngle / totalW;
    const cy = startTop + li * lineHeight + fontSize * 0.82 + d * r;
    const a0 = -d * totalAngle / 2;
    let acc = 0;
    for (let si = 0; si < segs.length; si++) {
      const th = a0 + d * angPer * (acc + widths[si] / 2);
      const px = cx + r * Math.sin(th);
      const py = cy - d * r * Math.cos(th);
      ctx.save();
      ctx.translate(px, py);
      ctx.rotate(th);
      if (l.textStroke && l.textStroke.width > 0) {
        ctx.lineWidth = l.textStroke.width;
        ctx.strokeStyle = l.textStroke.color;
        ctx.lineJoin = 'round';
        ctx.miterLimit = 2;
        ctx.strokeText(segs[si], 0, 0);
      }
      ctx.fillStyle = fillStyle;
      ctx.fillText(segs[si], 0, 0);
      ctx.restore();
      acc += widths[si];
    }
  }
}

async function drawImageLayer(ctx, l) {
  const img = getImage(l.src);
  if (!img) {
    ctx.save();
    ctx.filter = 'none';
    ctx.fillStyle = 'rgba(148,163,184,.25)';
    ctx.fillRect(0, 0, l.w, l.h);
    ctx.strokeStyle = 'rgba(148,163,184,.6)';
    ctx.setLineDash([12, 10]);
    ctx.lineWidth = 3;
    ctx.strokeRect(1.5, 1.5, l.w - 3, l.h - 3);
    ctx.restore();
    return;
  }
  const iw = img.naturalWidth || img.width;
  const ih = img.naturalHeight || img.height;
  let sx = 0, sy = 0, sw = iw, sh = ih, dx = 0, dy = 0, dw = l.w, dh = l.h;
  const target = l.w / l.h;
  const src = iw / ih;
  if (l.fit === 'cover') {
    if (src > target) { sw = ih * target; sx = (iw - sw) / 2; }
    else { sh = iw / target; sy = (ih - sh) / 2; }
  } else if (l.fit === 'contain') {
    if (src > target) { dh = l.w / src; dy = (l.h - dh) / 2; }
    else { dw = l.h * src; dx = (l.w - dw) / 2; }
  }
  const cs = l.cropShape && l.cropShape !== 'none' ? l.cropShape : null;
  let clipPath = null;
  if (cs) {
    clipPath = shapePath(cs === 'circle' ? 'ellipse' : cs, l.w, l.h);
  }
  if (cs || l.radius) {
    ctx.save();
    if (clipPath) ctx.clip(clipPath);
    else { roundRectPath(ctx, 0, 0, l.w, l.h, l.radius); ctx.clip(); }
    ctx.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
    ctx.restore();
  } else {
    ctx.drawImage(img, sx, sy, sw, sh, dx, dy, dw, dh);
  }
  if (l.stroke && l.stroke.width > 0) {
    ctx.shadowColor = 'transparent';
    ctx.lineWidth = l.stroke.width;
    ctx.strokeStyle = l.stroke.color;
    if (clipPath) ctx.stroke(clipPath);
    else if (l.radius) { roundRectPath(ctx, 0, 0, l.w, l.h, l.radius); ctx.stroke(); }
    else ctx.strokeRect(0, 0, l.w, l.h);
  }
}

/* ---------------------- الخلفية ---------------------- */

export async function drawBackground(ctx, page) {
  const { w, h } = page;
  const bg = page.bg || { type: 'color', color: '#ffffff' };
  if (bg.type === 'color') {
    ctx.fillStyle = bg.color || '#fff';
    ctx.fillRect(0, 0, w, h);
    return;
  }
  if (bg.type === 'gradient') {
    const stops = bg.stops || [{ c: '#7c5cff', at: 0 }, { c: '#22d3ee', at: 1 }];
    let g;
    if (bg.radial) {
      g = ctx.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, Math.max(w, h) / 1.2);
    } else {
      const ang = ((bg.angle == null ? 135 : bg.angle) * Math.PI) / 180;
      const len = Math.abs(w * Math.cos(ang)) + Math.abs(h * Math.sin(ang));
      const dx = Math.cos(ang) * len / 2, dy = Math.sin(ang) * len / 2;
      g = ctx.createLinearGradient(w / 2 - dx, h / 2 - dy, w / 2 + dx, h / 2 + dy);
    }
    stops.forEach((s) => g.addColorStop(s.at, s.c));
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, w, h);
    return;
  }
  if (bg.type === 'image') {
    const img = await ensureImage(bg.src);
    if (img) {
      const iw = img.naturalWidth, ih = img.naturalHeight;
      const t = w / h, s = iw / ih;
      let sx = 0, sy = 0, sw = iw, sh = ih;
      if (s > t) { sw = ih * t; sx = (iw - sw) / 2; } else { sh = iw / t; sy = (ih - sh) / 2; }
      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, w, h);
    } else {
      ctx.fillStyle = '#1a2130';
      ctx.fillRect(0, 0, w, h);
    }
    return;
  }
  if (bg.type === 'pattern') {
    ctx.fillStyle = bg.color || '#fff';
    ctx.fillRect(0, 0, w, h);
    const entry = getPattern(bg.src);
    if (entry.img) {
      const pat = ctx.createPattern(entry.img, 'repeat');
      ctx.save();
      ctx.scale(bg.scale || 1, bg.scale || 1);
      ctx.fillStyle = pat;
      ctx.fillRect(0, 0, w / (bg.scale || 1), h / (bg.scale || 1));
      ctx.restore();
    } else {
      entry.promise.then(() => { if (bg._onReady) bg._onReady(); });
    }
    return;
  }
}

/* ---------------------- الصفحة كاملة ---------------------- */

export async function renderPage(canvas, page, scale = 1) {
  const ctx = canvas.getContext('2d');
  canvas.width = Math.max(1, Math.round(page.w * scale));
  canvas.height = Math.max(1, Math.round(page.h * scale));
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.imageSmoothingQuality = 'high';
  ctx.save();
  ctx.scale(scale, scale);
  await drawBackground(ctx, page);
  const paintCv = await renderPaintOffscreen(page);
  if (paintCv) ctx.drawImage(paintCv, 0, 0, page.w, page.h);
  for (const l of page.layers) {
    if (l.type === 'image' && l.src) await ensureImage(l.src);
    await drawLayer(ctx, l);
  }
  ctx.restore();
  return canvas;
}

export async function pageToDataURL(page, scale = 1, type = 'image/png', quality = 0.94) {
  const c = document.createElement('canvas');
  await renderPage(c, page, scale);
  return c.toDataURL(type, quality);
}

export async function pageToBlob(page, scale = 1, type = 'image/png', quality = 0.94) {
  const c = document.createElement('canvas');
  await renderPage(c, page, scale);
  return new Promise((res) => c.toBlob((b) => res(b), type, quality));
}

/* ---------------------- استخراج ألوان ---------------------- */

export async function dominantColors(src, count = 6) {
  const img = await ensureImage(src);
  if (!img) return [];
  const c = document.createElement('canvas');
  const size = 64;
  c.width = size; c.height = size;
  const ctx = c.getContext('2d');
  ctx.drawImage(img, 0, 0, size, size);
  const data = ctx.getImageData(0, 0, size, size).data;
  const buckets = new Map();
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] < 128) continue;
    const r = data[i] >> 5, g = data[i + 1] >> 5, b = data[i + 2] >> 5;
    const key = (r << 10) | (g << 5) | b;
    const cur = buckets.get(key) || { n: 0, r: 0, g: 0, b: 0 };
    cur.n++; cur.r += data[i]; cur.g += data[i + 1]; cur.b += data[i + 2];
    buckets.set(key, cur);
  }
  return [...buckets.values()]
    .sort((a, b) => b.n - a.n)
    .slice(0, count)
    .map((v) => '#' + [v.r / v.n, v.g / v.n, v.b / v.n].map((x) => Math.round(x).toString(16).padStart(2, '0')).join(''));
}

export { roundRectPath, resolveFill, filterString };

/* ================= طبقة الرسم (Paint) — V2-E1 ================= */
/* page.paint = { ver, strokes: [{tool:'brush'|'eraser'|'gradient', color, color2, size, op, pts, g, sel}] } */

const _paintCache = new WeakMap();   // page -> { ver, canvas }
let _scratch = null;

export function bumpPaint(page) {
  if (!page.paint) page.paint = { ver: 0, strokes: [] };
  page.paint.ver = (page.paint.ver || 0) + 1;
}

function getScratch(w, h) {
  if (!_scratch) _scratch = document.createElement('canvas');
  if (_scratch.width !== w || _scratch.height !== h) { _scratch.width = w; _scratch.height = h; }
  const c = _scratch.getContext('2d');
  c.setTransform(1, 0, 0, 1, 0, 0);
  c.globalCompositeOperation = 'source-over';
  c.globalAlpha = 1;
  c.clearRect(0, 0, w, h);
  return _scratch;
}

function strokePath(t, st) {
  t.lineCap = 'round'; t.lineJoin = 'round';
  t.strokeStyle = st.color || '#000';
  t.globalAlpha = st.op == null ? 1 : st.op;
  t.lineWidth = Math.max(0.5, st.size || 8);
  const pts = st.pts || [];
  if (!pts.length) return;
  t.beginPath();
  if (pts.length === 1) {
    t.arc(pts[0][0], pts[0][1], t.lineWidth / 2, 0, Math.PI * 2);
    t.fillStyle = t.strokeStyle;
    t.fill();
    return;
  }
  t.moveTo(pts[0][0], pts[0][1]);
  for (let i = 1; i < pts.length - 1; i++) {
    const mx = (pts[i][0] + pts[i + 1][0]) / 2, my = (pts[i][1] + pts[i + 1][1]) / 2;
    t.quadraticCurveTo(pts[i][0], pts[i][1], mx, my);
  }
  t.lineTo(pts[pts.length - 1][0], pts[pts.length - 1][1]);
  t.stroke();
}

function applySelClip(t, sel) {
  // تحديد مستطيل/لاسو → قص مباشر
  t.beginPath();
  if (sel.type === 'rect') {
    t.rect(sel.x, sel.y, sel.w, sel.h);
  } else if (sel.type === 'poly') {
    const pts = sel.pts;
    if (!pts || pts.length < 2) return;
    t.moveTo(pts[0][0], pts[0][1]);
    for (let i = 1; i < pts.length; i++) t.lineTo(pts[i][0], pts[i][1]);
    t.closePath();
  }
  t.clip();
}

async function drawOneStroke(ctx, page, st) {
  const tmp = getScratch(page.w, page.h);
  const t = tmp.getContext('2d');
  t.save(); // عزل القص وأوضاع المزج لكل ضربة — clip يبقى لو مااتعملش restore
  if (st.sel && st.sel.type === 'mask') {
    paintStrokeContent(t, page, st);
    const img = st.sel.url ? await ensureImage(st.sel.url) : null;
    if (img) {
      t.globalCompositeOperation = 'destination-in';
      t.globalAlpha = 1;
      t.drawImage(img, 0, 0, page.w, page.h);
    }
  } else {
    if (st.sel) applySelClip(t, st.sel);
    paintStrokeContent(t, page, st);
  }
  t.restore();
  ctx.save();
  ctx.globalCompositeOperation = (st.tool === 'eraser' || st.tool === 'erase-fill') ? 'destination-out' : 'source-over';
  ctx.globalAlpha = 1;
  ctx.drawImage(tmp, 0, 0);
  ctx.restore();
}

function paintStrokeContent(t, page, st) {
  if (st.tool === 'erase-fill') {
    t.globalAlpha = st.op == null ? 1 : st.op;
    t.fillStyle = '#000';
    t.fillRect(0, 0, page.w, page.h);
    return;
  }
  if (st.tool === 'gradient') paintGradient(t, page, st);
  else strokePath(t, st);
}

function paintGradient(t, page, st) {
  const g = st.g || { x1: 0, y1: 0, x2: page.w, y2: page.h };
  const grad = t.createLinearGradient(g.x1, g.y1, g.x2, g.y2);
  grad.addColorStop(0, st.color || '#000');
  grad.addColorStop(1, st.color2 || st.color || '#000');
  t.globalAlpha = st.op == null ? 1 : st.op;
  t.fillStyle = grad;
  t.fillRect(0, 0, page.w, page.h);
}

export async function renderPaintOffscreen(page) {
  if (!page.paint || !page.paint.strokes || !page.paint.strokes.length) return null;
  const cached = _paintCache.get(page);
  if (cached && cached.ver === page.paint.ver && cached.canvas.width === page.w && cached.canvas.height === page.h) return cached.canvas;
  const cv = document.createElement('canvas');
  cv.width = page.w; cv.height = page.h;
  const ctx = cv.getContext('2d');
  for (const st of page.paint.strokes) await drawOneStroke(ctx, page, st);
  _paintCache.set(page, { ver: page.paint.ver, canvas: cv });
  return cv;
}

export async function paintCanvasImageData(page) {
  // بكسلات طبقة الرسم فقط (للغمر/العصا السحرية)
  const cv = await renderPaintOffscreen(page);
  if (!cv) return null;
  return cv.getContext('2d').getImageData(0, 0, cv.width, cv.height);
}

export function maskFromPixels(page, maskU8) {
  const c = document.createElement('canvas');
  c.width = page.w; c.height = page.h;
  const ctx = c.getContext('2d');
  const img = ctx.createImageData(page.w, page.h);
  for (let i = 0; i < maskU8.length; i++) {
    img.data[i * 4] = 255; img.data[i * 4 + 1] = 255; img.data[i * 4 + 2] = 255;
    img.data[i * 4 + 3] = maskU8[i] ? 255 : 0;
  }
  ctx.putImageData(img, 0, 0);
  return c.toDataURL('image/png');
}
