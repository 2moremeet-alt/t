/* ============================================================
   MEEM | محرر التصميم — التصدير (PNG / JPG / PDF)
   كاتب PDF بسيط بدون أي مكتبات (JPEG/DCTDecode)
   ============================================================ */
import { renderPage } from './render.js';
import { ensureFonts } from './fonts.js';
import { downloadBlob } from '../api.js';

export async function exportPage(page, { format = 'png', scale = 1, quality = 0.94, filename = 'design' } = {}) {
  await ensureFonts(page.layers);
  const canvas = document.createElement('canvas');
  await renderPage(canvas, page, scale);

  if (format === 'png' || format === 'jpg' || format === 'webp') {
    const type = format === 'png' ? 'image/png' : format === 'webp' ? 'image/webp' : 'image/jpeg';
    if (format !== 'png') {
      // خلفية بيضاء بدل الشفافية في JPG/WEBP
      const out = document.createElement('canvas');
      out.width = canvas.width; out.height = canvas.height;
      const c = out.getContext('2d');
      c.fillStyle = '#ffffff';
      c.fillRect(0, 0, out.width, out.height);
      c.drawImage(canvas, 0, 0);
      const blob = await new Promise((r) => out.toBlob(r, type, quality));
      downloadBlob(blob, `${filename}.${format}`);
      return blob;
    }
    const blob = await new Promise((r) => canvas.toBlob(r, type, quality));
    downloadBlob(blob, `${filename}.png`);
    return blob;
  }

  if (format === 'pdf') {
    const blob = await pagesToPdf([page], { scale, quality });
    downloadBlob(blob, `${filename}.pdf`);
    return blob;
  }
  throw new Error('format غير مدعوم: ' + format);
}

/* تصدير بمقاس هدف مختلف — التصميم يتناسب مع المقاس الجديد ويتوسّطه (fit) */
export async function exportFitted(page, { w, h, format = 'png', quality = 0.94, filename = 'design' } = {}) {
  await ensureFonts(page.layers);
  const k = Math.min(w / page.w, h / page.h);
  const finalW = page.w * k, finalH = page.h * k;
  // نرسم بدقة أعلى ثم نصغّر — جودة أنعم
  const sup = Math.min(3, Math.max(1, 2200 / Math.max(finalW, finalH)));
  const src = document.createElement('canvas');
  await renderPage(src, page, k * sup);

  const out = document.createElement('canvas');
  out.width = w; out.height = h;
  const c = out.getContext('2d');
  let bgFill = '#ffffff';
  if (page.bg && page.bg.type === 'color' && page.bg.color) bgFill = page.bg.color;
  c.fillStyle = bgFill;
  c.fillRect(0, 0, w, h);
  c.imageSmoothingQuality = 'high';
  c.drawImage(src, Math.round((w - finalW) / 2), Math.round((h - finalH) / 2), Math.round(finalW), Math.round(finalH));

  const type = format === 'png' ? 'image/png' : format === 'webp' ? 'image/webp' : 'image/jpeg';
  const blob = await new Promise((r) => out.toBlob(r, type, quality));
  downloadBlob(blob, `${filename}-${w}x${h}.${format}`);
  return blob;
}

export async function exportAllPages(pages, { format = 'pdf', scale = 1, quality = 0.94, filename = 'design' } = {}) {
  if (format === 'pdf') {
    const blob = await pagesToPdf(pages, { scale, quality });
    downloadBlob(blob, `${filename}.pdf`);
    return blob;
  }
  for (let i = 0; i < pages.length; i++) {
    await exportPage(pages[i], { format, scale, quality, filename: `${filename}-${i + 1}` });
  }
}

/* ------------------------- PDF ------------------------- */

async function pagesToPdf(pages, { scale = 1, quality = 0.94 } = {}) {
  const items = [];
  for (const page of pages) {
    await ensureFonts(page.layers);
    const canvas = document.createElement('canvas');
    await renderPage(canvas, page, Math.min(scale, 2));
    const flat = document.createElement('canvas');
    flat.width = canvas.width; flat.height = canvas.height;
    const fc = flat.getContext('2d');
    fc.fillStyle = '#ffffff';
    fc.fillRect(0, 0, flat.width, flat.height);
    fc.drawImage(canvas, 0, 0);
    const blob = await new Promise((r) => flat.toBlob(r, 'image/jpeg', quality));
    const buf = new Uint8Array(await blob.arrayBuffer());
    items.push({ jpeg: buf, w: flat.width, h: flat.height, pw: page.w, ph: page.h });
  }

  const enc = (s) => new TextEncoder().encode(s);
  const chunks = [];
  const offsets = [];
  let length = 0;
  const push = (bytes) => { chunks.push(bytes); length += bytes.length; };
  const pushStr = (s) => push(enc(s));

  const n = items.length;
  const pageObjStart = 3;
  const kids = items.map((_, i) => `${pageObjStart + i * 3} 0 R`).join(' ');

  pushStr('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');

  offsets[1] = length;
  pushStr(`1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n`);

  offsets[2] = length;
  pushStr(`2 0 obj\n<< /Type /Pages /Kids [${kids}] /Count ${n} >>\nendobj\n`);

  items.forEach((it, i) => {
    const pageObj = pageObjStart + i * 3;
    const imgObj = pageObj + 1;
    const contentObj = pageObj + 2;

    offsets[pageObj] = length;
    pushStr(`${pageObj} 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${it.pw} ${it.ph}] ` +
      `/Resources << /XObject << /Im0 ${imgObj} 0 R >> /ProcSet [/PDF /ImageC] >> ` +
      `/Contents ${contentObj} 0 R >>\nendobj\n`);

    offsets[imgObj] = length;
    pushStr(`${imgObj} 0 obj\n<< /Type /XObject /Subtype /Image /Width ${it.w} /Height ${it.h} ` +
      `/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${it.jpeg.length} >>\nstream\n`);
    push(it.jpeg);
    pushStr('\nendstream\nendobj\n');

    const stream = `q ${it.pw} 0 0 ${it.ph} 0 0 cm /Im0 Do Q`;
    offsets[contentObj] = length;
    pushStr(`${contentObj} 0 obj\n<< /Length ${stream.length} >>\nstream\n${stream}\nendstream\nendobj\n`);
  });

  const xrefPos = length;
  const total = pageObjStart + n * 3;
  let xref = `xref\n0 ${total}\n0000000000 65535 f \n`;
  for (let i = 1; i < total; i++) {
    xref += String(offsets[i] || 0).padStart(10, '0') + ' 00000 n \n';
  }
  pushStr(xref);
  pushStr(`trailer\n<< /Size ${total} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF`);

  const out = new Uint8Array(length);
  let o = 0;
  for (const c of chunks) { out.set(c, o); o += c.length; }
  return new Blob([out], { type: 'application/pdf' });
}

/* ------------------------- معاينة للطباعة ------------------------- */

export async function printPages(pages, title) {
  await ensureFonts(pages.flatMap((p) => p.layers));
  const imgs = [];
  for (const p of pages) {
    const c = document.createElement('canvas');
    await renderPage(c, p, Math.min(2, 2000 / Math.max(p.w, p.h)));
    imgs.push(c.toDataURL('image/jpeg', 0.92));
  }
  const w = window.open('', '_blank');
  if (!w) return;
  w.document.write(`<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>${title || 'print'}</title>
  <style>
    @page { margin: 0; }
    body { margin: 0; background: #fff; }
    img { width: 100%; display: block; page-break-after: always; }
  </style></head><body>${imgs.map((s) => `<img src="${s}">`).join('')}</body></html>`);
  w.document.close();
  setTimeout(() => w.print(), 700);
}
