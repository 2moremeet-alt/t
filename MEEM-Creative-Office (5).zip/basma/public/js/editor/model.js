/* ============================================================
   MEEM | محرر التصميم — موديل البيانات (Doc / Page / Layer)
   ============================================================ */
import { uid } from '../api.js';

export const PAGE_PRESETS = [
  { group: 'سوشيال ميديا', items: [
    { id: 'ig_post', label: 'بوست إنستجرام مربع', w: 1080, h: 1080 },
    { id: 'ig_portrait', label: 'بوست عمودي 4:5', w: 1080, h: 1350 },
    { id: 'story', label: 'ستوري / ريلز', w: 1080, h: 1920 },
    { id: 'fb_cover', label: 'غلاف فيسبوك', w: 820, h: 312 },
    { id: 'li_cover', label: 'غلاف لينكدإن', w: 1584, h: 396 },
    { id: 'x_post', label: 'بوست X / تويتر', w: 1600, h: 900 },
    { id: 'yt_thumb', label: 'غلاف يوتيوب', w: 1280, h: 720 },
    { id: 'yt_banner', label: 'بانر يوتيوب', w: 2560, h: 1440 },
    { id: 'pin', label: 'بينترست', w: 1000, h: 1500 },
    { id: 'snap_ad', label: 'إعلان سناب شات', w: 1080, h: 1920 },
  ]},
  { group: 'مطبوعات (300dpi)', items: [
    { id: 'a5_flyer', label: 'فلاير A5', w: 1748, h: 2480 },
    { id: 'a4_flyer', label: 'فلاير A4', w: 2480, h: 3508 },
    { id: 'a3_poster', label: 'بوستر A3', w: 3508, h: 4961 },
    { id: 'a2_poster', label: 'بوستر A2', w: 4961, h: 7016 },
    { id: 'biz_card', label: 'كارت شخصي 90×50mm', w: 1063, h: 591 },
    { id: 'a4_menu', label: 'منيو A4', w: 2480, h: 3508 },
    { id: 'a4_brochure', label: 'بروشور A4 أفقي', w: 3508, h: 2480 },
    { id: 'rollup', label: 'رول أب 80×200cm', w: 9449, h: 23622 },
    { id: 'dl_flyer', label: 'فلاير DL', w: 1299, h: 2480 },
    { id: 'circle_sticker', label: 'ستيكر دائري 10cm', w: 1181, h: 1181 },
    { id: 'letterhead', label: 'ورق رسمي A4', w: 2480, h: 3508 },
    { id: 'envelope', label: 'ظرف DL', w: 2551, h: 1299 },
  ]},
  { group: 'براندينج', items: [
    { id: 'logo_sq', label: 'شعار مربع', w: 1200, h: 1200 },
    { id: 'logo_wide', label: 'شعار أفقي', w: 2000, h: 800 },
    { id: 'brand_a4', label: 'صفحة دليل هوية A4', w: 2480, h: 3508 },
  ]},
  { group: 'موشن وفيديو', items: [
    { id: 'video_169', label: 'فيديو 16:9', w: 1920, h: 1080 },
    { id: 'video_916', label: 'ريلز 9:16', w: 1080, h: 1920 },
    { id: 'video_11', label: 'فيديو مربع', w: 1080, h: 1080 },
  ]},
  { group: 'واجهات', items: [
    { id: 'ui_desktop', label: 'شاشة ديسكتوب', w: 1440, h: 900 },
    { id: 'ui_mobile', label: 'شاشة موبايل', w: 390, h: 844 },
    { id: 'ui_tablet', label: 'تابلت', w: 834, h: 1112 },
  ]},
];

export const SHAPES = [
  { id: 'rect', label: 'مستطيل', icon: 'M3 5h18v14H3z' },
  { id: 'roundrect', label: 'مستطيل دائري', icon: 'M6 4h12a3 3 0 0 1 3 3v10a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3V7a3 3 0 0 1 3-3z' },
  { id: 'ellipse', label: 'دائرة / بيضاوي', icon: 'M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16z' },
  { id: 'triangle', label: 'مثلث', icon: 'M12 3 22 21H2z' },
  { id: 'diamond', label: 'معيّن', icon: 'M12 2 22 12 12 22 2 12z' },
  { id: 'pentagon', label: 'خماسي', icon: 'M12 2 22 9.5 18.2 21H5.8L2 9.5z' },
  { id: 'hexagon', label: 'سداسي', icon: 'M7 2h10l5 8.7L12 22 2 10.7z' },
  { id: 'star5', label: 'نجمة 5', icon: 'M12 2l2.9 6.3 6.9.8-5.1 4.7 1.4 6.8L12 17.3 5.9 20.6l1.4-6.8L2.2 9.1l6.9-.8z' },
  { id: 'star6', label: 'نجمة 6', icon: 'M12 1.5 14.6 8 21.5 8.4 16.8 13l1.9 6.7L12 16.2 5.3 19.7 7.2 13 2.5 8.4 9.4 8z' },
  { id: 'burst', label: 'انفجار', icon: 'M12 1l2.2 3.6L18 2.4l-.3 4.2 4.1-.9-2 3.7 4 1.3-3.3 2.6 3.3 2.6-4 1.3 2 3.7-4.1-.9.3 4.2-3.8-2.2L12 26l-2.2-3.6L6 24.6l.3-4.2-4.1.9 2-3.7-4-1.3L3.5 13.7.2 11.1l4-1.3-2-3.7 4.1.9L6 2.8l3.8 2.2z' },
  { id: 'heart', label: 'قلب', icon: 'M12 21S2 14.5 2 8.5A5.5 5.5 0 0 1 12 5a5.5 5.5 0 0 1 10 3.5C22 14.5 12 21 12 21z' },
  { id: 'arrow', label: 'سهم', icon: 'M2 9h12V4l8 8-8 8v-5H2z' },
  { id: 'chevron', label: 'شيفرون', icon: 'M2 2 14 12 2 22 10 12z M12 2l12 10-12 10 8-10z' },
  { id: 'speech', label: 'فقاعة كلام', icon: 'M4 3h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H9l-5 4V5a2 2 0 0 1 2-2z' },
  { id: 'ribbon', label: 'شريط', icon: 'M0 6h24v12H0l4-6z' },
  { id: 'cloud', label: 'سحابة', icon: 'M7 18a4.5 4.5 0 0 1-.5-9 6 6 0 0 1 11.4-1.3A4.5 4.5 0 0 1 18.5 18H7z' },
  { id: 'line', label: 'خط', icon: 'M2 11h20v2H2z' },
  { id: 'frame', label: 'إطار', icon: 'M3 3h18v18H3V3zm3 3v12h12V6H6z' },
  { id: 'tag', label: 'تاغ سعر', icon: 'M2 12V3h9l11 11-9 9L2 12zm4-4a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z' },
  { id: 'badge', label: 'شارة', icon: 'M12 1l2.6 2.2 3.3-.4 1.3 3.1 3.1 1.3-.4 3.3L24 13l-2.2 2.6.4 3.3-3.1 1.3-1.3 3.1-3.3-.4L12 25l-2.6-2.2-3.3.4-1.3-3.1-3.1-1.3.4-3.3L0 13l2.2-2.6-.4-3.3 3.1-1.3L6.2 2.7l3.3.4z' },
];

export const EMOJI_SETS = [
  { name: 'أعمال', items: ['💼', '📊', '📈', '💡', '🎯', '🚀', '⭐', '🏆', '💰', '🔥', '✅', '⚡', '📌', '🧩', '🛠️', '🔧', '📦', '🚚', '🏷️', '💳'] },
  { name: 'طعام', items: ['🍔', '🍕', '🍟', '🌮', '🥗', '🍜', '🍰', '🧁', '☕', '🥤', '🍓', '🍉', '🥐', '🍗', '🍤', '🥘', '🧃', '🍦'] },
  { name: 'رمضان وأعياد', items: ['🌙', '🕌', '🏮', '✨', '🌟', '🤲', '📿', '🥮', '🎉', '🎁', '🎊', '🪔', '❤️', '🌸'] },
  { name: 'سفر وسياحة', items: ['✈️', '🏖️', '🌊', '🏝️', '🧳', '🗺️', '🌅', '🚗', '🏨', '⛱️', '🐚', '🌴'] },
  { name: 'تقنية', items: ['💻', '📱', '🖥️', '⌨️', '🖱️', '🎧', '📷', '🎮', '🔌', '🛰️', '🤖', '🔒'] },
  { name: 'صحة', items: ['⚕️', '💊', '🩺', '🧪', '🏥', '💉', '🧴', '🦷', '❤️‍🩹', '🌿', '🥦', '🧘'] },
  { name: 'أسهم ورموز', items: ['➡️', '⬅️', '⬆️', '⬇️', '↗️', '↘️', '✔️', '❌', '❗', '❓', '🔴', '🟠', '🟡', '🟢', '🔵', '⚫', '⚪', '🟣'] },
  { name: 'وجوه', items: ['😀', '😍', '🤩', '😎', '🤔', '😴', '🙌', '👍', '👏', '💪', '🙏', '🤝'] },
];

export const GRADIENTS = [
  ['#667eea', '#764ba2'], ['#f093fb', '#f5576c'], ['#4facfe', '#00f2fe'], ['#43e97b', '#38f9d7'],
  ['#fa709a', '#fee140'], ['#30cfd0', '#330867'], ['#a8edea', '#fed6e3'], ['#ff9a9e', '#fecfef'],
  ['#ffecd2', '#fcb69f'], ['#5ee7df', '#b490ca'], ['#c471f5', '#fa71cd'], ['#0ba360', '#3cba92'],
  ['#1e3c72', '#2a5298'], ['#232526', '#414345'], ['#f83600', '#f9d423'], ['#0f2027', '#2c5364'],
  ['#ee0979', '#ff6a00'], ['#7f00ff', '#e100ff'], ['#11998e', '#38ef7d'], ['#fc466b', '#3f5efb'],
];

export const PALETTES = [
  { name: 'كلاسيك', colors: ['#0f172a', '#1e293b', '#f8fafc', '#e2e8f0', '#94a3b8', '#334155'] },
  { name: 'بنفسجي', colors: ['#2e1065', '#5b21b6', '#7c3aed', '#a78bfa', '#ddd6fe', '#f5f3ff'] },
  { name: 'ذهبي فاخر', colors: ['#1a1207', '#3f2d0f', '#b8860b', '#d4af37', '#f0d98c', '#fdf6e3'] },
  { name: 'بحري', colors: ['#042f2e', '#0f766e', '#14b8a6', '#5eead4', '#ccfbf1', '#f0fdfa'] },
  { name: 'ناري', colors: ['#450a0a', '#991b1b', '#dc2626', '#f97316', '#fdba74', '#fff7ed'] },
  { name: 'وردي', colors: ['#500724', '#9d174d', '#db2777', '#f472b6', '#fbcfe8', '#fdf2f8'] },
  { name: 'ترابي', colors: ['#292524', '#57534e', '#a8a29e', '#d6d3d1', '#f5f5f4', '#e7e5e4'] },
  { name: 'رمضاني', colors: ['#0b1d3a', '#123a63', '#1d5c8f', '#c9a227', '#e8c86a', '#f7ecc9'] },
];

export const PATTERNS = [
  { id: 'dots', label: 'نقاط', svg: (c1, c2) => svgWrap(`<rect width="40" height="40" fill="${c1}"/><circle cx="10" cy="10" r="3" fill="${c2}"/><circle cx="30" cy="30" r="3" fill="${c2}"/>`) },
  { id: 'stripes', label: 'خطوط', svg: (c1, c2) => svgWrap(`<rect width="40" height="40" fill="${c1}"/><path d="M0 40L40 0M-10 10L10 -10M30 50L50 30" stroke="${c2}" stroke-width="6"/>`) },
  { id: 'grid', label: 'شبكة', svg: (c1, c2) => svgWrap(`<rect width="40" height="40" fill="${c1}"/><path d="M40 0H0v40" fill="none" stroke="${c2}" stroke-width="1.5"/>`) },
  { id: 'chevron', label: 'شيفرون', svg: (c1, c2) => svgWrap(`<rect width="40" height="40" fill="${c1}"/><path d="M0 20L20 0l20 20M0 40L20 20l20 20" fill="none" stroke="${c2}" stroke-width="4"/>`) },
  { id: 'zigzag', label: 'زجزاج', svg: (c1, c2) => svgWrap(`<rect width="40" height="40" fill="${c1}"/><path d="M0 30l10-10 10 10 10-10 10 10" fill="none" stroke="${c2}" stroke-width="3"/>`) },
  { id: 'circles', label: 'دوائر', svg: (c1, c2) => svgWrap(`<rect width="60" height="60" fill="${c1}"/><circle cx="30" cy="30" r="16" fill="none" stroke="${c2}" stroke-width="3"/><circle cx="0" cy="0" r="10" fill="none" stroke="${c2}" stroke-width="3"/><circle cx="60" cy="60" r="10" fill="none" stroke="${c2}" stroke-width="3"/>`) },
  { id: 'islamic', label: 'زخرفة', svg: (c1, c2) => svgWrap(`<rect width="60" height="60" fill="${c1}"/><g fill="none" stroke="${c2}" stroke-width="1.6"><path d="M30 4l8 8 12-2-2 12 8 8-8 8 2 12-12-2-8 8-8-8-12 2 2-12-8-8 8-8-2-12 12 2z"/><circle cx="30" cy="30" r="9"/></g>`) },
  { id: 'waves', label: 'موج', svg: (c1, c2) => svgWrap(`<rect width="60" height="60" fill="${c1}"/><path d="M0 20c10-12 20 12 30 0s20-12 30 0M0 44c10-12 20 12 30 0s20-12 30 0" fill="none" stroke="${c2}" stroke-width="3"/>`) },
  { id: 'triangles', label: 'مثلثات', svg: (c1, c2) => svgWrap(`<rect width="48" height="48" fill="${c1}"/><path d="M24 6L42 42H6z" fill="none" stroke="${c2}" stroke-width="2.5"/>`) },
  { id: 'confetti', label: 'كونفيتي', svg: (c1, c2) => svgWrap(`<rect width="60" height="60" fill="${c1}"/><g fill="${c2}"><circle cx="10" cy="12" r="3"/><rect x="34" y="8" width="7" height="4" rx="2" transform="rotate(20 37 10)"/><circle cx="48" cy="38" r="2.5"/><rect x="12" y="40" width="8" height="4" rx="2" transform="rotate(-25 16 42)"/><circle cx="28" cy="28" r="2"/></g>`) },
];

function svgWrap(inner) {
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 60 60">${inner}</svg>`);
}

/* ------------------------- factories ------------------------- */

export function newFill(color) { return color || '#7c5cff'; }

export function makeLayer(type, over = {}) {
  const base = {
    id: uid('ly'),
    type,
    name: '',
    x: 100, y: 100, w: 300, h: 200, rot: 0,
    opacity: 1,
    visible: true,
    locked: false,
    fill: '#7c5cff',
    stroke: { color: '#000000', width: 0 },
    radius: 0,
    shadow: null,
    blend: 'source-over',
    filters: { brightness: 100, contrast: 100, saturate: 100, blur: 0, grayscale: 0, sepia: 0, hue: 0 },
    flipX: false, flipY: false,
  };
  if (type === 'text') {
    Object.assign(base, {
      text: 'نص جديد',
      fontFamily: 'Cairo', fontSize: 64, fontWeight: 700, italic: false,
      color: '#ffffff', align: 'center', lineHeight: 1.3, letterSpacing: 0,
      rtl: true, wrap: true, autoFit: false, padding: 0,
      textStroke: { color: '#000000', width: 0 },
      bgBox: false, bgBoxColor: '#000000', bgBoxOpacity: 0.5, bgBoxRadius: 12,
      w: 700, h: 120,
    });
  }
  if (type === 'image') {
    Object.assign(base, { src: '', fit: 'cover' });
  }
  if (type === 'shape') {
    Object.assign(base, { shape: 'rect', sides: 5 });
  }
  if (type === 'emoji') {
    Object.assign(base, { text: '⭐', fontSize: 160, w: 200, h: 200 });
  }
  return Object.assign(base, over);
}

export function makePage(w, h, bg) {
  return {
    id: uid('pg'),
    name: 'صفحة',
    w: w || 1080,
    h: h || 1080,
    bg: bg || { type: 'color', color: '#ffffff' },
    layers: [],
  };
}

export function makeDoc(title, w, h, bg) {
  return {
    id: null,
    title: title || 'تصميم بدون عنوان',
    pages: [makePage(w, h, bg)],
    meta: { createdAt: new Date().toISOString() },
  };
}

export function layerCenter(l) { return { cx: l.x + l.w / 2, cy: l.y + l.h / 2 }; }

export function cloneLayer(l) {
  return JSON.parse(JSON.stringify(l));
}

export function nextLayerName(layers, type) {
  const map = { text: 'نص', shape: 'شكل', image: 'صورة', emoji: 'ملصق' };
  const base = map[type] || 'عنصر';
  const n = layers.filter((l) => l.type === type).length + 1;
  return `${base} ${n}`;
}
