/* ============================================================
   MEEM | محرر التصميم — الخطوط
   ============================================================ */

export const FONTS = [
  { group: 'عربي / Arabic', list: ['Cairo', 'Tajawal', 'Almarai', 'Noto Kufi Arabic', 'El Messiri', 'Changa', 'Amiri', 'Aref Ruqaa', 'Reem Kufi', 'Lalezar', 'Rakkas', 'Marhey', 'Baloo Bhaijaan 2', 'Lemonada'] },
  { group: 'لاتيني / Latin', list: ['Poppins', 'Montserrat', 'Rubik', 'Playfair Display', 'Bebas Neue', 'Anton', 'Oswald', 'Righteous', 'Archivo Black', 'Abril Fatface', 'Space Grotesk'] },
  { group: 'يدوي / Script', list: ['Dancing Script', 'Pacifico', 'Great Vibes'] },
  { group: 'النظام / System', list: ['Arial', 'Tahoma', 'Georgia', 'Times New Roman', 'Verdana', 'Courier New', 'Impact', 'Segoe UI'] },
];

export const ALL_FONTS = FONTS.flatMap((g) => g.list);

/* ---------------- الخطوط المخصصة (رفع من الجهاز) ---------------- */
const CF_KEY = 'meem_custom_fonts';

export function getCustomFonts() {
  try { return JSON.parse(localStorage.getItem(CF_KEY) || '[]'); } catch (e) { return []; }
}

export async function loadCustomFonts() {
  for (const f of getCustomFonts()) {
    try {
      const face = new FontFace(f.name, `url(${f.url})`);
      await face.load();
      document.fonts.add(face);
    } catch (e) { /* تجاهل الخط التالف */ }
  }
}

export async function addCustomFont(file) {
  const name = file.name.replace(/\.[^.]+$/, '').slice(0, 40) || 'Custom Font';
  const dataURL = await new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
  const face = new FontFace(name, `url(${dataURL})`);
  await face.load();
  document.fonts.add(face);
  const list = getCustomFonts().filter((f) => f.name !== name);
  list.unshift({ name, url: dataURL });
  try { localStorage.setItem(CF_KEY, JSON.stringify(list.slice(0, 10))); } catch (e) { /* المساحة ممتلئة — الخط شغال للجلسة الحالية */ }
  return name;
}

export const FONT_FALLBACK = ", 'Noto Sans Arabic', 'Segoe UI', Tahoma, Arial, sans-serif";

export function cssFont(layer) {
  const style = layer.italic ? 'italic ' : '';
  return `${style}${layer.fontWeight || 400} ${layer.fontSize}px "${layer.fontFamily}"${FONT_FALLBACK}`;
}

/** يتأكد إن الخط محمّل قبل الرسم/التصدير */
export async function ensureFont(family, weight = 400) {
  try {
    if (document.fonts && document.fonts.load) {
      await document.fonts.load(`${weight} 48px "${family}"`);
      await document.fonts.load(`${weight} 48px "${family}"`, 'بسم الله الرحمن الرحيم ABCabc 123');
    }
  } catch (e) { /* ignore */ }
}

export async function ensureFonts(layers) {
  const set = new Set();
  (layers || []).forEach((l) => { if (l.type === 'text' && l.fontFamily) set.add(l.fontFamily + '|' + (l.fontWeight || 400)); });
  await Promise.all([...set].map((s) => { const [f, w] = s.split('|'); return ensureFont(f, w); }));
}

export function fontOptionsHTML(selected) {
  const custom = getCustomFonts();
  const groups = custom.length
    ? [{ group: 'خطوطي المرفوعة / My Fonts', list: custom.map((f) => f.name) }, ...FONTS]
    : FONTS;
  return groups.map((g) =>
    `<optgroup label="${g.group}">` +
    g.list.map((f) => `<option value="${f}" ${f === selected ? 'selected' : ''} style="font-family:'${f}'">${f}</option>`).join('') +
    `</optgroup>`
  ).join('');
}
