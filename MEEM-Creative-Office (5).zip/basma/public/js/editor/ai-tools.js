/* ============================================================
   MEEM — Phase 7: AI Tools (معالجة محلية حقيقية على Canvas)
   بدائل محلية لأدوات الصور + مولد خلفيات + مولد Layouts
   مع مفتاح Pro تبقى الجودة أعلى عبر /api/ai
   ============================================================ */

function hashStr(s) {
  let h = 2166136261;
  for (let i = 0; i < String(s).length; i++) { h ^= String(s).charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

function loadImg(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    if (!String(src).startsWith('data:')) img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('صورة مش صالحة'));
    img.src = src;
  });
}

/* ---------------- معالجة الصور ---------------- */
export async function processImage(src, kind) {
  const img = await loadImg(src);
  const w = img.naturalWidth, h = img.naturalHeight;
  const c = document.createElement('canvas');

  if (kind === 'upscale') {
    c.width = w * 2; c.height = h * 2;
    const x = c.getContext('2d');
    x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high';
    x.drawImage(img, 0, 0, c.width, c.height);
    return c.toDataURL('image/png');
  }

  c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  ctx.drawImage(img, 0, 0);
  const d = ctx.getImageData(0, 0, w, h);
  const p = d.data;

  if (kind === 'enhance') {
    for (let i = 0; i < p.length; i += 4) {
      for (let k = 0; k < 3; k++) { const v = (p[i + k] - 128) * 1.28 + 128; p[i + k] = Math.max(0, Math.min(255, v)); }
      const g = (p[i] + p[i + 1] + p[i + 2]) / 3;
      for (let k = 0; k < 3; k++) p[i + k] = Math.max(0, Math.min(255, g + (p[i + k] - g) * 1.35));
    }
  } else if (kind === 'retouch') {
    const s = new Uint8ClampedArray(p);
    for (let y = 1; y < h - 1; y++) {
      for (let x2 = 1; x2 < w - 1; x2++) {
        const i = (y * w + x2) * 4;
        for (let k = 0; k < 3; k++) {
          const sum = s[i - 4 + k] + s[i + 4 + k] + s[i - w * 4 + k] + s[i + w * 4 + k] + s[i + k] * 2;
          const v = (sum / 6 - 128) * 1.04 + 132;
          p[i + k] = Math.max(0, Math.min(255, v));
        }
      }
    }
  } else if (kind === 'colorize') {
    const hsh = hashStr('meem-colorize');
    const c1 = [hsh % 110 + 15, (hsh >> 8) % 90 + 50, (hsh >> 16) % 130 + 70];
    const c2 = [(hsh >> 4) % 70 + 175, (hsh >> 12) % 60 + 185, (hsh >> 20) % 55 + 200];
    for (let i = 0; i < p.length; i += 4) {
      const g = (p[i] * 0.3 + p[i + 1] * 0.59 + p[i + 2] * 0.11) / 255;
      for (let k = 0; k < 3; k++) p[i + k] = Math.round(c1[k] + (c2[k] - c1[k]) * g);
    }
  } else if (kind === 'removebg') {
    // Flood fill من الحواف بلون مشابه — شغال مع الخلفيات السادة
    const tol = 105; // مجموع فوارق RGB
    const idx = (x2, y) => y * w + x2;
    const px = (i) => [p[i * 4], p[i * 4 + 1], p[i * 4 + 2]];
    const refs = [px(idx(0, 0)), px(idx(w - 1, 0)), px(idx(0, h - 1)), px(idx(w - 1, h - 1))];
    const match = (i) => { const [r, g, b] = px(i); return refs.some((q) => Math.abs(q[0] - r) + Math.abs(q[1] - g) + Math.abs(q[2] - b) < tol); };
    const visited = new Uint8Array(w * h);
    const stack = [];
    for (let x2 = 0; x2 < w; x2++) { stack.push(idx(x2, 0)); stack.push(idx(x2, h - 1)); }
    for (let y = 0; y < h; y++) { stack.push(idx(0, y)); stack.push(idx(w - 1, y)); }
    while (stack.length) {
      const i = stack.pop();
      if (visited[i]) continue;
      if (!match(i)) continue;
      visited[i] = 1;
      p[i * 4 + 3] = 0;
      const x2 = i % w, y = (i / w) | 0;
      if (x2 > 0) stack.push(i - 1);
      if (x2 < w - 1) stack.push(i + 1);
      if (y > 0) stack.push(i - w);
      if (y < h - 1) stack.push(i + w);
    }
  }

  ctx.putImageData(d, 0, 0);
  return c.toDataURL('image/png');
}

/* ---------------- مولد خلفيات/صور (محلي) ---------------- */
export function generateArt(prompt, W = 1024, H = 1024) {
  const hsh = hashStr(prompt || 'meem') || 1;
  let s = hsh;
  const rnd = () => { s = (Math.imul(s, 1664525) + 1013904223) >>> 0; return s / 4294967296; };
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const ctx = c.getContext('2d');
  const hue = Math.floor(rnd() * 360);
  const g = ctx.createLinearGradient(0, 0, W, H);
  g.addColorStop(0, `hsl(${hue},72%,22%)`);
  g.addColorStop(1, `hsl(${(hue + 55) % 360},76%,52%)`);
  ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  for (let i = 0; i < 16; i++) {
    const x = rnd() * W, y = rnd() * H, r = 50 + rnd() * 280;
    const rg = ctx.createRadialGradient(x, y, 0, x, y, r);
    rg.addColorStop(0, `hsla(${(hue + rnd() * 140) % 360},85%,65%,${0.1 + rnd() * 0.22})`);
    rg.addColorStop(1, 'hsla(0,0%,0%,0)');
    ctx.fillStyle = rg;
    ctx.beginPath(); ctx.arc(x, y, r, 0, Math.PI * 2); ctx.fill();
  }
  ctx.strokeStyle = `hsla(${(hue + 180) % 360},90%,85%,0.22)`;
  ctx.lineWidth = 6;
  for (let i = 0; i < 6; i++) {
    ctx.beginPath();
    ctx.moveTo(rnd() * W, rnd() * H);
    ctx.bezierCurveTo(rnd() * W, rnd() * H, rnd() * W, rnd() * H, rnd() * W, rnd() * H);
    ctx.stroke();
  }
  return c.toDataURL('image/jpeg', 0.9);
}

/* ---------------- مولد Layouts (3 اقتراحات) ---------------- */
export function designLayouts(prompt, palette, W, H) {
  const [p1, p2, p3] = palette;
  const title = String(prompt || '').trim().split(/[،,.]/)[0].slice(0, 60) || 'عنوان الحملة';
  const T = (over) => Object.assign({ type: 'text', text: title, fontFamily: 'Cairo', fontWeight: 900, align: 'center', rtl: true, wrap: true }, over);
  return [
    { name: 'مركزي', bg: { type: 'color', color: p3 }, add: [
      { type: 'shape', shape: 'rect', fill: p1, x: 0, y: Math.round(H - 140), w: W, h: 140, opacity: 0.92 },
      T({ color: '#ffffff', x: Math.round(W * 0.1), y: Math.round(H * 0.34), w: Math.round(W * 0.8), h: Math.round(H * 0.2), fontSize: Math.round(W / 9) }),
      { type: 'text', text: 'اعرف أكتر 👇', color: '#ffffff', fontSize: Math.round(W / 22), fontWeight: 700, align: 'center', rtl: true, wrap: true, fontFamily: 'Cairo', x: Math.round(W * 0.1), y: Math.round(H - 118), w: Math.round(W * 0.8), h: 92 },
    ] },
    { name: 'مقسوم', bg: { type: 'color', color: '#ffffff' }, add: [
      { type: 'shape', shape: 'rect', fill: p1, x: 0, y: 0, w: W, h: Math.round(H * 0.55) },
      T({ color: '#ffffff', x: Math.round(W * 0.08), y: Math.round(H * 0.17), w: Math.round(W * 0.84), h: Math.round(H * 0.26), fontSize: Math.round(W / 10) }),
      { type: 'text', text: 'عرض لفترة محدودة', color: p3, fontSize: Math.round(W / 18), fontWeight: 700, align: 'center', rtl: true, wrap: true, fontFamily: 'Cairo', x: Math.round(W * 0.08), y: Math.round(H * 0.62), w: Math.round(W * 0.84), h: Math.round(H * 0.12) },
      { type: 'shape', shape: 'rect', fill: p2, radius: 40, x: Math.round(W * 0.3), y: Math.round(H * 0.79), w: Math.round(W * 0.4), h: Math.round(H * 0.09) },
      { type: 'text', text: 'اطلب دلوقتي', color: '#ffffff', fontSize: Math.round(W / 24), fontWeight: 800, align: 'center', rtl: true, wrap: true, fontFamily: 'Cairo', x: Math.round(W * 0.3), y: Math.round(H * 0.805), w: Math.round(W * 0.4), h: Math.round(H * 0.06) },
    ] },
    { name: 'بانر علوي', bg: { type: 'color', color: p2 }, add: [
      { type: 'shape', shape: 'rect', fill: p3, x: 0, y: 0, w: W, h: Math.round(H * 0.22) },
      { type: 'text', text: 'MEEM', color: '#ffffff', fontSize: Math.round(W / 20), fontWeight: 900, align: 'center', rtl: true, wrap: true, fontFamily: 'Cairo', x: Math.round(W * 0.35), y: Math.round(H * 0.06), w: Math.round(W * 0.3), h: Math.round(H * 0.1) },
      T({ color: p3, x: Math.round(W * 0.08), y: Math.round(H * 0.4), w: Math.round(W * 0.84), h: Math.round(H * 0.26), fontSize: Math.round(W / 11) }),
    ] },
  ];
}
