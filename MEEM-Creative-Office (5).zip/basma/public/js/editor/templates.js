/* ============================================================
   MEEM | محرر التصميم — القوالب الجاهزة
   ============================================================ */
import { makeLayer, makePage, PAGE_PRESETS } from './model.js';

const T = (over) => makeLayer('text', over);
const S = (shape, over) => makeLayer('shape', Object.assign({ shape }, over));
const I = (over) => makeLayer('image', over);

const G = (a, b, angle = 135) => ({ type: 'linear', angle, stops: [{ c: a, at: 0 }, { c: b, at: 1 }] });

export const TEMPLATES = [
  {
    id: 'tpl_ramadan_offer',
    name: 'عرض إفطار رمضان',
    cat: 'سوشيال',
    w: 1080, h: 1080,
    build: () => ({
      bg: { type: 'gradient', angle: 160, stops: [{ c: '#0b1d3a', at: 0 }, { c: '#123a63', at: 0.55 }, { c: '#1d5c8f', at: 1 }] },
      layers: [
        S('star5', { x: 70, y: 60, w: 130, h: 130, fill: '#c9a227', opacity: .9 }),
        S('star5', { x: 900, y: 120, w: 70, h: 70, fill: '#e8c86a', opacity: .7 }),
        S('star5', { x: 860, y: 850, w: 90, h: 90, fill: '#c9a227', opacity: .5 }),
        S('ellipse', { x: 150, y: 700, w: 500, h: 500, fill: G('#c9a227', '#e8c86a'), opacity: .07 }),
        T({ x: 90, y: 250, w: 900, h: 90, text: 'مطاعم زهرة اللوتس', fontFamily: 'Tajawal', fontSize: 44, fontWeight: 500, color: '#e8c86a', align: 'center' }),
        T({ x: 60, y: 350, w: 960, h: 180, text: 'عرض إفطار رمضان', fontFamily: 'Cairo', fontSize: 108, fontWeight: 900, color: '#ffffff', align: 'center' }),
        T({ x: 140, y: 560, w: 800, h: 70, text: 'وجبة عائلية كاملة + مشروبات + حلو', fontFamily: 'Almarai', fontSize: 40, fontWeight: 400, color: '#dbeafe', align: 'center' }),
        S('roundrect', { x: 300, y: 680, w: 480, h: 170, radius: 85, fill: G('#c9a227', '#f0d98c'), shadow: { color: 'rgba(201,162,39,.5)', blur: 40, x: 0, y: 12 } }),
        T({ x: 300, y: 705, w: 480, h: 70, text: '٢٩٩ جنيه فقط', fontFamily: 'Cairo', fontSize: 60, fontWeight: 900, color: '#0b1d3a', align: 'center' }),
        T({ x: 300, y: 785, w: 480, h: 50, text: 'العرض ساري طوال الشهر', fontFamily: 'Tajawal', fontSize: 28, fontWeight: 500, color: '#3f2d0f', align: 'center' }),
        T({ x: 140, y: 940, w: 800, h: 60, text: 'للحجز: ١٩٠٠٠  |  زهرة اللوتس — القاهرة', fontFamily: 'Almarai', fontSize: 30, fontWeight: 400, color: '#93c5fd', align: 'center' }),
      ],
    }),
  },
  {
    id: 'tpl_sale',
    name: 'خصم كبير',
    cat: 'سوشيال',
    w: 1080, h: 1080,
    build: () => ({
      bg: { type: 'gradient', angle: 120, stops: [{ c: '#f83600', at: 0 }, { c: '#f9d423', at: 1 }] },
      layers: [
        S('burst', { x: 540, y: 300, w: 620, h: 620, fill: 'rgba(255,255,255,.16)', sides: 16 }),
        T({ x: 90, y: 120, w: 900, h: 90, text: 'تخفيضات نهاية الموسم', fontFamily: 'Cairo', fontSize: 52, fontWeight: 800, color: '#fff', align: 'center' }),
        T({ x: 40, y: 330, w: 1000, h: 300, text: '50%', fontFamily: 'Archivo Black', fontSize: 300, fontWeight: 400, color: '#ffffff', align: 'center', rtl: false, textStroke: { color: '#7c2d12', width: 10 } }),
        T({ x: 90, y: 620, w: 900, h: 90, text: 'خصم على كل المجموعة', fontFamily: 'Tajawal', fontSize: 56, fontWeight: 700, color: '#fff7ed', align: 'center' }),
        S('roundrect', { x: 320, y: 780, w: 440, h: 130, radius: 65, fill: '#1a1207' }),
        T({ x: 320, y: 812, w: 440, h: 70, text: 'اشتري الآن', fontFamily: 'Cairo', fontSize: 46, fontWeight: 800, color: '#f9d423', align: 'center' }),
      ],
    }),
  },
  {
    id: 'tpl_new_product',
    name: 'إطلاق منتج',
    cat: 'سوشيال',
    w: 1080, h: 1350,
    build: () => ({
      bg: { type: 'color', color: '#0f172a' },
      layers: [
        S('ellipse', { x: -200, y: -200, w: 700, h: 700, fill: G('#7c3aed', '#22d3ee'), opacity: .35 }),
        S('ellipse', { x: 700, y: 900, w: 600, h: 600, fill: G('#22d3ee', '#7c3aed'), opacity: .28 }),
        S('roundrect', { x: 140, y: 380, w: 800, h: 560, radius: 40, fill: 'rgba(255,255,255,.06)', stroke: { color: 'rgba(255,255,255,.18)', width: 2 } }),
        T({ x: 140, y: 250, w: 800, h: 70, text: 'NEW ARRIVAL', fontFamily: 'Space Grotesk', fontSize: 34, fontWeight: 700, color: '#22d3ee', align: 'center', rtl: false, letterSpacing: 8 }),
        T({ x: 90, y: 480, w: 900, h: 160, text: 'المنتج الجديد\nوصل أخيرًا', fontFamily: 'Cairo', fontSize: 84, fontWeight: 900, color: '#fff', align: 'center' }),
        T({ x: 190, y: 700, w: 700, h: 120, text: 'تصميم عصري، جودة عالية، وسعر يناسب الجميع. اطلبه الآن قبل نفاذ الكمية.', fontFamily: 'Almarai', fontSize: 36, fontWeight: 400, color: '#cbd5e1', align: 'center' }),
        S('roundrect', { x: 340, y: 1010, w: 400, h: 120, radius: 60, fill: G('#7c3aed', '#22d3ee') }),
        T({ x: 340, y: 1040, w: 400, h: 60, text: 'اطلب الآن', fontFamily: 'Cairo', fontSize: 42, fontWeight: 800, color: '#fff', align: 'center' }),
        T({ x: 140, y: 1180, w: 800, h: 60, text: 'www.yourbrand.com', fontFamily: 'Poppins', fontSize: 30, fontWeight: 500, color: '#94a3b8', align: 'center', rtl: false }),
      ],
    }),
  },
  {
    id: 'tpl_story_countdown',
    name: 'ستوري عد تنازلي',
    cat: 'سوشيال',
    w: 1080, h: 1920,
    build: () => ({
      bg: { type: 'gradient', angle: 180, stops: [{ c: '#450a0a', at: 0 }, { c: '#991b1b', at: 0.6 }, { c: '#dc2626', at: 1 }] },
      layers: [
        S('ellipse', { x: 140, y: 420, w: 800, h: 800, fill: 'rgba(255,255,255,.08)' }),
        T({ x: 90, y: 200, w: 900, h: 70, text: 'العرض بيخلص خلال', fontFamily: 'Tajawal', fontSize: 44, fontWeight: 500, color: '#fecaca', align: 'center' }),
        T({ x: 40, y: 300, w: 1000, h: 220, text: '٣ أيام', fontFamily: 'Cairo', fontSize: 200, fontWeight: 900, color: '#fff', align: 'center' }),
        S('roundrect', { x: 120, y: 620, w: 250, h: 250, radius: 30, fill: 'rgba(255,255,255,.12)', stroke: { color: 'rgba(255,255,255,.3)', width: 3 } }),
        T({ x: 120, y: 690, w: 250, h: 120, text: '٢٣', fontFamily: 'Cairo', fontSize: 96, fontWeight: 800, color: '#fff', align: 'center' }),
        T({ x: 120, y: 810, w: 250, h: 50, text: 'ساعة', fontFamily: 'Almarai', fontSize: 30, color: '#fecaca', align: 'center' }),
        S('roundrect', { x: 415, y: 620, w: 250, h: 250, radius: 30, fill: 'rgba(255,255,255,.12)', stroke: { color: 'rgba(255,255,255,.3)', width: 3 } }),
        T({ x: 415, y: 690, w: 250, h: 120, text: '٤٥', fontFamily: 'Cairo', fontSize: 96, fontWeight: 800, color: '#fff', align: 'center' }),
        T({ x: 415, y: 810, w: 250, h: 50, text: 'دقيقة', fontFamily: 'Almarai', fontSize: 30, color: '#fecaca', align: 'center' }),
        S('roundrect', { x: 710, y: 620, w: 250, h: 250, radius: 30, fill: 'rgba(255,255,255,.12)', stroke: { color: 'rgba(255,255,255,.3)', width: 3 } }),
        T({ x: 710, y: 690, w: 250, h: 120, text: '١٢', fontFamily: 'Cairo', fontSize: 96, fontWeight: 800, color: '#fff', align: 'center' }),
        T({ x: 710, y: 810, w: 250, h: 50, text: 'ثانية', fontFamily: 'Almarai', fontSize: 30, color: '#fecaca', align: 'center' }),
        T({ x: 140, y: 1050, w: 800, h: 200, text: 'اسحب لأعلى\nواستفد بالخصم', fontFamily: 'Cairo', fontSize: 72, fontWeight: 900, color: '#fff', align: 'center' }),
        S('arrow', { x: 440, y: 1330, w: 200, h: 200, fill: '#fff', rot: 270 }),
      ],
    }),
  },
  {
    id: 'tpl_yt_thumb',
    name: 'غلاف يوتيوب',
    cat: 'سوشيال',
    w: 1280, h: 720,
    build: () => ({
      bg: { type: 'gradient', angle: 100, stops: [{ c: '#111827', at: 0 }, { c: '#1e3a8a', at: 1 }] },
      layers: [
        S('ellipse', { x: 850, y: -120, w: 520, h: 520, fill: G('#f59e0b', '#ef4444'), opacity: .5 }),
        S('rect', { x: 60, y: 560, w: 500, h: 12, fill: '#f59e0b' }),
        T({ x: 60, y: 150, w: 780, h: 220, text: 'كيف تبدأ\nمشروعك الخاص', fontFamily: 'Cairo', fontSize: 92, fontWeight: 900, color: '#ffffff', align: 'left', textStroke: { color: '#0b1220', width: 8 } }),
        S('roundrect', { x: 60, y: 400, w: 330, h: 90, radius: 45, fill: '#f59e0b' }),
        T({ x: 60, y: 421, w: 330, h: 50, text: 'الحلقة 12', fontFamily: 'Cairo', fontSize: 38, fontWeight: 800, color: '#111827', align: 'center' }),
        S('ellipse', { x: 980, y: 250, w: 250, h: 250, fill: G('#22d3ee', '#3b82f6'), stroke: { color: '#fff', width: 6 } }),
        T({ x: 980, y: 330, w: 250, h: 90, text: '🎬', type: 'emoji', fontSize: 120 }),
      ],
    }),
  },
  {
    id: 'tpl_flyer_a5',
    name: 'فلاير A5 — خدمات',
    cat: 'مطبوعات',
    w: 1748, h: 2480,
    build: () => ({
      bg: { type: 'color', color: '#ffffff' },
      layers: [
        S('rect', { x: 0, y: 0, w: 1748, h: 760, fill: G('#042f2e', '#0f766e', 135) }),
        S('ellipse', { x: 1200, y: -200, w: 700, h: 700, fill: 'rgba(255,255,255,.08)' }),
        T({ x: 120, y: 150, w: 1500, h: 90, text: 'منتجع البحاري', fontFamily: 'El Messiri', fontSize: 62, fontWeight: 600, color: '#99f6e4', align: 'right' }),
        T({ x: 120, y: 250, w: 1500, h: 260, text: 'صيف ٢٠٢٦\nباقات إقامة مميزة', fontFamily: 'Cairo', fontSize: 130, fontWeight: 900, color: '#ffffff', align: 'right' }),
        T({ x: 120, y: 560, w: 1500, h: 90, text: 'شاطئ خاص · مسابح · أنشطة عائلية', fontFamily: 'Almarai', fontSize: 52, fontWeight: 400, color: '#ccfbf1', align: 'right' }),
        T({ x: 120, y: 880, w: 1500, h: 80, text: 'ماذا نقدم؟', fontFamily: 'Cairo', fontSize: 66, fontWeight: 800, color: '#0f766e', align: 'right' }),
        S('rect', { x: 1400, y: 985, w: 220, h: 10, fill: '#0f766e' }),
        T({ x: 120, y: 1030, w: 1500, h: 520, text: 'غرف وأجنحة بإطلالة بحرية مباشرة\nمطاعم تقدم أشهى المأكولات البحرية\nنادي صحي وسبا على أعلى مستوى\nأنشطة مائية للأطفال والكبار\nخدمة انتقالات من المطار', fontFamily: 'Tajawal', fontSize: 54, fontWeight: 400, color: '#334155', align: 'right', lineHeight: 1.9 }),
        S('roundrect', { x: 120, y: 1750, w: 1508, h: 260, radius: 30, fill: '#f0fdfa', stroke: { color: '#99f6e4', width: 3 } }),
        T({ x: 180, y: 1800, w: 1390, h: 80, text: 'احجز الآن واستمتع بخصم ٢٥٪', fontFamily: 'Cairo', fontSize: 62, fontWeight: 800, color: '#0f766e', align: 'right' }),
        T({ x: 180, y: 1890, w: 1390, h: 70, text: '٠١٠٠ ٠٠٠ ٠٠٠٠  |  bahary-resort.com', fontFamily: 'Almarai', fontSize: 46, fontWeight: 400, color: '#475569', align: 'right', rtl: false }),
        S('rect', { x: 0, y: 2360, w: 1748, h: 120, fill: '#042f2e' }),
        T({ x: 120, y: 2392, w: 1500, h: 60, text: 'الساحل الشمالي — الكيلو ٧٥', fontFamily: 'Tajawal', fontSize: 42, fontWeight: 500, color: '#99f6e4', align: 'right' }),
      ],
    }),
  },
  {
    id: 'tpl_card',
    name: 'كارت شخصي',
    cat: 'مطبوعات',
    w: 1063, h: 591,
    build: () => ({
      bg: { type: 'color', color: '#0f172a' },
      layers: [
        S('rect', { x: 0, y: 0, w: 14, h: 591, fill: G('#7c5cff', '#22d3ee', 90) }),
        S('ellipse', { x: 780, y: -180, w: 460, h: 460, fill: 'rgba(124,92,255,.22)' }),
        T({ x: 90, y: 100, w: 880, h: 90, text: 'سارة حسن', fontFamily: 'Cairo', fontSize: 62, fontWeight: 800, color: '#ffffff', align: 'left' }),
        T({ x: 90, y: 195, w: 880, h: 55, text: 'مصممة جرافيك أولى', fontFamily: 'Tajawal', fontSize: 34, fontWeight: 400, color: '#a5b4fc', align: 'left' }),
        S('rect', { x: 90, y: 290, w: 200, h: 5, fill: '#22d3ee' }),
        T({ x: 90, y: 330, w: 880, h: 50, text: '+20 100 000 0000', fontFamily: 'Poppins', fontSize: 30, fontWeight: 500, color: '#cbd5e1', align: 'left', rtl: false }),
        T({ x: 90, y: 395, w: 880, h: 50, text: 'hello@meem.studio', fontFamily: 'Poppins', fontSize: 30, fontWeight: 500, color: '#cbd5e1', align: 'left', rtl: false }),
        T({ x: 90, y: 460, w: 880, h: 50, text: 'meem.studio', fontFamily: 'Poppins', fontSize: 30, fontWeight: 500, color: '#94a3b8', align: 'left', rtl: false }),
      ],
    }),
  },
  {
    id: 'tpl_eid',
    name: 'تهنئة عيد',
    cat: 'سوشيال',
    w: 1080, h: 1080,
    build: () => ({
      bg: { type: 'gradient', angle: 180, stops: [{ c: '#1a1207', at: 0 }, { c: '#3f2d0f', at: 0.6 }, { c: '#b8860b', at: 1 }] },
      layers: [
        S('star5', { x: 120, y: 120, w: 90, h: 90, fill: '#f0d98c', opacity: .8 }),
        S('star5', { x: 880, y: 180, w: 60, h: 60, fill: '#f0d98c', opacity: .6 }),
        S('star5', { x: 200, y: 830, w: 70, h: 70, fill: '#f0d98c', opacity: .5 }),
        S('star5', { x: 830, y: 790, w: 110, h: 110, fill: '#f0d98c', opacity: .7 }),
        S('ellipse', { x: 240, y: 240, w: 600, h: 600, fill: 'none', stroke: { color: '#d4af37', width: 4 } }),
        S('ellipse', { x: 280, y: 280, w: 520, h: 520, fill: 'none', stroke: { color: 'rgba(212,175,55,.5)', width: 2 } }),
        T({ x: 90, y: 380, w: 900, h: 130, text: 'عيد مبارك', fontFamily: 'Aref Ruqaa', fontSize: 120, fontWeight: 700, color: '#f7ecc9', align: 'center' }),
        T({ x: 140, y: 560, w: 800, h: 90, text: 'كل عام وأنتم بخير', fontFamily: 'Amiri', fontSize: 56, fontWeight: 400, color: '#e8c86a', align: 'center' }),
        T({ x: 140, y: 900, w: 800, h: 60, text: 'MEEM | Creative Office', fontFamily: 'Tajawal', fontSize: 32, fontWeight: 500, color: '#d4af37', align: 'center', rtl: false }),
      ],
    }),
  },
  {
    id: 'tpl_course',
    name: 'دورة تدريبية',
    cat: 'سوشيال',
    w: 1080, h: 1350,
    build: () => ({
      bg: { type: 'color', color: '#f8fafc' },
      layers: [
        S('rect', { x: 0, y: 0, w: 1080, h: 460, fill: G('#5b21b6', '#7c3aed', 120) }),
        S('ellipse', { x: -140, y: 240, w: 420, h: 420, fill: 'rgba(255,255,255,.1)' }),
        T({ x: 90, y: 110, w: 900, h: 60, text: 'ONLINE COURSE', fontFamily: 'Space Grotesk', fontSize: 30, fontWeight: 700, color: '#ddd6fe', align: 'center', rtl: false, letterSpacing: 6 }),
        T({ x: 60, y: 190, w: 960, h: 200, text: 'احترف تصميم\nالسوشيال ميديا', fontFamily: 'Cairo', fontSize: 88, fontWeight: 900, color: '#fff', align: 'center' }),
        S('roundrect', { x: 340, y: 520, w: 400, h: 110, radius: 55, fill: '#7c3aed' }),
        T({ x: 340, y: 548, w: 400, h: 60, text: '١٢ ساعة تدريب', fontFamily: 'Cairo', fontSize: 38, fontWeight: 700, color: '#fff', align: 'center' }),
        T({ x: 140, y: 700, w: 800, h: 320, text: '• أساسيات التصميم والهوية البصرية\n• أدوات التصميم العملية\n• تصميم بوستات احترافية\n• بناء بورتفوليو قوي', fontFamily: 'Tajawal', fontSize: 44, fontWeight: 500, color: '#334155', align: 'right', lineHeight: 1.9 }),
        S('rect', { x: 90, y: 1080, w: 900, h: 3, fill: '#e2e8f0' }),
        T({ x: 140, y: 1120, w: 800, h: 70, text: 'يبدأ ١ أكتوبر', fontFamily: 'Cairo', fontSize: 48, fontWeight: 800, color: '#5b21b6', align: 'center' }),
        T({ x: 140, y: 1210, w: 800, h: 60, text: 'سجّل الآن — المقاعد محدودة', fontFamily: 'Almarai', fontSize: 36, fontWeight: 400, color: '#64748b', align: 'center' }),
      ],
    }),
  },
  {
    id: 'tpl_menu',
    name: 'منيو مطعم',
    cat: 'مطبوعات',
    w: 2480, h: 3508,
    build: () => ({
      bg: { type: 'color', color: '#fdf6e3' },
      layers: [
        S('rect', { x: 60, y: 60, w: 2360, h: 3388, fill: 'none', stroke: { color: '#b8860b', width: 8 } }),
        S('rect', { x: 100, y: 100, w: 2280, h: 3308, fill: 'none', stroke: { color: 'rgba(184,134,11,.4)', width: 3 } }),
        T({ x: 240, y: 260, w: 2000, h: 160, text: 'قائمة الطعام', fontFamily: 'Aref Ruqaa', fontSize: 150, fontWeight: 700, color: '#3f2d0f', align: 'center' }),
        S('rect', { x: 940, y: 470, w: 600, h: 6, fill: '#b8860b' }),
        T({ x: 240, y: 620, w: 2000, h: 100, text: 'المقبلات', fontFamily: 'El Messiri', fontSize: 88, fontWeight: 600, color: '#b8860b', align: 'center' }),
        T({ x: 300, y: 780, w: 1880, h: 400, text: 'حمص بالزيت ...................................... ٤٥\nمتبل باذنجان .................................... ٥٠\nورق عنب .......................................... ٥٥\nفتة حمص ........................................... ٦٠', fontFamily: 'Tajawal', fontSize: 62, fontWeight: 400, color: '#3f2d0f', align: 'right', lineHeight: 2.0 }),
        T({ x: 240, y: 1280, w: 2000, h: 100, text: 'الأطباق الرئيسية', fontFamily: 'El Messiri', fontSize: 88, fontWeight: 600, color: '#b8860b', align: 'center' }),
        T({ x: 300, y: 1440, w: 1880, h: 500, text: 'مشاوي مشكلة .................................... ٢٢٠\nكفتة بالصينية ..................................... ١٨٠\nفراخ مشوية ........................................ ١٦٠\nسمك بلطي مشوي ................................. ٢٤٠', fontFamily: 'Tajawal', fontSize: 62, fontWeight: 400, color: '#3f2d0f', align: 'right', lineHeight: 2.0 }),
        T({ x: 240, y: 3260, w: 2000, h: 80, text: 'الأسعار شاملة الضريبة — زهرة اللوتس', fontFamily: 'Almarai', fontSize: 48, fontWeight: 400, color: '#8a6d1f', align: 'center' }),
      ],
    }),
  },
  {
    id: 'tpl_logo',
    name: 'شعار — عرض موك أب',
    cat: 'براندينج',
    w: 1200, h: 1200,
    build: () => ({
      bg: { type: 'color', color: '#ffffff' },
      layers: [
        S('ellipse', { x: 250, y: 250, w: 700, h: 700, fill: G('#7c5cff', '#22d3ee', 135) }),
        T({ x: 250, y: 400, w: 700, h: 400, text: 'ب', fontFamily: 'Cairo', fontSize: 460, fontWeight: 900, color: '#ffffff', align: 'center' }),
        T({ x: 150, y: 1000, w: 900, h: 100, text: 'MEEM', fontFamily: 'Cairo', fontSize: 76, fontWeight: 800, color: '#0f172a', align: 'center', rtl: false }),
        T({ x: 150, y: 1100, w: 900, h: 60, text: 'CREATIVE PRODUCTION STUDIO', fontFamily: 'Space Grotesk', fontSize: 32, fontWeight: 500, color: '#64748b', align: 'center', rtl: false, letterSpacing: 4 }),
      ],
    }),
  },
  {
    id: 'tpl_hiring',
    name: 'إعلان توظيف',
    cat: 'سوشيال',
    w: 1080, h: 1080,
    build: () => ({
      bg: { type: 'gradient', angle: 135, stops: [{ c: '#042f2e', at: 0 }, { c: '#0f766e', at: 1 }] },
      layers: [
        S('roundrect', { x: 140, y: 140, w: 800, h: 800, radius: 40, fill: 'rgba(255,255,255,.07)', stroke: { color: 'rgba(255,255,255,.2)', width: 3 } }),
        T({ x: 140, y: 230, w: 800, h: 90, text: 'WE ARE HIRING', fontFamily: 'Bebas Neue', fontSize: 62, fontWeight: 400, color: '#5eead4', align: 'center', rtl: false, letterSpacing: 6 }),
        T({ x: 100, y: 340, w: 880, h: 200, text: 'مطلوب مصمم\nجرافيك', fontFamily: 'Cairo', fontSize: 110, fontWeight: 900, color: '#fff', align: 'center' }),
        T({ x: 200, y: 620, w: 680, h: 200, text: 'خبرة سنة على الأقل\nإتقان Photoshop و Illustrator\nالعمل من المكتب — دمنهور', fontFamily: 'Tajawal', fontSize: 40, fontWeight: 400, color: '#ccfbf1', align: 'center', lineHeight: 1.8 }),
        S('roundrect', { x: 320, y: 850, w: 440, h: 110, radius: 55, fill: '#5eead4' }),
        T({ x: 320, y: 878, w: 440, h: 60, text: 'أرسل الـ CV', fontFamily: 'Cairo', fontSize: 42, fontWeight: 800, color: '#042f2e', align: 'center' }),
      ],
    }),
  },
  {
    id: 'tpl_quote',
    name: 'اقتباس',
    cat: 'سوشيال',
    w: 1080, h: 1080,
    build: () => ({
      bg: { type: 'color', color: '#0f172a' },
      layers: [
        T({ x: 140, y: 120, w: 800, h: 300, text: '”', fontFamily: 'Playfair Display', fontSize: 380, fontWeight: 700, color: '#7c5cff', align: 'left', rtl: false, opacity: .8 }),
        T({ x: 140, y: 380, w: 800, h: 320, text: 'التصميم ليس فقط ما يبدو عليه الشكل، التصميم هو كيف يعمل.', fontFamily: 'El Messiri', fontSize: 68, fontWeight: 500, color: '#f8fafc', align: 'right', lineHeight: 1.7 }),
        S('rect', { x: 640, y: 760, w: 300, h: 6, fill: '#7c5cff' }),
        T({ x: 140, y: 800, w: 800, h: 70, text: 'ستيف جوبز', fontFamily: 'Cairo', fontSize: 44, fontWeight: 700, color: '#a5b4fc', align: 'right' }),
        T({ x: 140, y: 960, w: 800, h: 50, text: 'MEEM | Creative Office', fontFamily: 'Tajawal', fontSize: 28, fontWeight: 400, color: '#64748b', align: 'right', rtl: false }),
      ],
    }),
  },
  {
    id: 'tpl_blank',
    name: 'صفحة فارغة',
    cat: 'عام',
    w: 1080, h: 1080,
    build: () => ({ bg: { type: 'color', color: '#ffffff' }, layers: [] }),
  },
];

export function buildTemplate(tpl) {
  const built = tpl.build();
  const page = makePage(tpl.w, tpl.h, built.bg);
  page.layers = built.layers.map((l) => {
    if (!l.name) l.name = defaultName(l);
    return l;
  });
  return page;
}

function defaultName(l) {
  if (l.type === 'text') return (l.text || 'نص').split('\n')[0].slice(0, 22);
  if (l.type === 'emoji') return l.text;
  if (l.type === 'image') return 'صورة';
  return 'شكل';
}

export function presetById(id) {
  for (const g of PAGE_PRESETS) {
    const p = g.items.find((x) => x.id === id);
    if (p) return p;
  }
  return null;
}
