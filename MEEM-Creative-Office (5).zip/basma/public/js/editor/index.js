/* ============================================================
   MEEM | محرر التصميم — الواجهة الكاملة
   أدوات: طبقات / قوالب / نص / أشكال / صور / ملصقات / خلفية / رفع
   ============================================================ */
import { t, getLang } from '../i18n.js';
import { state, save, saveDesign, loadDesign, userById } from '../store.js';
import { el, icon, clear, toast, modal, escapeHTML, debounce, timeAgo, confirmDialog } from '../ui.js';
import { uid, readFileAsDataURL, downloadBlob } from '../api.js';
import {
  PAGE_PRESETS, SHAPES, EMOJI_SETS, GRADIENTS, PALETTES, PATTERNS,
  makeLayer, makePage, makeDoc, cloneLayer, nextLayerName,
} from './model.js';
import { FONTS, fontOptionsHTML, ensureFont, ensureFonts, addCustomFont, loadCustomFonts } from './fonts.js';
import { renderPage, pageToDataURL, computeTextHeight, ensureImage, dominantColors, preloadLayers, bumpPaint, paintCanvasImageData, maskFromPixels } from './render.js';
import { TEMPLATES, buildTemplate } from './templates.js';
import { exportPage, exportAllPages, exportFitted, printPages } from './export.js';
import { api, socket } from '../api.js';
import { isPro } from '../ai.js';
import { processImage, generateArt, designLayouts } from './ai-tools.js';

const PAINT_TOOLS = ['brush', 'eraser', 'gradient'];

const MIN = 8;
const HANDLE = 12;

let instance = null;

/* نوع المؤشر لمقبض التحجيم حسب اتجاهه + دوران العنصر */
function cursorFor(handle, rot = 0) {
  const base = { n: 0, ne: 45, e: 90, se: 135, s: 180, sw: 225, w: 270, nw: 315 }[handle];
  if (base == null) return 'move';
  const angle = (Math.round(((base + (rot || 0)) % 360) / 45) * 45) % 180;
  const cursors = ['ns-resize', 'nesw-resize', 'ew-resize', 'nwse-resize'];
  return cursors[angle / 45] || 'move';
}

export function openEditor(designId, opts = {}) {
  if (instance) instance.close();
  const ed = new Editor(designId, opts);
  instance = ed;
  return ed;
}

export function getEditorInstance() { return instance; }

export async function openEditorForTask(task, onDone) {
  const existing = (state.designs || []).find((d) => d.taskId === task.id);
  if (existing) {
    openEditor(existing.id, { task, onDone });
    return;
  }
  const preset = sizeFromTask(task);
  const doc = makeDoc(task.title, preset.w, preset.h, { type: 'color', color: '#ffffff' });
  doc.taskId = task.id;
  doc.projectId = task.projectId;
  doc.dept = 'design';
  doc.type = task.type;
  openEditor(null, { doc, task, onDone });
}

function sizeFromTask(task) {
  const map = {
    '1080x1080': { w: 1080, h: 1080 }, '1080x1350': { w: 1080, h: 1350 },
    '1080x1920': { w: 1080, h: 1920 }, '820x312': { w: 820, h: 312 },
    '1584x396': { w: 1584, h: 396 }, '1280x720': { w: 1280, h: 720 },
    '2480x3508': { w: 2480, h: 3508 }, '1748x2480': { w: 1748, h: 2480 },
    '1063x591': { w: 1063, h: 591 },
  };
  const s = (task.sizes && task.sizes[0]) || '';
  return map[s] || { w: 1080, h: 1080 };
}

/* ============================================================ */

class Editor {
  constructor(designId, opts = {}) {
    this.opts = opts;
    this.designId = designId || null;
    this.doc = opts.doc || null;
    this.pageIndex = 0;
    this.selected = [];
    this.tool = 'templates';
    this.scale = 0.5;
    this.autoFit = true;
    this.history = [];
    this.hIndex = -1;
    this.editing = null;
    this.guides = [];
    this.showGrid = false;
    this.paintColor = '#2b6cff';
    this.paintColor2 = '#ff3d77';
    this.paintSize = 16;
    this.paintOp = 1;
    this.paintSelTool = 'rect';
    this.paintTol = 32;
    this.paintSel = null;
    this.propsOpen = true;
    this.dirty = false;
    this.reviewMode = !!opts.review;

    loadCustomFonts().catch(() => {});

    this.build();
    this.load();

    // تحديثات لحظية: لو حد علّق/قرّر على نفس التصميم وهو مفتوح
    this._offSync = socket.on((msg) => {
      if (msg.type !== 'sync' || msg.collection !== 'designs' || !msg.doc) return;
      if (msg.doc.id !== this.designId) return;
      const d = msg.doc;
      if (d.comments) this.doc.comments = d.comments;
      if (d.status) this.doc.status = d.status;
      if (d.review) this.doc.review = d.review;
      if (d.client) this.doc.client = d.client;
      if (d.versionCount != null && d.versionCount !== (this.doc.versions || []).length) this.syncDesignMeta();
      this.updateStatusUI();
      this.renderPins();
      if (this.tool === 'comments') this.panelComments();
      if (this.tool === 'versions') this.panelVersions();
    });
  }

  /* ---------------- بناء الواجهة ---------------- */
  build() {
    const root = document.getElementById('editor-root');
    clear(root);

    this.titleInput = el('input', { class: 'ed-title-input', value: this.doc ? this.doc.title : 'تصميم بدون عنوان' });
    this.titleInput.addEventListener('input', () => { if (this.doc) { this.doc.title = this.titleInput.value; this.markDirty(); } });

    this.btnUndo = el('button', { class: 'ed-icobtn', title: 'تراجع (Ctrl+Z)', html: icon('undo'), onclick: () => this.undo() });
    this.btnRedo = el('button', { class: 'ed-icobtn', title: 'إعادة (Ctrl+Shift+Z)', html: icon('redo'), onclick: () => this.redo() });

    this.zoomLabel = el('span', { class: 'zv', text: '100%' });
    this.zoomBox = el('div', { class: 'ed-zoom' }, [
      el('button', { html: icon('close'), title: 'تصغير', onclick: () => this.setZoom(this.scale / 1.2) }),
      this.zoomLabel,
      el('button', { html: icon('plus'), title: 'تكبير', onclick: () => this.setZoom(this.scale * 1.2) }),
      el('button', { html: icon('crop'), title: 'ملاءمة', onclick: () => this.fit() }),
    ]);

    const top = el('div', { class: 'ed-top' }, [
      el('button', { class: 'ed-icobtn', title: 'إغلاق', html: icon('chevronRight'), onclick: () => this.requestClose() }),
      this.titleInput,
      this.statusPill = el('span', { class: 'ed-statuspill' }),
      el('div', { class: 'grow' }),
      this.btnUndo, this.btnRedo,
      this.zoomBox,
      this.saveInd = el('span', { class: 'ed-saveind' }),
      el('button', { class: 'ed-icobtn', title: 'الشبكة', html: icon('grid'), onclick: (e) => { this.showGrid = !this.showGrid; e.currentTarget.classList.toggle('active', this.showGrid); this.drawOverlay(); } }),
      el('button', { class: 'ed-icobtn', title: 'تغيير المقاس / نسخ بمقاسات', html: icon('ruler'), onclick: () => this.resizeDialog() }),
      el('button', { class: 'ed-icobtn', title: 'حفظ كقالب للفريق', html: icon('template'), onclick: () => this.saveAsTemplate() }),
      el('button', { class: 'ed-icobtn', title: 'رابط اعتماد العميل', html: icon('globe'), onclick: () => this.shareDialog() }),
      el('button', { class: 'btn sm', html: icon('print') + `<span>${t('print')}</span>`, onclick: () => printPages(this.doc.pages, this.doc.title) }),
      el('button', { class: 'btn sm', html: icon('download') + `<span>${t('export')}</span>`, onclick: () => this.exportDialog() }),
      el('button', { class: 'btn sm', html: icon('check') + `<span>${t('save')}</span>`, onclick: () => this.save() }),
      el('button', { class: 'btn primary sm', html: icon('send') + `<span>${t('sendForReview')}</span>`, onclick: () => this.sendForReview() }),
    ]);

    /* شريط المراجعة (يظهر حسب حالة التصميم) */
    this.reviewBar = el('div', { class: 'ed-reviewbar', hidden: true });

    /* tools rail */
    this.rail = el('div', { class: 'ed-tools' });
    const tools = [
      ['templates', 'template', t('templates')],
      ['layers', 'layers', t('ed_layers')],
      ['text', 'text', t('ed_text')],
      ['shapes', 'shapes', t('ed_shapes')],
      ['brush', 'brush', t('ed_brush')],
      ['eraser', 'eraser', t('ed_eraser')],
      ['gradient', 'palette', t('ed_gradientTool')],
      ['psel', 'wand', t('ed_paintSel')],
      ['images', 'image', t('ed_images')],
      ['stickers', 'sparkles', t('ed_stickers')],
      ['background', 'palette', t('ed_background')],
      ['qr', 'qr', 'كود QR'],
      ['brand', 'star', 'Brand Kit'],
      ...((() => { const td = (state.settings || []).find((x) => x.id === 'tools') || {}; return (td.ai !== false || state.user.role === 'superadmin') ? [['ai', 'sparkles', 'AI']] : []; })()),
      ['comments', 'chat', 'التعليقات'],
      ['versions', 'history', 'النسخ'],
      ['history', 'refresh', 'السجل'],
      ['upload', 'upload', t('ed_upload')],
    ];
    tools.forEach(([key, ic, label]) => {
      this.rail.appendChild(el('button', {
        class: 'ed-tool' + (this.tool === key ? ' active' : ''), dataset: { tool: key },
        html: icon(ic) + `<span>${label}</span>`,
        onclick: () => this.setTool(key),
      }));
    });

    this.panelClose = el('button', { class: 'ed-close', title: 'إغلاق', html: icon('close'), onclick: () => this.panel.classList.remove('open') });
    this.panelHead = el('div', { class: 'ed-panel-head' });
    this.panelBody = el('div', { class: 'ed-panel-body' });
    this.panel = el('div', { class: 'ed-panel' }, [this.panelHead, this.panelBody]);
    this.panel.dataset.role = 'tools';

    /* stage */
    this.holder = el('div', { class: 'ed-canvas-holder' });
    this.canvas = el('canvas', { class: 'main' });
    this.handlesLayer = el('div', { class: 'ed-handles' });
    this.pinLayer = el('div', { class: 'ed-pins' });
    this.holder.append(this.canvas, this.handlesLayer, this.pinLayer);
    this.canvasWrap = el('div', { class: 'ed-canvas-wrap' }, [this.holder]);
    this.stage = el('div', { class: 'ed-stage' }, [
      this.canvasWrap,
      el('div', { class: 'ed-hint', html: `<b>Ctrl+Z</b> تراجع · <b>Ctrl+D</b> تكرار · <b>Delete</b> حذف · <b>نقر مزدوج</b> تعديل النص` }),
      this.propsToggle = el('button', {
        class: 'ed-props-toggle', title: t('settings'), html: icon('settings'),
        onclick: () => {
          const open = !this.props.classList.contains('open');
          this.props.classList.toggle('open', open);
          this.panel.classList.remove('open');
        },
      }),
    ]);

    /* properties */
    this.propsClose = el('button', { class: 'ed-close', title: 'إغلاق', html: icon('close'), onclick: () => this.props.classList.remove('open') });
    const propsHead = el('div', { class: 'ed-panel-head' });
    propsHead.innerHTML = icon('settings') + `<span>${t('settings')}</span>`;
    propsHead.appendChild(this.propsClose);
    this.propsBody = el('div', { class: 'ed-panel-body' });
    this.props = el('div', { class: 'ed-panel' }, [propsHead, this.propsBody]);
    this.props.dataset.role = 'props';

    const body = el('div', { class: 'ed-body' }, [this.rail, this.panel, this.stage, this.props]);

    /* pages strip */
    this.pagesStrip = el('div', { class: 'ed-pages' });

    this.menubar = this.buildMenuBar();
    this.recoverBar = el('div', { class: 'ed-recoverbar', hidden: true });
    this.rootEl = el('div', { class: 'ed' }, [this.menubar, top, this.recoverBar, this.reviewBar, body, this.pagesStrip]);
    root.appendChild(this.rootEl);

    this.bindPointer();
    this.bindKeys();
    this.bindDrop();

    window.addEventListener('resize', this._onResize = () => { if (this.autoFit) this.fit(); else this.drawCanvas(); });
    window.addEventListener('beforeunload', this._onUnload = () => this.saveDraft());
  }

  /* ---------------- تحميل ---------------- */
  async load() {
    if (this.designId) {
      try {
        const d = await loadDesign(this.designId);
        this.doc = d;
        this.titleInput.value = d.title;
      } catch (e) {
        toast('تعذّر تحميل التصميم', 'err');
        this.doc = makeDoc();
      }
    }
    if (!this.doc) this.doc = makeDoc();
    if (!this.doc.pages || !this.doc.pages.length) this.doc.pages = [makePage()];
    this.pushHistory(true);
    this.checkDraft();
    await this.refresh(true);
    this.updateStatusUI();
    this.renderPins();
    if (this.reviewMode) {
      this.tool = 'comments';
      this.rail.querySelectorAll('.ed-tool').forEach((b) => b.classList.toggle('active', b.dataset.tool === 'comments'));
      this.renderPanel();
      this.panel.classList.add('open');
    }
  }

  get page() { return this.doc.pages[this.pageIndex]; }
  get sel() {
    return this.selected.map((id) => this.page.layers.find((l) => l.id === id)).filter(Boolean);
  }
  get one() { return this.sel.length === 1 ? this.sel[0] : null; }

  /* ---------------- تحديث ---------------- */
  async refresh(fitFirst) {
    if (fitFirst) { this.fit(); } else { await this.drawCanvas(); this.drawOverlay(); }
    this.renderPages();
    this.renderProps();
    this.updateHistoryButtons();
  }

  scheduleDraw = debounce(() => { this.drawCanvas(); this.drawOverlay(); }, 30);

  async drawCanvas() {
    if (!this.doc) return;
    const page = this.page;
    const maxDim = 6000;
    const limit = Math.min(1, maxDim / Math.max(page.w, page.h));
    const scale = Math.min(this.scale, limit);
    this._renderScale = scale;
    await preloadLayers(page.layers);
    await renderPage(this.canvas, page, scale);
    this.canvas.style.width = (page.w * this.scale) + 'px';
    this.canvas.style.height = (page.h * this.scale) + 'px';
    this.canvas.width = Math.max(1, Math.round(page.w * scale));
    this.canvas.height = Math.max(1, Math.round(page.h * scale));
    // إعادة الرسم بالمقاس النهائي للعرض
    const ctx = this.canvas.getContext('2d');
    await renderPage(this.canvas, page, scale);
    this.holder.style.width = (page.w * this.scale) + 'px';
    this.holder.style.height = (page.h * this.scale) + 'px';
    this.zoomLabel.textContent = Math.round(this.scale * 100) + '%';
    if (this.showGrid) this.drawGridOverlay();
  }

  drawGridOverlay() {
    // الشبكة تُرسم فوق الكانفس
    const ctx = this.canvas.getContext('2d');
    const s = this._renderScale;
    ctx.save();
    ctx.strokeStyle = 'rgba(0,102,255,.18)';
    ctx.lineWidth = 1;
    const step = 50 * s;
    for (let x = step; x < this.canvas.width; x += step) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, this.canvas.height); ctx.stroke(); }
    for (let y = step; y < this.canvas.height; y += step) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.canvas.width, y); ctx.stroke(); }
    ctx.restore();
  }

  /* ---------------- overlay (تحديد ومقابض) ---------------- */
  drawOverlay() {
    clear(this.handlesLayer);
    this.guides = [];
    this.drawPaintSelOverlay();
    if (!this.selected.length) return;
    const s = this.scale;
    const box = this.selectionBox();
    if (!box) return;

    const outline = el('div', { class: 'ed-outline' });
    if (this.sel.length === 1 && this.one.rot) {
      outline.style.transform = `rotate(${this.one.rot}deg)`;
    }
    Object.assign(outline.style, {
      left: box.x * s + 'px', top: box.y * s + 'px',
      width: box.w * s + 'px', height: box.h * s + 'px',
    });
    if (this.sel.length === 1 && this.one.rot) {
      outline.style.left = (this.one.x) * s + 'px';
      outline.style.top = (this.one.y) * s + 'px';
      outline.style.width = (this.one.w) * s + 'px';
      outline.style.height = (this.one.h) * s + 'px';
    }
    this.handlesLayer.appendChild(outline);

    if (this.sel.length !== 1) return;
    const l = this.one;
    if (l.locked) return;

    const pts = [
      ['nw', 0, 0], ['n', .5, 0], ['ne', 1, 0],
      ['e', 1, .5], ['se', 1, 1], ['s', .5, 1],
      ['sw', 0, 1], ['w', 0, .5],
    ];
    pts.forEach(([key, fx, fy]) => {
      const hx = (l.x + l.w * fx) * s;
      const hy = (l.y + l.h * fy) * s;
      const h = el('div', { class: 'ed-handle', dataset: { h: key } });
      Object.assign(h.style, { left: (hx - HANDLE / 2) + 'px', top: (hy - HANDLE / 2) + 'px' });
      h.style.cursor = cursorFor(key, l.rot);
      this.handlesLayer.appendChild(h);
    });

    // مقبض التدوير
    const cx = (l.x + l.w / 2) * s, cy = (l.y + l.h / 2) * s;
    const rad = (l.rot - 90) * Math.PI / 180;
    const dist = (l.h / 2) * s + 28;
    const rot = el('div', { class: 'ed-handle rot', dataset: { h: 'rot' } });
    Object.assign(rot.style, {
      left: (cx + Math.cos(rad) * dist - HANDLE / 2) + 'px',
      top: (cy + Math.sin(rad) * dist - HANDLE / 2) + 'px',
      cursor: 'grab',
    });
    this.handlesLayer.appendChild(rot);

    // خط يربط
    const line = el('div', { style: { position: 'absolute', background: 'var(--brand)', pointerEvents: 'none', width: '1.5px', left: cx + 'px', top: (l.y) * s + 'px', height: '28px', transformOrigin: 'top center', transform: `rotate(${l.rot}deg)` } });
    this.handlesLayer.appendChild(line);
  }

  selectionBox() {
    const sel = this.sel;
    if (!sel.length) return null;
    if (sel.length === 1) return { x: sel[0].x, y: sel[0].y, w: sel[0].w, h: sel[0].h };
    const x = Math.min(...sel.map((l) => l.x));
    const y = Math.min(...sel.map((l) => l.y));
    const x2 = Math.max(...sel.map((l) => l.x + l.w));
    const y2 = Math.max(...sel.map((l) => l.y + l.h));
    return { x, y, w: x2 - x, h: y2 - y };
  }

  fit() {
    const r = this.canvasWrap.getBoundingClientRect();
    const page = this.page;
    const s = Math.min((r.width - 80) / page.w, (r.height - 80) / page.h);
    this.scale = Math.max(0.02, Math.min(4, s));
    this.autoFit = true;
    this.drawCanvas();
    this.drawOverlay();
  }

  setZoom(z) {
    this.scale = Math.max(0.02, Math.min(4, z));
    this.autoFit = false;
    this.drawCanvas();
    this.drawOverlay();
  }

  /* ---------------- تفاعل المؤشر ---------------- */
  toPage(e) {
    const r = this.holder.getBoundingClientRect();
    return { x: (e.clientX - r.left) / this.scale, y: (e.clientY - r.top) / this.scale };
  }

  hitTest(p) {
    const layers = this.page.layers;
    for (let i = layers.length - 1; i >= 0; i--) {
      const l = layers[i];
      if (l.visible === false) continue;
      const cx = l.x + l.w / 2, cy = l.y + l.h / 2;
      const a = -(l.rot || 0) * Math.PI / 180;
      const dx = p.x - cx, dy = p.y - cy;
      const lx = dx * Math.cos(a) - dy * Math.sin(a) + l.w / 2;
      const ly = dx * Math.sin(a) + dy * Math.cos(a) + l.h / 2;
      if (lx >= 0 && lx <= l.w && ly >= 0 && ly <= l.h) return l;
    }
    return null;
  }

  bindPointer() {
    let drag = null;

    this.handlesLayer.style.pointerEvents = 'none';

    const onDown = (e) => {
      if (this.editing) this.commitTextEdit();
      const handle = e.target.dataset && e.target.dataset.h;
      const p = this.toPage(e);

      // أداة التعليقات: أي ضغطة على الكانفس = دبوس جديد
      if (this.tool === 'comments' && !handle) {
        drag = { mode: 'pin', start: p };
        this.holder.setPointerCapture(e.pointerId);
        return;
      }

      if (!handle && PAINT_TOOLS.includes(this.tool)) {
        this.ensurePaint();
        const st = {
          tool: this.tool, color: this.paintColor, color2: this.paintColor2,
          size: this.paintSize, op: this.paintOp,
          pts: this.tool === 'gradient' ? null : [[p.x, p.y]],
          g: this.tool === 'gradient' ? { x1: p.x, y1: p.y, x2: p.x, y2: p.y } : null,
          sel: this.paintSel ? JSON.parse(JSON.stringify(this.paintSel)) : null,
        };
        this.page.paint.strokes.push(st);
        bumpPaint(this.page);
        drag = { mode: 'paint', st };
        this.holder.setPointerCapture(e.pointerId);
        this.scheduleDraw();
        return;
      }
      if (!handle && this.tool === 'psel') {
        if (this.paintSelTool === 'wand') { this.wandSelect(p); return; }
        drag = { mode: 'psel', start: p, pts: [[p.x, p.y]] };
        if (this.paintSelTool === 'rect') {
          this.marquee = el('div', { class: 'ed-marquee ed-paintsel' });
          this.handlesLayer.appendChild(this.marquee);
        } else {
          this._lassoSvg = el('div', { class: 'ed-lasso' });
          this.handlesLayer.appendChild(this._lassoSvg);
          this._lassoPts = [[p.x, p.y]];
        }
        this.holder.setPointerCapture(e.pointerId);
        return;
      }

      if (handle === 'rot' && this.one) {
        drag = { mode: 'rotate', l: this.one, start: this.one.rot };
        this.holder.setPointerCapture(e.pointerId);
        return;
      }
      if (handle && this.one) {
        drag = { mode: 'resize', h: handle, l: this.one, orig: JSON.parse(JSON.stringify(this.one)) };
        this.holder.setPointerCapture(e.pointerId);
        return;
      }

      const hit = this.hitTest(p);
      if (hit) {
        if (e.shiftKey) {
          this.selected = this.selected.includes(hit.id) ? this.selected.filter((x) => x !== hit.id) : [...this.selected, hit.id];
        } else if (!this.selected.includes(hit.id)) {
          // عنصر داخل مجموعة → حدد المجموعة كاملة
          if (hit.groupId) this.selected = this.page.layers.filter((x) => x.groupId === hit.groupId).map((x) => x.id);
          else this.selected = [hit.id];
        }
        if (!hit.locked) {
          drag = { mode: 'move', start: p, orig: this.sel.map((l) => ({ id: l.id, x: l.x, y: l.y })) };
          this.holder.setPointerCapture(e.pointerId);
        }
      } else {
        if (!e.shiftKey) this.selected = [];
        drag = { mode: 'marquee', start: p };
        this.marquee = el('div', { class: 'ed-marquee' });
        this.handlesLayer.appendChild(this.marquee);
        this.holder.setPointerCapture(e.pointerId);
      }
      this.drawOverlay();
      this.renderProps();
      this.renderLayersIfOpen();
    };

    const onMove = (e) => {
      if (!drag) return;
      const p = this.toPage(e);
      if (drag.mode === 'move') {
        let dx = p.x - drag.start.x, dy = p.y - drag.start.y;
        if (e.shiftKey) { if (Math.abs(dx) > Math.abs(dy)) dy = 0; else dx = 0; }
        drag.orig.forEach((o) => {
          const l = this.page.layers.find((x) => x.id === o.id);
          if (!l) return;
          l.x = Math.round(o.x + dx);
          l.y = Math.round(o.y + dy);
        });
        // snap
        if (this.sel.length === 1) {
          const l = this.sel[0];
          const cx = l.x + l.w / 2, cy = l.y + l.h / 2;
          const th = 6 / this.scale;
          this.guides = [];
          if (Math.abs(cx - this.page.w / 2) < th) { l.x = Math.round(this.page.w / 2 - l.w / 2); this.guides.push({ type: 'v', at: this.page.w / 2 }); }
          if (Math.abs(cy - this.page.h / 2) < th) { l.y = Math.round(this.page.h / 2 - l.h / 2); this.guides.push({ type: 'h', at: this.page.h / 2 }); }
        }
        this.scheduleDraw();
        this.drawOverlay();
        this.drawGuides();
        this.renderPropsValues();
      } else if (drag.mode === 'resize') {
        this.resizeLayer(drag, p, e.shiftKey);
        this.scheduleDraw();
        this.drawOverlay();
        this.renderPropsValues();
      } else if (drag.mode === 'rotate') {
        const l = drag.l;
        const cx = l.x + l.w / 2, cy = l.y + l.h / 2;
        let ang = Math.atan2(p.y - cy, p.x - cx) * 180 / Math.PI + 90;
        if (e.shiftKey) ang = Math.round(ang / 15) * 15;
        l.rot = Math.round(((ang % 360) + 360) % 360 * 10) / 10;
        this.scheduleDraw();
        this.drawOverlay();
        this.renderPropsValues();
      } else if (drag.mode === 'paint') {
        const st = drag.st;
        if (st.tool === 'gradient') { st.g.x2 = p.x; st.g.y2 = p.y; }
        else {
          const last = st.pts[st.pts.length - 1];
          if (Math.hypot(p.x - last[0], p.y - last[1]) * this.scale >= 1.2) st.pts.push([p.x, p.y]);
        }
        bumpPaint(this.page);
        this.scheduleDraw();
      } else if (drag.mode === 'psel') {
        if (this.paintSelTool === 'rect' && this.marquee) {
          const x = Math.min(drag.start.x, p.x), y = Math.min(drag.start.y, p.y);
          const w = Math.abs(p.x - drag.start.x), h = Math.abs(p.y - drag.start.y);
          Object.assign(this.marquee.style, { left: x * this.scale + 'px', top: y * this.scale + 'px', width: w * this.scale + 'px', height: h * this.scale + 'px', pointerEvents: 'none' });
          this._pselRect = { x, y, w, h };
        } else if (this._lassoPts) {
          this._lassoPts.push([p.x, p.y]);
          this._lassoSvg.innerHTML = `<svg width="100%" height="100%"><polygon points="${this._lassoPts.map((q) => q[0] * this.scale + ',' + q[1] * this.scale).join(' ')}" fill="rgba(43,108,255,.14)" stroke="#2b6cff" stroke-width="1" stroke-dasharray="4 3"/></svg>`;
        }
      } else if (drag.mode === 'marquee') {
        const x = Math.min(drag.start.x, p.x), y = Math.min(drag.start.y, p.y);
        const w = Math.abs(p.x - drag.start.x), h = Math.abs(p.y - drag.start.y);
        Object.assign(this.marquee.style, {
          left: x * this.scale + 'px', top: y * this.scale + 'px',
          width: w * this.scale + 'px', height: h * this.scale + 'px', pointerEvents: 'none',
        });
        this._marqueeRect = { x, y, w, h };
      }
    };

    const onUp = (e) => {
      if (!drag) return;
      if (drag.mode === 'pin') {
        const p = drag.start;
        drag = null;
        this.addPinAt(p);
        return;
      }
      if (drag.mode === 'paint') {
        bumpPaint(this.page);
        this.pushHistory();
        this.markDirty();
        this.scheduleDraw();
        drag = null;
        return;
      }
      if (drag.mode === 'psel') {
        if (this.paintSelTool === 'rect' && this._pselRect && this._pselRect.w > 3 && this._pselRect.h > 3) {
          this.paintSel = Object.assign({ type: 'rect' }, this._pselRect);
        } else if (this._lassoPts && this._lassoPts.length > 2) {
          this.paintSel = { type: 'poly', pts: this._lassoPts };
        } else {
          this.paintSel = null;
        }
        this.marquee && this.marquee.remove(); this.marquee = null;
        this._lassoSvg && this._lassoSvg.remove(); this._lassoSvg = null;
        this._pselRect = null; this._lassoPts = null;
        this.drawOverlay();
        if (this.tool === 'psel' || PAINT_TOOLS.includes(this.tool)) this.renderPanel();
        drag = null;
        return;
      }
      if (drag.mode === 'marquee' && this._marqueeRect) {
        const r = this._marqueeRect;
        const ids = this.page.layers.filter((l) => l.visible !== false && l.x < r.x + r.w && l.x + l.w > r.x && l.y < r.y + r.h && l.y + l.h > r.y).map((l) => l.id);
        this.selected = ids;
        this.marquee && this.marquee.remove();
        this.marquee = null;
        this._marqueeRect = null;
      }
      if (drag.mode !== 'marquee') { this.pushHistory(); this.markDirty(); }
      drag = null;
      this.guides = [];
      this.drawOverlay();
      this.renderProps();
      this.renderPages();
    };

    this.holder.addEventListener('pointerdown', onDown);
    this.holder.addEventListener('pointermove', onMove);
    this.holder.addEventListener('pointerup', onUp);
    this.holder.addEventListener('pointercancel', onUp);

    this.holder.addEventListener('dblclick', (e) => {
      const hit = this.hitTest(this.toPage(e));
      if (hit && (hit.type === 'text')) { this.selected = [hit.id]; this.startTextEdit(hit); }
    });

    this.holder.addEventListener('wheel', (e) => {
      if (e.ctrlKey || e.metaKey) {
        e.preventDefault();
        this.setZoom(this.scale * (e.deltaY < 0 ? 1.1 : 0.9));
      }
    }, { passive: false });
  }

  drawGuides() {
    this.handlesLayer.querySelectorAll('.ed-guideline').forEach((n) => n.remove());
    this.guides.forEach((g) => {
      const n = el('div', { class: 'ed-guideline ' + g.type });
      if (g.type === 'v') n.style.left = (g.at * this.scale) + 'px';
      else n.style.top = (g.at * this.scale) + 'px';
      this.handlesLayer.appendChild(n);
    });
  }

  resizeLayer(drag, p, keepRatio) {
    const l = drag.l, o = drag.orig;
    const cx = o.x + o.w / 2, cy = o.y + o.h / 2;
    const th = -(o.rot || 0) * Math.PI / 180;
    const dx = p.x - cx, dy = p.y - cy;
    let lx = dx * Math.cos(th) - dy * Math.sin(th);
    let ly = dx * Math.sin(th) + dy * Math.cos(th);

    let left = -o.w / 2, right = o.w / 2, top = -o.h / 2, bottom = o.h / 2;
    const h = drag.h;
    const hx = h.includes('w') ? -1 : h.includes('e') ? 1 : 0;
    const hy = h.includes('n') ? -1 : h.includes('s') ? 1 : 0;

    if (hx === -1) left = Math.min(lx, right - MIN);
    if (hx === 1) right = Math.max(lx, left + MIN);
    if (hy === -1) top = Math.min(ly, bottom - MIN);
    if (hy === 1) bottom = Math.max(ly, top + MIN);

    let nw = right - left, nh = bottom - top;
    if (keepRatio && hx && hy) {
      const ratio = o.w / o.h;
      if (nw / nh > ratio) nw = nh * ratio; else nh = nw / ratio;
      if (hx === -1) left = right - nw; else right = left + nw;
      if (hy === -1) top = bottom - nh; else bottom = top + nh;
    }
    const ncx = (left + right) / 2, ncy = (top + bottom) / 2;
    const c2 = Math.cos(-th), s2 = Math.sin(-th);
    const wx = cx + ncx * c2 - ncy * s2;
    const wy = cy + ncx * s2 + ncy * c2;

    l.w = Math.max(MIN, Math.round(nw));
    l.h = Math.max(MIN, Math.round(nh));
    l.x = Math.round(wx - l.w / 2);
    l.y = Math.round(wy - l.h / 2);
    if (l.type === 'text' && !l.autoFit) l.h = Math.max(l.h, 20);
  }

  /* ---------------- تحرير النص المباشر ---------------- */
  startTextEdit(layer) {
    if (this.editing) this.commitTextEdit();
    const ta = el('textarea', { class: 'ed-textedit' });
    ta.value = layer.text || '';
    const s = this.scale;
    Object.assign(ta.style, {
      left: layer.x * s + 'px', top: layer.y * s + 'px',
      width: layer.w * s + 'px', height: layer.h * s + 'px',
      font: `${layer.italic ? 'italic ' : ''}${layer.fontWeight} ${layer.fontSize * s}px "${layer.fontFamily}", sans-serif`,
      color: typeof layer.color === 'string' ? layer.color : '#fff',
      textAlign: layer.align,
      direction: layer.rtl ? 'rtl' : 'ltr',
      lineHeight: (layer.lineHeight || 1.3),
      padding: (layer.padding || 0) * s + 'px',
    });
    this.holder.appendChild(ta);
    ta.focus();
    ta.select();
    this.editing = { layer, ta };
    ta.addEventListener('input', () => { layer.text = ta.value; });
    ta.addEventListener('blur', () => this.commitTextEdit());
    ta.addEventListener('keydown', (e) => {
      e.stopPropagation();
      if (e.key === 'Escape') this.commitTextEdit();
    });
  }

  commitTextEdit() {
    if (!this.editing) return;
    const { layer, ta } = this.editing;
    layer.text = ta.value;
    ta.remove();
    this.editing = null;
    if (!layer.autoFit) layer.h = Math.max(30, Math.round(computeTextHeight(layer)));
    this.pushHistory();
    this.markDirty();
    this.drawCanvas();
    this.drawOverlay();
    this.renderPages();
    this.renderProps();
  }

  /* ---------------- لوحة المفاتيح ---------------- */
  /* ---------------- أدوات الرسم (V2-E1) ---------------- */
  ensurePaint() {
    if (!this.page.paint) this.page.paint = { ver: 0, strokes: [] };
    if (!this.page.paint.strokes) this.page.paint.strokes = [];
  }

  drawPaintSelOverlay() {
    const s = this.paintSel;
    if (!s) return;
    const sc = this.scale;
    if (s.type === 'rect') {
      this.handlesLayer.appendChild(el('div', {
        class: 'ed-paintsel', pointerEvents: 'none',
        style: { left: s.x * sc + 'px', top: s.y * sc + 'px', width: s.w * sc + 'px', height: s.h * sc + 'px' },
      }));
    } else if (s.type === 'poly') {
      const pts = (s.pts || []).map((q) => (q[0] * sc) + ',' + (q[1] * sc)).join(' ');
      const wrap = el('div', { class: 'ed-lasso' });
      wrap.innerHTML = `<svg width="100%" height="100%"><polygon points="${pts}" fill="rgba(43,108,255,.12)" stroke="#2b6cff" stroke-width="1" stroke-dasharray="4 3"/></svg>`;
      this.handlesLayer.appendChild(wrap);
    } else if (s.type === 'mask' && s.url) {
      this.handlesLayer.appendChild(el('div', {
        class: 'ed-paintsel-mask',
        style: {
          left: 0, top: 0, width: this.page.w * sc + 'px', height: this.page.h * sc + 'px',
          pointerEvents: 'none', background: '#2b6cff', opacity: '.45',
          webkitMaskImage: `url(${s.url})`, maskImage: `url(${s.url})`,
          webkitMaskSize: '100% 100%', maskSize: '100% 100%',
        },
      }));
    }
  }

  async wandSelect(p) {
    const imgd = await paintCanvasImageData(this.page);
    if (!imgd) { toast(t('ed_paintHint')); return; }
    const w = imgd.width, h = imgd.height, d = imgd.data;
    const sx = Math.floor(p.x), sy = Math.floor(p.y);
    if (sx < 0 || sy < 0 || sx >= w || sy >= h) return;
    const tol = this.paintTol;
    const i0 = (sy * w + sx) * 4;
    const tr = d[i0], tg = d[i0 + 1], tb = d[i0 + 2], ta = d[i0 + 3];
    const seen = new Uint8Array(w * h);
    const mask = new Uint8Array(w * h);
    const stack = [sx, sy];
    let count = 0;
    while (stack.length) {
      const y = stack.pop(), x = stack.pop();
      if (x < 0 || y < 0 || x >= w || y >= h) continue;
      const i = y * w + x;
      if (seen[i]) continue;
      const j = i * 4;
      if (Math.abs(d[j] - tr) > tol || Math.abs(d[j + 1] - tg) > tol || Math.abs(d[j + 2] - tb) > tol || Math.abs(d[j + 3] - ta) > Math.max(tol * 2, 24)) continue;
      seen[i] = 1; mask[i] = 1; count++;
      stack.push(x + 1, y, x - 1, y, x, y + 1, x, y - 1);
    }
    if (!count) { toast(t('ed_paintHint')); return; }
    this.paintSel = { type: 'mask', url: maskFromPixels(this.page, mask) };
    this.drawOverlay();
    if (this.tool === 'psel' || PAINT_TOOLS.includes(this.tool)) this.renderPanel();
  }

  clearPaintSel() {
    this.paintSel = null;
    this.drawOverlay();
    if (this.tool === 'psel' || PAINT_TOOLS.includes(this.tool)) this.renderPanel();
  }

  strokeForSel(tool) {
    if (!this.paintSel) return;
    const sel = JSON.parse(JSON.stringify(this.paintSel));
    let g = { x1: 0, y1: 0, x2: this.page.w, y2: this.page.h };
    if (sel.type === 'rect') g = { x1: sel.x, y1: sel.y, x2: sel.x + sel.w, y2: sel.y + sel.h };
    this.ensurePaint();
    this.page.paint.strokes.push({ tool, color: this.paintColor, color2: this.paintColor, size: 1, op: this.paintOp, pts: null, g, sel });
    bumpPaint(this.page);
    this.pushHistory();
    this.markDirty();
    this.drawCanvas();
    if (this.tool === 'psel' || PAINT_TOOLS.includes(this.tool)) this.renderPanel();
  }

  panelPaint() {
    const box = el('div');
    const tool = this.tool;
    const hasSel = !!this.paintSel;

    if (tool === 'brush' || tool === 'eraser') {
      if (tool === 'brush') box.appendChild(this.colorRow(t('ed_color'), this.paintColor, (c) => { this.paintColor = c; }));
      box.appendChild(this.sliderRow(t('ed_size'), this.paintSize, 1, 160, 1, 'px', (v) => { this.paintSize = v; }));
      box.appendChild(this.sliderRow(t('ed_opacity'), Math.round(this.paintOp * 100), 5, 100, 1, '%', (v) => { this.paintOp = v / 100; }));
      if (tool === 'brush') box.appendChild(this.paletteRow((c) => { this.paintColor = c; this.renderPanel(); }));
      box.appendChild(el('div', { class: 'ed-hint-sm', text: hasSel ? t('ed_selHint') : t('ed_paintHint') }));
    }
    if (tool === 'gradient') {
      box.appendChild(this.colorRow('1', this.paintColor, (c) => { this.paintColor = c; }));
      box.appendChild(this.colorRow('2', this.paintColor2, (c) => { this.paintColor2 = c; }));
      box.appendChild(this.sliderRow(t('ed_opacity'), Math.round(this.paintOp * 100), 5, 100, 1, '%', (v) => { this.paintOp = v / 100; }));
      box.appendChild(el('div', { class: 'ed-hint-sm', text: hasSel ? t('ed_selHint') : t('ed_gradHint') }));
    }
    if (tool === 'psel') {
      box.appendChild(el('div', { class: 'seg' }, [
        el('button', { text: t('ed_selRect'), class: this.paintSelTool === 'rect' ? 'active' : '', onclick: () => { this.paintSelTool = 'rect'; this.renderPanel(); } }),
        el('button', { text: t('ed_selLasso'), class: this.paintSelTool === 'lasso' ? 'active' : '', onclick: () => { this.paintSelTool = 'lasso'; this.renderPanel(); } }),
        el('button', { text: t('ed_selWand'), class: this.paintSelTool === 'wand' ? 'active' : '', onclick: () => { this.paintSelTool = 'wand'; this.renderPanel(); } }),
      ]));
      if (this.paintSelTool === 'wand') {
        box.appendChild(this.sliderRow(t('ed_tolerance'), this.paintTol, 0, 128, 1, '', (v) => { this.paintTol = v; }));
      }
      box.appendChild(el('div', { class: 'ed-hint-sm', text: t('ed_selHint') }));
    }

    box.appendChild(el('hr', { class: 'divider' }));
    const selName = hasSel ? (this.paintSel.type === 'mask' ? t('ed_selWand') : this.paintSel.type === 'poly' ? t('ed_selLasso') : t('ed_selRect')) : '';
    box.appendChild(el('div', { class: 'ed-row' }, [
      el('label', { text: hasSel ? ('✔ ' + selName) : t('ed_clearSel'), style: { opacity: hasSel ? '1' : '.4' } }),
    ]));
    box.appendChild(el('div', { class: 'ed-mini-row' }, [
      el('button', { class: 'ed-mini', text: t('ed_clearSel'), disabled: !hasSel, onclick: () => this.clearPaintSel() }),
      el('button', { class: 'ed-mini', text: t('ed_fillSel'), disabled: !hasSel, onclick: () => this.strokeForSel('gradient') }),
      el('button', { class: 'ed-mini', text: t('ed_eraseSel'), disabled: !hasSel, onclick: () => this.strokeForSel('erase-fill') }),
    ]));
    box.appendChild(el('hr', { class: 'divider' }));
    const strokes = (this.page.paint && this.page.paint.strokes) ? this.page.paint.strokes.length : 0;
    box.appendChild(el('button', {
      class: 'ed-mini', text: t('ed_clearPaint') + ` (${strokes})`, disabled: !strokes,
      onclick: async () => {
        const ok = await confirmDialog(t('ed_clearPaint') + '؟', { danger: true });
        if (!ok) return;
        this.ensurePaint();
        this.page.paint.strokes = [];
        bumpPaint(this.page);
        this.pushHistory(); this.markDirty(); this.drawCanvas(); this.renderPanel();
      },
    }));
    this.panelBody.appendChild(box);
  }

  /* ---------------- شريط القوائم (V2-E1) ---------------- */
  closeMenus() {
    (this._menus || []).forEach((m) => { m.dd.hidden = true; m.btn.classList.remove('active'); });
  }

  buildMenuBar() {
    this._menus = [];
    const mkItem = (label, fn, opts = {}) => el('button', {
      class: 'ed-mitem', text: label, disabled: !!opts.disabled,
      onclick: (e) => { e.stopPropagation(); this.closeMenus(); fn(); },
    });
    const mkMenu = (label, items) => {
      const dd = el('div', { class: 'ed-menu', hidden: true }, items);
      const btn = el('button', {
        class: 'ed-mbtn', text: label,
        onclick: (e) => {
          e.stopPropagation();
          const wasOpen = !dd.hidden;
          this.closeMenus();
          dd.hidden = wasOpen;
          btn.classList.toggle('active', !wasOpen);
        },
      });
      this._menus.push({ dd, btn });
      return el('div', { class: 'ed-mwrap' }, [btn, dd]);
    };

    const shortcuts = () => {
      const m = modal({
        title: t('ed_shortcutsTitle'),
        body: el('div', { class: 'ed-shortcuts' }, [
          ['Ctrl+Z / Ctrl+Shift+Z', t('ed_undo') + ' / ' + t('ed_redo')],
          ['Ctrl+D', t('ed_duplicate')],
          ['Ctrl+A', t('ed_selectAll')],
          ['Ctrl+S', t('save')],
          ['Ctrl+G / Ctrl+Shift+G', 'تجميع / إلغاء تجميع'],
          ['Delete', t('ed_del')],
          ['B', t('ed_brush')],
          ['E', t('ed_eraser')],
          ['G', t('ed_gradientTool')],
          ['W', t('ed_paintSel')],
          ['Escape', t('ed_clearSel')],
        ].map(([k, v]) => el('div', { class: 'ed-sc-row' }, [el('kbd', { text: k }), el('span', { text: v })]))),
      });
      return m;
    };

    const bar = el('div', { class: 'ed-menubar' }, [
      mkMenu(t('ed_m_file'), [
        mkItem(t('save'), () => this.save()),
        mkItem(t('ed_saveTemplate'), () => this.saveAsTemplate()),
        mkItem(t('export'), () => this.exportDialog()),
        mkItem(t('print'), () => printPages(this.doc.pages, this.doc.title)),
        mkItem(t('ed_resize') || 'تغيير المقاس', () => this.resizeDialog()),
        mkItem(t('ed_share') || 'رابط اعتماد العميل', () => this.shareDialog()),
        mkItem(t('close'), () => this.requestClose()),
      ]),
      mkMenu(t('ed_m_edit'), [
        mkItem(t('ed_undo'), () => this.undo()),
        mkItem(t('ed_redo'), () => this.redo()),
        mkItem(t('ed_duplicate'), () => this.duplicateSelected()),
        mkItem(t('ed_del'), () => this.deleteSelected()),
        mkItem(t('ed_selectAll'), () => { this.selected = this.page.layers.map((l) => l.id); this.drawOverlay(); this.renderProps(); }),
      ]),
      mkMenu(t('ed_m_view'), [
        mkItem(t('ed_zoomIn'), () => this.setZoom(this.scale * 1.2)),
        mkItem(t('ed_zoomOut'), () => this.setZoom(this.scale / 1.2)),
        mkItem(t('ed_zoom100'), () => this.setZoom(1)),
        mkItem(t('ed_fit'), () => this.fit()),
        mkItem('⟦ ' + t('ed_grid') + ' ⟧', () => { this.showGrid = !this.showGrid; this.drawCanvas(); }),
      ]),
      mkMenu(t('ed_m_layers'), [
        mkItem(t('ed_bringFront'), () => this.order('front')),
        mkItem(t('ed_sendBack'), () => this.order('back')),
        mkItem(t('ed_layers'), () => this.setTool('layers')),
      ]),
      mkMenu(t('ed_m_help'), [
        mkItem(t('ed_shortcutsTitle'), shortcuts),
      ]),
    ]);
    if (!this._menusDocClose) {
      this._menusDocClose = () => this.closeMenus();
      document.addEventListener('click', this._menusDocClose);
    }
    return bar;
  }

  /* ---------------- قناع من التحديد (V2-E2) ---------------- */
  async maskFromSelection() {
    const l = this.one;
    if (!l || !this.paintSel) return;
    const sel = this.paintSel;
    const w = Math.max(1, Math.ceil(l.w)), h = Math.max(1, Math.ceil(l.h));
    const c = el('canvas');
    c.width = w; c.height = h;
    const m = c.getContext('2d');
    m.translate(w / 2, h / 2);
    if (l.rot) m.rotate((-l.rot * Math.PI) / 180);
    m.translate(-w / 2, -h / 2);
    m.translate(-l.x, -l.y);
    m.fillStyle = '#fff';
    if (sel.type === 'rect') {
      m.fillRect(sel.x, sel.y, sel.w, sel.h);
    } else if (sel.type === 'poly') {
      m.beginPath();
      (sel.pts || []).forEach((q, i) => (i ? m.lineTo(q[0], q[1]) : m.moveTo(q[0], q[1])));
      m.closePath();
      m.fill();
    } else if (sel.type === 'mask' && sel.url) {
      const img = await ensureImage(sel.url);
      if (img) m.drawImage(img, 0, 0, this.page.w, this.page.h);
    }
    l.mask = c.toDataURL('image/png');
    this.pushHistory();
    this.markDirty();
    this.drawCanvas();
    this.renderProps();
    this.renderLayersIfOpen();
  }

  /* ---------------- مسودة الاستعادة بعد الانهيار (V2-E2) ---------------- */
  draftKey() {
    const base = this.designId ? 'id-' + this.designId : 'new-' + (state.user ? state.user.id : 'anon');
    return 'meem-draft-' + base;
  }

  saveDraft() {
    if (!this.dirty || !this.doc) return;
    try {
      const str = JSON.stringify({ at: Date.now(), doc: this.doc, pageIndex: this.pageIndex });
      if (str.length > 3800000) return; // أكبر من سعة localStorage الآمنة
      localStorage.setItem(this.draftKey(), str);
    } catch (e) { /* المسودة رفاهية — تجاهل أخطاء السعة */ }
  }

  clearDraft() {
    try { localStorage.removeItem(this.draftKey()); } catch (e) {}
  }

  scheduleDraft() {
    clearTimeout(this._draftT);
    this._draftT = setTimeout(() => this.saveDraft(), 15000);
  }

  checkDraft() {
    let raw = null;
    try { raw = localStorage.getItem(this.draftKey()); } catch (e) { return; }
    if (!raw) return;
    let draft;
    try { draft = JSON.parse(raw); } catch (e) { this.clearDraft(); return; }
    if (!draft || !draft.doc || Date.now() - draft.at > 12 * 3600 * 1000) { this.clearDraft(); return; }
    const when = new Date(draft.at);
    const hh = String(when.getHours()).padStart(2, '0') + ':' + String(when.getMinutes()).padStart(2, '0');
    this.recoverBar.hidden = false;
    clear(this.recoverBar);
    this.recoverBar.append(
      el('span', { text: '💾 ' + t('ed_recoverTitle') + ' (' + hh + ')' }),
      el('div', { class: 'grow' }),
      el('button', {
        class: 'btn sm primary', text: t('ed_restore'),
        onclick: async () => {
          this.doc = draft.doc;
          this.pageIndex = Math.min(draft.pageIndex || 0, this.doc.pages.length - 1);
          this.titleInput.value = this.doc.title;
          this.selected = [];
          this.clearDraft();
          this.recoverBar.hidden = true;
          this.history = [];
          this.hIndex = -1;
          this.pushHistory(true);
          await this.refresh(true);
          this.markDirty();
          toast(t('ed_restored'), 'ok');
        },
      }),
      el('button', {
        class: 'btn sm ghost', text: t('ed_ignore'),
        onclick: () => { this.clearDraft(); this.recoverBar.hidden = true; },
      }),
    );
  }

  bindKeys() {
    this._onKey = (e) => {
      if (!document.body.contains(this.rootEl)) return;
      const inField = /INPUT|TEXTAREA|SELECT/.test(e.target.tagName);
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === 'z') {
        e.preventDefault();
        e.shiftKey ? this.redo() : this.undo();
        return;
      }
      if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); this.redo(); return; }
      if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); this.duplicateSelected(); return; }
      if (mod && e.key.toLowerCase() === 'a') { e.preventDefault(); this.selected = this.page.layers.map((l) => l.id); this.drawOverlay(); this.renderProps(); return; }
      if (mod && e.key.toLowerCase() === 'g') { e.preventDefault(); e.shiftKey ? this.ungroupSelected() : this.groupSelected(); return; }
      if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); this.save(); return; }
      if (inField) return;
      if (!mod && !e.altKey) {
        const tk = e.key.toLowerCase();
        if (tk === 'b') { this.setTool('brush'); return; }
        if (tk === 'e') { this.setTool('eraser'); return; }
        if (tk === 'g') { this.setTool('gradient'); return; }
        if (tk === 'w') { this.setTool('psel'); return; }
      }
      if (e.key === 'Delete' || e.key === 'Backspace') { e.preventDefault(); this.deleteSelected(); return; }
      if (e.key === 'Escape') { this.selected = []; this.drawOverlay(); this.renderProps(); return; }
      const step = e.shiftKey ? 10 : 1;
      const arrows = { ArrowLeft: [-step, 0], ArrowRight: [step, 0], ArrowUp: [0, -step], ArrowDown: [0, step] };
      if (arrows[e.key] && this.sel.length) {
        e.preventDefault();
        const [dx, dy] = arrows[e.key];
        const dir = getLang() === 'ar' ? -1 : 1;
        this.sel.forEach((l) => { if (!l.locked) { l.x += dx * dir; l.y += dy; } });
        this.scheduleDraw();
        this.drawOverlay();
      }
    };
    window.addEventListener('keydown', this._onKey);
  }

  /* ---------------- سحب وإفلات الملفات ---------------- */
  bindDrop() {
    ['dragenter', 'dragover'].forEach((ev) => this.stage.addEventListener(ev, (e) => { e.preventDefault(); }));
    this.stage.addEventListener('drop', async (e) => {
      e.preventDefault();
      const files = [...(e.dataTransfer.files || [])].filter((f) => f.type.startsWith('image/'));
      for (const f of files) await this.addImageFile(f);
    });
  }

  /* ---------------- أدوات ---------------- */
  setTool(key) {
    const same = this.tool === key;
    this.tool = key;
    this.rail.querySelectorAll('.ed-tool').forEach((b) => b.classList.toggle('active', b.dataset.tool === key));
    this.renderPanel();
    if (this._isMobile()) {
      // ضغطة ثانية على نفس الأداة = إغلاق اللوحة
      if (same && this.panel.classList.contains('open')) this.panel.classList.remove('open');
      else { this.panel.classList.add('open'); this.props.classList.remove('open'); }
    }
  }

  _isMobile() { return window.matchMedia('(max-width: 860px)').matches; }

  renderPanel() {
    clear(this.panelBody);
    const titles = {
      templates: [t('templates'), 'template'],
      layers: [t('ed_layers'), 'layers'],
      text: [t('ed_text'), 'text'],
      shapes: [t('ed_shapes'), 'shapes'],
      brush: [t('ed_brush'), 'brush'],
      eraser: [t('ed_eraser'), 'eraser'],
      gradient: [t('ed_gradientTool'), 'palette'],
      psel: [t('ed_paintSel'), 'wand'],
      images: [t('ed_images'), 'image'],
      stickers: [t('ed_stickers'), 'sparkles'],
      background: [t('ed_background'), 'palette'],
      qr: ['كود QR', 'qr'],
      brand: ['Brand Kit', 'star'],
      ai: ['أدوات AI', 'sparkles'],
      comments: ['تعليقات المراجعة', 'chat'],
      versions: ['نسخ التصميم', 'history'],
      history: ['السجل', 'refresh'],
      upload: [t('ed_upload'), 'upload'],
    };
    const [title, ic] = titles[this.tool] || ['', 'settings'];
    this.panelHead.innerHTML = icon(ic) + `<span>${escapeHTML(title)}</span>`;
    this.panelHead.appendChild(this.panelClose);
    const fn = {
      templates: () => this.panelTemplates(),
      layers: () => this.panelLayers(),
      text: () => this.panelText(),
      shapes: () => this.panelShapes(),
      brush: () => this.panelPaint(),
      eraser: () => this.panelPaint(),
      gradient: () => this.panelPaint(),
      psel: () => this.panelPaint(),
      images: () => this.panelImages(),
      stickers: () => this.panelStickers(),
      background: () => this.panelBackground(),
      qr: () => this.panelQR(),
      brand: () => this.panelBrand(),
      ai: () => this.panelAI(),
      comments: () => this.panelComments(),
      versions: () => this.panelVersions(),
      history: () => this.panelHistory(),
      upload: () => this.panelUpload(),
    }[this.tool];
    if (fn) fn.call(this);
  }

  renderLayersIfOpen() {
    if (this.tool === 'layers') this.panelLayers();
  }

  /* ------- القوالب ------- */
  panelTemplates() {
    const cats = [...new Set(TEMPLATES.map((x) => x.cat))];
    const wrap = el('div');

    // قوالب الفريق (محفوظة من تصاميم حقيقية)
    const team = (state.templates || []).filter((x) => x.custom);
    if (team.length) {
      const sec = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: '⭐ قوالب الفريق' })]);
      const grid = el('div', { class: 'ed-grid c2' });
      team.forEach((tpl) => {
        const card = el('div', {
          class: 'ed-tpl',
          onclick: () => this.applyTeamTemplate(tpl),
        }, [
          el('div', { class: 'et-thumb', style: { background: '#fff' } }),
          el('div', { style: { padding: '6px 8px' } }, [
            el('div', { class: 'et-name', text: tpl.name }),
            el('div', { class: 'et-cat', text: `${tpl.w || '?'}×${tpl.h || '?'}` }),
          ]),
        ]);
        grid.appendChild(card);
        const holder = card.querySelector('.et-thumb');
        (async () => {
          try {
            const page = (tpl.pages || [])[0];
            if (!page) return;
            const { ensureFonts } = await import('./fonts.js');
            await ensureFonts(page.layers);
            const c = document.createElement('canvas');
            await renderPage(c, page, Math.min(1, 200 / Math.max(page.w, page.h)));
            c.style.width = '100%'; c.style.height = '100%'; c.style.objectFit = 'cover';
            holder.appendChild(c);
          } catch (e) { /* ignore */ }
        })();
      });
      sec.appendChild(grid);
      wrap.appendChild(sec);
    }

    // مقاسات الصفحات
    wrap.appendChild(el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: 'مقاس الصفحة' })]));
    const presetSec = wrap.lastChild;
    const presetGrid = el('div', { class: 'ed-grid c2' });
    PAGE_PRESETS.forEach((g) => {
      g.items.slice(0, 6).forEach((p) => {
        presetGrid.appendChild(el('button', {
          class: 'ed-item',
          onclick: () => this.resizePage(p.w, p.h),
        }, [
          el('div', { class: 'ei-thumb', style: { aspectRatio: '4/3' } }, [
            el('div', { style: { width: Math.min(46, 46 * p.w / p.h) + 'px', height: Math.min(46, 46 * p.h / p.w) + 'px', border: '1.5px solid #6b7690', borderRadius: '3px' } }),
          ]),
          el('div', { class: 'ei-label', text: p.label }),
        ]));
      });
    });
    presetSec.appendChild(presetGrid);

    presetSec.appendChild(el('div', { class: 'ed-row', style: { marginTop: '10px' } }, [
      el('input', { class: 'ed-in num', type: 'number', value: this.page.w, oninput: (e) => { this.page.w = Math.max(50, +e.target.value || 50); this.scheduleDraw(); this.drawOverlay(); } }),
      el('span', { text: '×' }),
      el('input', { class: 'ed-in num', type: 'number', value: this.page.h, oninput: (e) => { this.page.h = Math.max(50, +e.target.value || 50); this.scheduleDraw(); this.drawOverlay(); } }),
    ]));

    cats.forEach((cat) => {
      const sec = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: cat })]);
      const grid = el('div', { class: 'ed-grid c2' });
      TEMPLATES.filter((x) => x.cat === cat).forEach((tpl) => {
        const card = el('div', {
          class: 'ed-tpl',
          onclick: () => this.applyTemplate(tpl),
        }, [
          el('div', { class: 'et-thumb', style: { background: '#fff' } }),
          el('div', { style: { padding: '6px 8px' } }, [
            el('div', { class: 'et-name', text: tpl.name }),
            el('div', { class: 'et-cat', text: `${tpl.w}×${tpl.h}` }),
          ]),
        ]);
        grid.appendChild(card);
        this.thumbFor(card.querySelector('.et-thumb'), tpl);
      });
      sec.appendChild(grid);
      wrap.appendChild(sec);
    });
    this.panelBody.appendChild(wrap);
  }

  async thumbFor(container, tpl) {
    try {
      const page = buildTemplate(tpl);
      await ensureFonts(page.layers);
      const scale = Math.min(1, 220 / Math.max(page.w, page.h));
      const c = document.createElement('canvas');
      await renderPage(c, page, scale);
      c.style.width = '100%';
      c.style.display = 'block';
      container.appendChild(c);
    } catch (e) { /* ignore */ }
  }

  applyTemplate(tpl, mode = 'ask') {
    const doApply = (target) => {
      const page = buildTemplate(tpl);
      if (target === 'replace') {
        this.doc.pages[this.pageIndex] = page;
      } else {
        this.doc.pages.push(page);
        this.pageIndex = this.doc.pages.length - 1;
      }
      this.selected = [];
      this.pushHistory();
      this.markDirty();
      this.refresh(true);
      toast('تم تطبيق القالب', 'ok');
    };
    if (this.page.layers.length && mode === 'ask') {
      const m = modal({
        title: 'تطبيق القالب',
        body: [el('p', { class: 'muted', text: 'الصفحة الحالية فيها عناصر. تحب تستبدلها بالقالب ولا تضيف القالب كصفحة جديدة؟' })],
        footer: [
          el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
          el('button', { class: 'btn outline', text: 'صفحة جديدة', onclick: () => { m.close(); doApply('new'); } }),
          el('button', { class: 'btn primary', text: 'استبدال الصفحة', onclick: () => { m.close(); doApply('replace'); } }),
        ],
      });
      return;
    }
    doApply(this.page.layers.length ? 'new' : 'replace');
  }

  /* ------- الطبقات ------- */
  panelLayers() {
    const box = el('div');
    box.appendChild(el('div', { class: 'ed-row' }, [
      el('button', { class: 'ed-mini', html: icon('text') + `<span>${t('ed_addText')}</span>`, onclick: () => this.addText() }),
      el('button', { class: 'ed-mini', html: icon('shapes') + `<span>${t('ed_shapes')}</span>`, onclick: () => this.setTool('shapes') }),
      el('button', { class: 'ed-mini', html: icon('image') + `<span>${t('ed_images')}</span>`, onclick: () => this.setTool('images') }),
    ]));

    const list = el('div', { class: 'col', style: { gap: '3px' } });
    [...this.page.layers].reverse().forEach((l) => {
      const row = el('div', {
        class: 'ed-layer' + (this.selected.includes(l.id) ? ' sel' : ''),
        onclick: (e) => {
          this.selected = e.shiftKey
            ? (this.selected.includes(l.id) ? this.selected.filter((x) => x !== l.id) : [...this.selected, l.id])
            : [l.id];
          this.drawOverlay(); this.renderProps(); this.panelLayers();
        },
        ondblclick: () => { const n = prompt('اسم الطبقة', l.name || ''); if (n != null) { l.name = n; this.panelLayers(); } },
      }, [
        el('div', { class: 'el-icon', html: icon(l.type === 'text' ? 'text' : l.type === 'image' ? 'image' : l.type === 'emoji' ? 'sparkles' : 'shapes') }),
        el('div', { class: 'el-name', text: (l.groupId ? '🔗 ' : '') + (l.mask ? '🎭 ' : '') + (l.name || (l.type === 'text' ? (l.text || '').slice(0, 20) : l.type)) }),
        el('button', {
          class: 'el-btn', title: l.visible === false ? t('ed_visible') : t('ed_hidden'), html: icon(l.visible === false ? 'eyeOff' : 'eye'),
          onclick: (e) => { e.stopPropagation(); l.visible = l.visible === false; this.pushHistory(); this.drawCanvas(); this.drawOverlay(); this.panelLayers(); },
        }),
        el('button', {
          class: 'el-btn', title: l.locked ? t('ed_unlock') : t('ed_lock'), html: icon('lock'),
          style: { opacity: l.locked ? 1 : .35 },
          onclick: (e) => { e.stopPropagation(); l.locked = !l.locked; this.pushHistory(); this.drawOverlay(); this.panelLayers(); },
        }),
        el('button', {
          class: 'el-btn', title: t('delete'), html: icon('trash'),
          onclick: (e) => { e.stopPropagation(); this.selected = [l.id]; this.deleteSelected(); },
        }),
      ]);
      list.appendChild(row);
    });
    if (!this.page.layers.length) list.appendChild(el('div', { class: 'ed-empty-panel', html: icon('layers') + `<div>${t('noData')}</div>` }));
    box.appendChild(list);

    if (this.selected.length) {
      box.appendChild(el('hr', { class: 'divider' }));
      box.appendChild(el('div', { class: 'ed-row wrap' }, [
        el('button', { class: 'ed-mini', html: icon('arrowUp') + `<span>${t('ed_bringFront')}</span>`, onclick: () => this.order('front') }),
        el('button', { class: 'ed-mini', html: icon('arrowUp'), style: { transform: 'rotate(180deg)' }, title: t('ed_sendBack'), onclick: () => this.order('back') }),
        el('button', { class: 'ed-mini', html: icon('copy') + `<span>${t('ed_duplicate')}</span>`, onclick: () => this.duplicateSelected() }),
        el('button', { class: 'ed-mini', text: '🔗 تجميع', onclick: () => this.groupSelected() }),
        el('button', { class: 'ed-mini', text: 'فك التجميع', onclick: () => this.ungroupSelected() }),
      ]));
      box.appendChild(el('div', { class: 'dim', style: { fontSize: '11px', marginTop: '4px' }, text: 'Ctrl+G تجميع · Ctrl+Shift+G فك · النقر على عنصر مجمّع يحدد المجموعة' }));
    }
    clear(this.panelBody);
    this.panelBody.appendChild(box);
  }

  order(dir) {
    const layers = this.page.layers;
    this.sel.forEach((l) => {
      const i = layers.indexOf(l);
      layers.splice(i, 1);
      if (dir === 'front') layers.push(l); else layers.unshift(l);
    });
    this.pushHistory(); this.drawCanvas(); this.renderLayersIfOpen();
  }

  /* ------- النص ------- */
  panelText() {
    const box = el('div');
    const add = (preset) => {
      const page = this.page;
      const l = makeLayer('text', Object.assign({
        x: page.w * 0.1, y: page.h / 2 - 60, w: page.w * 0.8, h: 120,
        fontSize: Math.round(page.w / 12),
      }, preset));
      l.name = (l.text || '').slice(0, 20);
      this.addLayer(l);
    };
    box.appendChild(el('div', { class: 'ed-grid', style: { gap: '9px' } }, [
      el('button', { class: 'ed-item', style: { padding: '14px' }, onclick: () => add({ text: 'عنوان رئيسي', fontWeight: 900, fontSize: Math.round(this.page.w / 9) }), html: `<div style="font-family:Cairo;font-weight:900;font-size:20px">عنوان رئيسي</div>` }),
      el('button', { class: 'ed-item', style: { padding: '14px' }, onclick: () => add({ text: 'عنوان فرعي', fontWeight: 700, fontSize: Math.round(this.page.w / 16) }), html: `<div style="font-family:Cairo;font-weight:700;font-size:16px">عنوان فرعي</div>` }),
      el('button', { class: 'ed-item', style: { padding: '14px' }, onclick: () => add({ text: 'نص عادي هنا', fontWeight: 400, fontSize: Math.round(this.page.w / 26), fontFamily: 'Almarai' }), html: `<div style="font-family:Almarai;font-size:13px">نص عادي هنا</div>` }),
      el('button', { class: 'ed-item', style: { padding: '14px' }, onclick: () => add({ text: '٥٠٪', fontWeight: 900, fontSize: Math.round(this.page.w / 4), fontFamily: 'Cairo' }), html: `<div style="font-family:Cairo;font-weight:900;font-size:24px">٥٠٪</div>` }),
    ]));

    box.appendChild(el('hr', { class: 'divider' }));
    box.appendChild(el('div', { class: 'ed-sec-title', text: 'نصوص جاهزة' }));
    const presets = ['خصم يصل إلى ٥٠٪', 'عرض لفترة محدودة', 'اطلب الآن', 'شحن مجاني', 'الجودة أولاً', 'كل عام وأنتم بخير', 'افتتاح جديد', 'تابعونا', 'www.yoursite.com', '٠١٠٠ ٠٠٠ ٠٠٠٠'];
    const pw = el('div', { class: 'col', style: { gap: '6px' } });
    presets.forEach((p) => pw.appendChild(el('button', {
      class: 'ed-mini', style: { width: '100%', justifyContent: 'flex-start' }, text: p,
      onclick: () => add({ text: p, fontSize: Math.round(this.page.w / 16), fontWeight: 600, color: '#111827' }),
    })));
    box.appendChild(pw);

    clear(this.panelBody);
    this.panelBody.appendChild(box);
  }

  /* ------- الأشكال ------- */
  panelShapes() {
    const grid = el('div', { class: 'ed-grid c3' });
    SHAPES.forEach((s) => {
      grid.appendChild(el('button', {
        class: 'ed-item', title: s.label,
        onclick: () => {
          const page = this.page;
          const size = Math.min(page.w, page.h) * 0.28;
          const l = makeLayer('shape', {
            shape: s.id, name: s.label,
            w: s.id === 'line' ? page.w * 0.6 : size,
            h: s.id === 'line' ? 12 : size,
            x: page.w / 2 - size / 2, y: page.h / 2 - size / 2,
            fill: this._lastColor || '#7c5cff',
            radius: s.id === 'roundrect' ? 24 : 0,
          });
          this.addLayer(l);
        },
      }, [
        el('div', { class: 'ei-thumb' }, [el('div', { html: `<svg viewBox="0 0 24 24" width="30" height="30" fill="#98a2b8"><path d="${s.icon}"/></svg>` })]),
        el('div', { class: 'ei-label', text: s.label }),
      ]));
    });
    clear(this.panelBody);
    this.panelBody.appendChild(grid);
  }

  /* ------- الصور ------- */
  panelImages() {
    const box = el('div');
    box.appendChild(el('div', {
      class: 'ed-dropzone',
      html: icon('upload') + `<div>اسحب صورة هنا أو اضغط للاختيار — اختيار متعدد مدعوم</div>`,
      onclick: () => this.pickImage(),
    }));
    const urlInput = el('input', { class: 'ed-in', placeholder: t('ed_importUrlPh'), style: { flex: '1', minWidth: '0' } });
    box.appendChild(el('div', { class: 'ed-urlrow' }, [
      urlInput,
      el('button', {
        class: 'ed-mini', text: t('ed_importUrl'),
        onclick: async () => {
          const u = urlInput.value.trim();
          if (!u) return;
          try {
            const r = await fetch(u);
            if (!r.ok) throw new Error(r.status);
            const blob = await r.blob();
            const data = await readFileAsDataURL(new File([blob], 'imported'));
            await ensureImage(data);
            await this.addImage(data);
            toast(t('ed_imported'), 'ok');
          } catch (e) {
            toast('تعذّر الاستيراد: ' + e.message, 'err');
          }
        },
      }),
    ]));

    box.appendChild(el('hr', { class: 'divider' }));
    box.appendChild(el('div', { class: 'ed-sec-title', text: 'مكتبة الاستوديو' }));
    const grid = el('div', { class: 'ed-grid c2' });
    (STOCK || []).forEach((src) => {
      grid.appendChild(el('button', {
        class: 'ed-item', onclick: () => this.addImage(src),
      }, [el('div', { class: 'ei-thumb' }, [el('img', { src, loading: 'lazy', alt: '' })])]));
    });
    box.appendChild(grid);

    box.appendChild(el('hr', { class: 'divider' }));
    box.appendChild(el('div', { class: 'ed-sec-title', text: 'الملفات المرفوعة' }));
    const mine = el('div', { class: 'ed-grid c3' });
    (state.assets || []).filter((a) => a.type === 'image').forEach((a) => {
      mine.appendChild(el('button', {
        class: 'ed-item', title: a.name,
        onclick: async () => {
          const full = await import('../api.js').then((m) => m.api.asset(a.id)).catch(() => null);
          if (full && full.asset && full.asset.data) this.addImage(full.asset.data);
          else toast('تعذّر تحميل الملف', 'err');
        },
      }, [el('div', { class: 'ei-thumb' }, [el('div', { class: 'ei-label', text: a.name })])]));
    });
    if (!(state.assets || []).length) mine.appendChild(el('div', { class: 'dim', text: t('noData'), style: { fontSize: '12px' } }));
    box.appendChild(mine);

    clear(this.panelBody);
    this.panelBody.appendChild(box);
  }

  /* ------- الملصقات ------- */
  panelStickers() {
    const box = el('div');
    EMOJI_SETS.forEach((set) => {
      box.appendChild(el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: set.name })]));
      const grid = el('div', { class: 'ed-emoji-grid' });
      set.items.forEach((e) => {
        grid.appendChild(el('button', {
          class: 'ed-emoji', text: e,
          onclick: () => {
            const size = Math.min(this.page.w, this.page.h) * 0.2;
            this.addLayer(makeLayer('emoji', {
              text: e, name: e, w: size, h: size, fontSize: size * 0.8,
              x: this.page.w / 2 - size / 2, y: this.page.h / 2 - size / 2,
            }));
          },
        }));
      });
      box.lastChild.appendChild(grid);
    });
    clear(this.panelBody);
    this.panelBody.appendChild(box);
  }

  /* ------- الخلفية ------- */
  panelBackground() {
    const box = el('div');
    const bg = this.page.bg || (this.page.bg = { type: 'color', color: '#ffffff' });

    const tabs = el('div', { class: 'seg' }, [
      el('button', { text: t('ed_solid'), class: bg.type === 'color' ? 'active' : '', onclick: () => { this.page.bg = { type: 'color', color: '#ffffff' }; this.renderPanel(); this.commitBg(); } }),
      el('button', { text: t('ed_gradient'), class: bg.type === 'gradient' ? 'active' : '', onclick: () => { this.page.bg = { type: 'gradient', angle: 135, stops: [{ c: '#7c5cff', at: 0 }, { c: '#22d3ee', at: 1 }] }; this.renderPanel(); this.commitBg(); } }),
      el('button', { text: t('ed_pattern'), class: bg.type === 'pattern' ? 'active' : '', onclick: () => { this.page.bg = { type: 'pattern', color: '#ffffff', src: PATTERNS[0].svg('#ffffff', '#e2e8f0'), scale: 2 }; this.renderPanel(); this.commitBg(); } }),
      el('button', { text: t('ed_images'), class: bg.type === 'image' ? 'active' : '', onclick: () => { this.page.bg = { type: 'image', src: '' }; this.renderPanel(); this.commitBg(); } }),
    ]);
    box.appendChild(tabs);
    box.appendChild(el('hr', { class: 'divider' }));

    if (bg.type === 'color') {
      box.appendChild(this.colorRow('اللون', bg.color || '#ffffff', (c) => { bg.color = c; this.commitBg(); }));
      box.appendChild(this.paletteRow((c) => { bg.color = c; this.commitBg(); this.renderPanel(); }));
    }

    if (bg.type === 'gradient') {
      box.appendChild(this.sliderRow('الزاوية', bg.angle == null ? 135 : bg.angle, 0, 360, 1, '°', (v) => { bg.angle = v; this.commitBg(); }));
      (bg.stops || []).forEach((s, i) => {
        box.appendChild(this.colorRow('لون ' + (i + 1), s.c, (c) => { s.c = c; this.commitBg(); }));
        box.appendChild(this.sliderRow('موضع ' + (i + 1), Math.round(s.at * 100), 0, 100, 1, '%', (v) => { s.at = v / 100; this.commitBg(); }));
      });
      box.appendChild(el('button', {
        class: 'ed-mini', text: '+ إضافة لون',
        onclick: () => { bg.stops.push({ c: '#ffffff', at: 1 }); this.renderPanel(); this.commitBg(); },
      }));
      box.appendChild(el('hr', { class: 'divider' }));
      box.appendChild(el('div', { class: 'ed-sec-title', text: 'تدرجات جاهزة' }));
      const gg = el('div', { class: 'ed-swatches' });
      GRADIENTS.forEach(([a, b]) => {
        gg.appendChild(el('button', {
          class: 'ed-sw', style: { background: `linear-gradient(135deg, ${a}, ${b})`, width: '44px', height: '30px' },
          onclick: () => { bg.stops = [{ c: a, at: 0 }, { c: b, at: 1 }]; this.renderPanel(); this.commitBg(); },
        }));
      });
      box.appendChild(gg);
    }

    if (bg.type === 'pattern') {
      const pg = el('div', { class: 'ed-grid c3' });
      PATTERNS.forEach((p) => {
        pg.appendChild(el('button', {
          class: 'ed-item',
          onclick: () => {
            const c1 = bg.color || '#ffffff';
            const c2 = bg.patternColor || '#e2e8f0';
            bg.src = p.svg(c1, c2);
            bg.patternId = p.id;
            this.commitBg(); this.renderPanel();
          },
        }, [
          el('div', { class: 'ei-thumb', style: { backgroundImage: `url("${p.svg('#ffffff', '#e2e8f0')}")`, backgroundSize: '40px' } }),
          el('div', { class: 'ei-label', text: p.label }),
        ]));
      });
      box.appendChild(pg);
      box.appendChild(this.colorRow('لون الخلفية', bg.color || '#ffffff', (c) => { bg.color = c; this.rebuildPattern(); }));
      box.appendChild(this.colorRow('لون النقش', bg.patternColor || '#e2e8f0', (c) => { bg.patternColor = c; this.rebuildPattern(); }));
      box.appendChild(this.sliderRow('حجم النقش', bg.scale || 2, 0.5, 8, 0.5, '×', (v) => { bg.scale = v; this.commitBg(); }));
    }

    if (bg.type === 'image') {
      box.appendChild(el('div', { class: 'ed-dropzone', html: icon('upload') + `<div>اختر صورة للخلفية</div>`, onclick: async () => { const src = await this.pickImage(false); if (src) { bg.src = src; this.commitBg(); } } }));
      box.appendChild(el('hr', { class: 'divider' }));
      const g = el('div', { class: 'ed-grid c2' });
      (STOCK || []).forEach((src) => g.appendChild(el('button', { class: 'ed-item', onclick: () => { bg.src = src; this.commitBg(); } }, [el('div', { class: 'ei-thumb' }, [el('img', { src, loading: 'lazy' })])])));
      box.appendChild(g);
    }

    clear(this.panelBody);
    this.panelBody.appendChild(box);
  }

  rebuildPattern() {
    const bg = this.page.bg;
    const p = PATTERNS.find((x) => x.id === bg.patternId) || PATTERNS[0];
    bg.src = p.svg(bg.color || '#ffffff', bg.patternColor || '#e2e8f0');
    this.commitBg();
  }

  commitBg() {
    this.markDirty();
    this.drawCanvas();
    this.renderPages();
    clearTimeout(this._bgT);
    this._bgT = setTimeout(() => this.pushHistory(), 500);
  }

  /* ------- الرفع ------- */
  /* ------- كود QR ------- */

  /* ---------------- Phase 7: لوحة AI ---------------- */
  _brandPalette() {
    const c = this.doc && this.doc.clientId ? (state.clients || []).find((x) => x.id === this.doc.clientId) : null;
    const cols = (c && c.brandKit && Array.isArray(c.brandKit.colors) && c.brandKit.colors.length >= 3) ? c.brandKit.colors : null;
    return cols ? [cols[0], cols[1], cols[2]] : ['#7c5cff', '#f59e0b', '#111827'];
  }

  panelAI() {
    const b = this.panelBody;
    const pro = isPro(state.settings || []);
    const proBadge = (!pro) ? ' <span class="badge warn" style="font-size:9px">Pro</span>' : '';

    /* 1) أدوات الصورة */
    b.appendChild(el('div', { class: 'ed-sec-title', text: '🖼 أدوات الصورة (الليير المختار)' }));
    const one = this.one;
    const isImg = one && one.type === 'image';
    if (!isImg) {
      b.appendChild(el('div', { class: 'dim', style: { fontSize: '12px', marginBottom: '8px' }, text: 'اختار ليير صورة من الكانفس الأول' }));
    } else {
      const grid = el('div', { class: 'ed-grid', style: { gap: '8px' } });
      [['removebg', '✂️ تفريغ خلفية', true], ['enhance', '✨ تحسين', false], ['upscale', '🔍 تكبير ×2', false], ['colorize', '🎨 تلوين', true], ['retouch', '🧴 تنعيم', false]].forEach(([kind, label, proTool]) => {
        grid.appendChild(el('button', {
          class: 'ed-item', style: { padding: '11px 6px', fontSize: '12px' },
          html: label + (proTool ? proBadge : ''),
          onclick: async (e) => {
            const btn = e.currentTarget;
            const old = btn.innerHTML;
            btn.disabled = true; btn.innerHTML = '⏳…';
            try {
              const out = await processImage(one.src, kind);
              one.src = out;
              this.pushHistory(); this.drawCanvas(); this.markDirty();
              toast('تم ✓' + (proTool && !pro ? ' — بديل محلي، Pro لجودة أعلى' : ''), 'ok', 3000);
            } catch (err) { toast('فشلت المعالجة: ' + err.message, 'err'); }
            btn.disabled = false; btn.innerHTML = old;
          },
        }));
      });
      b.appendChild(grid);
    }

    /* 2) مولد التصميم */
    b.appendChild(el('hr', { class: 'divider' }));
    b.appendChild(el('div', { class: 'ed-sec-title', text: '🤖 مولد التصميم — وصف → 3 Layouts' }));
    const promptIn = el('textarea', { class: 'textarea', rows: 3, placeholder: 'مثال: بوست عرض تغيير زيت سيارات، احترافي، مساحة للسعر' });
    const results = el('div', { class: 'col', style: { gap: '8px' } });
    b.append(promptIn, el('button', {
      class: 'btn primary sm', style: { width: '100%', margin: '6px 0' },
      html: '✨ ولّد 3 Layouts' + proBadge,
      onclick: () => {
        const layouts = designLayouts(promptIn.value, this._brandPalette(), this.page.w, this.page.h);
        clear(results);
        const sW = 100, sH = Math.max(60, Math.round(100 * this.page.h / this.page.w));
        layouts.forEach((v) => {
          let inner = `<rect width="${sW}" height="${sH}" fill="${v.bg.color}"/>`;
          v.add.forEach((sp) => {
            const x = (sp.x / this.page.w * sW).toFixed(1), y = (sp.y / this.page.h * sH).toFixed(1);
            const w = (sp.w / this.page.w * sW).toFixed(1), h = (sp.h / this.page.h * sH).toFixed(1);
            inner += sp.type === 'shape'
              ? `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${sp.fill}" opacity="0.9" rx="2"/>`
              : `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#ffffff" opacity="0.3" rx="2"/>`;
          });
          results.appendChild(el('div', { class: 'ed-item', style: { padding: '8px', flexDirection: 'row', gap: '8px', alignItems: 'center' } }, [
            el('div', { style: { width: '64px', flexShrink: '0' }, html: `<svg viewBox="0 0 ${sW} ${sH}" style="width:100%;border-radius:6px;display:block">${inner}</svg>` }),
            el('b', { class: 'grow', style: { fontSize: '12px' }, text: v.name }),
            el('button', {
              class: 'btn sm primary', text: 'طبّق',
              onclick: () => {
                this.page.bg = JSON.parse(JSON.stringify(v.bg));
                v.add.forEach((spec) => { const l = makeLayer(spec.type, JSON.parse(JSON.stringify(spec))); l.name = (spec.text || spec.shape || 'AI').toString().slice(0, 18); this.page.layers.push(l); });
                this.pushHistory(); this.drawCanvas(); this.drawOverlay(); this.markDirty();
                toast('اتطبق layout «' + v.name + '» ✓', 'ok');
              },
            }),
          ]));
        });
      },
    }), results);

    /* 3) مولد صور/خلفيات */
    b.appendChild(el('hr', { class: 'divider' }));
    b.appendChild(el('div', { class: 'ed-sec-title', text: '🎨 مولد صور/خلفيات' }));
    const imgPrompt = el('input', { class: 'input', placeholder: 'وصف الخلفية… (ألوان/مود)' });
    b.append(imgPrompt, el('button', {
      class: 'btn sm', style: { width: '100%', marginTop: '6px' },
      html: '🖼 ولّد وأضف للكانفس' + proBadge,
      onclick: async (e) => {
        const btn = e.currentTarget;
        const old = btn.innerHTML;
        btn.disabled = true; btn.innerHTML = '⏳ توليد…';
        try {
          let data = null;
          if (pro) {
            try { const r = await api.ai({ action: 'image', prompt: imgPrompt.value }); if (r && r.image) data = r.image; } catch (err) { /* fallback */ }
          }
          if (!data) data = generateArt(imgPrompt.value || 'meem');
          await this.addImage(data);
          this.pushHistory(); this.markDirty();
          toast(pro ? 'اتولدت ✓' : 'اتولدت محليًا ✓ — مفتاح Pro = صور AI حقيقية', 'ok', 3500);
        } catch (err) { toast('فشل التوليد: ' + err.message, 'err'); }
        btn.disabled = false; btn.innerHTML = old;
      },
    }));
  }

  panelQR() {
    const box = el('div');
    let kind = 'url';
    const mainIn = el('input', { class: 'ed-in', placeholder: 'https://example.com', value: 'https://' });
    const phoneIn = el('input', { class: 'ed-in', placeholder: '201xxxxxxxxx', style: { display: 'none' } });
    const msgIn = el('input', { class: 'ed-in', placeholder: 'رسالة واتساب (اختياري)', style: { display: 'none' } });
    const kindSel = el('select', {
      class: 'ed-in',
      html: [['url', 'رابط / URL'], ['whatsapp', 'واتساب'], ['phone', 'مكالمة هاتفية'], ['text', 'نص'], ['email', 'بريد إلكتروني']]
        .map(([v, lab]) => `<option value="${v}">${lab}</option>`).join(''),
      onchange: (e) => {
        kind = e.target.value;
        const isWa = kind === 'whatsapp';
        phoneIn.style.display = (isWa || kind === 'phone') ? '' : 'none';
        msgIn.style.display = isWa ? '' : 'none';
        mainIn.style.display = (isWa || kind === 'phone') ? 'none' : '';
        mainIn.placeholder = kind === 'email' ? 'name@company.com' : kind === 'text' ? 'اكتب النص هنا…' : 'https://example.com';
      },
    });
    let fg = '#0f172a';
    const preview = el('div', { class: 'ed-row', style: { justifyContent: 'center', padding: '10px 0' } });

    const buildValue = () => {
      if (kind === 'whatsapp') return 'https://wa.me/' + phoneIn.value.replace(/[^0-9]/g, '') + (msgIn.value ? '?text=' + encodeURIComponent(msgIn.value) : '');
      if (kind === 'phone') return 'tel:' + phoneIn.value.replace(/[^0-9+]/g, '');
      if (kind === 'email') return 'mailto:' + mainIn.value.trim();
      return mainIn.value.trim();
    };

    const makeQR = () => {
      const val = buildValue();
      clear(preview);
      if (!val) { toast('اكتب المحتوى الأول', 'info'); return null; }
      try {
        const qr = qrcode(0, 'M');
        qr.addData(val);
        qr.make();
        const n = qr.getModuleCount();
        const mod = 10, quiet = 4;
        const c = document.createElement('canvas');
        c.width = c.height = (n + quiet * 2) * mod;
        const ctx = c.getContext('2d');
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, c.width, c.height);
        ctx.fillStyle = fg;
        for (let r = 0; r < n; r++) for (let col = 0; col < n; col++) {
          if (qr.isDark(r, col)) ctx.fillRect((col + quiet) * mod, (r + quiet) * mod, mod, mod);
        }
        const img = el('img', { src: c.toDataURL('image/png'), style: { width: '180px', height: '180px', borderRadius: '10px', border: '1px solid var(--line)' } });
        preview.appendChild(img);
        return { dataURL: c.toDataURL('image/png'), val };
      } catch (e) {
        toast('تعذّر توليد الكود: ' + e.message, 'err');
        return null;
      }
    };

    const genBtn = el('button', { class: 'btn sm', html: icon('refresh') + '<span>توليد</span>', onclick: () => makeQR() });
    const addBtn = el('button', {
      class: 'btn primary sm', html: icon('plus') + '<span>أضف للتصميم</span>',
      onclick: () => {
        const res = makeQR();
        if (!res) return;
        const size = Math.min(this.page.w, this.page.h) * 0.3;
        const l = makeLayer('image', {
          name: 'QR Code', src: res.dataURL, fit: 'contain',
          x: Math.round(this.page.w / 2 - size / 2), y: Math.round(this.page.h / 2 - size / 2),
          w: Math.round(size), h: Math.round(size),
        });
        this.page.layers.push(l);
        this.selected = [l.id];
        this.pushHistory(false, 'إضافة QR');
        this.markDirty();
        this.drawCanvas(); this.drawOverlay(); this.renderProps(); this.renderPages();
        toast('تمت إضافة الكود ✓', 'ok');
      },
    });

    box.appendChild(el('div', { class: 'ed-sec-title', text: 'نوع الكود' }));
    box.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: 'النوع' }), kindSel]));
    box.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: 'المحتوى' }), mainIn]));
    box.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: 'رقم واتساب' }), phoneIn]));
    box.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: 'رسالة' }), msgIn]));
    box.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: 'اللون' }), this.colorInput(fg, (c) => { fg = c; })]));
    box.appendChild(el('div', { class: 'ed-row wrap', style: { gap: '6px' } }, [genBtn, addBtn]));
    box.appendChild(preview);
    box.appendChild(el('div', { class: 'dim', style: { fontSize: '11px' }, text: 'يعمل بالكامل داخل المتصفح — بدون إنترنت أو خدمات خارجية.' }));
    clear(this.panelBody);
    this.panelBody.appendChild(box);
  }

  /* ------- سجل التعديلات ------- */
  panelHistory() {
    const box = el('div');
    box.appendChild(el('div', { class: 'dim', style: { fontSize: '11px', marginBottom: '6px' }, text: 'كل خطوة محفوظة — اضغط أي خطوة للرجوع إليها. Ctrl+Z تراجع · Ctrl+Y إعادة' }));
    const list = el('div', { class: 'col', style: { gap: '3px' } });
    [...this.history].map((h, i) => ({ h, i })).reverse().forEach(({ h, i }) => {
      const time = new Date(h.at).toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      list.appendChild(el('div', {
        class: 'ed-layer' + (i === this.hIndex ? ' sel' : ''),
        onclick: () => this.jumpHistory(i),
      }, [
        el('div', { class: 'el-name', text: `${i + 1}. ${h.label}` }),
        el('span', { class: 'dim', style: { fontSize: '11px' }, text: time }),
      ]));
    });
    if (!this.history.length) list.appendChild(el('div', { class: 'ed-empty-panel', text: 'لا توجد خطوات بعد' }));
    box.appendChild(list);
    clear(this.panelBody);
    this.panelBody.appendChild(box);
  }

  panelUpload() {
    const box = el('div');
    box.appendChild(el('div', {
      class: 'ed-dropzone',
      html: icon('upload') + `<div><b>رفع صورة للاستوديو</b><br>تتحفظ في مكتبة الأصول وتُستخدم في أي تصميم</div>`,
      onclick: () => this.pickImage(true),
    }));
    box.appendChild(el('hr', { class: 'divider' }));
    const list = el('div', { class: 'col', style: { gap: '6px' } });
    (state.assets || []).forEach((a) => {
      list.appendChild(el('div', { class: 'row', style: { padding: '6px', borderRadius: '8px', background: 'var(--panel-2)' } }, [
        el('div', { class: 'grow truncate', text: a.name, style: { fontSize: '13px' } }),
        el('span', { class: 'badge', text: Math.round((a.size || 0) / 1024) + ' KB' }),
      ]));
    });
    if (!(state.assets || []).length) list.appendChild(el('div', { class: 'dim', text: 'لا توجد أصول مرفوعة بعد', style: { fontSize: '12.5px' } }));
    box.appendChild(list);
    clear(this.panelBody);
    this.panelBody.appendChild(box);
  }

  /* ---------------- لوحة الخصائص ---------------- */
  renderProps() {
    clear(this.propsBody);
    // موبايل: الإعدادات تفتح تلقائيًا عند تحديد عنصر، وتُقفل عند فك التحديد
    if (this._isMobile()) {
      if (this.sel.length) { this.props.classList.add('open'); this.panel.classList.remove('open'); }
      else this.props.classList.remove('open');
    }
    const l = this.one;
    if (!l) {
      if (this.sel.length > 1) {
        this.propsBody.appendChild(el('div', { class: 'ed-empty-panel' }, [
          el('div', { html: icon('layers') }),
          el('div', { text: `${this.sel.length} عنصر محدد` }),
          this.alignRow(),
          el('div', { class: 'ed-row wrap', style: { justifyContent: 'center', marginTop: '10px' } }, [
            el('button', { class: 'ed-mini', text: '🔗 تجميع', onclick: () => this.groupSelected() }),
            el('button', { class: 'ed-mini', text: t('ed_duplicate'), onclick: () => this.duplicateSelected() }),
            el('button', { class: 'ed-mini', text: t('delete'), onclick: () => this.deleteSelected() }),
          ]),
        ]));
        return;
      }
      this.propsBody.appendChild(el('div', { class: 'ed-empty-panel' }, [
        el('div', { html: icon('target') }),
        el('div', { text: t('ed_noSelection') }),
        el('div', { class: 'dim', style: { fontSize: '12px', marginTop: '6px' }, text: t('ed_selectHint') }),
      ]));
      // خصائص الصفحة
      this.propsBody.appendChild(el('hr', { class: 'divider' }));
      this.propsBody.appendChild(el('div', { class: 'ed-sec-title', text: t('ed_page') }));
      this.propsBody.appendChild(el('div', { class: 'ed-row' }, [
        el('label', { text: t('width') }),
        el('input', { class: 'ed-in num', type: 'number', value: this.page.w, oninput: (e) => { this.page.w = +e.target.value || 50; this.scheduleDraw(); this.drawOverlay(); } }),
      ]));
      this.propsBody.appendChild(el('div', { class: 'ed-row' }, [
        el('label', { text: t('height') }),
        el('input', { class: 'ed-in num', type: 'number', value: this.page.h, oninput: (e) => { this.page.h = +e.target.value || 50; this.scheduleDraw(); this.drawOverlay(); } }),
      ]));
      this.propsBody.appendChild(el('button', { class: 'ed-mini', html: icon('palette') + `<span>${t('ed_background')}</span>`, onclick: () => this.setTool('background') }));
      return;
    }

    const P = [];

    /* الموضع والحجم */
    P.push(el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: t('ed_position') })]));
    const sec = P[P.length - 1];
    const num = (label, key, step = 1) => el('div', { class: 'ed-row' }, [
      el('label', { text: label }),
      el('input', {
        class: 'ed-in num', type: 'number', value: Math.round(l[key]), dataset: { prop: key },
        oninput: (e) => { l[key] = +e.target.value || 0; if (l.type === 'text' && key === 'w' && !l.autoFit) l.h = computeTextHeight(l); this.scheduleDraw(); this.drawOverlay(); this.markDirty(); },
        onchange: () => this.pushHistory(),
      }),
    ]);
    sec.appendChild(el('div', { class: 'ed-grid c2' }, [num('X', 'x'), num('Y', 'y')]));
    sec.appendChild(el('div', { class: 'ed-grid c2' }, [num(t('width'), 'w'), num(t('height'), 'h')]));
    sec.appendChild(el('div', { class: 'ed-grid c2' }, [
      (() => { const n = num('⟳', 'rot'); n.querySelector('input').max = 360; n.querySelector('input').min = -360; return n; })(),
      el('div', { class: 'ed-row' }, [
        el('label', { text: t('ed_opacity') }),
        el('input', {
          class: 'ed-in num', type: 'number', min: 0, max: 100, value: Math.round((l.opacity == null ? 1 : l.opacity) * 100),
          oninput: (e) => { l.opacity = Math.max(0, Math.min(100, +e.target.value || 0)) / 100; this.scheduleDraw(); this.markDirty(); },
          onchange: () => this.pushHistory(),
        }),
      ]),
    ]));
    sec.appendChild(this.alignRow());
    sec.appendChild(el('div', { class: 'ed-row wrap' }, [
      el('button', { class: 'ed-mini', title: t('ed_flipH'), text: '⇋', onclick: () => { l.flipX = !l.flipX; this.pushHistory(false, 'قلب أفقي'); this.markDirty(); this.drawCanvas(); } }),
      el('button', { class: 'ed-mini', title: t('ed_flipV'), text: '⇵', onclick: () => { l.flipY = !l.flipY; this.pushHistory(false, 'قلب رأسي'); this.markDirty(); this.drawCanvas(); } }),
      el('button', { class: 'ed-mini', title: 'ترتيب للأمام', text: '⬆', onclick: () => this.reorder(1) }),
      el('button', { class: 'ed-mini', title: 'ترتيب للخلف', text: '⬇', onclick: () => this.reorder(-1) }),
      el('button', { class: 'ed-mini', title: t('ed_duplicate'), html: icon('copy'), onclick: () => this.duplicateSelected() }),
      el('button', { class: 'ed-mini', title: t('delete'), html: icon('trash'), onclick: () => this.deleteSelected() }),
    ]));

    /* خصائص النص */
    if (l.type === 'text') {
      const s = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: t('ed_text') })]);
      const ta = el('textarea', { class: 'ed-in', rows: 3, oninput: (e) => { l.text = e.target.value; if (!l.autoFit) l.h = Math.max(30, Math.round(computeTextHeight(l))); this.scheduleDraw(); this.drawOverlay(); this.markDirty(); }, onchange: () => { this.pushHistory(); this.renderPages(); } });
      ta.value = l.text || '';
      s.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: 'المحتوى' }), ta]));

      const fontSel = el('select', { class: 'ed-in', html: fontOptionsHTML(l.fontFamily), onchange: async (e) => { l.fontFamily = e.target.value; await ensureFont(l.fontFamily, l.fontWeight); if (!l.autoFit) l.h = Math.max(30, Math.round(computeTextHeight(l))); this.pushHistory(false, 'تغيير الخط'); this.markDirty(); this.drawCanvas(); this.drawOverlay(); this.renderPages(); } });
      const fontUpBtn = el('button', {
        class: 'ed-mini', title: 'رفع خط من الجهاز (TTF/OTF/WOFF)', html: icon('upload'),
        onclick: () => {
          const inp = el('input', { type: 'file', accept: '.ttf,.otf,.woff,.woff2' });
          inp.addEventListener('change', async () => {
            const f = inp.files && inp.files[0];
            if (!f) return;
            try {
              toast('جارٍ تثبيت الخط…', 'info', 1500);
              const name = await addCustomFont(f);
              l.fontFamily = name;
              await ensureFont(name, l.fontWeight);
              this.pushHistory(false, 'رفع خط: ' + name);
              this.markDirty();
              this.drawCanvas(); this.renderProps(); this.renderPages();
              toast('تم تثبيت الخط «' + name + '» ✓', 'ok');
            } catch (e2) { toast('تعذّر قراءة الخط: ' + e2.message, 'err'); }
          });
          inp.click();
        },
      });
      s.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: t('ed_font') }), fontSel, fontUpBtn]));

      s.appendChild(el('div', { class: 'ed-grid c2' }, [
        el('div', { class: 'ed-row' }, [el('label', { text: t('ed_size') }), el('input', { class: 'ed-in num', type: 'number', min: 4, value: l.fontSize, oninput: (e) => { l.fontSize = Math.max(4, +e.target.value || 4); if (!l.autoFit) l.h = Math.max(30, Math.round(computeTextHeight(l))); this.scheduleDraw(); this.drawOverlay(); }, onchange: () => this.pushHistory() })]),
        el('div', { class: 'ed-row' }, [el('label', { text: t('ed_weight') }), el('select', { class: 'ed-in', html: [300, 400, 500, 600, 700, 800, 900].map((w) => `<option ${w === l.fontWeight ? 'selected' : ''}>${w}</option>`).join(''), onchange: async (e) => { l.fontWeight = +e.target.value; await ensureFont(l.fontFamily, l.fontWeight); if (!l.autoFit) l.h = Math.max(30, Math.round(computeTextHeight(l))); this.pushHistory(); this.drawCanvas(); this.drawOverlay(); } })]),
      ]));

      s.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: t('ed_color') }), this.colorInput(l.color, (c) => { l.color = c; this._lastColor = c; this.markDirty(); this.drawCanvas(); this.renderPages(); })]));
      s.appendChild(this.paletteRow((c) => { l.color = c; this.markDirty(); this.drawCanvas(); this.renderProps(); this.renderPages(); }));

      s.appendChild(el('div', { class: 'ed-row' }, [
        el('label', { text: t('ed_align') }),
        el('div', { class: 'seg' }, ['right', 'center', 'left'].map((a) => el('button', {
          text: a === 'right' ? '⇥' : a === 'center' ? '↔' : '⇤', class: l.align === a ? 'active' : '',
          onclick: () => { l.align = a; this.pushHistory(); this.drawCanvas(); this.renderProps(); },
        }))),
      ]));

      s.appendChild(this.sliderRow(t('ed_lineHeight'), Math.round((l.lineHeight || 1.3) * 100), 80, 300, 5, '%', (v) => { l.lineHeight = v / 100; if (!l.autoFit) l.h = Math.max(30, Math.round(computeTextHeight(l))); this.scheduleDraw(); this.drawOverlay(); }));
      s.appendChild(this.sliderRow(t('ed_letterSpacing'), l.letterSpacing || 0, -10, 40, 1, 'px', (v) => { l.letterSpacing = v; if (!l.autoFit) l.h = Math.max(30, Math.round(computeTextHeight(l))); this.scheduleDraw(); this.drawOverlay(); }));

      s.appendChild(el('div', { class: 'ed-row wrap' }, [
        el('label', { class: 'check' }, [el('input', { type: 'checkbox', checked: !!l.rtl, onchange: (e) => { l.rtl = e.target.checked; this.pushHistory(); this.drawCanvas(); } }), el('span', { text: 'عربي RTL' })]),
        el('label', { class: 'check' }, [el('input', { type: 'checkbox', checked: l.wrap !== false, onchange: (e) => { l.wrap = e.target.checked; if (!l.autoFit) l.h = Math.max(30, Math.round(computeTextHeight(l))); this.pushHistory(); this.drawCanvas(); this.drawOverlay(); } }), el('span', { text: 'التفاف النص' })]),
        el('label', { class: 'check' }, [el('input', { type: 'checkbox', checked: !!l.italic, onchange: (e) => { l.italic = e.target.checked; this.pushHistory(); this.drawCanvas(); } }), el('span', { text: 'مائل' })]),
        el('label', { class: 'check' }, [el('input', { type: 'checkbox', checked: !!l.autoFit, onchange: (e) => { l.autoFit = e.target.checked; if (!l.autoFit) l.h = Math.max(30, Math.round(computeTextHeight(l))); this.pushHistory(); this.drawCanvas(); this.drawOverlay(); } }), el('span', { text: 'ملاءمة تلقائية' })]),
        el('label', { class: 'check' }, [el('input', { type: 'checkbox', checked: !!l.bgBox, onchange: (e) => { l.bgBox = e.target.checked; this.pushHistory(); this.drawCanvas(); this.renderProps(); } }), el('span', { text: 'خلفية للنص' })]),
      ]));

      if (l.bgBox) {
        s.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: 'لون الخلفية' }), this.colorInput(l.bgBoxColor || '#000000', (c) => { l.bgBoxColor = c; this.markDirty(); this.drawCanvas(); })]));
        s.appendChild(this.sliderRow('شفافية الخلفية', Math.round((l.bgBoxOpacity == null ? .5 : l.bgBoxOpacity) * 100), 0, 100, 5, '%', (v) => { l.bgBoxOpacity = v / 100; this.markDirty(); this.drawCanvas(); }));
        s.appendChild(this.sliderRow('استدارة', l.bgBoxRadius || 0, 0, 80, 1, 'px', (v) => { l.bgBoxRadius = v; this.markDirty(); this.drawCanvas(); }));
      }

      s.appendChild(el('div', { class: 'ed-row' }, [
        el('label', { text: 'حد النص' }),
        el('input', { class: 'ed-in num', type: 'number', min: 0, value: (l.textStroke && l.textStroke.width) || 0, oninput: (e) => { l.textStroke = l.textStroke || { color: '#000', width: 0 }; l.textStroke.width = +e.target.value || 0; this.markDirty(); this.scheduleDraw(); }, onchange: () => this.pushHistory() }),
        this.colorInput((l.textStroke && l.textStroke.color) || '#000000', (c) => { l.textStroke = l.textStroke || { width: 0 }; l.textStroke.color = c; this.markDirty(); this.drawCanvas(); }),
      ]));

      s.appendChild(el('hr', { class: 'divider' }));
      s.appendChild(el('div', { class: 'ed-sec-title', text: t('ed_gradient') + ' للنص' }));
      s.appendChild(el('label', { class: 'check' }, [
        el('input', { type: 'checkbox', checked: !!(l.gradientFill && l.gradientFill.on), onchange: (e) => { l.gradientFill = Object.assign({ on: e.target.checked, angle: 0, stops: [{ c: '#7c5cff', at: 0 }, { c: '#22d3ee', at: 1 }] }, l.gradientFill || {}, { on: e.target.checked }); this.pushHistory(); this.drawCanvas(); this.renderProps(); } }),
        el('span', { text: 'تفعيل التدرج' }),
      ]));
      if (l.gradientFill && l.gradientFill.on) {
        (l.gradientFill.stops || []).forEach((st, i) => {
          s.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: 'لون ' + (i + 1) }), this.colorInput(st.c, (c) => { st.c = c; this.markDirty(); this.drawCanvas(); })]));
        });
        s.appendChild(this.sliderRow('الزاوية', l.gradientFill.angle || 0, 0, 360, 5, '°', (v) => { l.gradientFill.angle = v; this.markDirty(); this.drawCanvas(); }));
      }

      /* تعبئة النص بصورة */
      s.appendChild(el('hr', { class: 'divider' }));
      s.appendChild(el('div', { class: 'ed-sec-title', text: 'تعبئة النص بصورة' }));
      s.appendChild(el('label', { class: 'check' }, [
        el('input', {
          type: 'checkbox', checked: !!(l.imageFill && l.imageFill.src),
          onchange: async (e) => {
            if (e.target.checked) {
              if (!l.imageFill || !l.imageFill.src) {
                const src = await this.pickImage(false);
                if (!src) { e.target.checked = false; return; }
                l.imageFill = { src, scale: 1 };
              } else l.imageFill = l.imageFill || {};
            }
            this.pushHistory(false, 'تعبئة نص بصورة');
            this.markDirty(); this.drawCanvas(); this.renderProps();
          },
        }),
        el('span', { text: 'تفعيل (بدون تأثير على المنحني)' }),
      ]));
      if (l.imageFill && l.imageFill.src) {
        s.appendChild(el('div', { class: 'ed-row wrap' }, [
          el('button', { class: 'ed-mini', text: 'تغيير الصورة', onclick: async () => { const src = await this.pickImage(false); if (src) { l.imageFill.src = src; this.pushHistory(false, 'تغيير تعبئة'); this.markDirty(); this.drawCanvas(); } } }),
          el('button', { class: 'ed-mini', text: 'إزالة', onclick: () => { l.imageFill = null; this.pushHistory(false, 'إزالة تعبئة'); this.markDirty(); this.drawCanvas(); this.renderProps(); } }),
        ]));
        s.appendChild(this.sliderRow('تكبير الصورة داخل النص', Math.round((l.imageFill.scale || 1) * 100), 50, 300, 5, '%', (v) => { l.imageFill.scale = v / 100; this.markDirty(); this.drawCanvas(); }));
      }

      /* نص منحني */
      s.appendChild(el('hr', { class: 'divider' }));
      s.appendChild(el('div', { class: 'ed-sec-title', text: 'نص منحني (Curved)' }));
      s.appendChild(el('label', { class: 'check' }, [
        el('input', {
          type: 'checkbox', checked: !!(l.warp && l.warp.on),
          onchange: (e) => {
            l.warp = Object.assign({ on: e.target.checked, amount: 40 }, l.warp || {}, { on: e.target.checked });
            this.pushHistory(false, 'نص منحني');
            this.markDirty(); this.drawCanvas(); this.renderProps();
          },
        }),
        el('span', { text: 'تفعيل الانحناء' }),
      ]));
      if (l.warp && l.warp.on) {
        s.appendChild(this.sliderRow('مقدار الانحناء', l.warp.amount || 40, -100, 100, 5, '', (v) => { l.warp.amount = v; this.markDirty(); this.drawCanvas(); }));
        s.appendChild(el('div', { class: 'dim', style: { fontSize: '11px' }, text: 'موجب = قوس لأعلى، سالب = قوس لأسفل' }));
      }
      P.push(s);
    }

    /* التعبئة */
    if (l.type === 'shape' || l.type === 'rect') {
      const s = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: 'التعبئة' })]);
      const isGrad = l.fill && typeof l.fill === 'object';
      s.appendChild(el('div', { class: 'ed-row' }, [
        el('label', { text: 'النوع' }),
        el('select', {
          class: 'ed-in',
          html: `<option value="solid" ${!isGrad ? 'selected' : ''}>${t('ed_solid')}</option><option value="grad" ${isGrad ? 'selected' : ''}>${t('ed_gradient')}</option>`,
          onchange: (e) => {
            l.fill = e.target.value === 'solid' ? '#7c5cff' : { type: 'linear', angle: 135, stops: [{ c: '#7c5cff', at: 0 }, { c: '#22d3ee', at: 1 }] };
            this.pushHistory(); this.drawCanvas(); this.renderProps();
          },
        }),
      ]));
      if (!isGrad) {
        s.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: t('ed_color') }), this.colorInput(l.fill, (c) => { l.fill = c; this._lastColor = c; this.markDirty(); this.drawCanvas(); this.renderPages(); })]));
        s.appendChild(this.paletteRow((c) => { l.fill = c; this.markDirty(); this.drawCanvas(); this.renderProps(); }));
      } else {
        s.appendChild(this.sliderRow('الزاوية', l.fill.angle || 0, 0, 360, 5, '°', (v) => { l.fill.angle = v; this.markDirty(); this.drawCanvas(); }));
        (l.fill.stops || []).forEach((st, i) => s.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: 'لون ' + (i + 1) }), this.colorInput(st.c, (c) => { st.c = c; this.markDirty(); this.drawCanvas(); })])));
        const gg = el('div', { class: 'ed-swatches' });
        GRADIENTS.forEach(([a, b]) => gg.appendChild(el('button', { class: 'ed-sw', style: { background: `linear-gradient(135deg,${a},${b})` }, onclick: () => { l.fill.stops = [{ c: a, at: 0 }, { c: b, at: 1 }]; this.pushHistory(); this.drawCanvas(); this.renderProps(); } })));
        s.appendChild(gg);
      }
      P.push(s);
    }

    /* الصورة */
    if (l.type === 'image') {
      const s = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: t('ed_images') })]);
      s.appendChild(el('div', { class: 'ed-row' }, [
        el('label', { text: 'الملاءمة' }),
        el('select', {
          class: 'ed-in', html: ['cover', 'contain', 'fill'].map((f) => `<option ${l.fit === f ? 'selected' : ''}>${f}</option>`).join(''),
          onchange: (e) => { l.fit = e.target.value; this.pushHistory(); this.drawCanvas(); },
        }),
      ]));
      s.appendChild(el('div', { class: 'ed-row wrap' }, [
        el('button', { class: 'ed-mini', text: 'استبدال الصورة', onclick: async () => { const src = await this.pickImage(false); if (src) { l.src = src; await ensureImage(src); this.pushHistory(); this.drawCanvas(); this.renderPages(); } } }),
        el('button', { class: 'ed-mini', text: t('ed_extract'), onclick: async () => { const cs = await dominantColors(l.src); if (cs.length) { this._extracted = cs; toast('تم استخراج ' + cs.length + ' لون', 'ok'); this.renderProps(); } } }),
      ]));
      if (this._extracted) {
        s.appendChild(el('div', { class: 'ed-swatches', style: { marginTop: '8px' } }, this._extracted.map((c) => el('button', {
          class: 'ed-sw', style: { background: c }, title: c,
          onclick: () => { navigator.clipboard && navigator.clipboard.writeText(c); toast(c + ' — تم النسخ', 'ok', 1600); },
        }))));
      }

      /* قص بأشكال */
      s.appendChild(el('hr', { class: 'divider' }));
      s.appendChild(el('div', { class: 'ed-sec-title', text: 'قص الصورة بشكل' }));
      const crops = [
        ['none', 'بدون', '▭'], ['circle', 'دائرة', '◯'], ['heart', 'قلب', '♥'],
        ['star5', 'نجمة', '★'], ['triangle', 'مثلث', '▲'], ['diamond', 'معيّن', '◆'],
        ['hexagon', 'سداسي', '⬡'], ['roundrect', 'دائري الحواف', '▢'], ['speech', 'فقاعة', '💬'],
      ];
      s.appendChild(el('div', { class: 'ed-row wrap', style: { gap: '4px' } }, crops.map(([v, lab, sym]) =>
        el('button', {
          class: 'ed-mini' + ((l.cropShape || 'none') === v ? ' active' : ''), title: lab, text: sym,
          onclick: () => { l.cropShape = v === 'none' ? null : v; this.pushHistory(false, 'قص: ' + lab); this.markDirty(); this.drawCanvas(); this.renderProps(); },
        })
      )));
      P.push(s);
    }

    /* الحدود والاستدارة */
    if (l.type === 'shape' || l.type === 'image') {
      const s = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: t('ed_stroke') + ' / ' + t('ed_radius') })]);
      s.appendChild(el('div', { class: 'ed-row' }, [
        el('label', { text: 'سماكة الحد' }),
        el('input', { class: 'ed-in num', type: 'number', min: 0, value: (l.stroke && l.stroke.width) || 0, oninput: (e) => { l.stroke = l.stroke || { color: '#000' }; l.stroke.width = +e.target.value || 0; this.markDirty(); this.scheduleDraw(); }, onchange: () => this.pushHistory() }),
        this.colorInput((l.stroke && l.stroke.color) || '#000000', (c) => { l.stroke = l.stroke || { width: 0 }; l.stroke.color = c; this.markDirty(); this.drawCanvas(); }),
      ]));
      s.appendChild(this.sliderRow(t('ed_radius'), l.radius || 0, 0, Math.round(Math.min(l.w, l.h) / 2), 1, 'px', (v) => { l.radius = v; this.markDirty(); this.drawCanvas(); }));
      P.push(s);
    }

    /* الظل */
    const sh = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: t('ed_shadow') })]);
    sh.appendChild(el('label', { class: 'check' }, [
      el('input', {
        type: 'checkbox', checked: !!l.shadow,
        onchange: (e) => { l.shadow = e.target.checked ? { color: 'rgba(0,0,0,.45)', blur: 24, x: 0, y: 10, width: 1 } : null; this.pushHistory(); this.drawCanvas(); this.renderProps(); },
      }), el('span', { text: 'تفعيل الظل' }),
    ]));
    if (l.shadow) {
      sh.appendChild(el('div', { class: 'ed-row' }, [el('label', { text: 'اللون' }), this.colorInput(l.shadow.color || '#000000', (c) => { l.shadow.color = c; this.markDirty(); this.drawCanvas(); })]));
      sh.appendChild(this.sliderRow('الضبابية', l.shadow.blur || 0, 0, 120, 1, 'px', (v) => { l.shadow.blur = v; this.markDirty(); this.drawCanvas(); }));
      sh.appendChild(this.sliderRow('إزاحة X', l.shadow.x || 0, -100, 100, 1, 'px', (v) => { l.shadow.x = v; this.markDirty(); this.drawCanvas(); }));
      sh.appendChild(this.sliderRow('إزاحة Y', l.shadow.y || 0, -100, 100, 1, 'px', (v) => { l.shadow.y = v; this.markDirty(); this.drawCanvas(); }));
    }
    P.push(sh);

    /* الفلاتر */
    const f = l.filters || (l.filters = { brightness: 100, contrast: 100, saturate: 100, blur: 0, grayscale: 0, sepia: 0, hue: 0, sharpen: 0, dodge: 0, burn: 0, invert: 0 });
    const fs = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: t('ed_filters') })]);
    const filt = (label, key, min, max, unit, reset) => this.sliderRow(label, f[key] == null ? reset : f[key], min, max, 1, unit, (v) => { f[key] = v; this.markDirty(); this.drawCanvas(); });
    fs.appendChild(filt(t('ed_brightness'), 'brightness', 0, 300, '%', 100));
    fs.appendChild(filt(t('ed_contrast'), 'contrast', 0, 300, '%', 100));
    fs.appendChild(filt(t('ed_saturate'), 'saturate', 0, 300, '%', 100));
    fs.appendChild(filt(t('ed_grayscale'), 'grayscale', 0, 100, '%', 0));
    fs.appendChild(filt(t('ed_sepia'), 'sepia', 0, 100, '%', 0));
    fs.appendChild(filt(t('ed_hue'), 'hue', 0, 360, '°', 0));
    fs.appendChild(filt(t('ed_blur'), 'blur', 0, 60, 'px', 0));
    fs.appendChild(filt(t('ed_sharpen'), 'sharpen', 0, 100, '%', 0));
    fs.appendChild(filt(t('ed_dodge'), 'dodge', 0, 100, '%', 0));
    fs.appendChild(filt(t('ed_burn'), 'burn', 0, 100, '%', 0));
    fs.appendChild(filt(t('ed_invert'), 'invert', 0, 100, '%', 0));
    fs.appendChild(el('button', { class: 'ed-mini', text: 'إعادة ضبط الفلاتر', onclick: () => { l.filters = { brightness: 100, contrast: 100, saturate: 100, blur: 0, grayscale: 0, sepia: 0, hue: 0, sharpen: 0, dodge: 0, burn: 0, invert: 0 }; this.pushHistory(); this.drawCanvas(); this.renderProps(); } }));
    P.push(fs);

    /* الدمج */
    const BLEND_AR = {
      'source-over': 'عادي', multiply: 'ضرب', screen: 'شاشة', overlay: 'تراكب', darken: 'تغميق', lighten: 'تفتيح',
      'color-dodge': 'إنارة لونية', 'color-burn': 'إحراق لوني', 'hard-light': 'ضوء قوي', 'soft-light': 'ضوء ناعم',
      difference: 'فرق', exclusion: 'استبعاد', hue: 'صبغة', saturation: 'تشبع', color: 'لون', luminosity: 'إضاء ة'.replace(' ', ''),
    };
    if (getLang() !== 'ar') Object.keys(BLEND_AR).forEach((k) => { BLEND_AR[k] = k; });
    const bl = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: t('ed_blend') })]);
    bl.appendChild(el('select', {
      class: 'ed-in',
      html: ['source-over', 'multiply', 'screen', 'overlay', 'darken', 'lighten', 'color-dodge', 'color-burn', 'hard-light', 'soft-light', 'difference', 'exclusion', 'hue', 'saturation', 'color', 'luminosity']
        .map((b) => `<option value="${b}" ${l.blend === b ? 'selected' : ''}>${BLEND_AR[b] || b}</option>`).join(''),
      onchange: (e) => { l.blend = e.target.value; this.pushHistory(); this.drawCanvas(); },
    }));
    P.push(bl);

    /* القناع (V2-E2) */
    const mk = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: t('ed_mask') })]);
    if (l.mask) mk.appendChild(el('div', { class: 'ed-hint-sm', text: '🎭 ' + t('ed_maskOn') }));
    mk.appendChild(el('div', { class: 'ed-mini-row' }, [
      el('button', { class: 'ed-mini', text: t('ed_maskFromSel'), disabled: !this.paintSel, onclick: () => this.maskFromSelection() }),
      el('button', {
        class: 'ed-mini', text: t('ed_maskRemove'), disabled: !l.mask,
        onclick: () => { delete l.mask; this.pushHistory(); this.markDirty(); this.drawCanvas(); this.renderProps(); this.renderLayersIfOpen(); },
      }),
    ]));
    P.push(mk);

    P.forEach((n) => this.propsBody.appendChild(n));
  }

  renderPropsValues() {
    const l = this.one;
    if (!l) return;
    this.propsBody.querySelectorAll('input[data-prop]').forEach((inp) => {
      if (document.activeElement !== inp) inp.value = Math.round(l[inp.dataset.prop]);
    });
  }

  /* ---------------- عناصر مساعدة للوحة ---------------- */
  colorRow(label, value, onChange) {
    return el('div', { class: 'ed-row' }, [el('label', { text: label }), this.colorInput(value, onChange)]);
  }
  colorInput(value, onChange) {
    const v = (typeof value === 'string' && value.startsWith('#')) ? value : '#000000';
    const wrap = el('div', { class: 'ed-color-wrap', style: { flex: '1' } });
    const pick = el('input', { type: 'color', value: v });
    const txt = el('input', { class: 'ed-in', value: typeof value === 'string' ? value : '', style: { fontFamily: 'monospace', fontSize: '12px' } });
    pick.addEventListener('input', (e) => { txt.value = e.target.value; onChange(e.target.value); });
    txt.addEventListener('change', (e) => { const c = e.target.value.trim(); if (c) { pick.value = c.startsWith('#') ? c : '#' + c; onChange(c); } });
    wrap.append(pick, txt);
    return wrap;
  }
  sliderRow(label, value, min, max, step, unit, onChange) {
    const out = el('output', { text: value + unit });
    const r = el('input', { type: 'range', min, max, step, value, oninput: (e) => { out.textContent = e.target.value + unit; onChange(+e.target.value); }, onchange: () => this.pushHistory() });
    return el('div', { class: 'ed-row' }, [el('label', { text: label }), el('div', { class: 'ed-range', style: { flex: '1' } }, [r, out])]);
  }
  paletteRow(onPick) {
    const wrap = el('div', { class: 'col', style: { gap: '6px', marginTop: '4px' } });
    PALETTES.forEach((p) => {
      wrap.appendChild(el('div', { class: 'row', style: { gap: '5px' } }, [
        el('span', { class: 'dim', text: p.name, style: { fontSize: '11px', minWidth: '54px' } }),
        ...p.colors.map((c) => el('button', { class: 'ed-sw', style: { background: c, width: '22px', height: '22px' }, title: c, onclick: () => onPick(c) })),
      ]));
    });
    return wrap;
  }

  /* ---------------- عمليات ---------------- */
  addLayer(l) {
    this.page.layers.push(l);
    this.selected = [l.id];
    this.pushHistory();
    this.markDirty();
    this.drawCanvas();
    this.drawOverlay();
    this.renderProps();
    this.renderPages();
    this.renderLayersIfOpen();
    return l;
  }

  addText(preset = {}) {
    const page = this.page;
    const l = makeLayer('text', Object.assign({
      x: page.w * 0.1, y: page.h / 2 - 60, w: page.w * 0.8, h: 120,
      fontSize: Math.round(page.w / 12),
    }, preset));
    l.name = (l.text || '').slice(0, 20);
    return this.addLayer(l);
  }

  async addImage(src) {
    await ensureImage(src);
    const img = (await import('./render.js')).getImage(src);
    const page = this.page;
    let w = page.w * 0.5, h = page.w * 0.5;
    if (img && img.naturalWidth) {
      const r = img.naturalHeight / img.naturalWidth;
      w = Math.min(page.w * 0.6, img.naturalWidth);
      h = w * r;
      if (h > page.h * 0.6) { h = page.h * 0.6; w = h / r; }
    }
    const l = makeLayer('image', { src, name: 'صورة', x: Math.round(page.w / 2 - w / 2), y: Math.round(page.h / 2 - h / 2), w: Math.round(w), h: Math.round(h) });
    this.addLayer(l);
  }

  async addImageFile(file) {
    const data = await readFileAsDataURL(file);
    await ensureImage(data);
    await this.addImage(data);
    // حفظ في المكتبة
    try {
      await save('assets', { name: file.name, type: 'image', size: file.size, data });
      toast('تمت الإضافة للمكتبة', 'ok');
    } catch (e) { /* ignore */ }
  }

  pickImage(addToCanvas = true) {
    return new Promise((resolve) => {
      const inp = el('input', { type: 'file', accept: 'image/*', multiple: true, style: { display: 'none' } });
      document.body.appendChild(inp);
      inp.addEventListener('change', async () => {
        const files = Array.from(inp.files || []);
        inp.remove();
        if (!files.length) return resolve(null);
        let last = null;
        for (const f of files) {
          const data = await readFileAsDataURL(f);
          await ensureImage(data);
          if (addToCanvas) { await this.addImage(data); try { await save('assets', { name: f.name, type: 'image', size: f.size, data }); } catch (e) {} }
          last = data;
        }
        resolve(last);
      });
      inp.click();
    });
  }

  deleteSelected() {
    if (!this.selected.length) return;
    this.page.layers = this.page.layers.filter((l) => !this.selected.includes(l.id));
    this.selected = [];
    this.pushHistory();
    this.markDirty();
    this.drawCanvas();
    this.drawOverlay();
    this.renderProps();
    this.renderPages();
    this.renderLayersIfOpen();
  }

  duplicateSelected() {
    if (!this.selected.length) return;
    const gid = this.sel.length > 1 && this.sel[0].groupId ? this.sel[0].groupId : null;
    const clones = this.sel.map((l) => {
      const c = cloneLayer(l);
      c.id = uid('ly');
      c.x += 24; c.y += 24;
      c.name = (c.name || '') + ' (نسخة)';
      return c;
    });
    this.page.layers.push(...clones);
    this.selected = clones.map((c) => c.id);
    this.pushHistory(false, 'تكرار عنصر');
    this.markDirty();
    this.drawCanvas();
    this.drawOverlay();
    this.renderProps();
    this.renderPages();
  }

  /* ترتيب الطبقات: للأمام (+1) / للخلف (-1) */
  reorder(dir) {
    if (this.sel.length !== 1) return;
    const l = this.one;
    const i = this.page.layers.indexOf(l);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= this.page.layers.length) return;
    this.page.layers.splice(i, 1);
    this.page.layers.splice(j, 0, l);
    this.pushHistory(false, dir > 0 ? 'ترتيب للأمام' : 'ترتيب للخلف');
    this.markDirty();
    this.drawCanvas();
    this.renderLayersIfOpen();
  }

  /* ---------------- التجميع ---------------- */
  groupSelected() {
    if (this.sel.length < 2) { toast('حدد عنصرين أو أكثر للتجميع', 'info'); return; }
    const gid = uid('g');
    this.sel.forEach((l) => { l.groupId = gid; });
    this.pushHistory(false, 'تجميع عناصر');
    this.markDirty();
    this.drawOverlay();
    this.renderProps();
    this.renderLayersIfOpen();
    toast('تم التجميع ✓ (Ctrl+Shift+G للفك)', 'ok', 2200);
  }
  ungroupSelected() {
    if (!this.sel.some((l) => l.groupId)) return;
    this.sel.forEach((l) => { delete l.groupId; });
    this.pushHistory(false, 'فك تجميع');
    this.markDirty();
    this.drawOverlay();
    this.renderProps();
    this.renderLayersIfOpen();
  }

  alignSel(mode) {
    const sel = this.sel.filter((l) => !l.locked);
    if (!sel.length) return;
    // عنصر واحد → المحاذاة على الصفحة، أكثر من عنصر → على صندوق التحديد
    const box = sel.length === 1
      ? { x: 0, y: 0, w: this.page.w, h: this.page.h }
      : this.selectionBox();
    if (mode === 'distH' || mode === 'distV') {
      if (sel.length < 3) { toast('التوزيع يحتاج 3 عناصر على الأقل', 'info'); return; }
      const key = mode === 'distH' ? 'x' : 'y';
      const size = mode === 'distH' ? 'w' : 'h';
      const sorted = [...sel].sort((a, b) => a[key] - b[key]);
      const start = sorted[0][key];
      const end = Math.max(...sorted.map((l) => l[key] + l[size]));
      const total = sorted.reduce((a, l) => a + l[size], 0);
      const gap = (end - start - total) / (sorted.length - 1);
      let pos = start;
      sorted.forEach((l) => { l[key] = Math.round(pos); pos += l[size] + gap; });
    } else {
      sel.forEach((l) => {
        if (mode === 'left') l.x = Math.round(box.x);
        if (mode === 'cx') l.x = Math.round(box.x + box.w / 2 - l.w / 2);
        if (mode === 'right') l.x = Math.round(box.x + box.w - l.w);
        if (mode === 'top') l.y = Math.round(box.y);
        if (mode === 'cy') l.y = Math.round(box.y + box.h / 2 - l.h / 2);
        if (mode === 'bottom') l.y = Math.round(box.y + box.h - l.h);
      });
    }
    this.pushHistory(false, 'محاذاة');
    this.markDirty();
    this.drawCanvas();
    this.drawOverlay();
  }

  /* صف أزرار المحاذاة والتوزيع (يُستخدم في لوحة الخصائص) */
  alignRow() {
    const b = (label, title, mode) => el('button', { class: 'ed-mini', text: label, title, onclick: () => this.alignSel(mode) });
    return el('div', { class: 'ed-row wrap', style: { gap: '4px' } }, [
      b('⇤', 'محاذاة لليسار', 'left'),
      b('↔', 'توسيط أفقي', 'cx'),
      b('⇥', 'محاذاة لليمين', 'right'),
      b('⤒', 'محاذاة لأعلى', 'top'),
      b('↕', 'توسيط رأسي', 'cy'),
      b('⤓', 'محاذاة لأسفل', 'bottom'),
      b('↹', 'توزيع أفقي', 'distH'),
      b('⇹', 'توزيع رأسي', 'distV'),
    ]);
  }

  /* ---------------- الصفحات ---------------- */
  renderPages() {
    clear(this.pagesStrip);
    this.doc.pages.forEach((p, i) => {
      const thumb = el('div', {
        class: 'ed-page-thumb' + (i === this.pageIndex ? ' sel' : ''),
        onclick: () => { this.pageIndex = i; this.selected = []; this.refresh(true); },
      });
      const c = document.createElement('canvas');
      thumb.appendChild(c);
      const del = el('button', {
        class: 'pt-del', text: '×',
        onclick: (e) => {
          e.stopPropagation();
          if (this.doc.pages.length === 1) { toast('لا يمكن حذف الصفحة الوحيدة', 'warn'); return; }
          this.doc.pages.splice(i, 1);
          this.pageIndex = Math.max(0, Math.min(this.pageIndex, this.doc.pages.length - 1));
          this.selected = [];
          this.pushHistory(); this.markDirty(); this.refresh(true);
        },
      });
      thumb.appendChild(del);
      this.pagesStrip.appendChild(thumb);
      const scale = Math.min(1, 74 / p.h, 140 / p.w);
      preloadLayers(p.layers).then(() => renderPage(c, p, Math.max(0.02, scale))).then(() => {
        c.style.height = '70px';
        c.style.width = Math.max(20, (p.w * (70 / p.h))) + 'px';
      });
    });
    this.pagesStrip.appendChild(el('button', {
      class: 'ed-page-add', text: '+ ' + t('ed_addPage'),
      onclick: () => {
        const p = makePage(this.page.w, this.page.h, JSON.parse(JSON.stringify(this.page.bg || { type: 'color', color: '#ffffff' })));
        this.doc.pages.push(p);
        this.pageIndex = this.doc.pages.length - 1;
        this.selected = [];
        this.pushHistory(); this.markDirty(); this.refresh(true);
      },
    }));
    this.pagesStrip.appendChild(el('button', {
      class: 'ed-page-add', text: '⧉ ' + t('ed_duplicatePage'),
      onclick: () => {
        const p = JSON.parse(JSON.stringify(this.page));
        p.id = uid('pg');
        this.doc.pages.splice(this.pageIndex + 1, 0, p);
        this.pageIndex++;
        this.selected = [];
        this.pushHistory(); this.markDirty(); this.refresh(true);
      },
    }));
  }

  /* ---------------- التاريخ ---------------- */
  snapshot() { return JSON.stringify(this.doc); }

  pushHistory(initial, label) {
    const snap = this.snapshot();
    const cur = this.history[this.hIndex];
    if (cur && cur.snap === snap) return;
    this.history = this.history.slice(0, this.hIndex + 1);
    this.history.push({ snap, label: initial ? 'بداية' : (label || 'تعديل'), at: Date.now() });
    if (this.history.length > 80) this.history.shift();
    this.hIndex = this.history.length - 1;
    this.updateHistoryButtons();
    if (this.tool === 'history') this.panelHistory();
  }

  jumpHistory(i) {
    if (i < 0 || i >= this.history.length || i === this.hIndex) return;
    this.hIndex = i;
    this.restore(this.history[i].snap);
    if (this.tool === 'history') this.panelHistory();
  }

  restore(snap) {
    const sel = this.selected.slice();
    this.doc = JSON.parse(snap);
    if (this.pageIndex >= this.doc.pages.length) this.pageIndex = 0;
    this.selected = sel.filter((id) => this.page.layers.some((l) => l.id === id));
    this.titleInput.value = this.doc.title;
    this.markDirty();
    this.drawCanvas();
    this.drawOverlay();
    this.renderPages();
    this.renderProps();
    this.renderLayersIfOpen();
    this.updateHistoryButtons();
  }

  undo() {
    if (this.hIndex <= 0) return;
    this.hIndex--;
    this.restore(this.history[this.hIndex].snap);
    if (this.tool === 'history') this.panelHistory();
  }
  redo() {
    if (this.hIndex >= this.history.length - 1) return;
    this.hIndex++;
    this.restore(this.history[this.hIndex].snap);
    if (this.tool === 'history') this.panelHistory();
  }
  updateHistoryButtons() {
    if (this.btnUndo) this.btnUndo.disabled = this.hIndex <= 0;
    if (this.btnRedo) this.btnRedo.disabled = this.hIndex >= this.history.length - 1;
  }

  markDirty() {
    this.dirty = true;
    this.titleInput.style.borderColor = 'var(--warn)';
    clearTimeout(this._dirtyT);
    this._dirtyT = setTimeout(() => { this.titleInput.style.borderColor = ''; }, 1200);
    this.scheduleAutosave();
    this.scheduleDraft();
  }

  /* حفظ تلقائي — كل تعديل يُحفظ وحده خلال ثوانٍ */
  scheduleAutosave() {
    clearTimeout(this._autoT);
    this._autoT = setTimeout(async () => {
      if (!this.dirty || this._saving) return;
      this._saving = true;
      this.setSaveInd('saving');
      try { await this.save(true); this.setSaveInd('saved'); }
      catch (e) { this.setSaveInd('error'); }
      this._saving = false;
    }, 2500);
  }

  setSaveInd(st) {
    if (!this.saveInd) return;
    const map = { saving: '…جارٍ الحفظ', saved: '✓ محفوظ', error: 'تعذّر الحفظ' };
    this.saveInd.textContent = map[st] || '';
    this.saveInd.className = 'ed-saveind ' + (st || '');
    clearTimeout(this._indT);
    if (st === 'saved') this._indT = setTimeout(() => { this.saveInd.textContent = ''; }, 2200);
  }

  /* ---------------- حفظ وتصدير ---------------- */
  async save(silent) {
    try {
      const thumb = await pageToDataURL(this.doc.pages[0], Math.min(1, 420 / Math.max(this.doc.pages[0].w, this.doc.pages[0].h)), 'image/jpeg', 0.8);
      const payload = {
        id: this.doc.id || undefined,
        title: this.doc.title,
        w: this.page.w,
        h: this.page.h,
        pages: this.doc.pages,
        layers: this.page.layers,
        thumb,
        taskId: this.doc.taskId || (this.opts.task && this.opts.task.id) || null,
        projectId: this.doc.projectId || (this.opts.task && this.opts.task.projectId) || null,
        clientId: this.doc.clientId || null,
        dept: 'design',
        type: this.doc.type || (this.opts.task && this.opts.task.type) || 'سوشيال',
        owner: state.user.id,
        status: this.doc.status || 'progress',
      };
      const saved = await saveDesign(payload);
      this.doc.id = saved.id;
      this.clearDraft();
      this.designId = saved.id;
      this.dirty = false;
      this.titleInput.style.borderColor = '';
      if (!silent) toast(t('designSaved') + ' ✓', 'ok');
      return saved;
    } catch (e) {
      console.error(e);
      toast('تعذّر الحفظ: ' + e.message, 'err');
    }
  }

  async sendForReview() {
    await this.save(true);
    const task = this.opts.task || (this.doc.taskId ? state.tasks.find((x) => x.id === this.doc.taskId) : null);
    if (task) {
      task.status = 'review';
      task.files = task.files || [];
      if (!task.files.some((f) => f.designId === this.doc.id)) {
        task.files.push({ kind: 'design', designId: this.doc.id, name: this.doc.title, at: new Date().toISOString() });
      }
      task.comments = task.comments || [];
      task.comments.push({
        id: uid('cmt'), userId: state.user.id,
        text: `تم إرسال التصميم «${this.doc.title}» للمراجعة`, at: new Date().toISOString(),
      });
      await save('tasks', task);
    } else {
      await save('tasks', {
        dept: 'design', type: this.doc.type || 'سوشيال', title: this.doc.title,
        desc: 'تصميم مُرسل للمراجعة من المحرر', assignee: state.user.id, status: 'review',
        priority: 'medium', due: new Date(Date.now() + 86400000 * 2).toISOString().slice(0, 10),
        projectId: this.doc.projectId || '', comments: [], files: [{ kind: 'design', designId: this.doc.id, name: this.doc.title }],
      });
    }
    this.doc.status = 'review';
    // تسجيل رسمي في دورة الحياة: حالة review + نسخة V تلقائية + بث للفريق
    try {
      const res = await api.designSubmit(this.doc.id, '');
      if (res.version) this.doc._lastVersion = res.version.v;
      await this.syncDesignMeta();
    } catch (e) { /* التصميم محفوظ على أي حال */ }
    this.updateStatusUI();
    toast(t('sentForReview') + ' ✓ — وصل لقسم المراجعة والتسليمات', 'ok', 4200);
    if (this.opts.onDone) this.opts.onDone();
    setTimeout(() => { this.dirty = false; this.close(); }, 900);
  }

  /* ================= Phase 2 — دورة حياة التصميم ================= */

  static STATUS_META = {
    progress: ['مسودة', ''],
    draft: ['مسودة', ''],
    review: ['في المراجعة', 'warn'],
    changes: ['تعديلات مطلوبة', 'danger'],
    approved: ['معتمد داخليًا', 'ok'],
    client: ['عند العميل', 'pink'],
    client_approved: ['اعتمده العميل', 'ok'],
  };

  updateStatusUI() {
    const st = this.doc.status || 'progress';
    const [label, cls] = Editor.STATUS_META[st] || [st, ''];
    const unresolved = (this.doc.comments || []).filter((c) => !c.resolved).length;
    this.statusPill.className = 'ed-statuspill ' + cls;
    this.statusPill.innerHTML = `${escapeHTML(label)}${unresolved ? ` · 💬 ${unresolved}` : ''}`;

    // شريط المراجعة
    const bar = this.reviewBar;
    clear(bar);
    const isOwner = this.doc.owner && state.user && this.doc.owner === state.user.id;
    const canDecide = st === 'review' && (!isOwner || (state.user && state.user.role === 'admin'));
    const chip = el('span', { class: 'ed-rb-chip ' + (Editor.STATUS_META[st] || ['', ''])[1], text: label });
    bar.appendChild(chip);

    if (st === 'changes' && this.doc.review && this.doc.review.note) {
      bar.appendChild(el('span', { class: 'ed-rb-note', text: 'ملاحظات: ' + this.doc.review.note }));
    }
    if (st === 'client_approved' && this.doc.client && this.doc.client.note) {
      bar.appendChild(el('span', { class: 'ed-rb-note', text: this.doc.client.name + ': ' + this.doc.client.note }));
    }
    if (st === 'client' && this.doc.client && this.doc.client.decision === 'changes' && this.doc.client.note) {
      bar.appendChild(el('span', { class: 'ed-rb-note', text: 'ملاحظات العميل: ' + this.doc.client.note }));
    }

    bar.appendChild(el('div', { class: 'grow' }));
    bar.appendChild(el('button', {
      class: 'btn sm ghost', html: icon('chat') + `<span>التعليقات (${(this.doc.comments || []).length})</span>`,
      onclick: () => { this.setTool('comments'); if (!this._isMobile()) this.panel.classList.add('open'); },
    }));
    if (canDecide) {
      bar.appendChild(el('button', { class: 'btn sm danger', html: icon('close') + `<span>طلب تعديل</span>`, onclick: () => this.decisionDialog('changes') }));
      bar.appendChild(el('button', { class: 'btn sm ok', html: icon('check') + `<span>اعتماد</span>`, onclick: () => this.decisionDialog('approve') }));
    }
    if (st === 'approved') {
      bar.appendChild(el('button', { class: 'btn sm primary', html: icon('globe') + `<span>أرسله للعميل</span>`, onclick: () => this.shareDialog() }));
    }
    if (st === 'client' || st === 'client_approved') {
      bar.appendChild(el('button', { class: 'btn sm', html: icon('globe') + `<span>رابط العميل</span>`, onclick: () => this.shareDialog() }));
    }
    bar.hidden = st === 'progress' || st === 'draft';
  }

  async syncDesignMeta() {
    if (!this.designId) return;
    try {
      const d = await api.design(this.designId);
      ['comments', 'versions', 'status', 'review', 'client', 'share'].forEach((k) => {
        if (d[k] !== undefined) this.doc[k] = d[k];
      });
      this.updateStatusUI();
      this.renderPins();
    } catch (e) { /* ignore */ }
  }

  /* ---------------- دبابيس التعليقات ---------------- */
  renderPins() {
    if (!this.pinLayer) return;
    clear(this.pinLayer);
    (this.doc.comments || []).forEach((c, i) => {
      const pin = el('button', {
        class: 'ed-pin' + (c.resolved ? ' resolved' : ''),
        title: `${c.byName || ''}: ${c.text}`,
        text: String(i + 1),
        onclick: (e) => {
          e.stopPropagation();
          this.setTool('comments');
          if (!this._isMobile()) this.panel.classList.add('open');
          setTimeout(() => {
            const item = this.panelBody.querySelector(`[data-pin="${c.id}"]`);
            if (item) { item.classList.add('flash'); item.scrollIntoView({ block: 'nearest' }); }
          }, 60);
        },
      });
      pin.style.left = (c.x * 100) + '%';
      pin.style.top = (c.y * 100) + '%';
      this.pinLayer.appendChild(pin);
    });
  }

  addPinAt(p) {
    const nx = Math.max(0, Math.min(1, p.x / this.page.w));
    const ny = Math.max(0, Math.min(1, p.y / this.page.h));
    const inp = el('textarea', { class: 'input', rows: 3, placeholder: 'اكتب ملاحظتك على هذه النقطة…', style: { width: '100%' } });
    const m = modal({
      title: '📌 تعليق مثبّت',
      body: [inp],
      footer: [
        el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
        el('button', {
          class: 'btn primary', text: 'ثبّت التعليق',
          onclick: async () => {
            const text = inp.value.trim();
            if (!text) { toast('اكتب تعليقًا الأول', 'warn'); return; }
            m.close();
            try {
              if (!this.designId) await this.save(true);
              const res = await api.designComment(this.designId, { x: nx, y: ny, text });
              this.doc.comments = res.comments;
              this.renderPins();
              this.updateStatusUI();
              if (this.tool === 'comments') this.panelComments();
              toast('تم تثبيت التعليق ✓', 'ok');
            } catch (e) { toast('تعذّر إضافة التعليق: ' + e.message, 'err'); }
          },
        }),
      ],
    });
    setTimeout(() => inp.focus(), 80);
  }

  panelComments() {
    clear(this.panelBody);
    const list = this.doc.comments || [];
    const wrap = el('div');
    wrap.appendChild(el('div', { class: 'ed-hintbox', html: '💡 <b>اضغط على أي نقطة في التصميم</b> لتثبيت تعليق عليها — التعليقات تظهر كدبابيس مرقّمة للفريق كله.' }));
    if (!list.length) {
      wrap.appendChild(el('div', { class: 'dim', style: { padding: '18px 6px', textAlign: 'center', fontSize: '13px' }, text: 'لا توجد تعليقات بعد' }));
    }
    [...list].reverse().forEach((c, ri) => {
      const i = list.length - ri;
      const item = el('div', { class: 'ed-cmt' + (c.resolved ? ' resolved' : ''), dataset: { pin: c.id } }, [
        el('div', { class: 'ed-cmt-head' }, [
          el('span', { class: 'ed-pin num', text: String(i) }),
          el('b', { text: c.byName || '—' }),
          el('span', { class: 'dim', style: { fontSize: '11px' }, text: timeAgo(c.at) }),
          el('div', { class: 'grow' }),
          c.resolved ? el('span', { class: 'badge ok', text: 'تم ✓' }) : null,
        ]),
        el('div', { class: 'ed-cmt-text', text: c.text }),
        ...(c.replies || []).map((r) => el('div', { class: 'ed-cmt-reply' }, [
          el('b', { text: r.byName || '—' }), el('span', { text: ': ' + r.text }),
        ])),
        el('div', { class: 'row', style: { gap: '6px', marginTop: '6px' } }, [
          el('button', {
            class: 'btn ghost sm', text: 'رد',
            onclick: () => {
              const inp = el('input', { class: 'input', placeholder: 'اكتب ردًا…', style: { flex: '1' } });
              const row = el('div', { class: 'row', style: { gap: '6px', marginTop: '6px' } }, [
                inp,
                el('button', {
                  class: 'btn sm primary', text: '↩',
                  onclick: async () => {
                    if (!inp.value.trim()) return;
                    try {
                      const res = await api.designComment(this.designId, { id: c.id, op: 'reply', text: inp.value.trim() });
                      this.doc.comments = res.comments;
                      this.panelComments();
                    } catch (e) { toast('تعذّر الرد', 'err'); }
                  },
                }),
              ]);
              item.appendChild(row);
              setTimeout(() => inp.focus(), 50);
            },
          }),
          el('button', {
            class: 'btn ghost sm', text: c.resolved ? 'إعادة فتح' : 'تم ✓',
            onclick: async () => {
              try {
                const res = await api.designComment(this.designId, { id: c.id, op: c.resolved ? 'reopen' : 'resolve' });
                this.doc.comments = res.comments;
                this.renderPins();
                this.updateStatusUI();
                this.panelComments();
              } catch (e) { toast('تعذّر التحديث', 'err'); }
            },
          }),
        ]),
      ]);
      wrap.appendChild(item);
    });
    this.panelBody.appendChild(wrap);
  }

  /* ---------------- النسخ V1..Vn ---------------- */
  panelVersions() {
    clear(this.panelBody);
    const versions = this.doc.versions || [];
    const wrap = el('div');
    wrap.appendChild(el('button', {
      class: 'btn sm primary', style: { width: '100%', marginBottom: '10px' },
      html: icon('copy') + `<span>احفظ نسخة الآن</span>`,
      onclick: async () => {
        try {
          await this.save(true);
          await api.designVersion(this.designId, 'نسخة يدوية');
          await this.syncDesignMeta();
          this.panelVersions();
          toast('تم حفظ النسخة ✓', 'ok');
        } catch (e) { toast('تعذّر حفظ النسخة', 'err'); }
      },
    }));
    wrap.appendChild(el('div', { class: 'ed-hintbox', html: '🗂 كل <b>إرسال للمراجعة</b> و<b>اعتماد</b> ينشئ نسخة تلقائيًا — تقدر تقارن وتستعيد أي نسخة.' }));
    if (!versions.length) {
      wrap.appendChild(el('div', { class: 'dim', style: { padding: '18px 6px', textAlign: 'center', fontSize: '13px' }, text: 'لا توجد نسخ محفوظة بعد' }));
    }
    [...versions].reverse().forEach((v) => {
      wrap.appendChild(el('div', { class: 'ed-ver' }, [
        el('div', { class: 'ed-ver-thumb' }, v.thumb ? el('img', { src: v.thumb, alt: 'V' + v.v }) : el('span', { class: 'dim', text: '—' })),
        el('div', { class: 'grow', style: { minWidth: 0 } }, [
          el('div', { style: { fontWeight: '800', fontSize: '13px' }, text: `V${v.v} — ${v.note || ''}` }),
          el('div', { class: 'dim', style: { fontSize: '11px' }, text: `${v.byName || ''} · ${timeAgo(v.at)}` }),
        ]),
        el('button', { class: 'btn ghost sm', text: 'قارن', onclick: () => this.compareVersion(v) }),
        el('button', { class: 'btn outline sm', text: 'استعادة', onclick: () => this.restoreVersion(v) }),
      ]));
    });
    this.panelBody.appendChild(wrap);
  }

  async compareVersion(v) {
    const body = el('div');
    body.appendChild(el('div', { class: 'row', style: { gap: '10px' } }, [
      el('div', { style: { flex: '1', textAlign: 'center' } }, [
        el('div', { class: 'dim', style: { fontSize: '12px', marginBottom: '4px' }, text: `V${v.v} (${v.note || ''})` }),
        v.thumb ? el('img', { src: v.thumb, style: { width: '100%', borderRadius: '10px', border: '1px solid var(--line)' } }) : el('div', { class: 'dim', text: 'لا توجد صورة' }),
      ]),
      el('div', { style: { flex: '1', textAlign: 'center' } }, [
        el('div', { class: 'dim', style: { fontSize: '12px', marginBottom: '4px' }, text: 'الحالي' }),
        el('div', { class: 'ed-cmp-cur', text: '…' }),
      ]),
    ]));
    const m = modal({ title: `مقارنة — V${v.v} مقابل الحالي`, size: 'wide', body: [body] });
    try {
      const cur = await pageToDataURL(this.page, Math.min(1, 400 / Math.max(this.page.w, this.page.h)), 'image/jpeg', 0.82);
      const slot = body.querySelector('.ed-cmp-cur');
      slot.innerHTML = '';
      slot.appendChild(el('img', { src: cur, style: { width: '100%', borderRadius: '10px', border: '1px solid var(--line)' } }));
    } catch (e) { /* ignore */ }
  }

  restoreVersion(v) {
    const m = modal({
      title: `استعادة V${v.v}`,
      body: [el('p', { class: 'muted', text: `سيتم استبدال صفحات التصميم بنسخة V${v.v} (${v.note || ''}). التغيير الحالي يُحفظ في السجل ويمكن التراجع عنه.` })],
      footer: [
        el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
        el('button', {
          class: 'btn primary', text: 'استعادة',
          onclick: async () => {
            m.close();
            try {
              const res = await api.designRestore(this.designId, v.id);
              const d = res.design;
              this.doc.pages = d.pages || this.doc.pages;
              this.doc.layers = d.layers;
              this.pageIndex = 0;
              this.selected = [];
              this.pushHistory(true);
              await this.refresh(true);
              toast(`تمت استعادة V${v.v} ✓`, 'ok');
            } catch (e) { toast('تعذّر الاستعادة: ' + e.message, 'err'); }
          },
        }),
      ],
    });
  }

  /* ---------------- قرار المراجع (اعتماد / طلب تعديل) ---------------- */
  decisionDialog(decision) {
    const inp = el('textarea', {
      class: 'input', rows: 3, style: { width: '100%' },
      placeholder: decision === 'approve' ? 'ملاحظة اختيارية مع الاعتماد…' : 'اكتب التعديلات المطلوبة بالتفصيل…',
    });
    const m = modal({
      title: decision === 'approve' ? '✓ اعتماد التصميم' : '✗ طلب تعديل',
      body: [inp],
      footer: [
        el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
        el('button', {
          class: 'btn ' + (decision === 'approve' ? 'primary' : 'danger'),
          text: decision === 'approve' ? 'اعتماد' : 'إرسال طلب التعديل',
          onclick: async () => {
            const note = inp.value.trim();
            if (decision === 'changes' && !note) { toast('اكتب ملاحظات التعديل', 'warn'); return; }
            m.close();
            try {
              await api.designDecision(this.designId, decision, note);
              await this.syncDesignMeta();
              toast(decision === 'approve' ? 'تم الاعتماد ✓ — تقدر تبعتُه للعميل من زر الرابط' : 'تم إرسال طلب التعديل ✓', 'ok', 3600);
            } catch (e) { toast('تعذّر إرسال القرار: ' + e.message, 'err'); }
          },
        }),
      ],
    });
    setTimeout(() => inp.focus(), 80);
  }

  /* ---------------- رابط اعتماد العميل ---------------- */
  async shareDialog() {
    if (!this.designId) await this.save(true);
    const draw = () => {
      const body = el('div');
      const sh = this.doc.share;
      if (sh && !sh.revoked) {
        const url = location.origin + '/approve.html?t=' + sh.token;
        const inp = el('input', { class: 'input', value: url, readonly: true, style: { width: '100%', direction: 'ltr' }, onfocus: (e) => e.target.select() });
        body.appendChild(el('div', { class: 'field' }, [el('label', { text: 'رابط الاعتماد (يبعتُه للعميل — يفتح بدون تسجيل دخول)' }), inp]));
        body.appendChild(el('div', { class: 'row', style: { gap: '8px' } }, [
          el('button', {
            class: 'btn primary sm', html: icon('copy') + `<span>نسخ الرابط</span>`,
            onclick: async () => {
              try { await navigator.clipboard.writeText(url); toast('اتنسخ ✓', 'ok'); }
              catch (e) { inp.select(); toast('اعمل نسخ يدوي (Ctrl+C)', 'info', 3000); }
            },
          }),
          el('button', {
            class: 'btn ghost sm danger', text: 'إيقاف الرابط',
            onclick: async () => {
              await api.designShare(this.designId, true);
              this.doc.share.revoked = true;
              m.close();
              toast('تم إيقاف الرابط', 'ok');
            },
          }),
        ]));
        if (this.doc.client) {
          const c = this.doc.client;
          body.appendChild(el('div', { class: 'ed-hintbox', style: { marginTop: '10px' }, html: `${c.decision === 'approve' ? '✅' : '✏️'} <b>${escapeHTML(c.name)}</b> ${c.decision === 'approve' ? 'اعتمد التصميم' : 'طلب تعديل'}${c.note ? ': ' + escapeHTML(c.note) : ''} — ${timeAgo(c.at)}` }));
        }
        body.appendChild(el('div', { class: 'dim', style: { fontSize: '12px', marginTop: '8px' }, text: 'العميل يشوف التصميم بعلامة مائية، ويعتمد أو يطلب تعديلات — والرد يوصل هنا فورًا.' }));
      } else {
        body.appendChild(el('p', { class: 'muted', text: 'أنشئ رابطًا سريًا للعميل: يفتح صفحة اعتماد أنيقة (بدون حساب)، يشوف التصميم بعلامة مائية، ويضغط «اعتماد» أو «طلب تعديل» مع ملاحظاته.' }));
        body.appendChild(el('button', {
          class: 'btn primary', style: { width: '100%' }, html: icon('globe') + `<span>أنشئ رابط الاعتماد</span>`,
          onclick: async () => {
            try {
              const res = await api.designShare(this.designId);
              this.doc.share = { token: res.token, revoked: false };
              this.doc.status = this.doc.status === 'client_approved' ? 'client_approved' : 'client';
              this.updateStatusUI();
              m.close();
              this.shareDialog();
            } catch (e) { toast('تعذّر إنشاء الرابط: ' + e.message, 'err'); }
          },
        }));
      }
      return body;
    };
    const m = modal({ title: '🔗 اعتماد العميل', body: [draw()] });
  }

  /* ---------------- حفظ كقالب للفريق ---------------- */
  saveAsTemplate() {
    const name = el('input', { class: 'input', value: this.doc.title || '', style: { width: '100%' } });
    const cat = el('input', { class: 'input', value: 'فريق MEEM', style: { width: '100%' } });
    const m = modal({
      title: '⭐ حفظ كقالب للفريق',
      body: [
        el('div', { class: 'field' }, [el('label', { text: 'اسم القالب' }), name]),
        el('div', { class: 'field' }, [el('label', { text: 'التصنيف' }), cat]),
        el('div', { class: 'dim', style: { fontSize: '12px' }, text: `سيُحفظ بصفحاته الكاملة (${this.doc.pages.length} صفحة) ويظهر لكل الفريق في القوالب.` }),
      ],
      footer: [
        el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
        el('button', {
          class: 'btn primary', text: 'حفظ القالب',
          onclick: async () => {
            if (!name.value.trim()) { toast('اكتب اسمًا للقالب', 'warn'); return; }
            m.close();
            try {
              await save('templates', {
                name: name.value.trim(),
                cat: cat.value.trim() || 'فريق MEEM',
                custom: true,
                w: this.page.w, h: this.page.h,
                pages: JSON.parse(JSON.stringify(this.doc.pages)),
                by: state.user.id,
                at: new Date().toISOString(),
              });
              toast('اتحفظ كقالب للفريق ✓ — موجود في تبويب القوالب', 'ok', 3600);
            } catch (e) { toast('تعذّر حفظ القالب: ' + e.message, 'err'); }
          },
        }),
      ],
    });
  }

  applyTeamTemplate(tpl) {
    const pages = JSON.parse(JSON.stringify(tpl.pages || []));
    if (!pages.length) { toast('القالب فاضي', 'warn'); return; }
    this.doc.pages = pages;
    this.pageIndex = 0;
    this.selected = [];
    this.pushHistory(true);
    this.markDirty();
    this.refresh(true);
    toast('تم تطبيق قالب الفريق ✓', 'ok');
  }

  /* ---------------- Brand Kit داخل المحرر ---------------- */
  _brandKit() {
    const kit = (state.settings || []).find((s) => s.id === 'brandkit');
    return kit || {
      id: 'brandkit',
      colors: ['#7c5cff', '#22d3ee', '#0d1017', '#ffffff', '#ff4d8f'],
      fonts: ['Cairo', 'Tajawal', 'Almarai'],
      logo: '',
    };
  }

  async _saveBrandKit(kit) {
    try { await save('settings', kit); } catch (e) { /* ignore */ }
  }

  panelBrand() {
    clear(this.panelBody);
    const kit = this._brandKit();
    const wrap = el('div');

    // الألوان
    const colorsSec = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: 'ألوان البراند' })]);
    const swatches = el('div', { class: 'ed-swatches' });
    const drawSwatches = () => {
      clear(swatches);
      kit.colors.forEach((c, i) => {
        swatches.appendChild(el('button', {
          class: 'ed-swatch', title: c,
          style: { background: c },
          onclick: () => {
            const one = this.one;
            if (one && one.type === 'text') { one.color = c; }
            else if (one) { one.fill = c; }
            else { this._lastColor = c; toast('اتحفظ كلون افتراضي — اختار عنصرًا لتطبيقه فورًا', 'info'); }
            this._saveBrandKit(kit);
            this.markDirty(); this.drawCanvas(); this.renderProps(); this.renderPages();
          },
          oncontextmenu: (e) => {
            e.preventDefault();
            kit.colors.splice(i, 1);
            this._saveBrandKit(kit);
            drawSwatches();
          },
        }));
      });
      const picker = el('input', {
        type: 'color', value: '#7c5cff', class: 'ed-swatch-picker', title: 'أضف لونًا',
        onchange: (e) => {
          if (!kit.colors.includes(e.target.value)) {
            kit.colors.push(e.target.value);
            this._saveBrandKit(kit);
            drawSwatches();
          }
        },
      });
      swatches.appendChild(picker);
    };
    drawSwatches();
    colorsSec.appendChild(swatches);
    colorsSec.appendChild(el('div', { class: 'dim', style: { fontSize: '11px' }, text: 'ضغطة = تطبيق على العنصر المحدد · كليك يمين = حذف' }));
    wrap.appendChild(colorsSec);

    // الخطوط
    const fontsSec = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: 'خطوط البراند' })]);
    const sel = el('select', { class: 'ed-in', style: { width: '100%' } });
    sel.innerHTML = fontOptionsHTML((this.one && this.one.fontFamily) || kit.fonts[0] || 'Cairo');
    sel.addEventListener('change', async () => {
      const f = sel.value;
      if (!kit.fonts.includes(f)) kit.fonts.push(f);
      await ensureFont(f);
      this.sel.forEach((l) => { if (l.type === 'text') l.fontFamily = f; });
      if (!kit.fonts.includes(f)) { kit.fonts.push(f); }
      this._saveBrandKit(kit);
      this.markDirty(); this.drawCanvas(); this.renderProps();
    });
    fontsSec.appendChild(sel);
    fontsSec.appendChild(el('div', { class: 'row wrap', style: { gap: '5px', marginTop: '6px' } },
      kit.fonts.map((f) => el('span', { class: 'badge', text: f }))));
    wrap.appendChild(fontsSec);

    // الشعار
    const logoSec = el('div', { class: 'ed-sec' }, [el('div', { class: 'ed-sec-title', text: 'الشعار' })]);
    const logoBox = el('div', { class: 'ed-brand-logo' });
    const drawLogo = () => {
      clear(logoBox);
      if (kit.logo) {
        logoBox.appendChild(el('img', { src: kit.logo, alt: 'logo' }));
        logoBox.appendChild(el('button', {
          class: 'btn sm', text: 'أدخل الشعار في التصميم',
          onclick: () => {
            const w = Math.round(this.page.w * 0.35);
            const img = new Image();
            img.onload = () => {
              const h = Math.round(w * (img.naturalHeight / img.naturalWidth));
              const l = makeLayer('image', { src: kit.logo, w, h, x: Math.round((this.page.w - w) / 2), y: Math.round((this.page.h - h) / 2), fit: 'contain', name: 'الشعار' });
              this.page.layers.push(l);
              this.selected = [l.id];
              this.pushHistory(); this.markDirty();
              this.refresh(false);
              toast('اتضاف الشعار ✓', 'ok');
            };
            img.src = kit.logo;
          },
        }));
      } else {
        logoBox.appendChild(el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'لسه مفيش شعار مرفوع' }));
      }
    };
    drawLogo();
    logoSec.appendChild(logoBox);
    const file = el('input', {
      type: 'file', accept: 'image/*', style: { display: 'none' },
      onchange: async (e) => {
        const f = e.target.files && e.target.files[0];
        if (!f) return;
        kit.logo = await readFileAsDataURL(f);
        await this._saveBrandKit(kit);
        drawLogo();
        toast('اترفع الشعار ✓', 'ok');
      },
    });
    logoSec.appendChild(file);
    logoSec.appendChild(el('button', { class: 'btn sm outline', html: icon('upload') + `<span>${kit.logo ? 'تغيير الشعار' : 'ارفع الشعار'}</span>`, onclick: () => file.click() }));
    wrap.appendChild(logoSec);

    wrap.appendChild(el('div', { class: 'ed-hintbox', html: '🎨 الـ Brand Kit محفوظ لكل الفريق — أي مصمم يفتح أي تصميم يلاقي نفس الألوان والخطوط والشعار.' }));
    this.panelBody.appendChild(wrap);
  }

  /* ---------------- تغيير المقاس + نسخ بمقاسات ---------------- */
  resizePage(w, h) {
    const p = this.page;
    if (p.w === w && p.h === h) return;
    const k = Math.min(w / p.w, h / p.h);
    const dx = (w - p.w * k) / 2, dy = (h - p.h * k) / 2;
    p.layers.forEach((l) => this._scaleLayerForResize(l, k, dx, dy));
    p.w = w; p.h = h;
    this.selected = [];
    this.pushHistory();
    this.markDirty();
    this.fit();
    this.renderPages();
    toast(`تم تغيير المقاس إلى ${w}×${h} ✓`, 'ok');
  }

  _scaleLayerForResize(l, k, dx, dy) {
    l.x = Math.round(l.x * k + dx);
    l.y = Math.round(l.y * k + dy);
    l.w = Math.max(4, Math.round(l.w * k));
    l.h = Math.max(4, Math.round(l.h * k));
    if (l.fontSize) l.fontSize = Math.max(4, Math.round(l.fontSize * k));
    if (l.letterSpacing) l.letterSpacing = Math.round(l.letterSpacing * k * 10) / 10;
    if (l.radius) l.radius = Math.round(l.radius * k);
    if (l.stroke && l.stroke.width) l.stroke.width = Math.max(0, Math.round(l.stroke.width * k * 10) / 10);
    if (l.textStroke && l.textStroke.width) l.textStroke.width = Math.round(l.textStroke.width * k * 10) / 10;
    if (l.bgBoxRadius) l.bgBoxRadius = Math.round(l.bgBoxRadius * k);
    if (l.shadow) {
      l.shadow.x = Math.round((l.shadow.x || 0) * k);
      l.shadow.y = Math.round((l.shadow.y || 0) * k);
      l.shadow.blur = Math.round((l.shadow.blur || 0) * k);
    }
  }

  resizeDialog() {
    const QUICK = [
      { label: 'بوست إنستجرام', w: 1080, h: 1080 },
      { label: 'ستوري / ريلز', w: 1080, h: 1920 },
      { label: 'بوست X', w: 1600, h: 900 },
      { label: 'غلاف يوتيوب', w: 1280, h: 720 },
      { label: 'غلاف فيسبوك', w: 820, h: 312 },
      { label: 'بوست عمودي 4:5', w: 1080, h: 1350 },
    ];
    let customW = this.page.w, customH = this.page.h;
    const sizesBody = el('div');

    const grid = el('div', { class: 'cards-grid', style: { gridTemplateColumns: 'repeat(auto-fill,minmax(140px,1fr))' } });
    QUICK.forEach((q) => {
      grid.appendChild(el('button', {
        class: 'btn outline sm', style: { height: 'auto', flexDirection: 'column', padding: '9px', alignItems: 'flex-start', gap: '3px' },
        onclick: () => { m.close(); this.resizePage(q.w, q.h); },
      }, [
        el('div', { style: { fontSize: '12px', fontWeight: '700' }, text: q.label }),
        el('div', { class: 'dim', style: { fontSize: '10.5px' }, text: `${q.w}×${q.h}` }),
      ]));
    });

    const body = el('div', {}, [
      el('div', { class: 'ed-sec-title', text: `المقاس الحالي: ${this.page.w}×${this.page.h}` }),
      el('div', { class: 'dim', style: { fontSize: '12px', marginBottom: '8px' }, text: 'العناصر هتتكبّر/تصغر متناسبة وتتلزّم في النص — تقدر تظبط بعدها يدويًا.' }),
      grid,
      el('div', { class: 'grid2', style: { marginTop: '10px' } }, [
        el('div', { class: 'field' }, [el('label', { text: t('width') }), el('input', { class: 'input num', type: 'number', value: customW, oninput: (e) => customW = +e.target.value || 100 })]),
        el('div', { class: 'field' }, [el('label', { text: t('height') }), el('input', { class: 'input num', type: 'number', value: customH, oninput: (e) => customH = +e.target.value || 100 })]),
      ]),
    ]);

    const m = modal({
      title: '📐 تغيير المقاس',
      body: [body],
      footer: [
        el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
        el('button', { class: 'btn primary', text: 'غيّر المقاس', onclick: () => { m.close(); this.resizePage(Math.max(50, customW), Math.max(50, customH)); } }),
      ],
    });
    void sizesBody;
  }

  exportDialog() {
    const page = this.page;
    let format = 'png';
    let scaleMode = 'screen';
    const scaleMap = { screen: 1, hd: 2, print: Math.min(3, 3508 / Math.max(page.w, page.h)) };
    const SIZES = [
      { label: 'بوست إنستجرام 1080×1080', w: 1080, h: 1080 },
      { label: 'ستوري 1080×1920', w: 1080, h: 1920 },
      { label: 'بوست X 1600×900', w: 1600, h: 900 },
      { label: 'غلاف يوتيوب 1280×720', w: 1280, h: 720 },
      { label: 'غلاف فيسبوك 820×312', w: 820, h: 312 },
      { label: 'بوست عمودي 1080×1350', w: 1080, h: 1350 },
    ];
    const chosen = new Set();

    const segF = el('div', { class: 'seg brand' }, ['png', 'jpg', 'webp', 'pdf'].map((f) => el('button', { text: f.toUpperCase(), class: f === format ? 'active' : '', onclick: (e) => { format = f; [...e.target.parentNode.children].forEach((b) => b.classList.remove('active')); e.target.classList.add('active'); } })));
    const segS = el('div', { class: 'seg' }, [['screen', 'مقاس الشاشة'], ['hd', 'HD ×2'], ['print', 'طباعة 300dpi']].map(([k, lab]) => el('button', { text: lab, class: k === scaleMode ? 'active' : '', onclick: (e) => { scaleMode = k; [...e.target.parentNode.children].forEach((b) => b.classList.remove('active')); e.target.classList.add('active'); updateDim(); } })));
    const allPages = el('input', { type: 'checkbox', checked: false });
    const dimLabel = el('div', { class: 'dim', style: { fontSize: '12px' }, text: '' });
    const updateDim = () => {
      dimLabel.textContent = `المقاس النهائي: ${Math.round(page.w * scaleMap[scaleMode])} × ${Math.round(page.h * scaleMap[scaleMode])} بكسل`;
    };
    updateDim();

    const sizesBox = el('div', { class: 'ed-sizes' });
    SIZES.forEach((s) => {
      const cb = el('input', { type: 'checkbox' });
      cb.addEventListener('change', () => cb.checked ? chosen.add(s) : chosen.delete(s));
      sizesBox.appendChild(el('label', { class: 'check' }, [cb, el('span', { text: s.label })]));
    });

    const m = modal({
      title: t('export'),
      body: [
        el('div', { class: 'field' }, [el('label', { text: 'الصيغة' }), segF]),
        el('div', { class: 'field' }, [el('label', { text: 'الجودة' }), segS, dimLabel]),
        el('label', { class: 'check' }, [allPages, el('span', { text: `تصدير كل الصفحات (${this.doc.pages.length})` })]),
        el('div', { class: 'field', style: { marginTop: '8px' } }, [
          el('label', { text: '✨ نسخ بمقاسات أخرى (تتناسب تلقائيًا وتتنزّل مع الأساسي)' }),
          sizesBox,
        ]),
      ],
      footer: [
        el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
        el('button', {
          class: 'btn primary', html: icon('download') + `<span>${t('download')}</span>`,
          onclick: async () => {
            m.close();
            toast('جاري التصدير…', 'info', 1800);
            const name = (this.doc.title || 'design').replace(/[^\p{L}\p{N}._-]/gu, '-');
            try {
              if (allPages.checked) await exportAllPages(this.doc.pages, { format, scale: scaleMap[scaleMode], filename: name });
              else await exportPage(page, { format, scale: scaleMap[scaleMode], filename: name });
              const fmt = format === 'pdf' ? 'png' : format;
              for (const s of chosen) {
                await exportFitted(page, { w: s.w, h: s.h, format: fmt, filename: name });
              }
              toast('تم التصدير ✓' + (chosen.size ? ` (+${chosen.size} مقاس)` : ''), 'ok');
            } catch (e) {
              toast('فشل التصدير: ' + e.message, 'err');
            }
          },
        }),
      ],
    });
  }

  requestClose() {
    if (!this.dirty) { this.close(); return; }
    const m = modal({
      title: 'فيه تغييرات لم تُحفظ',
      body: [el('p', { class: 'muted', text: 'تحب تحفظ التصميم قبل الإغلاق؟' })],
      footer: [
        el('button', { class: 'btn ghost', text: 'إغلاق بدون حفظ', onclick: () => { m.close(); this.close(); } }),
        el('button', { class: 'btn outline', text: 'إلغاء', onclick: () => m.close() }),
        el('button', { class: 'btn primary', text: 'حفظ وإغلاق', onclick: async () => { m.close(); await this.save(true); this.close(); } }),
      ],
    });
  }

  close() {
    window.removeEventListener('keydown', this._onKey);
    window.removeEventListener('resize', this._onResize);
    if (this._onUnload) window.removeEventListener('beforeunload', this._onUnload);
    clearTimeout(this._draftT);
    if (this._menusDocClose) document.removeEventListener('click', this._menusDocClose);
    if (!this.dirty) this.clearDraft();
    if (this._offSync) this._offSync();
    this.rootEl.remove();
    if (instance === this) instance = null;
  }
}

/* مكتبة الصور المدمجة */
export const STOCK = [
  '/assets/stock/food.jpg',
  '/assets/stock/tech.jpg',
  '/assets/stock/abstract.jpg',
  '/assets/stock/ramadan.jpg',
  '/assets/stock/resort.jpg',
  '/assets/stock/medical.jpg',
  '/assets/stock/coffee.jpg',
  '/assets/stock/office.jpg',
];
