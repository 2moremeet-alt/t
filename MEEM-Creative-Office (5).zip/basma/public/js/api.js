/* ============================================================
   MEEM | Creative Office — طبقة الاتصال (REST + WebSocket)
   ============================================================ */

const TOKEN_KEY = 'basma_token';
export function getToken() { try { return localStorage.getItem(TOKEN_KEY) || ''; } catch (e) { return window.__memToken || ''; } }
export function setToken(t) {
  try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); }
  catch (e) { window.__memToken = t || ''; }
}

async function req(path, opts = {}) {
  const headers = Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {});
  const token = getToken();
  if (token) headers['Authorization'] = 'Bearer ' + token;
  const res = await fetch('/api' + path, {
    method: opts.method || 'GET',
    headers,
    body: opts.body ? JSON.stringify(opts.body) : undefined,
    credentials: 'same-origin',
  });
  let json = null;
  try { json = await res.json(); } catch (e) { /* empty */ }
  if (res.status === 401 && path !== '/login' && !opts._retried) {
    const healed = await healSession();
    if (healed) return req(path, Object.assign({}, opts, { _retried: true }));
    setToken('');
    window.dispatchEvent(new CustomEvent('auth-expired'));
  }
  if (!res.ok || !json || json.ok === false) {
    const err = new Error((json && (json.error || json.errorEn)) || ('HTTP ' + res.status));
    err.status = res.status;
    throw err;
  }
  return json;
}

/* ---------------- تذكّر آخر حساب + إصلاح الجلسة تلقائيًا ---------------- */
export function rememberCreds(email, password) {
  try {
    localStorage.setItem('basma_last_email', email);
    localStorage.setItem('basma_last_pass', password);
    localStorage.removeItem('basma_logged_out');
  } catch (e) {}
}
export function forgotCreds() {
  try { localStorage.setItem('basma_logged_out', '1'); } catch (e) {}
}
export function lastCreds() {
  try {
    return {
      email: localStorage.getItem('basma_last_email') || '',
      password: localStorage.getItem('basma_last_pass') || '',
      loggedOut: !!localStorage.getItem('basma_logged_out'),
    };
  } catch (e) { return { email: '', password: '', loggedOut: true }; }
}

let healPromise = null;
async function healSession() {
  if (healPromise) return healPromise;
  healPromise = (async () => {
    const { email, password } = lastCreds();
    const em = email || 'designer@meem.studio';
    const pw = password || '123456';
    try {
      const r = await req('/login', { method: 'POST', body: { email: em, password: pw } });
      setToken(r.token);
      return true;
    } catch (e) {
      return false;
    } finally {
      setTimeout(() => { healPromise = null; }, 500);
    }
  })();
  return healPromise;
}

/** محاولة دخول تلقائي بصمت (لتجربة.demo بدون رسائل جلسة منتهية) */
export async function tryAutoLogin() {
  const { loggedOut, email } = lastCreds();
  if (loggedOut) return false;          // المستخدم طلوع بإرادته → شاشة الدخول
  if (!email && !getToken()) return false;
  return healSession();
}

export const api = {
  login: (email, password) => req('/login', { method: 'POST', body: { email, password } }),
  logout: () => req('/logout', { method: 'POST' }).catch(() => ({})),
  me: () => req('/me'),
  state: () => req('/state'),
  activity: () => req('/activity'),
  design: (id) => req('/design/' + encodeURIComponent(id)),
  asset: (id) => req('/asset/' + encodeURIComponent(id)),
  upsert: (collection, doc) => req('/mutate', { method: 'POST', body: { op: 'upsert', collection, doc } }),
  bulk: (collection, docs) => req('/mutate', { method: 'POST', body: { op: 'bulk', collection, doc: docs } }),
  remove: (collection, id) => req('/mutate', { method: 'POST', body: { op: 'delete', collection, id } }),
  /* V2-3 — إدارة الحسابات (المالك) */
  user: (payload) => req('/user', { method: 'POST', body: payload }),
  /* Phase 2 — دورة حياة التصميم */
  designSubmit: (id, note) => req(`/design/${id}/submit`, { method: 'POST', body: { note } }),
  designDecision: (id, decision, note) => req(`/design/${id}/decision`, { method: 'POST', body: { decision, note } }),
  designComment: (id, payload) => req(`/design/${id}/comment`, { method: 'POST', body: payload }),
  designVersion: (id, note) => req(`/design/${id}/version`, { method: 'POST', body: { note } }),
  designRestore: (id, vid) => req(`/design/${id}/restore`, { method: 'POST', body: { vid } }),
  designShare: (id, off) => req(`/design/${id}/share`, { method: 'POST', body: { off: !!off } }),
  /* Phase 4 */
  docGet: (col, id) => req(`/doc/${col}/${encodeURIComponent(id)}`),
  docSubmit: (col, id, note) => req(`/doc/${col}/${id}/submit`, { method: 'POST', body: { note } }),
  docDecision: (col, id, decision, note) => req(`/doc/${col}/${id}/decision`, { method: 'POST', body: { decision, note } }),
  docComment: (col, id, payload) => req(`/doc/${col}/${id}/comment`, { method: 'POST', body: payload }),
  ai: (payload) => req('/ai', { method: 'POST', body: payload }),
  /* Phase 7 — شات */
  chatSend: (room, text) => req('/chat', { method: 'POST', body: { room, text } }),
  changePassword: (current, next) => req('/password', { method: 'POST', body: { current, next } }),
  clientLink: (projectId, regenerate) => req('/client-link', { method: 'POST', body: { projectId, regenerate: !!regenerate } }),
  /* Phase 5 — رفع ميديا (raw body) */
  uploadFile: async (name, blob) => {
    const res = await fetch('/api/upload?name=' + encodeURIComponent(name), {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + getToken(), 'Content-Type': 'application/octet-stream' },
      body: blob,
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok || !j.ok) throw Object.assign(new Error(j.error || ('upload failed ' + res.status)), { status: res.status });
    return j;
  },
};

/* ------------------------- WebSocket ------------------------- */

class Socket {
  constructor() {
    this.ws = null;
    this.handlers = new Set();
    this.queue = [];
    this.connected = false;
    this.retry = 0;
    this.clientId = localStorage.getItem('basma_cid') || Math.random().toString(36).slice(2, 10);
    localStorage.setItem('basma_cid', this.clientId);
    this.room = null;
  }

  connect() {
    if (this.ws && (this.ws.readyState === 0 || this.ws.readyState === 1)) return;
    const proto = location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = `${proto}//${location.host}/ws?token=${encodeURIComponent(getToken())}&cid=${this.clientId}`;
    try { this.ws = new WebSocket(url); } catch (e) { this.scheduleRetry(); return; }

    this.ws.onopen = () => {
      this.connected = true;
      this.retry = 0;
      this.emit({ type: 'ws-state', connected: true });
      const flush = this.queue.splice(0);
      flush.forEach((m) => this.raw(m));
      if (this.room) this.raw({ type: 'join-room', room: this.room });
    };
    this.ws.onmessage = (ev) => {
      let msg;
      try { msg = JSON.parse(ev.data); } catch (e) { return; }
      this.emit(msg);
    };
    this.ws.onclose = () => {
      this.connected = false;
      this.emit({ type: 'ws-state', connected: false });
      this.scheduleRetry();
    };
    this.ws.onerror = () => { try { this.ws.close(); } catch (e) {} };
  }

  scheduleRetry() {
    this.retry = Math.min(this.retry + 1, 8);
    setTimeout(() => this.connect(), 800 * this.retry);
  }

  raw(msg) {
    if (this.ws && this.ws.readyState === 1) this.ws.send(JSON.stringify(msg));
    else this.queue.push(msg);
  }

  send(msg) { this.raw(msg); }
  on(fn) { this.handlers.add(fn); return () => this.handlers.delete(fn); }
  emit(msg) { this.handlers.forEach((h) => { try { h(msg); } catch (e) { console.error(e); } }); }

  joinRoom(room, info) {
    this.room = room;
    this.raw({ type: 'join-room', room });
    if (info) this.raw(Object.assign({ type: 'hello' }, info));
  }
  leaveRoom() {
    if (!this.room) return;
    this.raw({ type: 'leave-room' });
    this.room = null;
  }
}

export const socket = new Socket();

/* ------------------------- أدوات عامة ------------------------- */

export function uid(prefix) {
  return (prefix || 'id') + '_' + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-3);
}

export function readFileAsDataURL(file) {
  return new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = reject;
    r.readAsDataURL(file);
  });
}

export function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 800);
}
