/* ============================================================
   MEEM | Creative Office — الهيكل (Sidebar + Topbar)
   ============================================================ */
import { t, getLang, setLang, bi } from './i18n.js';
import { state, logout, deptStats, isOverdue, subscribe, userById } from './store.js';
import { openDM } from './views/chat.js';
import { api } from './api.js';
import { el, icon, avatarHTML, clear, escapeHTML, toast, modal } from './ui.js';
import { openTaskModal } from './taskform.js';
import { openNewMeetingModal } from './views/meetings.js';

const NAV = [
  { group: 'nav_workspace', items: [
    { key: 'office', title: 'المكتب', icon: 'grid' },
    { key: 'dashboard', title: 'nav_dashboard', icon: 'dashboard' },
  ] },
  {
    group: 'nav_workspace',
    items: [
      { key: 'projects', title: 'المشاريع', icon: 'kanban' },
      { key: 'tasks', title: 'المهام', icon: 'check' },
      { key: 'content', title: 'nav_content', icon: 'content', roles: ['content', 'editor', 'admin', 'superadmin'] },
      { key: 'voice', title: 'nav_voice', icon: 'voice', roles: ['voice', 'editor', 'admin', 'superadmin'] },
      { key: 'video', title: 'استوديو الفيديو', icon: 'code' },
      { key: 'photo', title: 'التصوير', icon: 'image', roles: ['designer', 'admin', 'superadmin'] },
      { key: 'design', title: 'nav_design', icon: 'design', roles: ['designer', 'admin', 'superadmin'] },
      { key: 'delivery', title: 'nav_delivery', icon: 'delivery' },
      { key: 'dev', title: 'nav_dev', icon: 'code', roles: ['dev', 'admin', 'superadmin'] },
    ],
  },
  {
    group: 'التنظيم',
    items: [
      { key: 'chat', title: 'الدردشة', icon: 'chat' },
      { key: 'requests', title: 'الطلبات', icon: 'bell', roles: ['cs', 'admin', 'superadmin'] },
      { key: 'calendar', title: 'التقويم', icon: 'calendar' },
      { key: 'activity', title: 'سجل النشاط', icon: 'clock' },
    ],
  },
  {
    group: 'الإدارة',
    items: [
      { key: 'reports', title: 'التقارير', icon: 'target', admin: true },
      { key: 'finance', title: 'المالية', icon: 'money', admin: true },
      { key: 'time', title: 'تتبع الوقت', icon: 'clock' },
      { key: 'marketing', title: 'التسويق', icon: 'sparkles', admin: true },
      { key: 'kb', title: 'المعرفة', icon: 'template' },
    ],
  },
  {
    group: 'nav_admin',
    items: [
      { key: 'meetings', title: 'nav_meet', icon: 'meet' },
      { key: 'clients', title: 'nav_clients', icon: 'clients', roles: ['cs', 'admin', 'superadmin'] },
      { key: 'assets', title: 'nav_files', icon: 'folder' },
      { key: 'automation', title: 'الأتمتة', icon: 'bolt', admin: true },
      { key: 'team', title: 'nav_team', icon: 'users', admin: true },
    ],
  },
];

/* V2-3: قائمة المالك المخفي — منفصلة تمامًا */
const NAV_OWNER = [
  { group: 'MEE M CONTROL', items: [{ key: 'owner', title: 'لوحة المالك', icon: 'lock' }] },
];

const NAV_CLIENT = [
  { group: 'مساحتك', items: [
    { key: 'portal', title: 'لوحتي', icon: 'dashboard' },
    { key: 'projects', title: 'مشاريعي', icon: 'kanban' },
    { key: 'chat', title: 'الدردشة', icon: 'chat' },
  ] },
];

function applyTheme() {
  const theme = localStorage.getItem('basma_theme') || 'dark';
  document.documentElement.dataset.theme = theme;
}

export function renderShell(root, { onNav }) {
  applyTheme();
  clear(root);

  const sidebar = el('aside', { class: 'sidebar', id: 'sidebar' });
  const content = el('main', { class: 'view' });
  const main = el('div', { class: 'main' });
  const topbar = el('header', { class: 'topbar' });
  main.append(topbar, content);

  const shellEl = el('div', { class: 'shell' }, [sidebar, main]);
  root.appendChild(shellEl);

  /* ---------- sidebar ---------- */
  sidebar.appendChild(el('div', { class: 'side-head' }, [
    el('div', { class: 'side-logo', text: 'M' }),
    el('div', { class: 'grow' }, [
      el('div', { class: 'side-title', text: t('appName') + ' | Creative Office' }),
      el('div', { class: 'side-sub', text: t('appSub') }),
    ]),
    el('button', {
      class: 'btn ghost icon sm mobile-only', onclick: () => sidebar.classList.remove('open'), html: icon('close'),
    }),
  ]));

  const nav = el('nav', { class: 'side-nav' });
  sidebar.appendChild(nav);

  /* V2-9: الرسائل المباشرة في السايدبار */
  const dmBox = el('div', { class: 'side-dms' });
  sidebar.appendChild(dmBox);
  function buildDMs() {
    clear(dmBox);
    if (!state.user || state.user.role === 'client' || state.user.role === 'superadmin') return;
    const on = new Set(state.online || []);
    const partners = [...new Set((state.chats || [])
      .filter((m) => m.room && m.room.startsWith('dm:') && m.room.includes(state.user.id))
      .map((m) => m.room.split(':').slice(1).find((id) => id !== state.user.id)))]
      .map((id) => userById(id)).filter(Boolean);
    if (!partners.length) return;
    dmBox.appendChild(el('div', { class: 'ng-title', text: getLang() === 'ar' ? 'رسائل مباشرة' : 'Direct Messages' }));
    partners.forEach((u) => {
      dmBox.appendChild(el('button', {
        class: 'dm-item',
        onclick: () => { sidebar.classList.remove('open'); document.querySelector('.side-scrim')?.remove(); openDM(u.id); },
      }, [
        el('span', { class: 'dm-av', html: avatarHTML(u, 'sm') }),
        el('span', { class: 'grow', text: u.name }),
        el('span', { class: 'dm-dot' + (on.has(u.id) ? ' on' : '') }),
      ]));
    });
  }
  buildDMs();
  subscribe((what) => { if (what === 'chats' || what === 'presence') buildDMs(); });

  const counts = () => {
    const ds = deptStats();
    return {
      content: ds.content.open,
      voice: ds.voice.open,
      design: ds.design.open,
      delivery: ds.delivery.open,
      dev: ds.dev.open,
      projects: (state.projects || []).filter((p) => !['done', 'delivered'].includes(p.status)).length,
      requests: (state.requests || []).filter((r) => r.status === 'new').length,
    };
  };

  function buildNav() {
    clear(nav);
    const c = counts();
    /* V2-2: فلترة القائمة حسب الدور (والحماية الحقيقية server-side في perms.js) */
    const me = state.user.role;
    const isAdm = me === 'admin' || me === 'superadmin';
    /* V2-3: الفيديو/الاجتماعات مخفية عن الفريق إلا لو المالك أتاحها من Tools */
    const td = (state.settings || []).find((x) => x.id === 'tools') || {};
    const toolsOn = (k) => me === 'superadmin' || td[k] !== false;
    const groups = (me === 'client' ? NAV_CLIENT : me === 'superadmin' ? NAV_OWNER : NAV)
      .map((g) => ({ group: g.group, items: g.items.filter((it) => (!it.admin || isAdm) && (!it.roles || it.roles.includes(me)) && ((it.key !== 'video' && it.key !== 'meetings') || toolsOn('video'))) }))
      .filter((g) => g.items.length);
    let title = '';
    groups.forEach((group) => {
      if (group.group !== title) {
        title = group.group;
        nav.appendChild(el('div', { class: 'ng-title', text: t(title) }, null));
        nav.lastChild.className = 'nav-group';
        clear(nav.lastChild);
        nav.lastChild.appendChild(el('div', { class: 'ng-title', text: t(title) }));
      }
      const wrap = nav.lastChild;
      group.items.forEach((item) => {
        const btn = el('button', {
          class: 'nav-item', dataset: { nav: item.key },
          onclick: () => {
            sidebar.classList.remove('open');
            document.querySelector('.side-scrim')?.remove();
            location.hash = '#/' + item.key;
          },
        }, [
          el('span', { html: icon(item.icon) }),
          el('span', { class: 'grow', text: t(item.title) }),
        ]);
        if (c[item.key]) btn.appendChild(el('span', { class: 'ni-count num', text: String(c[item.key]) }));
        wrap.appendChild(btn);
      });
    });
  }

  /* ---------- user chip ---------- */
  const user = state.user;
  sidebar.appendChild(el('div', { class: 'side-foot' }, [
    el('div', { class: 'user-chip', title: 'البروفايل', onclick: () => openProfile() }, [
      el('div', { html: avatarHTML(user) }),
      el('div', { class: 'grow' }, [
        el('div', { class: 'uc-name', text: getLang() === 'ar' ? user.name : (user.nameEn || user.name) }),
        el('div', { class: 'uc-role', text: getLang() === 'ar' ? user.title : (user.titleEn || user.title) }),
      ]),
      el('button', {
        class: 'btn ghost icon sm', title: t('logout'), html: icon('logout'),
        onclick: (e) => { e.stopPropagation(); logout(); },
      }),
    ]),
  ]));

  /* V2-9: بروفايل الموظف — تغيير كلمة المرور فقط */
  function openProfile() {
    const AR = getLang() === 'ar';
    const cur = el('input', { class: 'input', type: 'password', placeholder: AR ? 'كلمة المرور الحالية' : 'Current password' });
    const nxt = el('input', { class: 'input', type: 'password', placeholder: AR ? 'الجديدة (6 حروف على الأقل)' : 'New password (6+ chars)' });
    const rep = el('input', { class: 'input', type: 'password', placeholder: AR ? 'أكد الجديدة' : 'Confirm new password' });
    const m = modal({
      title: AR ? '👤 البروفايل' : '👤 Profile',
      body: el('div', { class: 'col', style: { gap: '12px' } }, [
        el('div', { class: 'row', style: { gap: '12px', alignItems: 'center' } }, [
          el('div', { html: avatarHTML(state.user) }),
          el('div', {}, [
            el('div', { style: { fontWeight: '800' }, text: state.user.name }),
            el('div', { class: 'dim', style: { fontSize: '12px' }, text: state.user.email }),
            el('div', { class: 'badge', style: { marginTop: '4px' }, text: state.user.title || state.user.role }),
          ]),
        ]),
        el('div', { class: 'dim', style: { fontSize: '12px' }, text: AR ? 'لتعديل الاسم أو الدور كلم الإدارة — هنا تقدر تغيّر كلمة مرورك بس.' : 'For name/role changes contact admin — here you can only change your password.' }),
        el('div', { class: 'ed-sec-title', style: { margin: '0' }, text: AR ? '🔑 تغيير كلمة المرور' : '🔑 Change Password' }),
        cur, nxt, rep,
      ]),
      footer: [
        el('button', { class: 'btn', text: AR ? 'إغلاق' : 'Close', onclick: () => m.close() }),
        el('button', { class: 'btn primary', text: AR ? 'حفظ' : 'Save', onclick: async () => {
          if (!cur.value || !nxt.value) { toast(AR ? 'كمل الخانات' : 'Fill all fields', 'err'); return; }
          if (nxt.value.length < 6) { toast(AR ? 'كلمة المرور قصيرة (6+)' : 'Password too short (6+)', 'err'); return; }
          if (nxt.value !== rep.value) { toast(AR ? 'التأكيد مش مطابق' : 'Passwords do not match', 'err'); return; }
          try {
            await api.changePassword(cur.value, nxt.value);
            m.close();
            toast(AR ? 'كلمة المرور اتغيرت ✓' : 'Password changed ✓', 'ok');
          } catch (e) { toast(e.message || (AR ? 'مفش' : 'Failed'), 'err'); }
        } }),
      ],
    });
  }

  /* ---------- topbar ---------- */
  const tbTitle = el('div', { class: 'tb-title', text: '' });
  const tbSub = el('div', { class: 'tb-sub', text: '' });
  const connDot = el('span', { class: 'conn-dot', title: 'realtime' });

  const search = el('div', { class: 'tb-search' }, [
    el('span', { html: icon('search') }),
    el('input', {
      class: 'input', placeholder: t('search') + '  (Ctrl+K)',
      oninput: (e) => window.dispatchEvent(new CustomEvent('global-search', { detail: e.target.value })),
    }),
  ]);

  topbar.append(...[
    el('button', {
      class: 'btn ghost icon sm mobile-only', html: icon('menu'),
      onclick: () => {
        sidebar.classList.add('open');
        if (!document.querySelector('.side-scrim')) {
          const scrim = el('div', { class: 'side-scrim', onclick: () => { sidebar.classList.remove('open'); scrim.remove(); } });
          document.body.appendChild(scrim);
        }
      },
    }),
    el('div', { class: 'col', style: { gap: '0' } }, [tbTitle, tbSub]),
    el('div', { class: 'grow' }),
    search,
    connDot,
    el('button', {
      class: 'btn ghost icon', title: t('language'), dataset: { act: 'lang' },
      html: icon('globe'),
      onclick: () => setLang(getLang() === 'ar' ? 'en' : 'ar'),
    }),
    el('button', {
      class: 'btn ghost icon', title: t('theme'), dataset: { act: 'theme' },
      html: icon(localStorage.getItem('basma_theme') === 'light' ? 'moon' : 'sun'),
      onclick: (e) => {
        const next = (localStorage.getItem('basma_theme') || 'dark') === 'dark' ? 'light' : 'dark';
        localStorage.setItem('basma_theme', next);
        applyTheme();
        e.currentTarget.innerHTML = icon(next === 'dark' ? 'sun' : 'moon');
      },
    }),
    user.role === 'client' ? undefined : el('button', {
      class: 'btn primary sm', html: icon('plus') + `<span>${t('newTask')}</span>`,
      onclick: () => openTaskModal(null, () => onNav && onNav()),
    }),
  ].filter(Boolean));

  buildNav();

  return {
    content,
    setActive(key) {
      buildNav();
      nav.querySelectorAll('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.nav === key));
    },
    setTitle(title, sub) { tbTitle.textContent = title; tbSub.textContent = sub || ''; },
    setConnection(on) {
      connDot.classList.toggle('off', !on);
      connDot.title = on ? t('meet_connected') : 'offline';
    },
    refreshNav: buildNav,
  };
}
