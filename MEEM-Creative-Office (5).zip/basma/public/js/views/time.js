/* ============================================================
   MEEM | Creative Office — Phase 6: Time Tracker
   تايمر حي لكل مهمة + إدخال يدوي + مجاميع ساعات (عضو/مشروع)
   ============================================================ */
import { state, save, remove, userById } from '../store.js';
import { el, icon, clear, escapeHTML, toast, confirmDialog, modal } from '../ui.js';

const fmtDur = (mins) => {
  const h = Math.floor(mins / 60), m = Math.round(mins % 60);
  return h ? `${h}س ${m}د` : `${m}د`;
};
const fmtClock = (ms) => {
  const s = Math.floor(ms / 1000);
  return `${String(Math.floor(s / 3600)).padStart(2, '0')}:${String(Math.floor((s % 3600) / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
};
const startOfMonth = () => new Date().toISOString().slice(0, 7);
const startOfWeek = () => { const d = new Date(); const day = (d.getDay() + 1) % 7; d.setDate(d.getDate() - day); return d.toISOString().slice(0, 10); };

/* حالة التايمر على مستوى الموديول — تعيش بعد إعادة التصيير (أي حفظ بيعمل re-render) */
let run = null; // { taskId, startedAt }

export function renderTime(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('clock') + ' تتبع الوقت', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'شغّل تايمر على المهمة اللي شغال عليها — والساعات بتتجمع لكل عضو ومشروع' }),
    ]),
    el('button', { class: 'btn', html: icon('plus') + `<span>إدخال يدوي</span>`, onclick: () => openEntryModal(draw) }),
  ]));
  const area = el('div');
  host.appendChild(area);

  /* --------- التايمر الحي --------- */
  const openTasks = (state.tasks || []).filter((t) => !['done', 'delivered'].includes(t.status));
  const taskSel = el('select', { class: 'select', style: { maxWidth: '360px' }, html: openTasks.map((t) => { const p = (state.projects || []).find((x) => x.id === t.projectId); return `<option value="${t.id}">${escapeHTML(t.title)}${p ? ' — ' + escapeHTML(p.title) : ''}</option>`; }).join('') });
  const clock = el('div', { class: 'tt-clock num', text: '00:00:00' });
  let tick = null;
  const btn = el('button', { class: 'btn ok', style: { minWidth: '110px' }, html: icon('play') + `<span>ابدأ</span>` });
  function paintRunning() {
    if (run) {
      if (taskSel.querySelector(`option[value="${run.taskId}"]`)) taskSel.value = run.taskId;
      btn.className = 'btn danger';
      btn.innerHTML = icon('stop') + `<span>إنهاء وحفظ</span>`;
      clock.textContent = fmtClock(Date.now() - run.startedAt);
      clearInterval(tick);
      tick = setInterval(() => {
        if (!run || !document.contains(clock)) { clearInterval(tick); return; }
        clock.textContent = fmtClock(Date.now() - run.startedAt);
      }, 1000);
    }
  }
  btn.onclick = async () => {
    if (!run) {
      if (!taskSel.value) { toast('اختار مهمة', 'warn'); return; }
      run = { taskId: taskSel.value, startedAt: Date.now() };
      paintRunning();
    } else {
      clearInterval(tick);
      const mins = Math.max(1, Math.round((Date.now() - run.startedAt) / 60000));
      const t = (state.tasks || []).find((x) => x.id === run.taskId);
      const startedAt = run.startedAt;
      run = null;
      await save('timeentries', {
        taskId: t ? t.id : '', taskTitle: t ? t.title : '', projectId: t ? t.projectId : '',
        userId: state.user.id, start: new Date(startedAt).toISOString(), end: new Date().toISOString(), mins, note: 'تايمر',
      });
      clock.textContent = '00:00:00';
      btn.className = 'btn ok';
      btn.innerHTML = icon('play') + `<span>ابدأ</span>`;
      toast(`اتسجلت ${fmtDur(mins)} ✓`, 'ok');
      draw();
    }
  };
  paintRunning();

  function draw() {
    clear(area);
    area.appendChild(el('div', { class: 'card tt-timer', style: { marginBottom: '12px' } }, [
      el('div', {}, [el('div', { class: 'dim', style: { fontSize: '12px', marginBottom: '5px' }, text: 'المهمة' }), taskSel]),
      clock, btn,
    ]));

    const m = startOfMonth();
    const wk = startOfWeek();
    const mine = (state.timeentries || []).filter((e) => e.userId === state.user.id);
    const monthAll = (state.timeentries || []).filter((e) => (e.start || '').slice(0, 7) === m);
    const kpis = el('div', { class: 'kpis', style: { marginBottom: '12px' } }, [
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'ساعاتي (الأسبوع)' }), el('div', { class: 'k-value num', text: fmtDur(mine.filter((e) => (e.start || '').slice(0, 10) >= wk).reduce((s, e) => s + (+e.mins || 0), 0)) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'ساعاتي (الشهر)' }), el('div', { class: 'k-value num', text: fmtDur(mine.filter((e) => (e.start || '').slice(0, 7) === m).reduce((s, e) => s + (+e.mins || 0), 0)) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'ساعات الفريق (الشهر)' }), el('div', { class: 'k-value num', text: fmtDur(monthAll.reduce((s, e) => s + (+e.mins || 0), 0)) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'إدخالات (الشهر)' }), el('div', { class: 'k-value num', text: String(monthAll.length) })]),
    ]);
    area.appendChild(kpis);

    /* مجاميع لكل عضو */
    const byUser = {};
    monthAll.forEach((e) => { byUser[e.userId] = (byUser[e.userId] || 0) + (+e.mins || 0); });
    const rows = Object.entries(byUser).sort((a, b) => b[1] - a[1]);
    const maxM = Math.max(1, ...rows.map((r) => r[1]));
    const usersBox = el('div', { class: 'ct-panel', style: { marginBottom: '12px' } }, [el('div', { class: 'ct-panel-title', text: '👥 ساعات الفريق (الشهر)' })]);
    if (!rows.length) usersBox.appendChild(el('div', { class: 'dim', style: { fontSize: '12.5px' }, text: 'لسه مفيش ساعات مسجلة الشهر ده' }));
    rows.forEach(([uid, mins]) => {
      const u = userById(uid);
      usersBox.appendChild(el('div', { class: 'tt-row' }, [
        el('span', { style: { fontSize: '12.5px', minWidth: '120px' }, text: u ? u.name : uid }),
        el('div', { class: 'pbar grow' }, [el('i', { style: { width: Math.round((mins / maxM) * 100) + '%' } })]),
        el('span', { class: 'num dim', style: { fontSize: '12px', minWidth: '70px', textAlign: 'left' }, text: fmtDur(mins) }),
      ]));
    });
    area.appendChild(usersBox);

    /* الجدول */
    const list = [...(state.timeentries || [])].sort((a, b) => (b.start || '').localeCompare(a.start || ''));
    const tbl = el('div', { class: 'fin-table' });
    tbl.appendChild(el('div', { class: 'fin-tr fin-th' }, [el('span', { text: 'التاريخ' }), el('span', { text: 'المهمة' }), el('span', { text: 'العضو' }), el('span', { text: 'المدة' }), el('span', { text: '' })]));
    list.slice(0, 40).forEach((e) => {
      const u = userById(e.userId);
      tbl.appendChild(el('div', { class: 'fin-tr' }, [
        el('span', { class: 'num dim', text: (e.start || '').slice(0, 16).replace('T', ' ') }),
        el('span', { text: e.taskTitle || '—' }),
        el('span', { class: 'dim', text: u ? u.name : '—' }),
        el('span', { class: 'num', style: { fontWeight: '700' }, text: fmtDur(e.mins) }),
        el('span', {}, [el('button', { class: 'btn ghost icon sm', html: icon('trash'), onclick: async () => { if (await confirmDialog('حذف الإدخال؟')) { await remove('timeentries', e.id); draw(); } } })]),
      ]));
    });
    area.appendChild(el('div', { class: 'ct-panel' }, [el('div', { class: 'ct-panel-title', text: '📋 الإدخالات' }), tbl]));
  }
  draw();
}

function openEntryModal(onDone) {
  const tasks = state.tasks || [];
  const doc = { taskId: (tasks[0] || {}).id || '', userId: state.user.id, date: new Date().toISOString().slice(0, 10), mins: 60, note: '' };
  const m = modal({
    title: '⏱ إدخال ساعات يدوي',
    body: [
      el('div', { class: 'field' }, [el('label', { text: 'المهمة' }), el('select', { class: 'select', html: tasks.map((t) => `<option value="${t.id}" ${t.id === doc.taskId ? 'selected' : ''}>${escapeHTML(t.title)}</option>`).join(''), onchange: (e) => doc.taskId = e.target.value })]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'التاريخ' }), el('input', { class: 'input', type: 'date', value: doc.date, oninput: (e) => doc.date = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'الدقائق *' }), el('input', { class: 'input num', type: 'number', value: doc.mins, oninput: (e) => doc.mins = +e.target.value })]),
      ]),
      state.user.role === 'admin' ? el('div', { class: 'field' }, [el('label', { text: 'العضو' }), el('select', { class: 'select', html: (state.users || []).filter((u) => u.role !== 'client').map((u) => `<option value="${u.id}" ${u.id === doc.userId ? 'selected' : ''}>${escapeHTML(u.name)}</option>`).join(''), onchange: (e) => doc.userId = e.target.value })]) : null,
      el('div', { class: 'field' }, [el('label', { text: 'ملاحظة' }), el('input', { class: 'input', oninput: (e) => doc.note = e.target.value })]),
    ],
    footer: [
      el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: 'حفظ',
        onclick: async () => {
          if (!doc.mins || doc.mins <= 0) { toast('اكتب مدة', 'warn'); return; }
          const t = tasks.find((x) => x.id === doc.taskId);
          await save('timeentries', { taskId: doc.taskId, taskTitle: t ? t.title : '', projectId: t ? t.projectId : '', userId: doc.userId, start: doc.date + 'T09:00:00.000Z', end: doc.date + 'T09:00:00.000Z', mins: doc.mins, note: doc.note });
          m.close(); toast('اتسجلت ✓', 'ok'); onDone();
        },
      }),
    ],
  });
}
