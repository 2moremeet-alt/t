/* ============================================================
   MEEM | Creative Office — Phase 7: MEEM Chat
   غرف فريق + شات مشاريع + شات عملاء — لحظي عبر WebSocket
   ============================================================ */
import { state, userById, notify } from '../store.js';
import { el, icon, clear, escapeHTML, toast, avatarHTML, modal } from '../ui.js';
import { api, socket } from '../api.js';
import { getLang } from '../i18n.js';

/* V2-9: الرسائل المباشرة — مفتاح غرفة ثابت للطرفين */
export const dmKey = (a, b) => 'dm:' + [a, b].sort().join(':');
export function openDM(uid) {
  if (!uid || uid === state.user.id) return;
  curRoom = dmKey(state.user.id, uid);
  if (location.hash.startsWith('#/chat')) notify('chats');
  else location.hash = '#/chat';
}

let curRoom = 'general'; // يعيش بعد إعادة التصيير (رسالة واردة = re-render)
const drafts = {};       // مسودة كل غرفة

const TEAM_ROOMS = [
  ['general', '🌐 العام'],
  ['design', '🎨 فريق التصميم'],
  ['content', '✍️ فريق المحتوى'],
  ['dev', '💻 فريق التطوير'],
];

function roomsFor(user) {
  const rooms = [];
  if (user.role === 'client') {
    rooms.push(['cli:' + user.clientId, '💬 دردشتي مع ميم']);
    (state.projects || []).forEach((p) => rooms.push(['prj:' + p.id, '📁 ' + p.title]));
  } else {
    /* V2-9: محادثات مباشرة موجودة + الحالية لو لسه فاضية */
    const dmRooms = [...new Set((state.chats || []).map((m) => m.room).filter((r) => r.startsWith('dm:') && r.includes(user.id)))];
    if (curRoom.startsWith('dm:') && !dmRooms.includes(curRoom)) dmRooms.unshift(curRoom);
    dmRooms.forEach((k) => {
      const other = k.split(':').slice(1).find((id) => id !== user.id);
      const u = userById(other);
      rooms.push([k, '💬 ' + (u ? (getLang() === 'ar' ? u.name : (u.nameEn || u.name)) : (getLang() === 'ar' ? 'محادثة' : 'Chat'))]);
    });
    TEAM_ROOMS.forEach((r) => rooms.push(r));
    (state.projects || []).forEach((p) => rooms.push(['prj:' + p.id, '📁 ' + p.title]));
    (state.clients || []).forEach((c) => rooms.push(['cli:' + c.id, '👨‍💼 ' + c.name]));
  }
  return rooms;
}

const fmtTime = (iso) => { const d = new Date(iso); return d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }); };
const fmtDay = (iso) => new Date(iso).toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long' });

export function renderChat(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('chat') + ' MEE M Chat', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'غرف الفريق · شات المشاريع · شات العملاء — كله لحظي' }),
    ]),
  ]));

  const rooms = roomsFor(state.user);
  if (!rooms.find(([k]) => k === curRoom)) curRoom = rooms[0][0];

  const list = el('div', { class: 'chat-rooms' });
  if (state.user.role !== 'client') {
    list.appendChild(el('button', {
      class: 'chat-room chat-new',
      onclick: () => {
        const team = (state.users || []).filter((u) => u.role !== 'client' && u.role !== 'superadmin' && u.id !== state.user.id && u.active !== false);
        const on = new Set(state.online || []);
        team.sort((a, b) => (on.has(b.id) ? 1 : 0) - (on.has(a.id) ? 1 : 0));
        const m = modal({
          title: getLang() === 'ar' ? '💬 رسالة مباشرة جديدة' : '💬 New Direct Message',
          body: el('div', { class: 'col', style: { gap: '6px' } }, team.map((u) => el('button', {
            class: 'dm-pick',
            onclick: () => { m.close(); openDM(u.id); },
          }, [
            el('span', { html: avatarHTML(u, 'sm') }),
            el('span', { class: 'grow', style: { textAlign: 'start' }, text: u.name }),
            el('span', { class: 'dm-dot' + (on.has(u.id) ? ' on' : '') }),
          ]))),
        });
      },
    }, [el('span', { style: { fontWeight: '800', fontSize: '13px' }, text: getLang() === 'ar' ? '＋ رسالة مباشرة جديدة' : '＋ New Direct Message' })]));
  }
  rooms.forEach(([key, label]) => {
    const msgs = (state.chats || []).filter((m) => m.room === key);
    const last = msgs[msgs.length - 1];
    list.appendChild(el('button', {
      class: 'chat-room' + (key === curRoom ? ' active' : ''),
      onclick: () => { curRoom = key; renderChat(host); },
    }, [
      el('div', { class: 'row', style: { gap: '6px' } }, [
        key.startsWith('dm:') ? el('span', { class: 'dm-dot' + ((state.online || []).includes(key.split(':').slice(1).find((id) => id !== state.user.id)) ? ' on' : '') }) : null,
        el('span', { class: 'grow', style: { fontWeight: '700', fontSize: '13px', textAlign: 'start' }, text: label }),
        last ? el('span', { class: 'dim num', style: { fontSize: '10px' }, text: fmtTime(last.at) }) : null,
      ]),
      last ? el('div', { class: 'dim', style: { fontSize: '11.5px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textAlign: 'start' }, text: last.byName + ': ' + last.text }) : el('div', { class: 'dim', style: { fontSize: '11.5px' }, text: 'لسه مفيش رسائل' }),
    ]));
  });

  const msgsBox = el('div', { class: 'chat-msgs' });
  const msgs = (state.chats || []).filter((m) => m.room === curRoom);
  let lastDay = '';
  msgs.forEach((m) => {
    const day = (m.at || '').slice(0, 10);
    if (day !== lastDay) {
      lastDay = day;
      msgsBox.appendChild(el('div', { class: 'chat-day', text: fmtDay(m.at) }));
    }
    const mine = m.by === state.user.id;
    const u = userById(m.by);
    msgsBox.appendChild(el('div', { class: 'chat-msg' + (mine ? ' mine' : '') }, [
      !mine ? el('div', { class: 'chat-av', html: u ? avatarHTML(u, 'sm') : '', title: m.byName }) : null,
      el('div', { class: 'chat-bub' }, [
        !mine ? el('div', { class: 'chat-who', text: m.byName }) : null,
        el('div', { class: 'chat-txt', text: m.text }),
        el('div', { class: 'chat-time num', text: fmtTime(m.at) }),
      ]),
    ]));
  });
  if (!msgs.length) msgsBox.appendChild(el('div', { class: 'empty', style: { padding: '40px' }, text: 'ابدأ المحادثة 👋' }));

  const input = el('input', { class: 'input chat-input', placeholder: 'اكتب رسالة…', value: drafts[curRoom] || '' });
  let lastTyp = 0;
  input.oninput = () => {
    drafts[curRoom] = input.value;
    /* V3-2: typing indicator للمكتب — الطرف التاني يشوف ✍️ فوق أفاتارك */
    if (curRoom.startsWith('dm:') && input.value && Date.now() - lastTyp > 900) {
      lastTyp = Date.now();
      const other = curRoom.split(':').slice(1).find((id) => id !== state.user.id);
      if (other) socket.send({ type: 'otyping', to: other });
    }
  };
  const send = async () => {
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    drafts[curRoom] = '';
    try {
      await api.chatSend(curRoom, text);
      // الرسالة هترجع لحظيًا عبر الـ WebSocket
    } catch (e) { toast('مبعتتش: ' + e.message, 'err'); input.value = text; drafts[curRoom] = text; }
  };
  input.onkeydown = (e) => { if (e.key === 'Enter') send(); };

  const pane = el('div', { class: 'chat-pane' }, [
    msgsBox,
    el('div', { class: 'chat-compose' }, [
      input,
      el('button', { class: 'btn primary', html: icon('send') + `<span>إرسال</span>`, onclick: send }),
    ]),
  ]);

  host.appendChild(el('div', { class: 'chat-wrap' }, [list, pane]));
  requestAnimationFrame(() => { msgsBox.scrollTop = msgsBox.scrollHeight; });
}
