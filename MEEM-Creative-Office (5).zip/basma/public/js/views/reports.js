/* ============================================================
   MEEM | Creative Office — Phase 6: Reports
   تقرير شهر كامل: مشاريع · تأخير · أداء فريق · ربحية + رسوم SVG
   ============================================================ */
import { state, userById } from '../store.js';
import { el, icon, clear, escapeHTML, toast, money, invTotal } from '../ui.js';

const monthKey = (iso) => (iso || '').slice(0, 7);
const dayKey = (iso) => (iso || '').slice(0, 10);
const fmtDur = (mins) => { const h = Math.floor(mins / 60), m = Math.round(mins % 60); return h ? `${h}س ${m}د` : `${m}د`; };

function svgBars(pairs, color) {
  // pairs: [label, value]
  const max = Math.max(1, ...pairs.map((p) => p[1]));
  const W = 520, H = 150, bw = Math.min(46, (W - 20) / Math.max(1, pairs.length) - 12);
  let s = `<svg viewBox="0 0 ${W} ${H}" class="rep-chart" role="img">`;
  pairs.forEach(([lb, v], i) => {
    const h = Math.max(3, Math.round((v / max) * (H - 40)));
    const x = 14 + i * (bw + 12);
    s += `<rect x="${x}" y="${H - 24 - h}" width="${bw}" height="${h}" rx="5" fill="${color}" opacity="${0.55 + 0.45 * (v / max)}"></rect>`;
    s += `<text x="${x + bw / 2}" y="${H - 8}" text-anchor="middle" class="rep-lbl">${String(lb).slice(0, 10)}</text>`;
    s += `<text x="${x + bw / 2}" y="${H - 30 - h}" text-anchor="middle" class="rep-val">${Math.round(v)}</text>`;
  });
  s += '</svg>';
  return s;
}

export function renderReports(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  const monthInp = el('input', { class: 'input', type: 'month', value: new Date().toISOString().slice(0, 7), style: { width: 'auto' } });
  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('target') + ' التقارير', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'تقرير شهر كامل — مشاريع، تأخير، أداء الفريق، والربحية' }),
    ]),
    el('div', { class: 'row', style: { gap: '8px' } }, [
      monthInp,
      el('button', { class: 'btn', html: icon('print') + `<span>طباعة</span>`, onclick: () => window.print() }),
    ]),
  ]));
  const area = el('div');
  host.appendChild(area);
  monthInp.onchange = () => draw(monthInp.value);
  draw(monthInp.value);

  function draw(m) {
    clear(area);
    if (!/^\d{4}-\d{2}$/.test(m || '')) return;
    const end = m + '-31';

    /* ---------- حسابات ---------- */
    const projects = state.projects || [];
    const tasks = state.tasks || [];
    const today = new Date().toISOString().slice(0, 10);
    const doneThisMonth = tasks.filter((t) => ['done', 'delivered'].includes(t.status) && monthKey(t.updatedAt) === m);
    const openLate = tasks.filter((t) => !['done', 'delivered'].includes(t.status) && t.due && t.due < today);
    const doneLate = doneThisMonth.filter((t) => t.due && dayKey(t.updatedAt) > t.due);
    const delivM = (state.deliveries || []).filter((d) => monthKey(d.deliveredAt) === m);
    const revisions = delivM.reduce((s, d) => s + (d.revisions || 0), 0);

    const team = (state.users || []).filter((u) => u.role !== 'client').map((u) => {
      const mine = tasks.filter((t) => t.assignee === u.id);
      const done = mine.filter((t) => ['done', 'delivered'].includes(t.status) && monthKey(t.updatedAt) === m);
      const late = done.filter((t) => t.due && dayKey(t.updatedAt) > t.due);
      const openL = mine.filter((t) => !['done', 'delivered'].includes(t.status) && t.due && t.due < today);
      const mins = (state.timeentries || []).filter((e) => e.userId === u.id && monthKey(e.start) === m).reduce((s, e) => s + (+e.mins || 0), 0);
      const withDue = done.filter((t) => t.due).length;
      const onTime = withDue ? Math.round(((withDue - late.filter((t) => t.due).length) / withDue) * 100) : null;
      return { u, done: done.length, late: late.length + openL.length, mins, onTime };
    }).filter((r) => r.done || r.mins || r.late);

    const issued = (state.invoices || []).filter((v) => monthKey(v.issuedAt) === m).reduce((s, v) => s + invTotal(v), 0);
    const collected = (state.payments || []).filter((p) => monthKey(p.at) === m).reduce((s, p) => s + (+p.amount || 0), 0);
    const spent = (state.expenses || []).filter((e) => monthKey(e.at) === m).reduce((s, e) => s + (+e.amount || 0), 0);
    const profit = collected - spent;
    const margin = collected ? Math.round((profit / collected) * 100) : 0;
    const prjDueM = projects.filter((p) => p.due && p.due.slice(0, 7) === m);
    const prjDone = projects.filter((p) => ['done', 'delivered'].includes(p.status));

    /* ---------- KPIs ---------- */
    area.appendChild(el('div', { class: 'kpis', style: { marginBottom: '12px' } }, [
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'مهام اتخلصت' }), el('div', { class: 'k-value num', text: String(doneThisMonth.length) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'مهام متأخرة' }), el('div', { class: 'k-value num', style: { color: openLate.length + doneLate.length ? 'var(--danger)' : 'var(--ok)' }, text: String(openLate.length + doneLate.length) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'تسليمات الشهر' }), el('div', { class: 'k-value num', text: String(delivM.length) + (delivM.length ? ` · ${revisions} تعديل` : '') })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'إصدار فواتير' }), el('div', { class: 'k-value num', text: money(issued) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'تحصيل' }), el('div', { class: 'k-value num', style: { color: 'var(--ok)' }, text: money(collected) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: `صافي الربح (${margin}%)` }), el('div', { class: 'k-value num', style: { color: profit >= 0 ? 'var(--ok)' : 'var(--danger)' }, text: money(profit) })]),
    ]));

    const grid = el('div', { class: 'rep-grid' });

    /* ---------- المشاريع ---------- */
    grid.appendChild(el('div', { class: 'ct-panel' }, [
      el('div', { class: 'ct-panel-title', text: '📁 المشاريع' }),
      el('div', { class: 'rep-lines' }, [
        el('div', { class: 'rep-line' }, [el('span', { class: 'dim', text: 'الإجمالي' }), el('b', { class: 'num', text: String(projects.length) })]),
        el('div', { class: 'rep-line' }, [el('span', { class: 'dim', text: 'منتهية/مُسلّمة' }), el('b', { class: 'num', text: String(prjDone.length) })]),
        el('div', { class: 'rep-line' }, [el('span', { class: 'dim', text: 'استحقاقها الشهر ده' }), el('b', { class: 'num', text: String(prjDueM.length) })]),
      ]),
      el('div', { class: 'dim', style: { fontSize: '12px', margin: '8px 0 4px' }, text: 'مشاريع استحقاق الشهر:' }),
      ...(prjDueM.length ? prjDueM.map((p) => el('div', { class: 'rep-line' }, [
        el('span', { style: { fontSize: '12.5px' }, text: p.title }),
        el('span', { class: 'badge ' + (['done', 'delivered'].includes(p.status) ? 'ok' : (p.due < today ? 'danger' : 'warn')), text: p.due }),
      ])) : [el('div', { class: 'dim', style: { fontSize: '12px' }, text: '—' })]),
    ]));

    /* ---------- التأخير ---------- */
    const lateList = [...openLate, ...doneLate];
    grid.appendChild(el('div', { class: 'ct-panel' }, [
      el('div', { class: 'ct-panel-title', text: '⏰ التأخير' }),
      el('div', { class: 'rep-lines' }, [
        el('div', { class: 'rep-line' }, [el('span', { class: 'dim', text: 'مفتوحة فات موعدها' }), el('b', { class: 'num', style: { color: 'var(--danger)' }, text: String(openLate.length) })]),
        el('div', { class: 'rep-line' }, [el('span', { class: 'dim', text: 'اتسلمت متأخر (الشهر ده)' }), el('b', { class: 'num', text: String(doneLate.length) })]),
        el('div', { class: 'rep-line' }, [el('span', { class: 'dim', text: 'متوسط تعديلات التسليمات' }), el('b', { class: 'num', text: delivM.length ? (revisions / delivM.length).toFixed(1) : '—' })]),
      ]),
      ...(lateList.slice(0, 6).map((t) => el('div', { class: 'rep-line' }, [
        el('span', { style: { fontSize: '12.5px' }, text: t.title }),
        el('span', { class: 'badge danger', text: t.due || '' }),
      ]))),
    ]));

    /* ---------- أداء الفريق ---------- */
    const teamPanel = el('div', { class: 'ct-panel' }, [el('div', { class: 'ct-panel-title', text: '👥 أداء الفريق (الشهر)' })]);
    const tbl = el('div', { class: 'fin-table' });
    tbl.appendChild(el('div', { class: 'fin-tr fin-th' }, [el('span', { text: 'العضو' }), el('span', { text: 'مهام خلصت' }), el('span', { text: 'تأخير' }), el('span', { text: 'ساعات' }), el('span', { text: 'التزام' })]));
    team.forEach((r) => {
      tbl.appendChild(el('div', { class: 'fin-tr' }, [
        el('span', { text: r.u.name }),
        el('span', { class: 'num', text: String(r.done) }),
        el('span', { class: 'num', style: { color: r.late ? 'var(--danger)' : 'inherit' }, text: String(r.late) }),
        el('span', { class: 'num', text: fmtDur(r.mins) }),
        el('span', {}, [el('span', { class: 'badge ' + (r.onTime == null ? '' : r.onTime >= 80 ? 'ok' : r.onTime >= 50 ? 'warn' : 'danger'), text: r.onTime == null ? '—' : r.onTime + '%' })]),
      ]));
    });
    if (!team.length) teamPanel.appendChild(el('div', { class: 'dim', style: { fontSize: '12.5px' }, text: 'لا نشاط مسجل الشهر ده' }));
    teamPanel.appendChild(tbl);
    if (team.length) teamPanel.appendChild(el('div', { html: svgBars(team.map((r) => [r.u.name.split(' ')[0], Math.round(r.mins / 6) / 10]), 'var(--brand)') }));
    grid.appendChild(teamPanel);

    /* ---------- الربحية ---------- */
    grid.appendChild(el('div', { class: 'ct-panel' }, [
      el('div', { class: 'ct-panel-title', text: '💰 الربحية' }),
      el('div', { class: 'rep-lines' }, [
        el('div', { class: 'rep-line' }, [el('span', { class: 'dim', text: 'فواتير اتصدرت' }), el('b', { class: 'num', text: money(issued) })]),
        el('div', { class: 'rep-line' }, [el('span', { class: 'dim', text: 'اتحصل فعلاً' }), el('b', { class: 'num', style: { color: 'var(--ok)' }, text: money(collected) })]),
        el('div', { class: 'rep-line' }, [el('span', { class: 'dim', text: 'مصروفات' }), el('b', { class: 'num', style: { color: 'var(--danger)' }, text: money(spent) })]),
        el('div', { class: 'rep-line', style: { borderTop: '1px solid var(--line)', paddingTop: '6px' } }, [el('span', { style: { fontWeight: '800' }, text: 'صافي الربح' }), el('b', { class: 'num', style: { color: profit >= 0 ? 'var(--ok)' : 'var(--danger)', fontSize: '15px' }, text: money(profit) })]),
        el('div', { class: 'rep-line' }, [el('span', { class: 'dim', text: 'هامش الربح' }), el('b', { class: 'num', text: margin + '%' })]),
      ]),
      el('div', { html: svgBars([['إصدار', issued / 1000], ['تحصيل', collected / 1000], ['مصروف', spent / 1000], ['ربح', profit / 1000]], 'var(--ok)') }),
      el('div', { class: 'dim', style: { fontSize: '11px', textAlign: 'center' }, text: 'بالألف جنيه' }),
    ]));

    area.appendChild(grid);
  }
}
