/* ============================================================
   MEEM | Creative Office — Phase 3: سجل النشاط الموسع
   ============================================================ */
import { getLang } from '../i18n.js';
import { state, userById } from '../store.js';
import { el, icon, clear, avatarHTML, timeAgo, escapeHTML } from '../ui.js';
import { api } from '../api.js';

export function renderActivity(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  let filterUser = '';
  let q = '';
  let items = (state.activity || []).slice(0, 60);

  host.append(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('clock') + ' سجل النشاط', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'كل اللي حصل في المكتب: تصاميم، اعتمادات، أتمتة، مهام' }),
    ]),
  ]));

  const bar = el('div', { class: 'row wrap', style: { gap: '8px', marginBottom: '14px' } }, [
    el('div', { class: 'tb-search', style: { flex: '1', minWidth: '180px' } }, [
      el('span', { html: icon('search') }),
      el('input', { class: 'input', placeholder: 'دوّر في النشاط…', oninput: (e) => { q = e.target.value; draw(); } }),
    ]),
    (() => {
      const sel = el('select', { class: 'select', style: { width: 'auto' }, onchange: (e) => { filterUser = e.target.value; draw(); } });
      sel.append(el('option', { value: '', text: 'كل الفريق' }));
      (state.users || []).forEach((u) => sel.appendChild(el('option', { value: u.id, text: u.name })));
      return sel;
    })(),
  ]);
  const list = el('div', { class: 'col', style: { gap: '6px' } });
  host.append(bar, list);

  function draw() {
    clear(list);
    let arr = items;
    if (filterUser) arr = arr.filter((a) => a.userId === filterUser);
    if (q.trim()) arr = arr.filter((a) => ((a.text || '') + (a.textEn || '')).includes(q.trim()));
    if (!arr.length) { list.appendChild(el('div', { class: 'empty', text: 'لا نتائج' })); return; }
    arr.forEach((a) => {
      const u = userById(a.userId);
      const isAuto = (a.text || '').includes('🤖');
      list.appendChild(el('div', { class: 'act-row', style: isAuto ? { borderColor: 'rgba(34,211,238,.35)', background: 'rgba(34,211,238,.05)' } : {} }, [
        isAuto ? el('div', { class: 'act-ico', html: '🤖' }) : el('div', { html: avatarHTML(u, 'sm') }),
        el('div', { class: 'grow' }, [
          el('div', { style: { fontSize: '13.5px', lineHeight: 1.6 }, text: getLang() === 'ar' ? a.text : (a.textEn || a.text) }),
          u ? el('div', { class: 'dim', style: { fontSize: '11px' }, text: u.name }) : null,
        ]),
        el('span', { class: 'dim', style: { fontSize: '11px', whiteSpace: 'nowrap' }, text: timeAgo(a.at) }),
      ]));
    });
  }

  // اسحب 100 حدث من السيرفر
  api.activity().then((r) => { items = r.activity || items; draw(); }).catch(() => draw());
  draw();
}
