/* ============================================================
   MEE M — Virtual Office (V2-7/V2-8 + V3-1 Gather-look)
   عالم Pixel-art أكبر من الشاشة: أرضيات/جدران/أبواب/أثاث SVG،
   sprite متحرك باتجاهات، لوحة اسم بحالة، كاميرا متابعة + Zoom.
   الحركة: WASD/أسهم + tap + joystick لمس — بلا مكتبات خارجية.
   ============================================================ */
import { state, userById, subscribe, notify } from '../store.js';
import { socket, api } from '../api.js';
import { openDM } from './chat.js';
import { el, icon, avatarHTML, toast } from '../ui.js';
import { getLang } from '../i18n.js';

/* ترتيب الأقسام على الخريطة (إحداثيات نسبية %) */
const ROOMS = [
  { id: 'reception', ar: 'الاستقبال', en: 'RECEPTION', ic: 'star', x: 30, y: 0, w: 40, h: 17, color: '#2f7bff', floor: 1 },
  { id: 'design', ar: 'التصميم', en: 'DESIGN', ic: 'design', x: 0, y: 22, w: 30, h: 32, color: '#0066ff', route: '#/design', roles: ['designer', 'admin', 'superadmin'], floor: 1 },
  { id: 'content', ar: 'المحتوى', en: 'CONTENT', ic: 'content', x: 33, y: 22, w: 30, h: 26, color: '#f59e0b', route: '#/content', roles: ['content', 'editor', 'admin', 'superadmin'], floor: 1 },
  { id: 'clounge', ar: 'صالة العملاء', en: 'CLIENT LOUNGE', ic: 'clients', x: 66, y: 22, w: 34, h: 32, color: '#14b8a6', floor: 1 },
  { id: 'lounge', ar: 'الاستراحة', en: 'LOUNGE', ic: 'chat', x: 0, y: 58, w: 30, h: 42, color: '#06b6d4', route: '#/chat', floor: 1 },
  { id: 'delivery', ar: 'التسليمات', en: 'DELIVERY', ic: 'delivery', x: 33, y: 59, w: 30, h: 22, color: '#8b5cf6', route: '#/delivery', floor: 1 },
  { id: 'dev', ar: 'البرمجة', en: 'DEVELOPMENT', ic: 'code', x: 0, y: 22, w: 30, h: 32, color: '#10b981', route: '#/dev', roles: ['dev', 'admin', 'superadmin'], floor: 2 },
  { id: 'voice', ar: 'الفويس أوفر', en: 'VOICE OVER', ic: 'mic', x: 33, y: 22, w: 30, h: 26, color: '#ec4899', route: '#/voice', roles: ['voice', 'editor', 'admin', 'superadmin'], floor: 2 },
  { id: 'cs', ar: 'خدمة العملاء', en: 'CUSTOMER SERVICE', ic: 'clients', x: 66, y: 22, w: 34, h: 32, color: '#f97316', route: '#/clients', roles: ['cs', 'admin', 'superadmin'], floor: 2 },
  { id: 'meeting', ar: 'الاجتماعات', en: 'MEETINGS', ic: 'meet', x: 33, y: 59, w: 30, h: 22, color: '#3d8bff', route: '#/meetings', floor: 2 },
  { id: 'management', ar: 'الإدارة', en: 'MANAGEMENT', ic: 'lock', x: 66, y: 58, w: 34, h: 42, color: '#64748b', route: '#/team', roles: ['admin', 'superadmin'], locked: true, floor: 2 },
];

const DEPT_OF_ROLE = { designer: 'design', content: 'content', voice: 'voice', dev: 'dev', cs: 'cs', admin: 'management', superadmin: 'management', editor: 'content' };
const STATUSES = [
  { id: 'available', ar: 'متاح', en: 'Available', ic: '🟢' },
  { id: 'busy', ar: 'مشغول', en: 'Busy', ic: '🔴' },
  { id: 'meeting', ar: 'في اجتماع', en: 'In Meeting', ic: '🟡' },
];
const STATUS_COLOR = { available: '#22c55e', busy: '#ef4444', meeting: '#f59e0b' };

/* V3-2 — قرب + فقاعات + إيموتات + بوكسات اجتماع خاصة + كائنات تفاعلية */
const BOOTHS = [
  { id: 'booth1', ar: 'بوكس اجتماع ١', en: 'Pod 1', x: 44.5, y: 49, w: 5, h: 8.5, floor: 1 },
  { id: 'booth2', ar: 'بوكس اجتماع ٢', en: 'Pod 2', x: 50.5, y: 49, w: 5, h: 8.5, floor: 1 },
];
const PRIVATE = new Set(BOOTHS.map((b) => b.id));
const NEAR_R = 300; /* بكسل عالم — مدى السمع */
const EMOTES = ['👋', '👍', '', '❤️'];
const FURN_SIZE = {
  desk2: [190, 84], chair: [60, 58], sofa: [152, 56], ctable: [90, 62], plant: [60, 66], plant2: [60, 84],
  aqua: [120, 66], coffee: [56, 70], cooler: [40, 72], board: [130, 70], tv: [120, 64], cabinet: [90, 60],
  shelf: [110, 80], ping: [140, 96], rug: [220, 140], printer: [90, 60], counter: [170, 54], lamp: [34, 77],
};
/* كائنات تفاعلية — إحداثياتها تُشتق من التخطيط الحي (تتبع البنّاء) */
const HOTSPOT_DEFS = [
  { room: 'design', type: 'desk2', ic: '💻', ar: 'لوحة مشاريع التصميم', en: 'Design board', act: { route: '#/design' } },
  { room: 'design', type: 'tv', ic: '📺', ar: 'شاشة القسم', en: 'Dept screen', act: { emote: '📊', bubble: 'براجع الأرقام على الشاشة 📊' } },
  { room: 'content', type: 'desk2', ic: '💻', ar: 'لوحة المحتوى', en: 'Content board', act: { route: '#/content' } },
  { room: 'content', type: 'shelf', ic: '🗄️', ar: 'دولاب الأصول', en: 'Assets', act: { route: '#/assets' } },
  { room: 'dev', type: 'desk2', ic: '💻', ar: 'لوحة البرمجة', en: 'Dev board', act: { route: '#/dev' } },
  { room: 'dev', type: 'cooler', ic: '💧', ar: 'مية مثلجة', en: 'Cold water', act: { emote: '💧' } },
  { room: 'clounge', type: 'tv', ic: '🖥️', ar: 'معرض الأعمال', en: 'Showcase', act: { route: '#/dashboard' } },
  { room: 'lounge', type: 'coffee', ic: '☕', ar: 'بريك قهوة', en: 'Coffee break', act: { emote: '☕', bubble: 'بريك قهوة ☕', break: true } },
  { room: 'lounge', type: 'ping', ic: '🏓', ar: 'بينج بونج', en: 'Ping pong', act: { emote: '🏓', bubble: 'مين يلاعبني بينج بونج؟ 🏓' } },
  { room: 'delivery', type: 'printer', ic: '🖨️', ar: 'شاشة التسليمات', en: 'Deliveries', act: { route: '#/delivery' } },
  { room: 'management', type: 'board', ic: '📌', ar: 'إعلانات الإدارة', en: 'Announcements', act: { route: '#/team', roles: ['admin', 'superadmin'] } },
  { room: 'reception', type: 'plant2', ic: '🌿', ar: 'نبتة الاستقبال', en: 'Reception plant', act: { emote: '🌿' } },
];
const KEYS = { w: 'up', W: 'up', ArrowUp: 'up', s: 'down', S: 'down', ArrowDown: 'down', a: 'left', A: 'left', ArrowLeft: 'left', d: 'right', D: 'right', ArrowRight: 'right' };

/* أبعاد العالم بالبكسل — أكبر من أي شاشة عشان الكاميرا تشتغل */
const W = 2400, H = 1700;
const px = (x) => (x / 100) * W;
const py = (y) => (y / 100) * H;

/* حالة الحركة — على مستوى الوحدة عشان تفضل بين re-renders */
let me = null;
let curFloor = 1;
let editOn = false;
let selRoom = 'reception';
let layoutLoaded = false;
const DEFAULT_ROOM_IDS = new Set(ROOMS.map((r) => r.id));
let LAY = null;   /* التخطيط الحي (يُدمج مع حفظ البنّاء) */
let ROOMS_LIVE = null;
let myStatus = localStorage.getItem('office_status') || 'available';
const keys = new Set();
let target = null;
let lastSend = 0;
let settleTimer = null;
let joyVec = null;
const prevPos = {};   /* كشف مشي باقي الأفاتارات */

let meAll = null;
function spawn() {
  if (me) return;
  let all = null;
  try { all = JSON.parse(localStorage.getItem('office_me_floors')); } catch (e) { all = null; }
  if (!all || typeof all !== 'object') all = {};
  if (!all['1'] || typeof all['1'].x !== 'number') all['1'] = { x: 50, y: 92 };
  if (!all['2'] || typeof all['2'].x !== 'number') all['2'] = { x: 50, y: 53 };
  meAll = all;
  me = meAll[String(curFloor)];
}
function roomsOf(fl) { return (ROOMS_LIVE || ROOMS).filter((r) => (r.floor || 1) === fl); }
function boothsOf(fl) { return BOOTHS.filter((b) => (b.floor || 1) === fl); }
function roomAt(x, y, fl) {
  fl = fl || curFloor;
  const b = boothsOf(fl).find((b) => x >= b.x && x <= b.x + b.w && y >= b.y && y <= b.y + b.h);
  if (b) return b.id;
  const r = roomsOf(fl).find((r) => x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h);
  return r ? r.id : 'floor';
}
function sendPos(force) {
  if (!me) return;
  const now = Date.now();
  if (!force && now - lastSend < 120) return;
  lastSend = now;
  socket.send({ type: 'pos', x: Math.round(me.x * 10) / 10, y: Math.round(me.y * 10) / 10, status: myStatus, room: roomAt(me.x, me.y), floor: curFloor });
  try { meAll[String(curFloor)] = me; localStorage.setItem('office_me_floors', JSON.stringify(meAll)); } catch (e) {}
  clearTimeout(settleTimer);
  settleTimer = setTimeout(() => sendPos(true), 200);
}

/* V2-15: joystick لمس للأجهزة اللمسية */
function buildJoystick() {
  if (!('ontouchstart' in window) && !window.matchMedia('(pointer: coarse)').matches) return null;
  const knob = el('div', { class: 'of-joy-knob' });
  const base = el('div', { class: 'of-joy', title: 'تحريك' }, [knob]);
  document.body.appendChild(base);
  let active = false;
  const move = (e) => {
    const t = e.touches[0];
    if (!t) return;
    const b = base.getBoundingClientRect();
    const cx = b.left + b.width / 2, cy = b.top + b.height / 2, rad = b.width / 2;
    const dx = t.clientX - cx, dy = t.clientY - cy;
    const d = Math.hypot(dx, dy) || 1;
    const cl = Math.min(d, rad);
    const ux = dx / d, uy = dy / d;
    knob.style.transform = `translate(${(ux * cl * 0.6).toFixed(1)}px, ${(uy * cl * 0.6).toFixed(1)}px)`;
    joyVec = { x: ux * (cl / rad), y: uy * (cl / rad) };
  };
  const end = () => { active = false; joyVec = null; knob.style.transform = ''; };
  base.addEventListener('touchstart', (e) => { active = true; move(e); e.preventDefault(); }, { passive: false });
  base.addEventListener('touchmove', (e) => { if (active) { move(e); e.preventDefault(); } }, { passive: false });
  base.addEventListener('touchend', end);
  base.addEventListener('touchcancel', end);
  return base;
}

/* ================= فن العالم — SVG (V3-1) ================= */

const FLOOR_OF = {
  reception: 'pat-tile', design: 'pat-carpet', content: 'pat-carpet2', voice: 'pat-carpet2',
  dev: 'pat-carpet', lounge: 'pat-wood', cs: 'pat-tile', delivery: 'pat-conc', management: 'pat-wood',
};

function furnDefs() {
  return `
  <g id="of-desk2"><rect x="0" y="26" width="190" height="52" rx="6" fill="#e8ecf3"/><rect x="0" y="70" width="190" height="14" rx="4" fill="#b9c2d0"/><rect x="18" y="0" width="52" height="34" rx="4" fill="#141a26"/><rect x="22" y="4" width="44" height="24" rx="2" fill="#3b82f6"/><rect x="40" y="34" width="8" height="6" fill="#8b93a1"/><rect x="112" y="0" width="52" height="34" rx="4" fill="#141a26"/><rect x="116" y="4" width="44" height="24" rx="2" fill="#22d3ee"/><rect x="134" y="34" width="8" height="6" fill="#8b93a1"/><rect x="30" y="44" width="34" height="8" rx="2" fill="#98a2b3"/><rect x="124" y="44" width="34" height="8" rx="2" fill="#98a2b3"/></g>
  <g id="of-chair"><rect x="10" y="0" width="40" height="12" rx="6" fill="#2a3242"/><rect x="8" y="10" width="44" height="30" rx="8" fill="#39435a"/><rect x="26" y="40" width="8" height="12" fill="#2a3242"/><rect x="14" y="52" width="32" height="6" rx="3" fill="#2a3242"/></g>
  <g id="of-sofa"><rect x="0" y="10" width="150" height="46" rx="12" fill="#d98a4b"/><rect x="0" y="0" width="150" height="22" rx="10" fill="#e8a061"/><rect x="8" y="14" width="62" height="26" rx="8" fill="#f2b47c"/><rect x="80" y="14" width="62" height="26" rx="8" fill="#f2b47c"/><rect x="-6" y="6" width="16" height="48" rx="7" fill="#c67a3e"/><rect x="140" y="6" width="16" height="48" rx="7" fill="#c67a3e"/></g>
  <g id="of-ctable"><ellipse cx="45" cy="30" rx="45" ry="26" fill="#e0b57f"/><ellipse cx="45" cy="26" rx="45" ry="26" fill="#eec894"/><rect x="40" y="48" width="10" height="14" fill="#a97c4f"/></g>
  <g id="of-plant"><rect x="16" y="42" width="28" height="24" rx="4" fill="#b0653a"/><circle cx="30" cy="26" r="18" fill="#2f9e57"/><circle cx="18" cy="34" r="12" fill="#37b565"/><circle cx="42" cy="34" r="12" fill="#27894b"/></g>
  <g id="of-plant2"><rect x="18" y="64" width="24" height="20" rx="4" fill="#b0653a"/><rect x="27" y="20" width="6" height="48" fill="#27894b"/><circle cx="30" cy="14" r="16" fill="#2f9e57"/><circle cx="16" cy="30" r="11" fill="#37b565"/><circle cx="44" cy="30" r="11" fill="#27894b"/></g>
  <g id="of-aqua"><rect x="0" y="10" width="120" height="56" rx="6" fill="#0e3a52"/><rect x="4" y="14" width="112" height="44" rx="4" fill="#2492c9"/><circle cx="30" cy="36" r="5" fill="#ffd166"/><circle cx="70" cy="44" r="4" fill="#ff8fab"/><circle cx="92" cy="30" r="4" fill="#ffd166"/><path d="M20 54 q6 -10 0 -18 M48 56 q6 -10 0 -18 M84 54 q6 -10 0 -18" stroke="#7dd8ff" stroke-width="3" fill="none"/><rect x="0" y="0" width="120" height="12" rx="4" fill="#1b212d"/></g>
  <g id="of-coffee"><rect x="0" y="0" width="56" height="70" rx="6" fill="#3a2a20"/><rect x="6" y="8" width="44" height="20" rx="4" fill="#5a4433"/><circle cx="28" cy="44" r="8" fill="#e8ecf3"/><rect x="20" y="52" width="16" height="10" rx="2" fill="#c67a3e"/></g>
  <g id="of-cooler"><rect x="0" y="12" width="40" height="60" rx="6" fill="#dfe5ee"/><rect x="6" y="0" width="28" height="22" rx="8" fill="#7dd8ff" opacity=".8"/><rect x="12" y="34" width="16" height="8" rx="2" fill="#8b93a1"/></g>
  <g id="of-board"><rect x="0" y="0" width="130" height="70" rx="6" fill="#dfe5ee"/><rect x="6" y="6" width="118" height="58" rx="4" fill="#f7fafc"/><path d="M16 22 h60 M16 36 h84 M16 50 h48" stroke="#2b6cff" stroke-width="4" stroke-linecap="round"/></g>
  <g id="of-tv"><rect x="0" y="0" width="120" height="64" rx="6" fill="#141a26"/><rect x="5" y="5" width="110" height="50" rx="3" fill="#0066ff"/><path d="M14 44 L40 24 L62 38 L96 14" stroke="#7dd8ff" stroke-width="5" fill="none" stroke-linecap="round"/></g>
  <g id="of-cabinet"><rect x="0" y="0" width="90" height="60" rx="6" fill="#4a5468"/><rect x="6" y="6" width="78" height="22" rx="3" fill="#5b6579"/><rect x="6" y="32" width="78" height="22" rx="3" fill="#5b6579"/><rect x="38" y="14" width="14" height="5" rx="2" fill="#cfd6e4"/><rect x="38" y="40" width="14" height="5" rx="2" fill="#cfd6e4"/></g>
  <g id="of-shelf"><rect x="0" y="0" width="110" height="80" rx="6" fill="#6b4a2f"/><rect x="6" y="8" width="98" height="18" fill="#8a6240"/><rect x="6" y="32" width="98" height="18" fill="#8a6240"/><rect x="6" y="56" width="98" height="18" fill="#8a6240"/><path d="M12 8 v18 M22 8 v18 M32 8 v18 M46 10 v16 M60 8 v18 M74 9 v17 M88 8 v18" stroke="#d98a4b" stroke-width="6"/><path d="M14 32 v18 M28 34 v16 M42 32 v18 M58 33 v17 M76 32 v18 M92 34 v16" stroke="#2f9e57" stroke-width="6"/></g>
  <g id="of-ping"><rect x="0" y="8" width="140" height="76" rx="6" fill="#2f9e57"/><rect x="0" y="44" width="140" height="4" fill="#f7fafc"/><rect x="68" y="0" width="4" height="84" fill="#dfe5ee"/><rect x="10" y="84" width="10" height="12" fill="#1b212d"/><rect x="120" y="84" width="10" height="12" fill="#1b212d"/></g>
  <g id="of-rug"><rect x="0" y="0" width="220" height="140" rx="14" fill="#5b6579"/><rect x="12" y="12" width="196" height="116" rx="10" fill="#6b7690"/><rect x="30" y="30" width="160" height="80" rx="8" fill="#7c88a3"/></g>
  <g id="of-printer"><rect x="0" y="16" width="90" height="44" rx="6" fill="#39435a"/><rect x="10" y="0" width="70" height="22" rx="4" fill="#4a5468"/><rect x="18" y="6" width="54" height="10" rx="2" fill="#f7fafc"/><circle cx="76" cy="44" r="4" fill="#22c55e"/></g>
  <g id="of-counter"><rect x="0" y="0" width="170" height="54" rx="8" fill="#c67a3e"/><rect x="0" y="0" width="170" height="14" rx="7" fill="#e0b57f"/><rect x="14" y="22" width="40" height="24" rx="4" fill="#a97c4f"/><rect x="66" y="22" width="40" height="24" rx="4" fill="#a97c4f"/><rect x="118" y="22" width="40" height="24" rx="4" fill="#a97c4f"/></g>
  <g id="of-lamp"><rect x="14" y="30" width="6" height="40" fill="#2a3242"/><path d="M0 30 a17 14 0 0 1 34 0 Z" fill="#f59e0b"/><ellipse cx="17" cy="72" rx="16" ry="5" fill="#2a3242"/></g>`;
}

/* توزيع الأثاث داخل كل قسم (٪ من العالم) */
const LAYOUT = {
  reception: [['counter', 41, 4], ['plant', 36, 10], ['plant2', 63, 4], ['aqua', 52, 8], ['sofa', 57, 9], ['ctable', 61, 12]],
  design: [['desk2', 3, 26], ['chair', 7, 32], ['desk2', 11, 26], ['chair', 15, 32], ['desk2', 3, 42], ['chair', 7, 48], ['plant', 26, 24], ['cabinet', 24, 46], ['tv', 8, 22.5]],
  content: [['desk2', 36, 26], ['chair', 40, 32], ['desk2', 44, 26], ['chair', 48, 32], ['shelf', 36, 42], ['plant', 59, 24]],
  clounge: [['rug', 76, 34], ['sofa', 78, 30], ['ctable', 81, 38], ['sofa', 78, 44], ['tv', 88, 24], ['plant', 68, 24], ['plant2', 96, 24], ['aqua', 88, 44]],
  lounge: [['rug', 4, 70], ['sofa', 7, 66], ['ctable', 10, 74], ['sofa', 7, 82], ['ping', 16, 84], ['plant', 3, 62], ['plant2', 26, 62], ['tv', 17, 62], ['coffee', 3, 92], ['cooler', 6, 92], ['lamp', 24, 76]],
  delivery: [['cabinet', 36, 62], ['cabinet', 41, 62], ['printer', 47, 64], ['desk2', 36, 72], ['chair', 40, 78]],
  dev: [['desk2', 3, 26], ['chair', 7, 32], ['desk2', 11, 26], ['chair', 15, 32], ['desk2', 3, 42], ['chair', 7, 48], ['cooler', 27, 24], ['plant', 26, 48]],
  voice: [['desk2', 36, 26], ['chair', 40, 32], ['desk2', 36, 38], ['chair', 40, 44], ['plant2', 59, 24]],
  cs: [['desk2', 70, 26], ['chair', 74, 32], ['desk2', 78, 26], ['chair', 82, 32], ['plant', 96, 24]],
  meeting: [['sofa', 36, 64], ['ctable', 40, 72], ['sofa', 44, 64], ['tv', 52, 60], ['plant', 34, 60]],
  management: [['desk2', 72, 64], ['chair', 76, 70], ['chair', 80, 70], ['shelf', 68, 62], ['board', 88, 60], ['plant', 96, 62]],
};

function wallsFor(r) {
  const x = px(r.x), y = py(r.y), w = px(r.w), h = py(r.h), t = 10, door = 90;
  const cx = x + w / 2;
  return `
    <rect x="${x - t / 2}" y="${y - t / 2}" width="${w + t}" height="${t}" rx="4" fill="#39435a"/>
    <rect x="${x - t / 2}" y="${y - t / 2}" width="${t}" height="${h + t}" rx="4" fill="#39435a"/>
    <rect x="${x + w - t / 2}" y="${y - t / 2}" width="${t}" height="${h + t}" rx="4" fill="#39435a"/>
    <rect x="${x - t / 2}" y="${y + h - t / 2}" width="${(cx - door / 2) - x + t / 2}" height="${t}" rx="4" fill="#39435a"/>
    <rect x="${cx + door / 2}" y="${y + h - t / 2}" width="${x + w - (cx + door / 2) + t / 2}" height="${t}" rx="4" fill="#39435a"/>
    <rect x="${cx - door / 2}" y="${y + h - 3}" width="${door}" height="6" rx="3" fill="#e0b57f"/>`;
}

function tree(x, y, s) {
  return `<circle cx="${x}" cy="${y}" r="${34 * s}" fill="#27894b"/><circle cx="${x - 20 * s}" cy="${y + 14 * s}" r="${24 * s}" fill="#2f9e57"/><circle cx="${x + 20 * s}" cy="${y + 12 * s}" r="${26 * s}" fill="#37b565"/><rect x="${x - 5 * s}" y="${y + 30 * s}" width="${10 * s}" height="${26 * s}" fill="#6b4a2f"/>`;
}

function artSVG(fl) {
  fl = fl || curFloor || 1;
  const _rooms = (ROOMS_LIVE || ROOMS).filter((r) => (r.floor || 1) === fl);
  const _booths = BOOTHS.filter((b) => (b.floor || 1) === fl);
  const _lay = LAY || LAYOUT;
  const S = [];
  S.push(`<defs>
    <pattern id="pat-tile" width="46" height="46" patternUnits="userSpaceOnUse"><rect width="46" height="46" fill="#e7e2d8"/><path d="M0 0H46V46" fill="none" stroke="#d4cec2" stroke-width="2"/></pattern>
    <pattern id="pat-carpet" width="34" height="34" patternUnits="userSpaceOnUse"><rect width="34" height="34" fill="#8f9bd4"/><circle cx="8" cy="8" r="2.4" fill="#a5b0e2"/><circle cx="25" cy="25" r="2.4" fill="#7d89c4"/></pattern>
    <pattern id="pat-carpet2" width="30" height="30" patternUnits="userSpaceOnUse"><rect width="30" height="30" fill="#cfd4dd"/><path d="M0 15H30M15 0V30" stroke="#c0c6d2" stroke-width="2"/></pattern>
    <pattern id="pat-wood" width="120" height="26" patternUnits="userSpaceOnUse"><rect width="120" height="26" fill="#e6c79a"/><path d="M0 0H120M60 0V26" stroke="#d3b183" stroke-width="3"/></pattern>
    <pattern id="pat-conc" width="40" height="40" patternUnits="userSpaceOnUse"><rect width="40" height="40" fill="#c9ccd3"/><circle cx="10" cy="12" r="1.6" fill="#b7bac2"/><circle cx="28" cy="30" r="1.6" fill="#b7bac2"/></pattern>
    <pattern id="pat-grass" width="56" height="56" patternUnits="userSpaceOnUse"><rect width="56" height="56" fill="#cdeccb"/><circle cx="12" cy="14" r="2.6" fill="#b5dcb4"/></pattern>
    ${furnDefs()}
  </defs>`);
  /* الأرضية العامة (ممرات) + الحزام الأخضر */
  S.push(`<rect x="0" y="0" width="${W}" height="${H}" fill="url(#pat-tile)"/>`);
  S.push(`<rect x="0" y="0" width="${px(2.5)}" height="${H}" fill="#cdeccb"/>`);
  S.push(tree(px(1.2), py(12), 1), tree(px(1.4), py(38), 1.25), tree(px(1.1), py(66), 1.1), tree(px(1.5), py(90), 1.3));
  /* أرضيات الغرف + الجدران + الأثاث */
  _rooms.forEach((r) => {
    S.push(`<rect x="${px(r.x)}" y="${py(r.y)}" width="${px(r.w)}" height="${py(r.h)}" fill="url(#${FLOOR_OF[r.id] || 'pat-tile'})" rx="6"/>`);
  });
  _rooms.forEach((r) => {
    (_lay[r.id] || []).forEach(([t, fx, fy, rot]) => {
      const sz = FURN_SIZE[t] || [100, 60];
      const cx = px(fx) + sz[0] / 2, cy = py(fy) + sz[1] / 2;
      S.push(`<use href="#of-${t}" class="of-furn" x="${px(fx)}" y="${py(fy)}"${rot ? ` transform="rotate(${rot} ${cx} ${cy})"` : ''}/>`);
    });
  });
  _rooms.forEach((r) => S.push(wallsFor(r)));
  /* بوكسات الاجتماع الخاصة (V3-2) */
  _booths.forEach((b) => {
    S.push(`<rect x="${px(b.x)}" y="${py(b.y)}" width="${px(b.w)}" height="${py(b.h)}" fill="url(#pat-wood)" rx="4"/>`);
    S.push(wallsFor(b));
    S.push(`<use href="#of-ctable" class="of-furn" x="${px(b.x + b.w / 2) - 45}" y="${py(b.y + 3)}"/>`);
  });
  /* سور المبنى الخارجي */
  S.push(`<rect x="${px(2.5)}" y="4" width="${W - px(2.5) - 6}" height="${H - 10}" fill="none" stroke="#39435a" stroke-width="14" rx="18"/>`);
  return `<svg class="of-art" viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" aria-hidden="true">${S.join('')}</svg>`;
}

/* ================= الواجهة ================= */

export function renderOffice(host) {
  host.innerHTML = '';
  host.classList.add('office-scope');
  if (state.user && state.user.role === 'client') curFloor = 1;
  spawn();
  if (state.user && state.user.role === 'client' && me.x === 50 && me.y === 92) me = meAll['1'] = { x: 83, y: 40 };

  /* V3-3: دمج تخطيط البنّاء المحفوظ — لا يُعاد التحميل أثناء التحرير حتى تعيش التعديلات غير المحفوظة */
  if (!layoutLoaded || !editOn) {
    ROOMS_LIVE = ROOMS.map((r) => Object.assign({}, r));
    LAY = JSON.parse(JSON.stringify(LAYOUT));
    const olDoc = (state.settings || []).find((x) => x.id === 'officeLayout');
    if (olDoc && olDoc.layout) { for (const k of Object.keys(olDoc.layout)) LAY[k] = olDoc.layout[k]; }
    if (olDoc && Array.isArray(olDoc.rooms)) olDoc.rooms.forEach((rc) => {
      const r = ROOMS_LIVE.find((x) => x.id === rc.id);
      if (r) Object.assign(r, { x: rc.x, y: rc.y, w: rc.w, h: rc.h, ar: rc.ar || r.ar, en: rc.en || r.en });
      else ROOMS_LIVE.push(Object.assign({ ic: 'star', color: '#3d8bff' }, rc));
    });
    layoutLoaded = true;
  }
  const online = () => new Set(state.online || []);
  const team = () => (state.users || []).filter((u) => u.role !== 'client' && u.role !== 'superadmin');

  /* ---- الرأس ---- */
  const head = el('div', { class: 'office-head' });
  const headLeft = el('div', {}, [
    el('h1', { class: 'office-h1', html: '🏢 MEE M <i>Virtual Office</i>' }),
    el('div', { class: 'office-sub', text: getLang() === 'ar' ? 'اتحرك بـ WASD أو الأسهم — أو المس أي مكان في المكتب' : 'Move with WASD / arrows — or tap anywhere' }),
  ]);
  const statusBox = el('div', { class: 'of-status-box' }, STATUSES.map((st) => el('button', {
    class: 'of-status-chip' + (st.id === myStatus ? ' on' : ''),
    style: { '--sc': STATUS_COLOR[st.id] },
    html: `<span>${st.ic}</span><span>${getLang() === 'ar' ? st.ar : st.en}</span>`,
    onclick: () => {
      myStatus = st.id;
      localStorage.setItem('office_status', st.id);
      socket.send({ type: 'status', status: st.id });
      sendPos(true);
      renderOffice(host);
    },
  })));
  const liveCount = el('div', { class: 'office-live' });
  head.append(headLeft, statusBox, liveCount);
  host.appendChild(head);

  /* ---- الكاميرا + العالم ---- */
  let zoom = 'fit';
  const viewport = el('div', { class: 'of-viewport', dir: 'ltr' });
  const map = el('div', { class: 'office-map' });
  map.innerHTML = artSVG(curFloor);

  function applyCam() {
    const vw = viewport.clientWidth || 1, vh = viewport.clientHeight || 1;
    const zFit = Math.min(vw / W, vh / H);
    const eff = zoom === 'fit' ? zFit : Math.max(zFit * 1.05, Math.min(2.6, zoom));
    let tx, ty;
    if (zoom === 'fit') {
      tx = (vw - W * eff) / 2;
      ty = (vh - H * eff) / 2;
    } else {
      tx = vw / 2 - px(me.x) * eff;
      ty = vh / 2 - py(me.y) * eff;
      tx = Math.min(0, Math.max(vw - W * eff, tx));
      ty = Math.min(0, Math.max(vh - H * eff, ty));
    }
    map.style.transform = `translate(${tx.toFixed(1)}px, ${ty.toFixed(1)}px) scale(${eff.toFixed(4)})`;
    map.dataset.zoom = (zoom === 'fit' ? zFit : eff).toFixed(3);
  }

  const zoomLbl = el('span', { class: 'of-zlbl', text: '⤢' });
  const hud = el('div', { class: 'of-hud', dir: 'ltr' }, [
    el('button', { class: 'of-hbtn', text: '−', title: getLang() === 'ar' ? 'تصغير' : 'Zoom out', onclick: () => { const cur = zoom === 'fit' ? Math.min(viewport.clientWidth / W, viewport.clientHeight / H) : zoom; zoom = Math.max(0.4, cur / 1.25); zoomLbl.textContent = Math.round((zoom / Math.min(viewport.clientWidth / W, viewport.clientHeight / H)) * 100) + '%'; applyCam(); } }),
    zoomLbl,
    el('button', { class: 'of-hbtn', text: '+', title: getLang() === 'ar' ? 'تكبير' : 'Zoom in', onclick: () => { const cur = zoom === 'fit' ? Math.min(viewport.clientWidth / W, viewport.clientHeight / H) : zoom; zoom = Math.min(2.6, cur * 1.25); zoomLbl.textContent = Math.round((zoom / Math.min(viewport.clientWidth / W, viewport.clientHeight / H)) * 100) + '%'; applyCam(); } }),
    el('button', { class: 'of-hbtn', text: '⤢', title: getLang() === 'ar' ? 'كل المكتب' : 'Fit', onclick: () => { zoom = 'fit'; zoomLbl.textContent = '⤢'; applyCam(); } }),
  ]);
  viewport.addEventListener('wheel', (e) => {
    e.preventDefault();
    const zFit = Math.min(viewport.clientWidth / W, viewport.clientHeight / H);
    const cur = zoom === 'fit' ? zFit : zoom;
    zoom = Math.max(zFit, Math.min(2.6, cur * (e.deltaY < 0 ? 1.12 : 0.9)));
    if (zoom <= zFit * 1.01) zoom = 'fit';
    applyCam();
  }, { passive: false });
  /* pinch-zoom للمس */
  let pinch0 = null;
  viewport.addEventListener('touchstart', (e) => { if (e.touches.length === 2) pinch0 = { d: Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY), z: zoom === 'fit' ? Math.min(viewport.clientWidth / W, viewport.clientHeight / H) : zoom }; }, { passive: true });
  viewport.addEventListener('touchmove', (e) => {
    if (pinch0 && e.touches.length === 2) {
      const d = Math.hypot(e.touches[0].clientX - e.touches[1].clientX, e.touches[0].clientY - e.touches[1].clientY);
      zoom = Math.max(0.4, Math.min(2.6, pinch0.z * (d / pinch0.d)));
      applyCam();
    }
  }, { passive: true });
  viewport.addEventListener('touchend', (e) => { if (e.touches.length < 2) pinch0 = null; });

  /* ---- الغرف ---- */
  const roomEls = {};
  (ROOMS_LIVE || ROOMS).filter((r) => (r.floor || 1) === curFloor).forEach((r) => {
    const myDept = DEPT_OF_ROLE[state.user.role] === r.id;
    const allowed = !r.roles || r.roles.includes(state.user.role);
    const room = el('div', {
      class: 'office-room' + (myDept ? ' mine' : '') + (r.locked && !allowed ? ' locked' : ''),
      style: { left: r.x + '%', top: r.y + '%', width: r.w + '%', height: r.h + '%' },
      dataset: { room: r.id },
      onclick: () => {
        if (editOn) { selRoom = r.id; renderOffice(host); return; }
        if (state.user.role === 'client' && !['clounge', 'reception'].includes(r.id)) { toast(getLang() === 'ar' ? '🔒 منطقة فريق MEE M' : '🔒 Team area', 'err'); return; }
        if (r.id === 'reception') { location.hash = '#/dashboard'; return; }
        if (!allowed) { toast(getLang() === 'ar' ? '🔒 القسم ده للإدارة' : '🔒 Management only', 'err'); return; }
        if (r.route) location.hash = r.route;
      },
    }, [
      el('div', { class: 'or-label' }, [
        el('span', { class: 'or-ic', html: icon(r.id === 'reception' ? 'star' : r.ic) }),
        el('span', { class: 'or-name', text: getLang() === 'ar' ? r.ar : r.en }),
      ]),
      el('div', { class: 'or-people' }),
      el('div', { class: 'or-count num' }),
    ]);
    room.style.setProperty('--rc', r.color);
    if (editOn && ['admin', 'superadmin'].includes(state.user.role)) {
      room.addEventListener('pointerdown', (e) => {
        e.preventDefault();
        selRoom = r.id;
        const sx = e.clientX, sy = e.clientY, ox = r.x, oy = r.y;
        const b = map.getBoundingClientRect();
        const move = (ev) => {
          r.x = Math.max(0, Math.min(95, ox + ((ev.clientX - sx) / b.width) * 100));
          r.y = Math.max(0, Math.min(95, oy + ((ev.clientY - sy) / b.height) * 100));
          room.style.left = r.x + '%'; room.style.top = r.y + '%';
        };
        const up = () => { ['pointermove', 'mousemove'].forEach((n) => window.removeEventListener(n, move)); ['pointerup', 'mouseup'].forEach((n) => window.removeEventListener(n, up)); renderOffice(host); };
        ['pointermove', 'mousemove'].forEach((n) => window.addEventListener(n, move));
        ['pointerup', 'mouseup'].forEach((n) => window.addEventListener(n, up));
      });
    }
    roomEls[r.id] = room;
    map.appendChild(room);
  });

  /* ---- الأفاتارات (sprite + لوحة اسم) ---- */
  const avLayer = el('div', { class: 'of-layer' });
  const SPR = `<svg viewBox="0 0 40 34" class="of-body"><rect x="12" y="12" width="16" height="14" rx="6" fill="#39435a"/><rect x="10" y="14" width="5" height="10" rx="2.5" fill="#39435a"/><rect x="25" y="14" width="5" height="10" rx="2.5" fill="#39435a"/><rect x="13" y="26" width="6" height="8" rx="3" fill="#232a38"/><rect x="21" y="26" width="6" height="8" rx="3" fill="#232a38"/></svg>`;
  function spriteNode(u, isMe, status) {
    const tag = el('div', { class: 'of-tag' + (isMe ? ' me' : '') }, [
      el('span', { class: 'of-tag-dot', style: { background: STATUS_COLOR[status] || '#22c55e' } }),
      el('span', { class: 'of-tag-name', text: isMe ? (getLang() === 'ar' ? 'أنت' : 'You') : (getLang() === 'ar' ? u.name : (u.nameEn || u.name)) }),
    ]);
    const spr = el('div', { class: 'of-sprite' }, [
      el('div', { class: 'of-head', html: avatarHTML(u, 'sm') }),
      el('div', { class: 'of-bodywrap', html: SPR }),
    ]);
    return el('div', { class: 'of-av' + (isMe ? ' me' : ' clickable'), style: { '--sc': STATUS_COLOR[status] || '#22c55e' }, title: isMe ? '' : (getLang() === 'ar' ? 'رسالة لـ ' : 'Message ') + u.name }, [tag, spr]);
  }
  const myAv = spriteNode(state.user, true, myStatus);
  avLayer.appendChild(myAv);
  map.appendChild(avLayer);
  const fxLayer = el('div', { class: 'of-layer of-fx' });
  map.appendChild(fxLayer);

  /* ---- V3-2: بوكسات + كائنات تفاعلية ---- */
  const boothEls = {};
  boothsOf(curFloor).forEach((b) => {
    const bd = el('div', { class: 'of-booth', style: { left: b.x + '%', top: b.y + '%', width: b.w + '%', height: b.h + '%' } }, [
      el('div', { class: 'ob-label', html: '🔒 <span>' + (getLang() === 'ar' ? b.ar : b.en) + '</span>' }),
      el('div', { class: 'ob-people' }),
    ]);
    boothEls[b.id] = bd;
    map.appendChild(bd);
  });
  HOTSPOT_DEFS.forEach((h) => {
    const room = (ROOMS_LIVE || ROOMS).find((r) => r.id === h.room);
    const item = room && ((LAY || LAYOUT)[h.room] || []).find((it) => it[0] === h.type);
    if (!room || !item || (room.floor || 1) !== curFloor) return;
    const sz = FURN_SIZE[h.type] || [100, 60];
    map.appendChild(el('button', {
      class: 'of-hot', title: getLang() === 'ar' ? h.ar : h.en,
      style: { left: item[1] + '%', top: item[2] + '%', width: ((sz[0] / W) * 100).toFixed(2) + '%', height: ((sz[1] / H) * 100).toFixed(2) + '%' },
      onclick: (e) => {
        e.stopPropagation();
        if (h.act.roles && !h.act.roles.includes(state.user.role)) { toast(getLang() === 'ar' ? '🔒 ده للإدارة' : '🔒 Management only', 'err'); return; }
        if (h.act.route) { location.hash = h.act.route; return; }
        if (h.act.emote) sendEmote(h.act.emote);
        if (h.act.bubble) sendBubble(h.act.bubble);
        if (h.act.break) {
          myStatus = 'busy'; localStorage.setItem('office_status', 'busy');
          socket.send({ type: 'status', status: 'busy' }); sendPos(true);
          statusBox.querySelectorAll('.of-status-chip').forEach((c2) => c2.classList.toggle('on', c2.textContent.includes(getLang() === 'ar' ? 'مشغول' : 'Busy')));
          myAv.querySelector('.of-tag-dot').style.background = STATUS_COLOR.busy;
          myAv.style.setProperty('--sc', STATUS_COLOR.busy);
          toast(getLang() === 'ar' ? '☕ بريك! حالتك بقت مشغول' : '☕ Break! Status set to busy');
        }
      },
    }, [el('span', { class: 'of-hot-ic', text: h.ic })]));
  });

  /* ---- V3-3: وضع البنّاء ---- */
  function toggleEdit() { editOn = !editOn; renderOffice(host); }
  async function saveLayout() {
    try {
      await api.upsert('settings', {
        id: 'officeLayout',
        layout: LAY,
        rooms: ROOMS_LIVE.map((r) => ({ id: r.id, ar: r.ar, en: r.en, x: Math.round(r.x * 10) / 10, y: Math.round(r.y * 10) / 10, w: Math.round(r.w * 10) / 10, h: Math.round(r.h * 10) / 10, color: r.color, floor: r.floor })),
      });
      toast(getLang() === 'ar' ? '💾 اتحفظ — كل الفريق هيشوف نفس المكتب' : '💾 Saved for everyone');
    } catch (e) { toast('حفظ ممنوع: ' + e.message, 'err'); }
  }
  async function resetLayout() {
    try { await api.remove('settings', 'officeLayout'); } catch (e) {}
    for (let i = ROOMS.length - 1; i >= 0; i--) if (!DEFAULT_ROOM_IDS.has(ROOMS[i].id)) ROOMS.splice(i, 1);
    layoutLoaded = false;
    toast(getLang() === 'ar' ? '↩️ رجعنا للتخطيط الافتراضي' : '↩️ Default layout restored');
    renderOffice(host);
  }
  function addRoom(name) {
    const id = 'custom' + Date.now().toString(36);
    const r = { id, ar: name, en: String(name).toUpperCase(), ic: 'star', x: 38, y: 38, w: 16, h: 14, color: '#3d8bff', floor: curFloor };
    ROOMS.push(r); ROOMS_LIVE.push(Object.assign({}, r)); LAY[id] = [];
    selRoom = id;
    renderOffice(host);
  }
  if (editOn && ['admin', 'superadmin'].includes(state.user.role)) {
    host.classList.add('of-editing');
    const blayer = el('div', { class: 'of-layer of-bl' });
    map.appendChild(blayer);
    (ROOMS_LIVE || ROOMS).filter((r) => (r.floor || 1) === curFloor).forEach((r) => {
      (LAY[r.id] || []).forEach((item) => {
        const t = item[0];
        const sz = FURN_SIZE[t] || [100, 60];
        const bx = el('div', { class: 'of-bitem' + (r.id === selRoom ? ' sel' : ''), title: t, style: { left: item[1] + '%', top: item[2] + '%', width: ((sz[0] / W) * 100).toFixed(2) + '%', height: ((sz[1] / H) * 100).toFixed(2) + '%' } });
        bx.appendChild(el('button', { class: 'of-bx', text: '✖', title: getLang() === 'ar' ? 'حذف' : 'Delete', onclick: (e) => { e.stopPropagation(); LAY[r.id] = (LAY[r.id] || []).filter((x) => x !== item); renderOffice(host); } }));
        bx.appendChild(el('button', { class: 'of-bx rr', text: '↻', title: getLang() === 'ar' ? 'تدوير ٩٠°' : 'Rotate', onclick: (e) => { e.stopPropagation(); item[3] = ((item[3] || 0) + 90) % 360; renderOffice(host); } }));
        bx.addEventListener('pointerdown', (e) => {
          if (e.target.closest('.of-bx')) return;
          e.preventDefault(); e.stopPropagation();
          const move = (ev) => {
            const b = map.getBoundingClientRect();
            item[1] = Math.round(Math.max(0, Math.min(97, ((ev.clientX - b.left) / b.width) * 100)) * 10) / 10;
            item[2] = Math.round(Math.max(0, Math.min(97, ((ev.clientY - b.top) / b.height) * 100)) * 10) / 10;
            bx.style.left = item[1] + '%'; bx.style.top = item[2] + '%';
          };
          const up = () => { ['pointermove', 'mousemove'].forEach((n) => window.removeEventListener(n, move)); ['pointerup', 'mouseup'].forEach((n) => window.removeEventListener(n, up)); renderOffice(host); };
          ['pointermove', 'mousemove'].forEach((n) => window.addEventListener(n, move));
          ['pointerup', 'mouseup'].forEach((n) => window.addEventListener(n, up));
        });
        blayer.appendChild(bx);
      });
    });
    const bar = el('div', { class: 'of-bbar', dir: 'rtl' });
    bar.append(
      el('span', { class: 'of-bt', text: getLang() === 'ar' ? '🛠️ البنّاء — اسحب الأثاث والغرف:' : '🛠️ Builder — drag furniture/rooms:' }),
      el('select', { class: 'of-pal', onchange: (e) => { if (!e.target.value) return; (LAY[selRoom] = LAY[selRoom] || []).push([e.target.value, 40, 40]); e.target.value = ''; renderOffice(host); } }, [
        el('option', { value: '', text: getLang() === 'ar' ? '➕ أضف أثاث لـ«' + ((ROOMS_LIVE.find((r) => r.id === selRoom) || {}).ar || '') + '»' : '➕ add to room' }),
        ...Object.keys(FURN_SIZE).map((t) => el('option', { value: t, text: t })),
      ]),
      el('button', { class: 'of-hbtn', text: '🏷️', title: getLang() === 'ar' ? 'قسم جديد' : 'New room', onclick: () => {
        const wrap = el('span', { class: 'of-newroom' }, []);
        const inp = el('input', { class: 'of-say', placeholder: getLang() === 'ar' ? 'اسم القسم' : 'Room name' });
        inp.onkeydown = (ev) => { if (ev.key === 'Enter' && inp.value.trim()) { wrap.remove(); addRoom(inp.value.trim()); } };
        wrap.appendChild(inp); bar.appendChild(wrap); inp.focus();
      } }),
      el('button', { class: 'of-hbtn', text: '💾', title: getLang() === 'ar' ? 'حفظ للجميع' : 'Save for all', onclick: () => saveLayout() }),
      el('button', { class: 'of-hbtn', text: '🗑️', title: getLang() === 'ar' ? 'افتراضي' : 'Reset', onclick: () => resetLayout() }),
      el('button', { class: 'of-hbtn', text: '✕', title: getLang() === 'ar' ? 'خروج' : 'Exit', onclick: () => toggleEdit() }),
    );
    viewport.appendChild(bar);
  }

  viewport.appendChild(map);
  viewport.appendChild(hud);
  /* V3-3: مبدّل الطوابق + زر البنّاء */
  hud.appendChild(el('span', { class: 'of-hsep' }));
  [1, 2].forEach((fl) => hud.appendChild(el('button', {
    class: 'of-flr' + (fl === curFloor ? ' on' : ''), text: fl === 1 ? '١' : '٢',
    title: (getLang() === 'ar' ? 'الطابق ' : 'Floor ') + fl,
    onclick: () => {
      if (state.user.role === 'client') { toast(getLang() === 'ar' ? '🔒 العملاء في الطابق ١' : '🔒 Clients stay on floor 1', 'err'); return; }
      meAll[String(curFloor)] = me; curFloor = fl; me = meAll[String(fl)]; renderOffice(host);
    },
  })));
  if (['admin', 'superadmin'].includes(state.user.role)) {
    hud.appendChild(el('button', { class: 'of-hbtn of-build', text: '🛠️', title: getLang() === 'ar' ? 'بنّاء المكتب' : 'Office builder', onclick: () => toggleEdit() }));
  }
  /* V3-2: إيموتات + حقل «قول حاجة» في الـ HUD */
  hud.appendChild(el('span', { class: 'of-hsep' }));
  EMOTES.forEach((em) => hud.appendChild(el('button', { class: 'of-emo', text: em, title: em, onclick: () => sendEmote(em) })));
  hud.appendChild(el('input', {
    class: 'of-say', dir: getLang() === 'ar' ? 'rtl' : 'ltr',
    placeholder: getLang() === 'ar' ? 'قول حاجة لقريبينك…' : 'Say something nearby…',
    onkeydown: (e) => { if (e.key === 'Enter') { const v = e.target.value.trim(); if (v) sendBubble(v); e.target.value = ''; } },
  }));
  const nearBar = el('div', { class: 'of-near', dir: 'rtl' });
  viewport.appendChild(nearBar);
  const chanList = el('div', { class: 'oc-list' });
  const chanIn = el('input', { class: 'input oc-in', placeholder: getLang() === 'ar' ? 'رسالة لأهل البوكس…' : 'Message the pod…' });
  chanIn.onkeydown = (e) => { if (e.key === 'Enter') { const v = chanIn.value.trim(); if (v) sendBubble(v); chanIn.value = ''; } };
  const chan = el('div', { class: 'of-chan card', dir: 'rtl', hidden: true }, [
    el('div', { class: 'oc-t', text: getLang() === 'ar' ? '🔒 قناة البوكس — اللي بره مش شايفكم' : '🔒 Pod channel — hidden outside' }),
    chanList, chanIn,
  ]);
  viewport.appendChild(chan);
  /* V3-3: لوحة العميل في صالة العملاء */
  if (state.user.role === 'client') {
    const myPrj = (state.projects || []).filter((p) => p.clientId === state.user.clientId);
    const am = (state.users || []).find((u) => u.role === 'admin');
    viewport.appendChild(el('div', { class: 'of-clpanel card', dir: 'rtl' }, [
      el('div', { class: 'oc-t', text: getLang() === 'ar' ? '🏢 أهلًا بيك في مكتب MEE M' : '🏢 Welcome to MEE M office' }),
      am ? el('div', { class: 'oc-am' }, [
        el('span', { html: avatarHTML(am, 'sm') }),
        el('span', { text: (getLang() === 'ar' ? 'مدير حسابك: ' : 'Your AM: ') + am.name }),
        el('button', { class: 'of-near-b', title: getLang() === 'ar' ? 'مراسلة' : 'Message', onclick: () => { location.hash = '#/chat'; } }, [el('span', { text: '💬' })]),
      ]) : null,
      el('div', { class: 'oc-t', text: getLang() === 'ar' ? 'مشاريعك:' : 'Your projects:' }),
      el('div', { class: 'oc-list' }, myPrj.length ? myPrj.map((p) => el('span', { class: 'oc-m', text: '📁 ' + p.title })) : [el('span', { class: 'dim', text: '—' })]),
      el('button', { class: 'btn primary', text: getLang() === 'ar' ? '📅 دعوة لاجتماع' : '📅 Invite to meeting', onclick: () => { location.hash = '#/meetings'; } }),
    ]));
  }
  host.appendChild(viewport);

  /* tap-to-move على أرضية المكتب (إحداثيات العالم الصحيحة مع أي zoom) */
  map.addEventListener('click', (e) => {
    if (e.target.closest('.office-room') || e.target.closest('.of-av')) return;
    const b = map.getBoundingClientRect();
    target = {
      x: Math.max(2, Math.min(98, ((e.clientX - b.left) / b.width) * 100)),
      y: Math.max(2, Math.min(98, ((e.clientY - b.top) / b.height) * 100)),
    };
  });

  /* ---- V3-2: محرك القرب + الفقاعات + الإيموتات + البوكسات ---- */
  const fxNodes = {};
  const typUntil = {};
  const distPx = (a, b) => Math.hypot(px(a.x) - px(b.x), py(a.y) - py(b.y));
  function canHear(uid, senderRoom) {
    const p = uid === state.user.id ? me : (state.pos || {})[uid];
    if (!p) return false;
    if ((p.floor || 1) !== curFloor) return false;
    const myRoom = roomAt(me.x, me.y);
    const theirRoom = senderRoom || roomAt(p.x, p.y);
    if (PRIVATE.has(myRoom) || PRIVATE.has(theirRoom)) return myRoom === theirRoom;
    return distPx(me, p) <= NEAR_R;
  }
  const fxAnchor = (uid) => (uid === state.user.id ? me : (state.pos || {})[uid] || null);
  function placeFx() {
    for (const uid of Object.keys(fxNodes)) {
      const p = fxAnchor(uid); if (!p) continue;
      for (const k of ['bub', 'emo', 'badge']) { const n = fxNodes[uid][k]; if (n) { n.style.left = p.x + '%'; n.style.top = p.y + '%'; } }
    }
  }
  function dropFx(uid, key) { const n = fxNodes[uid]; if (n && n[key]) { n[key].remove(); n[key] = null; } }
  function showBubble(uid, text) {
    dropFx(uid, 'bub');
    const node = el('div', { class: 'of-bubble', text });
    const p = fxAnchor(uid); if (p) { node.style.left = p.x + '%'; node.style.top = p.y + '%'; }
    fxLayer.appendChild(node);
    (fxNodes[uid] = fxNodes[uid] || { bub: null, emo: null, badge: null }).bub = node;
    setTimeout(() => dropFx(uid, 'bub'), 4600);
  }
  function showEmote(uid, em) {
    dropFx(uid, 'emo');
    const node = el('div', { class: 'of-emote', text: em });
    const p = fxAnchor(uid); if (p) { node.style.left = p.x + '%'; node.style.top = p.y + '%'; }
    fxLayer.appendChild(node);
    (fxNodes[uid] = fxNodes[uid] || { bub: null, emo: null, badge: null }).emo = node;
    setTimeout(() => dropFx(uid, 'emo'), 2100);
  }
  function sendBubble(text) {
    showBubble(state.user.id, text);
    socket.send({ type: 'obubble', text, room: roomAt(me.x, me.y) });
  }
  function sendEmote(em) {
    showEmote(state.user.id, em);
    socket.send({ type: 'oemote', emote: em, room: roomAt(me.x, me.y) });
  }
  function setBadge(uid, txt) {
    const n = (fxNodes[uid] = fxNodes[uid] || { bub: null, emo: null, badge: null });
    if (!txt) { dropFx(uid, 'badge'); return; }
    if (!n.badge) {
      const node = el('div', { class: 'of-badge' });
      const p = fxAnchor(uid); if (p) { node.style.left = p.x + '%'; node.style.top = p.y + '%'; }
      fxLayer.appendChild(node); n.badge = node;
    }
    if (n.badge.textContent !== txt) n.badge.textContent = txt;
  }
  function refreshNear() {
    const now = Date.now();
    const on = online();
    const myRoom = roomAt(me.x, me.y);
    nearBar.innerHTML = '';
    const near = team().filter((u) => u.id !== state.user.id && on.has(u.id) && (state.pos || {})[u.id] && canHear(u.id));
    if (near.length) {
      nearBar.appendChild(el('span', { class: 'of-near-t', text: getLang() === 'ar' ? 'قريبين منك:' : 'Near you:' }));
      near.forEach((u) => nearBar.appendChild(el('button', { class: 'of-near-b', onclick: () => openDM(u.id) }, [
        el('span', { html: avatarHTML(u, 'sm') }),
        el('span', { text: getLang() === 'ar' ? u.name : (u.nameEn || u.name) }),
        el('span', { class: 'of-near-dm', text: '💬' }),
      ])));
    }
    team().forEach((u) => {
      if (u.id === state.user.id) return;
      const p = (state.pos || {})[u.id];
      if (!p || !on.has(u.id)) { setBadge(u.id, ''); return; }
      const theirRoom = roomAt(p.x, p.y);
      let btxt = '';
      if (PRIVATE.has(theirRoom) && theirRoom !== myRoom) btxt = '🔒';
      else if ((typUntil[u.id] || 0) > now) btxt = '✍️';
      else if (p.status === 'busy') btxt = '🎧';
      setBadge(u.id, btxt);
    });
    boothsOf(curFloor).forEach((b) => {
      const pe = (boothEls[b.id] || {}).querySelector ? boothEls[b.id].querySelector('.ob-people') : null;
      if (!pe) return;
      pe.innerHTML = '';
      const here = [];
      if (myRoom === b.id) here.push(state.user);
      team().forEach((u) => { if (u.id !== state.user.id && on.has(u.id) && (state.pos || {})[u.id] && roomAt((state.pos[u.id]).x, (state.pos[u.id]).y) === b.id) here.push(u); });
      here.slice(0, 4).forEach((u) => pe.appendChild(el('span', { class: 'or-av', html: avatarHTML(u, 'sm'), title: u.name })));
    });
    if (PRIVATE.has(myRoom)) {
      chan.hidden = false;
      chanList.innerHTML = '';
      const mates = [state.user, ...team().filter((u) => u.id !== state.user.id && on.has(u.id) && (state.pos || {})[u.id] && roomAt((state.pos[u.id]).x, (state.pos[u.id]).y) === myRoom)];
      mates.forEach((u) => chanList.appendChild(el('span', { class: 'oc-m' }, [
        el('span', { html: avatarHTML(u, 'sm') }),
        el('span', { text: getLang() === 'ar' ? u.name : (u.nameEn || u.name) }),
      ])));
    } else chan.hidden = true;
    placeFx();
  }
  const offSock = socket.on((m) => {
    if (!host.isConnected) { offSock(); return; }
    if (m.type === 'obubble' && m.userId !== state.user.id && canHear(m.userId, m.room)) showBubble(m.userId, m.text);
    else if (m.type === 'oemote' && m.userId !== state.user.id && canHear(m.userId, m.room)) showEmote(m.userId, m.emote);
    else if (m.type === 'otyping' && m.from) typUntil[m.from] = Date.now() + 2500;
  });
  const v32Timer = setInterval(() => {
    if (!host.isConnected) { clearInterval(v32Timer); offSock(); return; }
    refreshNear();
  }, 700);

  /* ---- شريط المتصلين ---- */
  const strip = el('div', { class: 'office-strip card' });
  host.appendChild(strip);

  /* ---- الرسم اللحظي ---- */
  function place(av, p) { av.style.left = p.x + '%'; av.style.top = p.y + '%'; }
  function setWalk(av, walking, dx) {
    av.classList.toggle('walking', !!walking);
    if (dx > 0.02) av.classList.remove('face-left');
    else if (dx < -0.02) av.classList.add('face-left');
  }
  function paintMe(dx) {
    place(myAv, me);
    myAv.querySelector('.of-tag-dot').style.background = STATUS_COLOR[myStatus] || '#22c55e';
    myAv.style.setProperty('--sc', STATUS_COLOR[myStatus] || '#22c55e');
    placeFx();
  }
  function paintOthers() {
    avLayer.querySelectorAll('.of-av:not(.me)').forEach((n) => n.remove());
    for (const [uid, p] of Object.entries(state.pos || {})) {
      if (uid === state.user.id) continue;
      if ((p.floor || 1) !== curFloor) continue;
      const u = userById(uid);
      if (!u) continue;
      const prev = prevPos[uid];
      const dx = prev ? p.x - prev.x : 0;
      prevPos[uid] = { x: p.x, y: p.y };
      const av = spriteNode(u, false, p.status);
      av.addEventListener('click', (e) => { e.stopPropagation(); openDM(u.id); });
      setWalk(av, Math.abs(dx) > 0.05, dx);
      place(av, p);
      avLayer.appendChild(av);
    }
    placeFx();
  }
  function paintRooms() {
    const on = online();
    const posMap = state.pos || {};
    (ROOMS_LIVE || ROOMS).forEach((r) => {
      const roomEl = roomEls[r.id];
      if (!roomEl) return;
      const here = [];
      if (roomAt(me.x, me.y) === r.id) here.push(state.user);
      for (const [uid, p] of Object.entries(posMap)) { if (p.room === r.id && on.has(uid) && uid !== state.user.id) here.push(userById(uid)); }
      if (!here.length) team().forEach((u) => { if (DEPT_OF_ROLE[u.role] === r.id && on.has(u.id) && !posMap[u.id]) here.push(u); });
      const pe = roomEl.querySelector('.or-people');
      pe.innerHTML = '';
      here.filter(Boolean).slice(0, 5).forEach((u) => pe.appendChild(el('span', { class: 'or-av', html: avatarHTML(u, 'sm'), title: u.name })));
      const c = roomEl.querySelector('.or-count');
      c.textContent = here.length ? String(here.length) : '';
    });
  }
  function paintHead() {
    const on = online();
    liveCount.innerHTML = '';
    liveCount.append(
      el('span', { class: 'office-dot' }),
      el('span', { class: 'num', text: String(team().filter((u) => on.has(u.id)).length) }),
      el('span', { text: getLang() === 'ar' ? 'في المكتب الآن' : 'in the office' })
    );
    strip.innerHTML = '';
    const onTeam = team().filter((u) => on.has(u.id));
    strip.append(
      el('div', { class: 'os-title', text: getLang() === 'ar' ? '🟢 متصلون الآن' : 'Online now' }),
      el('div', { class: 'os-list' }, onTeam.length ? onTeam.map((u) => {
        const st = (state.pos && state.pos[u.id] && state.pos[u.id].status) || 'available';
        return el('span', { class: 'os-person' }, [
          el('span', { html: avatarHTML(u, 'sm') }),
          el('span', { class: 'os-st-dot', style: { background: STATUS_COLOR[st] } }),
          el('span', { text: getLang() === 'ar' ? u.name : (u.nameEn || u.name) }),
        ]);
      }) : [el('span', { class: 'dim', text: getLang() === 'ar' ? 'مفيش حد متصل غيرك' : 'No one else online' })])
    );
  }
  function paintAll() { paintMe(); paintOthers(); paintRooms(); paintHead(); }
  paintAll();
  applyCam();

  /* ---- التحديث اللحظي ---- */
  const unsub = subscribe((what) => {
    if (!host.isConnected) { unsub(); return; }
    if (what === 'pos' || what === 'presence') paintAll();
    if (what === 'settings' && !editOn) layoutLoaded = false;
  });

  /* ---- حلقة الحركة ---- */
  const kd = (e) => { const tg = e.target; if (tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA' || tg.isContentEditable)) return; if (KEYS[e.key]) { keys.add(KEYS[e.key]); if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) e.preventDefault(); } };
  const ku = (e) => { if (KEYS[e.key]) keys.delete(KEYS[e.key]); };
  window.addEventListener('keydown', kd);
  window.addEventListener('keyup', ku);

  const joy = buildJoystick();
  let lastT = performance.now();
  let moving = false;
  function tick(t) {
    if (!host.isConnected) { window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku); if (joy) joy.remove(); joyVec = null; return; }
    const dt = Math.min(50, t - lastT); lastT = t;
    const sp = 0.028 * dt;
    let dx = 0, dy = 0;
    if (keys.has('up')) dy -= sp;
    if (keys.has('down')) dy += sp;
    if (keys.has('left')) dx -= sp;
    if (keys.has('right')) dx += sp;
    if (dx || dy) { target = null; me.x += dx; me.y += dy; }
    else if (joyVec) { dx = joyVec.x; dy = joyVec.y; me.x += joyVec.x * sp * 1.5; me.y += joyVec.y * sp * 1.5; }
    else if (target) {
      const tx = target.x - me.x, ty = target.y - me.y;
      const dist = Math.hypot(tx, ty);
      if (dist < 0.6) { me.x = target.x; me.y = target.y; target = null; }
      else { me.x += (tx / dist) * sp; me.y += (ty / dist) * sp; }
      dx = tx; dy = ty;
    }
    const wasMoving = moving;
    moving = !!(dx || dy);
    if (moving || wasMoving) {
      me.x = Math.max(2, Math.min(98, me.x));
      me.y = Math.max(2, Math.min(98, me.y));
      paintMe(dx);
      setWalk(myAv, moving, dx);
      sendPos(false);
      if (zoom !== 'fit') applyCam();
    }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
  sendPos(true);
  window.addEventListener('resize', applyCam);
}
