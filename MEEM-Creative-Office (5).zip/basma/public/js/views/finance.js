/* ============================================================
   MEEM | Creative Office — Phase 6: Finance
   فواتير (بنود/ضريبة/خصم) + دفعات جزئية + مصروفات + KPIs ربحية
   ============================================================ */
import { state, save, remove, userById, clientById } from '../store.js';
import { el, icon, clear, escapeHTML, toast, modal, confirmDialog, money, invTotal, invSubtotal } from '../ui.js';

const ISTATUS = {
  draft: ['مسودة', ''],
  sent: ['مُرسلة', 'warn'],
  paid: ['مدفوعة', 'ok'],
};
const todayStr = () => new Date().toISOString().slice(0, 10);
const isOverdueInv = (v) => v.status === 'sent' && v.due && v.due < todayStr();
const paidOf = (inv) => (state.payments || []).filter((p) => p.invoiceId === inv.id).reduce((s, p) => s + (+p.amount || 0), 0);
const thisMonth = () => new Date().toISOString().slice(0, 7);
let finTab = 'invoices'; // يتحمل إعادة التصيير بعد الحفظ
const inMonth = (iso, m) => (iso || '').slice(0, 7) === m;

export function renderFinance(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('money') + ' المالية', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'فواتير · دفعات · مصروفات — وصافي ربح محسوب أوتوماتيك' }),
    ]),
    el('button', { class: 'btn primary', html: icon('plus') + `<span>فاتورة جديدة</span>`, onclick: () => openInvoiceModal(null, draw) }),
  ]));
  const kpis = el('div', { class: 'kpis' });
  const tabs = el('div', { class: 'tabs' });
  const area = el('div');
  host.append(kpis, tabs, area);

  tabs.append(...[['invoices', '🧾 الفواتير'], ['payments', '💵 المدفوعات'], ['expenses', '📉 المصروفات']].map(([k, lb]) => el('button', {
    class: k === finTab ? 'active' : '', text: lb,
    onclick: (e) => { finTab = k; tabs.querySelectorAll('button').forEach((b) => b.classList.remove('active')); e.currentTarget.classList.add('active'); draw(); },
  })));

  function draw() {
    const m = thisMonth();
    const invs = state.invoices || [];
    const collectedM = (state.payments || []).filter((p) => inMonth(p.at, m)).reduce((s, p) => s + (+p.amount || 0), 0);
    const outstanding = invs.filter((v) => v.status !== 'paid').reduce((s, v) => s + (invTotal(v) - paidOf(v)), 0);
    const overdue = invs.filter(isOverdueInv).reduce((s, v) => s + (invTotal(v) - paidOf(v)), 0);
    const expM = (state.expenses || []).filter((e) => inMonth(e.at, m)).reduce((s, e) => s + (+e.amount || 0), 0);
    clear(kpis);
    kpis.append(
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'محصل (الشهر)' }), el('div', { class: 'k-value num', style: { color: 'var(--ok)' }, text: money(collectedM) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'مستحق' }), el('div', { class: 'k-value num', text: money(outstanding) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'متأخر 🔥' }), el('div', { class: 'k-value num', style: { color: 'var(--danger)' }, text: money(overdue) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'مصروفات (الشهر)' }), el('div', { class: 'k-value num', text: money(expM) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'صافي ربح (الشهر)' }), el('div', { class: 'k-value num', style: { color: collectedM - expM >= 0 ? 'var(--ok)' : 'var(--danger)' }, text: money(collectedM - expM) })]),
    );
    clear(area);
    if (finTab === 'invoices') drawInvoices(area, draw);
    else if (finTab === 'payments') drawPayments(area, draw);
    else drawExpenses(area, draw);
  }
  draw();
}

function drawInvoices(area, onDone) {
  const list = [...(state.invoices || [])].sort((a, b) => (b.issuedAt || '').localeCompare(a.issuedAt || ''));
  if (!list.length) { area.appendChild(el('div', { class: 'empty card', style: { padding: '40px' }, text: 'لا فواتير — ابدأ واحدة جديدة 🧾' })); return; }
  const grid = el('div', { class: 'col', style: { gap: '9px' } });
  list.forEach((v) => {
    const c = clientById(v.clientId);
    const total = invTotal(v);
    const paid = paidOf(v);
    const rem = total - paid;
    const [lb, cl] = isOverdueInv(v) ? ['متأخرة ⏰', 'danger'] : (ISTATUS[v.status] || ['', '']);
    grid.appendChild(el('div', { class: 'card row wrap', style: { padding: '13px 15px', gap: '12px' } }, [
      el('div', { style: { width: '40px', height: '40px', borderRadius: '11px', background: 'rgba(52,211,153,.12)', color: 'var(--ok)', display: 'grid', placeItems: 'center', fontSize: '18px' }, text: '🧾' }),
      el('div', { class: 'grow', style: { minWidth: '220px' } }, [
        el('div', { class: 'row', style: { gap: '8px' } }, [
          el('span', { class: 'num', style: { fontWeight: '800', fontSize: '13px' }, text: v.num || v.id }),
          el('span', { class: 'badge ' + cl, text: lb }),
        ]),
        el('div', { style: { fontWeight: '700', fontSize: '14px', margin: '3px 0 2px' }, text: v.title || '' }),
        el('div', { class: 'dim', style: { fontSize: '12px' }, text: `${c ? c.name : '—'} · أصدرت ${v.issuedAt || '—'} · استحقاق ${v.due || '—'}` }),
      ]),
      el('div', { style: { textAlign: 'left', minWidth: '130px' } }, [
        el('div', { class: 'num', style: { fontWeight: '800', fontSize: '15px' }, text: money(total) }),
        el('div', { class: 'dim num', style: { fontSize: '11.5px' }, text: rem > 0 ? `متبقي ${money(rem)}` : 'مكتملة ✓' }),
      ]),
      el('div', { class: 'row', style: { gap: '6px' } }, [
        v.status !== 'paid' ? el('button', { class: 'btn sm ok', html: icon('money') + `<span>دفعة</span>`, onclick: () => openPaymentModal(v, onDone) }) : null,
        el('button', { class: 'btn sm ghost', html: icon('edit'), onclick: () => openInvoiceModal(v, onDone) }),
        el('button', { class: 'btn sm danger ghost', html: icon('trash'), onclick: async () => { if (await confirmDialog('حذف الفاتورة وكل دفعاتها؟', { danger: true })) { for (const p of (state.payments || []).filter((x) => x.invoiceId === v.id)) await remove('payments', p.id); await remove('invoices', v.id); onDone(); } } }),
      ]),
    ]));
  });
  area.appendChild(grid);
}

function drawPayments(area, onDone) {
  const list = [...(state.payments || [])].sort((a, b) => (b.at || '').localeCompare(a.at || ''));
  const wrap = el('div', {}, [
    el('div', { class: 'row', style: { marginBottom: '10px' } }, [el('div', { class: 'grow' })]),
  ]);
  if (!list.length) { wrap.appendChild(el('div', { class: 'empty card', style: { padding: '30px' }, text: 'لا مدفوعات مسجلة' })); area.appendChild(wrap); return; }
  const tbl = el('div', { class: 'fin-table' });
  tbl.appendChild(el('div', { class: 'fin-tr fin-th' }, [el('span', { text: 'التاريخ' }), el('span', { text: 'الفاتورة' }), el('span', { text: 'الطريقة' }), el('span', { text: 'المبلغ' }), el('span', { text: '' })]));
  list.forEach((p) => {
    const inv = (state.invoices || []).find((v) => v.id === p.invoiceId);
    tbl.appendChild(el('div', { class: 'fin-tr' }, [
      el('span', { class: 'num dim', text: (p.at || '').slice(0, 10) }),
      el('span', { text: inv ? (inv.num || inv.title) : '—' }),
      el('span', { class: 'dim', text: p.method || '—' }),
      el('span', { class: 'num', style: { fontWeight: '700', color: 'var(--ok)' }, text: money(p.amount) }),
      el('span', {}, [el('button', { class: 'btn ghost icon sm', html: icon('trash'), onclick: async () => { await remove('payments', p.id); if (inv && inv.status === 'paid') await save('invoices', { id: inv.id, status: 'sent' }); onDone(); } })]),
    ]));
  });
  wrap.appendChild(tbl);
  area.appendChild(wrap);
}

function drawExpenses(area, onDone) {
  const CATS = ['رواتب', 'أدوات', 'إعلانات', 'أجهزة', 'أوتسورس', 'إيجار', 'أخرى'];
  const head = el('div', { class: 'row', style: { marginBottom: '10px', gap: '8px' } }, [
    el('div', { class: 'grow' }),
    el('button', { class: 'btn sm primary', html: icon('plus') + `<span>مصروف جديد</span>`, onclick: () => openExpenseModal(onDone) }),
  ]);
  area.appendChild(head);
  const list = [...(state.expenses || [])].sort((a, b) => (b.at || '').localeCompare(a.at || ''));
  if (!list.length) { area.appendChild(el('div', { class: 'empty card', style: { padding: '30px' }, text: 'لا مصروفات' })); return; }
  const tbl = el('div', { class: 'fin-table' });
  tbl.appendChild(el('div', { class: 'fin-tr fin-th' }, [el('span', { text: 'التاريخ' }), el('span', { text: 'البند' }), el('span', { text: 'الفئة' }), el('span', { text: 'المشروع' }), el('span', { text: 'المبلغ' }), el('span', { text: '' })]));
  list.forEach((e) => {
    const prj = (state.projects || []).find((p) => p.id === e.projectId);
    tbl.appendChild(el('div', { class: 'fin-tr' }, [
      el('span', { class: 'num dim', text: (e.at || '').slice(0, 10) }),
      el('span', { text: e.title }),
      el('span', {}, [el('span', { class: 'badge', text: e.category })]),
      el('span', { class: 'dim', style: { fontSize: '12px' }, text: prj ? prj.title : '—' }),
      el('span', { class: 'num', style: { fontWeight: '700', color: 'var(--danger)' }, text: money(e.amount) }),
      el('span', {}, [el('button', { class: 'btn ghost icon sm', html: icon('trash'), onclick: async () => { await remove('expenses', e.id); onDone(); } })]),
    ]));
  });
  area.appendChild(tbl);

  function openExpenseModal(onDone2) {
    const doc = { title: '', category: 'أدوات', amount: 0, at: todayStr(), projectId: '' };
    const m = modal({
      title: '📉 مصروف جديد',
      body: [
        el('div', { class: 'field' }, [el('label', { text: 'البند *' }), el('input', { class: 'input', oninput: (e) => doc.title = e.target.value })]),
        el('div', { class: 'grid2' }, [
          el('div', { class: 'field' }, [el('label', { text: 'الفئة' }), el('select', { class: 'select', html: CATS.map((c) => `<option>${c}</option>`).join(''), onchange: (e) => doc.category = e.target.value })]),
          el('div', { class: 'field' }, [el('label', { text: 'المبلغ *' }), el('input', { class: 'input num', type: 'number', oninput: (e) => doc.amount = +e.target.value })]),
        ]),
        el('div', { class: 'grid2' }, [
          el('div', { class: 'field' }, [el('label', { text: 'التاريخ' }), el('input', { class: 'input', type: 'date', value: doc.at, oninput: (e) => doc.at = e.target.value })]),
          el('div', { class: 'field' }, [el('label', { text: 'على مشروع؟' }), el('select', { class: 'select', html: `<option value="">—</option>` + (state.projects || []).map((p) => `<option value="${p.id}">${escapeHTML(p.title)}</option>`).join(''), onchange: (e) => doc.projectId = e.target.value })]),
        ]),
      ],
      footer: [
        el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
        el('button', { class: 'btn primary', text: 'حفظ', onclick: async () => { if (!doc.title.trim() || !doc.amount) { toast('اكمل البند والمبلغ', 'warn'); return; } await save('expenses', doc); m.close(); toast('اتسجل المصروف', 'ok'); onDone2(); } }),
      ],
    });
  }
}

/* ================= مودال فاتورة ================= */
function openInvoiceModal(inv, onDone) {
  const isNew = !inv;
  const doc = Object.assign({
    num: '', clientId: (state.clients[0] || {}).id || '', projectId: '', title: '',
    tax: 14, discount: 0, notes: '', status: 'draft',
    issuedAt: todayStr(), due: new Date(Date.now() + 14 * 86400e3).toISOString().slice(0, 10),
    items: [],
  }, inv ? JSON.parse(JSON.stringify(inv)) : {});
  if (isNew) doc.num = 'INV-' + new Date().getFullYear() + '-' + String((state.invoices || []).length + 1).padStart(3, '0');

  const itemsBox = el('div', { class: 'col', style: { gap: '6px' } });
  const totalLbl = el('div', { class: 'fin-total num' });
  function drawItems() {
    clear(itemsBox);
    doc.items.forEach((it, idx) => {
      itemsBox.appendChild(el('div', { class: 'fin-item' }, [
        el('input', { class: 'input grow', placeholder: 'وصف البند', value: it.desc, oninput: (e) => { it.desc = e.target.value; upd(); } }),
        el('input', { class: 'input num', type: 'number', style: { width: '64px' }, value: it.qty, oninput: (e) => { it.qty = +e.target.value; upd(); } }),
        el('input', { class: 'input num', type: 'number', style: { width: '96px' }, value: it.price, oninput: (e) => { it.price = +e.target.value; upd(); } }),
        el('button', { class: 'btn ghost icon sm', html: icon('trash'), onclick: () => { doc.items.splice(idx, 1); drawItems(); } }),
      ]));
    });
    upd();
  }
  function upd() {
    const sub = invSubtotal(doc);
    const taxV = Math.round(sub * (+doc.tax || 0) / 100);
    totalLbl.innerHTML = `الإجمالي: <b>${money(sub)}</b> · ضريبة ${doc.tax || 0}%: <b>${money(taxV)}</b>${+doc.discount ? ` · خصم: <b>${money(doc.discount)}</b>` : ''} · <span style="color:var(--ok)">المطلوب: <b>${money(invTotal(doc))}</b></span>`;
  }

  const m = modal({
    title: isNew ? '🧾 فاتورة جديدة' : '🧾 ' + (inv.num || ''),
    size: 'wide',
    body: [
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'رقم الفاتورة' }), el('input', { class: 'input num', value: doc.num, oninput: (e) => doc.num = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'العنوان' }), el('input', { class: 'input', value: doc.title, oninput: (e) => doc.title = e.target.value })]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'العميل' }), el('select', { class: 'select', html: (state.clients || []).map((c) => `<option value="${c.id}" ${c.id === doc.clientId ? 'selected' : ''}>${escapeHTML(c.name)}</option>`).join(''), onchange: (e) => doc.clientId = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'المشروع' }), el('select', { class: 'select', html: `<option value="">—</option>` + (state.projects || []).map((p) => `<option value="${p.id}" ${p.id === doc.projectId ? 'selected' : ''}>${escapeHTML(p.title)}</option>`).join(''), onchange: (e) => doc.projectId = e.target.value })]),
      ]),
      el('div', {}, [
        el('div', { class: 'row', style: { marginBottom: '6px' } }, [
          el('label', { style: { fontWeight: '700', fontSize: '13px' }, text: 'البنود' }),
          el('div', { class: 'grow' }),
          el('button', { class: 'btn ghost sm', html: icon('plus') + `<span>بند</span>`, onclick: () => { doc.items.push({ desc: '', qty: 1, price: 0 }); drawItems(); } }),
        ]),
        itemsBox,
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'ضريبة %' }), el('input', { class: 'input num', type: 'number', value: doc.tax, oninput: (e) => { doc.tax = +e.target.value; upd(); } })]),
        el('div', { class: 'field' }, [el('label', { text: 'خصم' }), el('input', { class: 'input num', type: 'number', value: doc.discount, oninput: (e) => { doc.discount = +e.target.value; upd(); } })]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'تاريخ الإصدار' }), el('input', { class: 'input', type: 'date', value: doc.issuedAt, oninput: (e) => doc.issuedAt = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'الاستحقاق' }), el('input', { class: 'input', type: 'date', value: doc.due, oninput: (e) => doc.due = e.target.value })]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'الحالة' }), el('select', { class: 'select', html: Object.entries(ISTATUS).map(([k, v]) => `<option value="${k}" ${k === doc.status ? 'selected' : ''}>${v[0]}</option>`).join(''), onchange: (e) => doc.status = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'ملاحظات' }), el('input', { class: 'input', value: doc.notes || '', oninput: (e) => doc.notes = e.target.value })]),
      ]),
      totalLbl,
    ],
    footer: [
      el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: 'حفظ',
        onclick: async () => {
          if (!doc.items.length) { toast('ضيف بند واحد على الأقل', 'warn'); return; }
          const saved = await save('invoices', doc);
          doc.id = saved.id;
          m.close(); toast('اتحفظت الفاتورة ✓', 'ok'); onDone();
        },
      }),
    ],
  });
  drawItems();
}

/* ================= مودال دفعة ================= */
function openPaymentModal(inv, onDone) {
  const rem = invTotal(inv) - paidOf(inv);
  const doc = { invoiceId: inv.id, amount: rem, method: 'تحويل بنكي', at: new Date().toISOString(), by: state.user.id };
  const m = modal({
    title: '💵 تسجيل دفعة — ' + (inv.num || ''),
    body: [
      el('div', { class: 'ct-note', text: `المطلوب: ${money(invTotal(inv))} · المتبقي: ${money(rem)}` }),
      el('div', { class: 'field' }, [el('label', { text: 'المبلغ *' }), el('input', { class: 'input num', type: 'number', value: rem, oninput: (e) => doc.amount = +e.target.value })]),
      el('div', { class: 'field' }, [el('label', { text: 'طريقة الدفع' }), el('select', { class: 'select', html: ['تحويل بنكي', 'فودافون كاش', 'إنستاباي', 'كاش', 'شيك'].map((x) => `<option>${x}</option>`).join(''), onchange: (e) => doc.method = e.target.value })]),
    ],
    footer: [
      el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
      el('button', {
        class: 'btn ok', text: 'سجل الدفعة',
        onclick: async () => {
          if (!doc.amount || doc.amount <= 0) { toast('اكتب مبلغ صحيح', 'warn'); return; }
          await save('payments', doc);
          const newPaid = paidOf(inv) ;
          if (inv.status !== 'paid' && newPaid >= invTotal(inv)) { await save('invoices', { id: inv.id, status: 'paid' }); toast('الفاتورة اتقفلت — مدفوعة بالكامل ✓', 'ok', 3500); }
          else toast('اتسجلت الدفعة ✓', 'ok');
          m.close(); onDone();
        },
      }),
    ],
  });
}
