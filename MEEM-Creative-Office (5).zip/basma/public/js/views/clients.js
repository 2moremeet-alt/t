/* ============================================================
   MEEM | Creative Office — العملاء
   ============================================================ */
import { t, getLang } from '../i18n.js';
import { state, save } from '../store.js';
import { el, icon, clear, escapeHTML, toast, modal, confirmDialog } from '../ui.js';

export function renderClients(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');

  host.append(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('clients') + ' ' + t('nav_clients'), style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'بيانات العملاء وتاريخ الشغل مع كل واحد' }),
    ]),
    el('button', { class: 'btn primary', html: icon('plus') + `<span>${t('add')}</span>`, onclick: () => openClientModal(null, refresh) }),
  ]));

  const tbl = el('table', { class: 'tbl' }, [
    el('thead', {}, [el('tr', {}, [
      el('th', { text: t('client') }),
      el('th', { text: 'جهة التواصل' }),
      el('th', { text: 'الهاتف' }),
      el('th', { text: 'المدينة' }),
      el('th', { text: 'المشاريع' }),
      el('th', { text: 'التسليمات' }),
      el('th', { text: '' }),
    ])]),
  ]);
  const tb = el('tbody');
  (state.clients || []).forEach((c) => {
    const projects = state.projects.filter((p) => p.clientId === c.id);
    const deliveries = state.deliveries.filter((d) => d.clientId === c.id);
    tb.appendChild(el('tr', {}, [
      el('td', {}, [
        el('div', { style: { fontWeight: '700' }, text: getLang() === 'ar' ? c.name : (c.nameEn || c.name) }),
        el('div', { class: 'dim', style: { fontSize: '11.5px' }, text: c.type || '' }),
      ]),
      el('td', { text: c.contact || '—' }),
      el('td', { class: 'ltr', text: c.phone || '—' }),
      el('td', { text: c.city || '—' }),
      el('td', {}, [el('span', { class: 'badge num', text: String(projects.length) })]),
      el('td', {}, [el('span', { class: 'badge num', text: String(deliveries.length) })]),
      el('td', { class: 'row-actions' }, [
        el('button', { class: 'btn ghost icon sm', html: icon('edit'), onclick: () => openClientModal(c, refresh) }),
      ]),
    ]));
  });
  tbl.appendChild(tb);
  host.appendChild(el('div', { class: 'card', style: { overflow: 'auto' } }, [tbl]));

  function refresh() { host.innerHTML = ''; renderClients(host); }
}

export function openClientModal(c, onDone) {
  const doc = Object.assign({ name: '', nameEn: '', contact: '', phone: '', email: '', city: '', type: '', notes: '', brandKit: { colors: ['#7c5cff', '#ffffff'], fonts: ['Cairo'], logo: '' }, brandVoice: { tone: '', keywords: '', donts: '', sample: '' } }, c || {});
  doc.brandKit = Object.assign({ colors: [], fonts: [], logo: '' }, doc.brandKit || {});
  doc.brandVoice = Object.assign({ tone: '', keywords: '', donts: '', sample: '' }, doc.brandVoice || {});
  const f = (label, key, extra = {}) => {
    const inp = el('input', Object.assign({ class: 'input', value: doc[key] || '', oninput: (e) => doc[key] = e.target.value }, extra));
    return el('div', { class: 'field' }, [el('label', { text: label }), inp]);
  };
  const notes = el('textarea', { class: 'textarea', oninput: (e) => doc.notes = e.target.value });
  notes.value = doc.notes || '';

  /* ---- تبويب: أساسيات ---- */
  const portalUser = (state.users || []).find((u) => u.clientId === doc.id);
  const tabBasic = el('div', {}, [
    el('div', { class: 'grid2' }, [f('الاسم بالعربي *', 'name'), f('Name (EN)', 'nameEn')]),
    el('div', { class: 'grid2' }, [f('جهة التواصل', 'contact'), f('الهاتف', 'phone')]),
    el('div', { class: 'grid2' }, [f('البريد', 'email', { type: 'email' }), f('المدينة', 'city')]),
    f('نوع النشاط', 'type'),
    el('div', { class: 'field' }, [el('label', { text: t('notes') }), notes]),
    el('div', { class: 'ed-hintbox', html: portalUser
      ? `👤 <b>حساب البورتال:</b> ${escapeHTML(portalUser.email || '')} — بيدخل من صفحة الدخول ويشوف شغله فقط.`
      : '💡 اربط لهذا العميل حساب بورتال (من شاشة الفريق: دور = عميل) عشان يدخل يشوف تصاميمه ويعتمدها بنفسه.' }),
  ]);

  /* ---- تبويب: Brand Kit ---- */
  const swatches = el('div', { class: 'row wrap', style: { gap: '8px' } });
  function drawSwatches() {
    clear(swatches);
    (doc.brandKit.colors || []).forEach((col, i) => {
      swatches.appendChild(el('span', { class: 'swatch-view editable', style: { background: col } }, [
        el('button', { class: 'sw-x', text: '×', title: 'حذف', onclick: () => { doc.brandKit.colors.splice(i, 1); drawSwatches(); } }),
      ]));
    });
    const picker = el('input', { type: 'color', value: '#7c5cff', style: { width: '44px', height: '44px', padding: '0', border: 'none', background: 'none', cursor: 'pointer' }, title: 'أضف لون' });
    picker.addEventListener('change', () => { doc.brandKit.colors.push(picker.value); drawSwatches(); });
    swatches.appendChild(picker);
  }
  drawSwatches();
  const logoPrev = el('div', { class: 'row', style: { gap: '10px', alignItems: 'center' } });
  function drawLogo() {
    clear(logoPrev);
    logoPrev.append(
      doc.brandKit.logo ? el('img', { src: doc.brandKit.logo, style: { width: '56px', height: '56px', objectFit: 'contain', borderRadius: '10px', background: '#fff', padding: '4px' } }) : el('div', { class: 'dim', text: 'لا لوجو مرفوع' }),
      el('button', {
        class: 'btn sm', text: 'ارفع لوجو',
        onclick: async () => {
          const inp = el('input', { type: 'file', accept: 'image/*', style: { display: 'none' }, onchange: async (e) => {
            const file = e.target.files[0]; if (!file) return;
            const { readFileAsDataURL } = await import('../api.js');
            doc.brandKit.logo = await readFileAsDataURL(file);
            drawLogo();
          } });
          document.body.appendChild(inp); inp.click();
        },
      }),
    );
  }
  drawLogo();
  const fontsInp = el('input', { class: 'input', value: (doc.brandKit.fonts || []).join('، '), oninput: (e) => doc.brandKit.fonts = e.target.value.split(/[،,]/).map((s) => s.trim()).filter(Boolean) });
  const tabBrand = el('div', {}, [
    el('div', { class: 'field' }, [el('label', { text: '🎨 ألوان الهوية (اضغط المربع للتعديل، + لإضافة)' }), swatches]),
    el('div', { class: 'field' }, [el('label', { text: 'الخطوط المعتمدة (مفصولة بفواصل)' }), fontsInp]),
    el('div', { class: 'field' }, [el('label', { text: 'اللوجو' }), logoPrev]),
    el('div', { class: 'ed-hintbox', text: 'المحرر بيجيب الهوية دي تلقائيًا في لوحة البراند لأي تصميم مربوط بالعميل.' }),
  ]);

  /* ---- تبويب: Brand Voice ---- */
  const bvF = (label, key) => {
    const ta = el('textarea', { class: 'textarea', rows: 2, oninput: (e) => doc.brandVoice[key] = e.target.value });
    ta.value = doc.brandVoice[key] || '';
    return el('div', { class: 'field' }, [el('label', { text: label }), ta]);
  };
  const tabVoice = el('div', {}, [
    bvF('✍️ النبرة (Tone)', 'tone'),
    bvF('كلمات مفتاحية يحبها', 'keywords'),
    bvF('ممنوعات (Don\'ts)', 'donts'),
    bvF('جملة مثال بصوتهم', 'sample'),
  ]);

  /* ---- التبويبات ---- */
  const tabs = ['أساسيات', '🎨 هوية البراند', '✍️ صوت البراند'];
  let active = 0;
  const tabBar = el('div', { class: 'tabs compact' });
  const body = el('div');
  function drawTab() {
    clear(body);
    body.appendChild([tabBasic, tabBrand, tabVoice][active]);
  }
  tabBar.append(...tabs.map((tb, i) => el('button', {
    class: i === active ? 'active' : '', text: tb,
    onclick: () => { active = i; tabBar.querySelectorAll('button').forEach((b, j) => b.classList.toggle('active', j === i)); drawTab(); },
  })));
  drawTab();

  const m = modal({
    title: c ? t('edit') : t('add'),
    size: 'wide',
    body: [tabBar, body],
    footer: [
      c ? el('button', {
        class: 'btn danger ghost', text: t('delete'),
        onclick: async () => {
          if (!await confirmDialog(t('cantUndo'), { danger: true })) return;
          const { remove } = await import('../store.js');
          await remove('clients', doc.id);
          m.close(); onDone && onDone();
        },
      }) : null,
      el('div', { class: 'grow' }),
      el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: t('save'),
        onclick: async () => {
          if (!doc.name.trim()) { toast(t('required'), 'warn'); return; }
          await save('clients', doc);
          m.close(); toast(t('saved'), 'ok'); onDone && onDone();
        },
      }),
    ],
  });
}
