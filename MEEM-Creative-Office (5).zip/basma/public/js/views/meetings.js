/* ============================================================
   MEEM | Creative Office — الاجتماعات (غرفة WebRTC حقيقية)
   signaling عبر WebSocket الخاص بالسيرفر + STUN عام
   ============================================================ */
import { t, getLang } from '../i18n.js';
import { state, save, userById } from '../store.js';
import { el, icon, clear, avatarHTML, formatDate, escapeHTML, toast, modal } from '../ui.js';
import { socket, uid } from '../api.js';

const ICE = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:global.stun.twilio.com:3478' },
  ],
};

export function renderMeetings(host, { param } = {}) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');

  const roomFromHash = param && !state.meetings.some((m) => m.id === param) ? param : null;
  const meetingFromHash = param ? state.meetings.find((m) => m.id === param) : null;

  if (roomFromHash || meetingFromHash) {
    renderRoom(host, meetingFromHash || { id: null, title: roomFromHash, room: roomFromHash });
    return;
  }

  const list = [...(state.meetings || [])].sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt));
  const quickRoom = el('input', { class: 'input', placeholder: 'اسم الغرفة (مثال: design-review)', style: { maxWidth: '280px' } });

  host.append(
    el('div', { class: 'page-head' }, [
      el('div', {}, [
        el('h1', { html: icon('meet') + ' ' + t('nav_meet'), style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
        el('div', { class: 'ph-sub', text: 'غرف اجتماعات بالصوت والصورة + دردشة + مشاركة شاشة — اتصال مباشر بين المستخدمين' }),
      ]),
      el('button', { class: 'btn primary', html: icon('plus') + `<span>${t('newMeeting')}</span>`, onclick: () => openNewMeetingModal(refresh) }),
    ]),

    el('div', { class: 'card card-pad', style: { marginBottom: '16px' } }, [
      el('div', { class: 'row wrap', style: { gap: '9px' } }, [
        el('div', { style: { width: '40px', height: '40px', borderRadius: '12px', background: 'var(--ok-soft)', color: 'var(--ok)', display: 'grid', placeItems: 'center' }, html: icon('bolt') }),
        el('div', { class: 'grow' }, [
          el('div', { style: { fontWeight: '800' }, text: 'اجتماع فوري' }),
          el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'ادخل أي اسم غرفة وشارك الرابط مع الفريق' }),
        ]),
        quickRoom,
        el('button', {
          class: 'btn ok', html: icon('video') + `<span>${t('meet_start')}</span>`,
          onclick: () => {
            const r = (quickRoom.value || 'quick-' + Math.random().toString(36).slice(2, 7)).trim().replace(/\s+/g, '-');
            location.hash = '#/meetings/' + encodeURIComponent(r);
          },
        }),
      ]),
    ]),

    el('h3', { text: t('upcomingMeetings'), style: { fontSize: '16px', marginBottom: '12px' } }),
  );

  const grid = el('div', { class: 'col', style: { gap: '10px' } });
  if (!list.length) grid.appendChild(el('div', { class: 'empty card', style: { padding: '40px' }, text: t('noData') }));

  list.forEach((mt) => {
    const soon = new Date(mt.scheduledAt) - Date.now();
    const live = soon < 15 * 60000;
    grid.appendChild(el('div', { class: 'meet-card' + (live ? ' live' : '') }, [
      el('div', { class: 'mc-icon', html: icon(live ? 'video' : 'calendar') }),
      el('div', { class: 'grow' }, [
        el('div', { style: { fontWeight: '800', fontSize: '15px' }, text: getLang() === 'ar' ? mt.title : (mt.titleEn || mt.title) }),
        el('div', { class: 'dim', style: { fontSize: '12px' }, text: `${formatDate(mt.scheduledAt, true)} · ${mt.durationMin} دقيقة · غرفة: ${mt.room}` }),
        el('div', { class: 'row', style: { gap: '5px', marginTop: '7px' } },
          (mt.attendees || []).slice(0, 6).map((id) => el('div', { html: avatarHTML(userById(id), 'sm') }))),
      ]),
      el('div', { class: 'col', style: { gap: '6px' } }, [
        el('button', {
          class: 'btn sm ' + (live ? 'ok' : 'primary'), html: icon('video') + `<span>${t('meet_join')}</span>`,
          onclick: () => { location.hash = '#/meetings/' + mt.id; },
        }),
        el('button', {
          class: 'btn sm ghost', html: icon('text') + `<span>الملاحظات</span>`,
          onclick: () => openNotesModal(mt, refresh),
        }),
        el('button', {
          class: 'btn sm ghost', html: icon('copy') + `<span>الرابط</span>`,
          onclick: () => {
            const url = location.origin + location.pathname + '#/meetings/' + mt.room;
            navigator.clipboard && navigator.clipboard.writeText(url);
            toast(t('copied') + ' ✓', 'ok');
          },
        }),
      ]),
    ]));
  });
  host.appendChild(grid);

  function refresh() { host.innerHTML = ''; renderMeetings(host); }
}

/* ---------------- Phase 7: ملاحظات → مهام ---------------- */
export function openNotesModal(mt, onDone) {
  const ta = el('textarea', { class: 'textarea', rows: 8, placeholder: 'اكتب نقاط الاجتماع — كل سطر يتحول مهمة…' });
  ta.value = mt.notes || '';
  const m = modal({
    title: '📋 ملاحظات — ' + mt.title,
    size: 'wide',
    body: [
      el('div', { class: 'field' }, [el('label', { text: 'النقاط (كل سطر = مهمة عند التحويل)' }), ta]),
    ],
    footer: [
      el('button', { class: 'btn ghost', text: 'إغلاق', onclick: () => m.close() }),
      el('button', {
        class: 'btn', html: icon('check') + `<span>حفظ الملاحظات</span>`,
        onclick: async () => { await save('meetings', { id: mt.id, notes: ta.value }); toast('اتحفظت الملاحظات ✓', 'ok'); m.close(); onDone && onDone(); },
      }),
      el('button', {
        class: 'btn primary', html: icon('kanban') + `<span>حوّل لمهام</span>`,
        onclick: async () => {
          await save('meetings', { id: mt.id, notes: ta.value });
          m.close();
          openConvertModal(mt, ta.value, onDone);
        },
      }),
    ],
  });
}

function openConvertModal(mt, notesText, onDone) {
  const lines = String(notesText || '').split('\n').map((l) => l.replace(/^[-•*\s]+/, '').trim()).filter(Boolean);
  if (!lines.length) { toast('مفيش نقاط في الملاحظات', 'warn'); onDone && onDone(); return; }
  const checks = lines.map((line, i) => {
    const cb = el('input', { type: 'checkbox', checked: true });
    return { cb, line, row: el('label', { class: 'check' }, [cb, el('span', { text: line })]) };
  });
  const prjSel = el('select', { class: 'select', html: `<option value="">—</option>` + (state.projects || []).map((p) => `<option value="${p.id}">${escapeHTML(p.title)}</option>`).join('') });
  const asgSel = el('select', { class: 'select', html: (state.users || []).filter((u) => u.role !== 'client').map((u) => `<option value="${u.id}" ${u.id === mt.host ? 'selected' : ''}>${escapeHTML(u.name)}</option>`).join('') });
  const m = modal({
    title: '📋 الملاحظات → مهام',
    body: [
      el('div', { class: 'ct-note', text: `${lines.length} سطر من ملاحظات «${mt.title}» — اختار اللي يتحول مهام` }),
      el('div', { class: 'col', style: { gap: '6px', margin: '8px 0' } }, checks.map((c) => c.row)),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'على مشروع' }), prjSel]),
        el('div', { class: 'field' }, [el('label', { text: 'إسناد لـ' }), asgSel]),
      ]),
    ],
    footer: [
      el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: 'أنشئ المهام',
        onclick: async () => {
          const picked = checks.filter((c) => c.cb.checked).map((c) => c.line);
          if (!picked.length) { toast('اختار سطر واحد على الأقل', 'warn'); return; }
          const prj = (state.projects || []).find((p) => p.id === prjSel.value);
          let n = 0;
          for (const line of picked) {
            await save('tasks', {
              projectId: prjSel.value || '', dept: prj ? (prj.dept || 'design') : 'design', type: 'task',
              title: line, desc: 'من اجتماع: ' + mt.title, assignee: asgSel.value,
              status: 'progress', priority: 'medium', due: '', comments: [], files: [],
            });
            n++;
          }
          m.close();
          toast(`اتعملت ${n} مهمة من الاجتماع ✓`, 'ok', 3500);
          onDone && onDone();
        },
      }),
    ],
  });
}

/* ---------------- اجتماع جديد ---------------- */
export function openNewMeetingModal(onDone) {
  const doc = { title: '', titleEn: '', room: '', scheduledAt: '', durationMin: 30, attendees: [], notes: '' };
  const title = el('input', { class: 'input', oninput: (e) => { doc.title = e.target.value; if (!roomTouched) { doc.room = slug(e.target.value); roomInp.value = doc.room; } } });
  const roomInp = el('input', { class: 'input ltr', oninput: (e) => { doc.room = e.target.value; roomTouched = true; } });
  let roomTouched = false;
  const when = el('input', { class: 'input', type: 'datetime-local' });
  const dur = el('input', { class: 'input num', type: 'number', value: 30 });
  const notes = el('textarea', { class: 'textarea' });
  const attBox = el('div', { class: 'row wrap', style: { gap: '6px' } });
  state.users.forEach((u) => {
    const cb = el('input', { type: 'checkbox', checked: true });
    cb.addEventListener('change', () => {
      doc.attendees = cb.checked ? [...doc.attendees, u.id] : doc.attendees.filter((x) => x !== u.id);
    });
    doc.attendees.push(u.id);
    attBox.appendChild(el('label', { class: 'check' }, [cb, el('span', { text: getLang() === 'ar' ? u.name : (u.nameEn || u.name) })]));
  });

  const m = modal({
    title: t('newMeeting'),
    size: 'wide',
    body: [
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'عنوان الاجتماع *' }), title]),
        el('div', { class: 'field' }, [el('label', { text: t('meet_room') + ' *' }), roomInp]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'الموعد' }), when]),
        el('div', { class: 'field' }, [el('label', { text: 'المدة (دقيقة)' }), dur]),
      ]),
      el('div', { class: 'field' }, [el('label', { text: t('meet_attendees') }), attBox]),
      el('div', { class: 'field' }, [el('label', { text: t('meet_notes') }), notes]),
    ],
    footer: [
      el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: t('create'),
        onclick: async () => {
          if (!doc.title.trim()) { toast(t('required'), 'warn'); return; }
          doc.room = (doc.room || slug(doc.title)).trim();
          doc.scheduledAt = when.value ? new Date(when.value).toISOString() : new Date().toISOString();
          doc.durationMin = +dur.value || 30;
          doc.notes = notes.value;
          doc.host = state.user.id;
          await save('meetings', doc);
          m.close();
          toast(t('saved'), 'ok');
          onDone && onDone();
        },
      }),
    ],
  });
}

function slug(s) {
  return String(s).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '-').replace(/^-|-$/g, '').slice(0, 40) || 'meeting';
}

/* ============================================================
   الغرفة
   ============================================================ */

function renderRoom(host, meeting) {
  host.innerHTML = '';
  const room = meeting.room || meeting.id;
  const me = state.user;

  const peers = new Map(); // clientId -> {pc, video, name, tile, muted}
  let localStream = null;
  let screenStream = null;
  let senders = [];
  let micOn = true, camOn = true, sharing = false, handUp = false;
  let sideTab = null;
  let chatLog = [];
  let unsub = null;

  /* ---------- DOM ---------- */
  const stage = el('div', { class: 'mr-stage' });
  const localTile = tile('me');
  stage.appendChild(localTile.el);

  const statusBadge = el('span', { class: 'badge', html: `<i class="dot"></i>${t('meet_connecting')}` });
  const clock = el('span', { class: 'badge num ltr', text: '00:00' });
  const startedAt = Date.now();
  const clockTimer = setInterval(() => {
    const s = Math.floor((Date.now() - startedAt) / 1000);
    clock.textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  }, 1000);

  const side = el('div', { class: 'mr-side hide' });

  const top = el('div', { class: 'mr-top' }, [
    el('div', { style: { width: '34px', height: '34px', borderRadius: '10px', background: 'var(--ok-soft)', color: 'var(--ok)', display: 'grid', placeItems: 'center' }, html: icon('video') }),
    el('div', { class: 'grow' }, [
      el('div', { style: { fontWeight: '800', fontSize: '14.5px' }, text: getLang() === 'ar' ? (meeting.title || room) : (meeting.titleEn || meeting.title || room) }),
      el('div', { class: 'row', style: { gap: '7px' } }, [statusBadge, el('span', { class: 'dim', style: { fontSize: '11.5px' }, text: 'غرفة: ' + room })]),
    ]),
    clock,
    el('button', { class: 'mr-btn', title: t('meet_copyLink'), html: icon('copy'), onclick: () => { const u = location.origin + location.pathname + '#/meetings/' + encodeURIComponent(room); navigator.clipboard && navigator.clipboard.writeText(u); toast(t('copied') + ' ✓', 'ok'); } }),
  ]);

  const bar = el('div', { class: 'mr-bar' }, [
    ctrl('mic', t('meet_mute'), () => toggleMic()),
    ctrl('video', t('meet_camOff'), () => toggleCam()),
    ctrl('screen', t('meet_share'), () => toggleShare()),
    ctrl('hand', t('meet_hand'), () => toggleHand()),
    ctrl('chat', t('meet_chat'), () => openSide('chat')),
    ctrl('users', t('meet_people'), () => openSide('people')),
    el('button', { class: 'mr-btn danger', title: t('meet_leave'), html: icon('phoneOff'), onclick: () => leave() }),
  ]);

  const roomEl = el('div', { class: 'meet-room' }, [top, stage, bar, side]);
  host.appendChild(roomEl);

  function ctrl(ic, title, fn) {
    const b = el('button', { class: 'mr-btn', title, html: icon(ic), onclick: fn });
    b.dataset.ic = ic;
    return b;
  }
  function btnOf(ic) { return bar.querySelector(`[data-ic="${ic}"]`); }

  /* ---------- tiles ---------- */
  function tile(id) {
    const video = el('video', { autoplay: true, playsinline: true });
    if (id === 'me') { video.muted = true; video.style.transform = 'scaleX(-1)'; }
    const name = el('div', { class: 'mt-name' }, [el('span', { html: icon('mic') }), el('span', { text: id === 'me' ? t('meet_you') : id })]);
    const off = el('div', { class: 'mt-off', html: icon('videoOff') + `<div style="font-size:12px">الكاميرا مغلقة</div>` });
    const hand = el('div', { class: 'mt-hand hide', text: '✋' });
    const elTile = el('div', { class: 'mr-tile' }, [video, off, name, hand]);
    off.classList.add('hide');
    return { el: elTile, video, name, off, hand };
  }

  /* ---------- media ---------- */
  async function initMedia() {
    try {
      localStream = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 1280 } }, audio: { echoCancellation: true, noiseSuppression: true } });
      localTile.video.srcObject = localStream;
      await localTile.video.play().catch(() => {});
      localTile.off.classList.add('hide');
    } catch (e) {
      console.warn('media error', e);
      try {
        localStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        localTile.video.srcObject = localStream;
        camOn = false;
        btnOf('video').classList.remove('on');
        toast('الكاميرا غير متاحة — تم الدخول بالصوت فقط', 'warn', 5000);
      } catch (e2) {
        localStream = new MediaStream();
        camOn = false; micOn = false;
        toast(t('meet_noMedia') + ' — يمكنك المشاركة بدون ميكروفون', 'warn', 6000);
      }
    }
    updateMicBtn();
  }

  function updateMicBtn() {
    const b = btnOf('mic');
    b.classList.toggle('danger', !micOn);
    b.innerHTML = icon(micOn ? 'mic' : 'micOff');
    localTile.name.querySelector('svg').outerHTML = icon(micOn ? 'mic' : 'micOff');
  }

  async function toggleMic() {
    if (!localStream) { toast('لا يوجد ميكروفون متاح', 'warn'); return; }
    const tracks = localStream.getAudioTracks();
    if (!tracks.length) { toast('لا يوجد ميكروفون متاح', 'warn'); return; }
    micOn = !micOn;
    tracks.forEach((tr) => tr.enabled = micOn);
    updateMicBtn();
  }

  async function toggleCam() {
    if (!localStream || !localStream.getVideoTracks().length) {
      // محاولة تشغيل الكاميرا
      try {
        const s = await navigator.mediaDevices.getUserMedia({ video: true });
        const vt = s.getVideoTracks()[0];
        localStream.addTrack(vt);
        localTile.video.srcObject = localStream;
        senders.forEach((pc) => pc.pc.addTrack(vt, localStream));
        camOn = true;
        localTile.off.classList.add('hide');
        btnOf('video').classList.add('on');
      } catch (e) { toast('الكاميرا غير متاحة', 'warn'); }
      return;
    }
    camOn = !camOn;
    localStream.getVideoTracks().forEach((tr) => tr.enabled = camOn);
    localTile.off.classList.toggle('hide', camOn);
    btnOf('video').classList.toggle('on', !camOn);
  }

  async function toggleShare() {
    if (sharing) {
      // رجوع للكاميرا
      const vt = localStream && localStream.getVideoTracks()[0];
      if (screenStream) screenStream.getTracks().forEach((t) => t.stop());
      screenStream = null;
      sharing = false;
      btnOf('screen').classList.remove('on');
      localTile.video.srcObject = localStream;
      const sender = senders.map((p) => p.pc.getSenders().find((s) => s.track && s.track.kind === 'video')).filter(Boolean);
      if (vt) sender.forEach((s) => s.replaceTrack(vt).catch(() => {}));
      return;
    }
    try {
      screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true, audio: false });
      sharing = true;
      btnOf('screen').classList.add('on');
      localTile.video.srcObject = screenStream;
      localTile.video.style.transform = 'none';
      const st = screenStream.getVideoTracks()[0];
      st.addEventListener('ended', () => toggleShare());
      const sender = senders.map((p) => p.pc.getSenders().find((s) => s.track && s.track.kind === 'video')).filter(Boolean);
      await Promise.all(sender.map((s) => s.replaceTrack(st).catch(() => {})));
      // لو مفيش connections لسه، هتتضاف تلقائي عند الإنشاء
    } catch (e) {
      toast('تم إلغاء مشاركة الشاشة', 'info');
    }
  }

  function toggleHand() {
    handUp = !handUp;
    btnOf('hand').classList.toggle('on', handUp);
    localTile.hand.classList.toggle('hide', !handUp);
    socket.send({ type: 'hand-raise', up: handUp });
  }

  /* ---------- WebRTC ---------- */
  function makePC(clientId) {
    const pc = new RTCPeerConnection(ICE);
    senders.push({ clientId, pc });

    if (localStream) localStream.getTracks().forEach((tr) => pc.addTrack(tr, localStream));
    if (sharing && screenStream) {
      const vt = screenStream.getVideoTracks()[0];
      const vs = pc.getSenders().find((s) => s.track && s.track.kind === 'video');
      if (vs) vs.replaceTrack(vt).catch(() => {});
    }

    pc.onicecandidate = (e) => {
      if (e.candidate) socket.send({ type: 'ice', to: clientId, candidate: e.candidate });
    };
    pc.ontrack = (e) => {
      const p = peers.get(clientId);
      if (!p) return;
      p.video.srcObject = e.streams[0];
      p.video.play().catch(() => {});
    };
    pc.onconnectionstatechange = () => {
      if (['failed', 'closed', 'disconnected'].includes(pc.connectionState)) {
        // نسيبها للـ signaling
      }
    };
    return pc;
  }

  async function callPeer(clientId) {
    const pc = makePC(clientId);
    try {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      socket.send({ type: 'offer', to: clientId, sdp: pc.localDescription });
    } catch (e) { console.error(e); }
  }

  async function handleSignal(msg) {
    const from = msg.from;
    if (msg.type === 'peer-joined') {
      addPeerTile(msg.clientId, msg.name, msg.color);
      // قاعدة حسم الـ glare: الأصغر client-id هو اللي يبدأ المكالمة
      if (socket.clientId < msg.clientId) await callPeer(msg.clientId);
    } else if (msg.type === 'offer') {
      let p = peers.get(from);
      if (!p) { p = addPeerTile(from, msg.fromName, null); }
      let pc = senders.find((s) => s.clientId === from);
      if (!pc) pc = { clientId: from, pc: makePC(from) };
      try {
        await pc.pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
        const answer = await pc.pc.createAnswer();
        await pc.pc.setLocalDescription(answer);
        socket.send({ type: 'answer', to: from, sdp: pc.pc.localDescription });
      } catch (e) { console.error(e); }
    } else if (msg.type === 'answer') {
      const s = senders.find((x) => x.clientId === from);
      if (s) { try { await s.pc.setRemoteDescription(new RTCSessionDescription(msg.sdp)); } catch (e) { console.error(e); } }
    } else if (msg.type === 'ice') {
      const s = senders.find((x) => x.clientId === from);
      if (s && msg.candidate) { try { await s.pc.addIceCandidate(new RTCIceCandidate(msg.candidate)); } catch (e) {} }
    } else if (msg.type === 'peer-left') {
      removePeer(msg.clientId);
    } else if (msg.type === 'chat') {
      pushChat(msg.fromName || 'ضيف', msg.text, false);
    } else if (msg.type === 'hand-raise') {
      const p = peers.get(msg.from);
      if (p) p.hand.classList.toggle('hide', !msg.up);
    } else if (msg.type === 'room-joined') {
      statusBadge.className = 'badge ok';
      statusBadge.innerHTML = `<i class="dot"></i>${t('meet_connected')}`;
      (msg.peers || []).forEach((p) => {
        addPeerTile(p.clientId, p.name, p.color);
        if (socket.clientId < p.clientId) callPeer(p.clientId);
      });
    }
  }

  function addPeerTile(clientId, name, color) {
    if (peers.has(clientId)) return peers.get(clientId);
    const tl = tile(clientId);
    tl.name.querySelector('span:last-child').textContent = name || 'ضيف';
    tl.video.srcObject = null;
    stage.appendChild(tl.el);
    const p = { ...tl, clientId, name, color };
    peers.set(clientId, p);
    renderRoster();
    return p;
  }

  function removePeer(clientId) {
    const p = peers.get(clientId);
    if (!p) return;
    p.el.remove();
    const s = senders.find((x) => x.clientId === clientId);
    if (s) { try { s.pc.close(); } catch (e) {} senders.splice(senders.indexOf(s), 1); }
    peers.delete(clientId);
    renderRoster();
  }

  /* ---------- chat / people ---------- */
  function openSide(tab) {
    sideTab = tab;
    side.classList.remove('hide');
    clear(side);
    side.appendChild(el('div', { class: 'mr-side-head' }, [
      el('b', { text: tab === 'chat' ? t('meet_chat') : t('meet_people') }),
      el('button', { class: 'btn ghost icon sm', html: icon('close'), onclick: () => side.classList.add('hide') }),
    ]));
    if (tab === 'chat') {
      const log = el('div', { class: 'mr-chat' });
      chatLog.forEach((c) => log.appendChild(chatBubble(c)));
      const input = el('input', { class: 'input', placeholder: t('meet_typeMessage') });
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && input.value.trim()) {
          const text = input.value.trim();
          socket.send({ type: 'chat', text });
          pushChat(t('meet_you'), text, true);
          input.value = '';
          log.scrollTop = log.scrollHeight;
        }
      });
      side.append(log, el('div', { class: 'mr-chat-form' }, [
        input,
        el('button', { class: 'btn primary', html: icon('send'), onclick: () => { if (input.value.trim()) { socket.send({ type: 'chat', text: input.value.trim() }); pushChat(t('meet_you'), input.value.trim(), true); input.value = ''; log.scrollTop = log.scrollHeight; } } }),
      ]));
      setTimeout(() => input.focus(), 80);
      log.scrollTop = log.scrollHeight;
    } else {
      const roster = el('div', { class: 'mr-roster' });
      const all = [{ clientId: 'me', name: t('meet_you') + ' — ' + me.name, me: true }, ...[...peers.values()].map((p) => ({ clientId: p.clientId, name: p.name }))];
      all.forEach((p) => roster.appendChild(el('div', { class: 'mr-person' }, [
        el('div', { class: 'avatar sm', style: { background: p.me ? me.avatarColor : 'var(--brand)' }, text: (p.name || '?')[0] }),
        el('div', { class: 'grow', style: { fontSize: '13px' }, text: p.name }),
        el('span', { class: 'badge ok', html: `<i class="dot"></i>` }),
      ])));
      side.appendChild(roster);
    }
  }

  function chatBubble(c) {
    return el('div', { class: 'mr-msg' + (c.me ? ' me' : '') }, [
      el('span', { class: 'mm-who', text: c.who }),
      el('div', { class: 'mm-body', text: c.text }),
    ]);
  }

  function pushChat(who, text, isMe) {
    chatLog.push({ who, text, me: isMe });
    if (sideTab === 'chat') {
      const log = side.querySelector('.mr-chat');
      if (log) { log.appendChild(chatBubble({ who, text, me: isMe })); log.scrollTop = log.scrollHeight; }
    }
  }

  function renderRoster() {
    if (sideTab === 'people') openSide('people');
  }

  /* ---------- lifecycle ---------- */
  async function start() {
    await initMedia();
    unsub = socket.on(handleSignal);
    socket.connect();
    socket.joinRoom(room, { name: me.name, role: me.role, color: me.avatarColor });
    // لو السيرفر مش متصل، نعيد المحاولة
    setTimeout(() => { if (!socket.connected) { statusBadge.className = 'badge warn'; statusBadge.innerHTML = `<i class="dot"></i>بانتظار السيرفر…`; socket.connect(); socket.joinRoom(room, { name: me.name }); } }, 2500);
  }

  function leave() {
    clearInterval(clockTimer);
    try { socket.leaveRoom(); } catch (e) {}
    if (unsub) unsub();
    senders.forEach((s) => { try { s.pc.close(); } catch (e) {} });
    senders = [];
    if (localStream) localStream.getTracks().forEach((t) => t.stop());
    if (screenStream) screenStream.getTracks().forEach((t) => t.stop());
    location.hash = '#/meetings';
    host.innerHTML = '';
    renderMeetings(host);
  }

  // تنظيف عند تغيير المسار
  const hashWatcher = () => {
    if (!location.hash.includes('/meetings/' + encodeURIComponent(room)) && location.hash !== '#/meetings/' + room) {
      window.removeEventListener('hashchange', hashWatcher);
      leave();
    }
  };
  window.addEventListener('hashchange', hashWatcher);

  start();
}
