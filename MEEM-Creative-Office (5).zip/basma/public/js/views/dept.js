/* ============================================================
   MEEM | Creative Office — لوحة الأقسام (Kanban) — محتوى / فويس / برمجة
   ============================================================ */
import { t, getLang } from '../i18n.js';
import { state, save, STATUS, STATUS_COLOR, PRIORITIES, userById, projectById, isOverdue, isDueToday, deptStats } from '../store.js';
import { el, icon, clear, avatarHTML, statusBadge, priorityBadge, dueLabel, escapeHTML, toast, modal } from '../ui.js';
import { openTaskModal, openTaskDetails, DEPT_TYPES } from '../taskform.js';

const DEPT_META = {
  content: {
    icon: 'content',
    title: 'nav_content',
    sub: ['سكربتات، كابشنات، بريفات — من الفكرة للنص المعتمد', 'Scripts, captions and briefs — from idea to approved copy'],
    quick: ['سكربت إعلان', 'كابشن', 'محتوى موقع', 'مقال'],
  },
  voice: {
    icon: 'voice',
    title: 'nav_voice',
    sub: ['تسجيلات، تيكات، واعتماد الصوت النهائي', 'Recordings, takes and final voice sign-off'],
    quick: ['إعلان إذاعي', 'فيديو', 'بودكاست', 'IVR/رد آلي'],
  },
  dev: {
    icon: 'code',
    title: 'nav_dev',
    sub: ['مهام التطوير، البقز، والنشر', 'Dev tasks, bugs and releases'],
    quick: ['واجهة', 'باك-إند', 'خلل', 'نشر'],
  },
  design: {
    icon: 'design',
    title: 'nav_design',
    sub: ['كل أنواع التصميمات بفروعها', 'Every design discipline and its branches'],
    quick: ['سوشيال', 'مطبوعات', 'براندينج', 'موشن'],
  },
};

export function renderDept(dept, container, opts = {}) {
  const meta = DEPT_META[dept] || DEPT_META.design;
  const host = container || document.querySelector('.view');
  host.innerHTML = '';
  host.setAttribute('data-live', '1');

  const filters = { assignee: '', priority: '', q: '', view: localStorage.getItem('view_' + dept) || 'board' };

  /* ---------------- head ---------------- */
  const head = el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon(meta.icon) + ' ' + t(meta.title), style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: getLang() === 'ar' ? meta.sub[0] : meta.sub[1] }),
    ]),
    el('div', { class: 'row wrap', style: { gap: '8px' } }, [
      ...meta.quick.map((q) => el('button', {
        class: 'btn sm ghost', html: icon('plus') + `<span>${escapeHTML(q)}</span>`,
        onclick: () => openTaskModal({ dept, type: q }, refresh),
      })),
      el('button', {
        class: 'btn primary sm', html: icon('plus') + `<span>${t('newTask')}</span>`,
        onclick: () => openTaskModal({ dept }, refresh),
      }),
    ]),
  ]);

  /* ---------------- KPIs ---------------- */
  const ds = deptStats()[dept];
  const kpis = el('div', { class: 'kpis' }, [
    kpi('target', t('totalTasks'), ds.total, ''),
    kpi('bolt', t('openTasks'), ds.open, ''),
    kpi('warning', t('overdue'), ds.overdue, ds.overdue ? 'var(--danger)' : ''),
    kpi('checkCircle', t('delivered'), ds.done, ''),
  ]);

  /* ---------------- toolbar ---------------- */
  const searchInput = el('input', { class: 'input', placeholder: t('search') + '…', style: { maxWidth: '240px' } });
  searchInput.addEventListener('input', () => { filters.q = searchInput.value.toLowerCase(); drawBody(); });

  const assigneeSel = el('select', {
    class: 'select', style: { maxWidth: '190px' },
    html: `<option value="">${t('assignee')}: ${t('all')}</option>` + state.users.map((u) => `<option value="${u.id}">${escapeHTML(getLang() === 'ar' ? u.name : u.nameEn)}</option>`).join(''),
    onchange: (e) => { filters.assignee = e.target.value; drawBody(); },
  });
  const prioSel = el('select', {
    class: 'select', style: { maxWidth: '160px' },
    html: `<option value="">${t('priority')}: ${t('all')}</option>` + PRIORITIES.map((p) => `<option value="${p}">${t(p)}</option>`).join(''),
    onchange: (e) => { filters.priority = e.target.value; drawBody(); },
  });
  const myBtn = el('button', {
    class: 'btn sm ghost', html: icon('users') + `<span>${t('myTasks')}</span>`,
    onclick: () => {
      filters.assignee = filters.assignee === state.user.id ? '' : state.user.id;
      assigneeSel.value = filters.assignee;
      myBtn.classList.toggle('btn primary', !!filters.assignee);
      myBtn.classList.toggle('ghost', !filters.assignee);
      drawBody();
    },
  });
  const viewSeg = el('div', { class: 'seg' }, [
    segBtn('kanban', 'board', () => { filters.view = 'board'; localStorage.setItem('view_' + dept, 'board'); drawBody(); }),
    segBtn('menu', 'list', () => { filters.view = 'list'; localStorage.setItem('view_' + dept, 'list'); drawBody(); }),
  ]);

  const toolbar = el('div', { class: 'board-toolbar' }, [searchInput, assigneeSel, prioSel, myBtn, el('div', { class: 'grow' }), viewSeg]);

  const body = el('div', {});

  host.append(head, kpis, toolbar, body);

  function segBtn(ic, key, fn) {
    const b = el('button', { html: icon(ic), class: filters.view === key ? 'active' : '', onclick: fn });
    b.dataset.key = key;
    return b;
  }

  function filtered() {
    return state.tasks
      .filter((x) => x.dept === dept)
      .filter((x) => !filters.assignee || x.assignee === filters.assignee)
      .filter((x) => !filters.priority || x.priority === filters.priority)
      .filter((x) => !filters.q || (x.title + ' ' + (x.desc || '') + ' ' + (x.type || '')).toLowerCase().includes(filters.q))
      .sort((a, b) => (a.order || 0) - (b.order || 0) || (b.updatedAt || '').localeCompare(a.updatedAt || ''));
  }

  function drawBody() {
    clear(body);
    viewSeg.querySelectorAll('button').forEach((b) => b.classList.toggle('active', b.dataset.key === filters.view));
    const list = filtered();
    if (filters.view === 'list') body.appendChild(listView(list));
    else body.appendChild(boardView(list));
  }

  /* ---------------- Board ---------------- */
  function boardView(list) {
    const board = el('div', { class: 'board' });
    STATUS.forEach((st) => {
      const items = list.filter((x) => x.status === st);
      const colBody = el('div', { class: 'bcol-body' });
      items.forEach((task) => colBody.appendChild(taskCard(task, refresh)));

      colBody.addEventListener('dragover', (e) => { e.preventDefault(); colBody.classList.add('dragover'); });
      colBody.addEventListener('dragleave', () => colBody.classList.remove('dragover'));
      colBody.addEventListener('drop', async (e) => {
        e.preventDefault();
        colBody.classList.remove('dragover');
        const id = e.dataTransfer.getData('text/task');
        const task = state.tasks.find((x) => x.id === id);
        if (!task || task.status === st) return;
        task.status = st;
        await save('tasks', task);
        toast(`${task.title} → ${t('st_' + st)}`, 'ok', 2000);
        refresh();
      });

      board.appendChild(el('div', { class: 'bcol' }, [
        el('div', { class: 'bcol-head' }, [
          el('span', { class: 'bc-dot', style: { background: dotColor(st) } }),
          el('span', { text: t('st_' + st) }),
          el('span', { class: 'bc-count num', text: String(items.length) }),
        ]),
        colBody,
      ]));
    });
    return board;
  }

  /* ---------------- List ---------------- */
  function listView(list) {
    if (!list.length) return emptyState();
    const tbl = el('table', { class: 'tbl' }, [
      el('thead', {}, [el('tr', {}, [
        el('th', { text: t('status') }),
        el('th', { text: 'العنوان' }),
        el('th', { text: 'النوع' }),
        el('th', { text: t('project') }),
        el('th', { text: t('assignee') }),
        el('th', { text: t('priority') }),
        el('th', { text: t('due') }),
        el('th', { text: '' }),
      ])]),
    ]);
    const tb = el('tbody');
    list.forEach((task) => {
      const p = projectById(task.projectId);
      const u = userById(task.assignee);
      const tr = el('tr', { onclick: () => openTaskDetails(task.id, refresh), style: { cursor: 'pointer' } }, [
        el('td', { html: statusBadge(task.status) }),
        el('td', { text: task.title, style: { fontWeight: '600' } }),
        el('td', { text: task.type || '—' }),
        el('td', { text: p ? p.title : '—' }),
        el('td', {}, [el('div', { class: 'row', style: { gap: '7px' } }, [el('div', { html: avatarHTML(u, 'sm') }), el('span', { text: u ? (getLang() === 'ar' ? u.name : u.nameEn) : '—', style: { fontSize: '13px' } })])]),
        el('td', { html: priorityBadge(task.priority) }),
        el('td', { text: dueLabel(task.due), class: isOverdue(task) ? 'badge danger' : '' }),
        el('td', { class: 'row-actions' }, [
          el('button', {
            class: 'btn ghost icon sm', html: icon('edit'),
            onclick: (e) => { e.stopPropagation(); openTaskModal(task, refresh); },
          }),
        ]),
      ]);
      tb.appendChild(tr);
    });
    tbl.appendChild(tb);
    return el('div', { class: 'card', style: { overflow: 'auto' } }, [tbl]);
  }

  function refresh() {
    host.innerHTML = '';
    renderDept(dept, host);
  }

  drawBody();
}

/* ---------------- بطاقة مهمة ---------------- */
export function taskCard(task, onOpen) {
  const u = userById(task.assignee);
  const p = projectById(task.projectId);
  const cls = 'tcard' + (isOverdue(task) ? ' overdue' : isDueToday(task) ? ' duetoday' : '');
  const card = el('div', {
    class: cls,
    draggable: 'true',
    onclick: () => openTaskDetails ? openTaskDetails(task.id, onOpen) : null,
  }, [
    el('div', { class: 'row', style: { justifyContent: 'space-between' } }, [
      el('span', { class: 'tc-type', text: (task.type || '').toUpperCase() }),
      el('span', { html: priorityBadge(task.priority) }),
    ]),
    el('div', { class: 'tc-title', text: task.title }),
    el('div', { class: 'tc-meta' }, [
      p ? el('span', { html: icon('folder') + ' ' + escapeHTML(p.title) }) : null,
      task.due ? el('span', { class: isOverdue(task) ? 'badge danger' : '', html: icon('clock') + ' ' + dueLabel(task.due) }) : null,
      (task.comments || []).length ? el('span', { html: icon('chat') + ' ' + task.comments.length }) : null,
    ]),
    el('div', { class: 'tc-foot' }, [
      el('div', { html: avatarHTML(u, 'sm') }),
      el('span', { class: 'dim', text: u ? (getLang() === 'ar' ? u.name : u.nameEn) : t('unassigned'), style: { fontSize: '12px' } }),
      el('div', { class: 'grow' }),
      task.dept === 'design' ? el('span', { class: 'badge brand', html: icon('design') }) : null,
    ]),
  ]);
  card.addEventListener('dragstart', (e) => {
    e.dataTransfer.setData('text/task', task.id);
    card.classList.add('dragging');
  });
  card.addEventListener('dragend', () => card.classList.remove('dragging'));
  return card;
}

function dotColor(st) {
  return {
    new: 'var(--info)', progress: 'var(--brand)', review: 'var(--warn)',
    client: 'var(--pink)', revision: 'var(--danger)', delivered: 'var(--ok)', done: 'var(--text-3)',
  }[st] || 'var(--text-3)';
}

function kpi(ic, label, value, color) {
  return el('div', { class: 'kpi' }, [
    el('div', { class: 'k-label', html: icon(ic) + `<span>${escapeHTML(label)}</span>` }),
    el('div', { class: 'k-value num', text: String(value), style: color ? { color } : {} }),
  ]);
}

export function emptyState(msg) {
  return el('div', { class: 'empty', html: icon('folder') + `<div>${msg || t('noData')}</div>` });
}
