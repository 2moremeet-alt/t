/* ============================================================
   MEE M — Public Request Page (V2-13)
   /request — اطلب مشروعك من غير تسجيل · فورم ديناميكي لكل خدمة
   ============================================================ */
import { el } from '../ui.js';
import { SERVICES, COMMON_FIELDS } from '../services.js';
import { getLang, setLang } from '../i18n.js';

export function renderPubRequest(host) {
  host.innerHTML = '';
  host.hidden = false;
  host.classList.add('pr-scope');

  const wrap = el('div', { class: 'pr-wrap' });
  host.appendChild(wrap);

  let chosen = null;
  const vals = {};

  function draw() {
    const AR = getLang() === 'ar';
    wrap.innerHTML = '';
    wrap.appendChild(el('header', { class: 'pr-head' }, [
      el('button', { class: 'pr-lang', text: AR ? 'EN' : 'عربي', onclick: () => setLang(AR ? 'en' : 'ar') }),
      el('div', { class: 'tp-logo', text: 'MEE M' }),
      el('h1', { text: AR ? 'اطلب مشروعك' : 'Request a Project' }),
      el('p', { class: 'tp-dim', text: AR ? 'اختار الخدمة، املأ البيانات، وفريقنا هيرد عليك في أقل من 24 ساعة' : 'Pick a service, fill the form, and our team will reply within 24 hours' }),
    ]));

    if (!chosen) {
      /* ---- اختيار الخدمة ---- */
      const grid = el('div', { class: 'pr-grid' });
      SERVICES.forEach((svc) => {
        grid.appendChild(el('button', {
          class: 'pr-svc',
          onclick: () => { chosen = svc; draw(); },
        }, [
          el('span', { class: 'pr-svc-ic', text: svc.ic }),
          el('b', { text: AR ? svc.ar : svc.en }),
          el('span', { class: 'tp-dim', text: AR ? svc.en : svc.ar }),
        ]));
      });
      wrap.appendChild(grid);
      wrap.appendChild(el('footer', { class: 'tp-foot', text: 'MEE M — Creative Office' }));
      return;
    }
    const FL = (f) => (AR ? f.label : (f.labelEn || f.label));

    /* ---- الفورم الديناميكي ---- */
    const fields = chosen.fields.concat(COMMON_FIELDS);
    const boxes = [];
    fields.forEach((f) => {
      let input;
      const id = 'prf_' + f.k;
      if (f.type === 'textarea') input = el('textarea', { class: 'input pr-input', id, rows: 3, placeholder: FL(f) });
      else if (f.type === 'select') input = el('select', { class: 'select pr-input', id },
        [el('option', { value: '', text: '— اختار —' })].concat(f.options.map((o) => el('option', { value: o, text: o }))));
      else input = el('input', { class: 'input pr-input', id, type: f.type === 'email' ? 'email' : f.type === 'tel' ? 'tel' : f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : 'text', placeholder: FL(f) });
      boxes.push([f, input]);
      wrap.appendChild(el('label', { class: 'pr-field', for: id }, [
        el('span', { class: 'pr-label', text: FL(f) }),
        input,
      ]));
    });

    const err = el('div', { class: 'pr-err' });
    wrap.appendChild(err);
    wrap.appendChild(el('div', { class: 'pr-acts' }, [
      el('button', { class: 'btn pr-back', text: AR ? '→ رجوع للخدمات' : '← Back to services', onclick: () => { chosen = null; draw(); } }),
      el('button', { class: 'btn pr-send', text: AR ? 'إرسال الطلب 🚀' : 'Send Request 🚀', onclick: async (e) => {
        const form = {};
        let missing = null;
        boxes.forEach(([f, inp]) => {
          form[f.k] = inp.value.trim();
          if (f.required && !form[f.k] && !missing) missing = FL(f);
        });
        if (missing) { err.textContent = (AR ? '⚠️ كمّل خانة: ' : '⚠️ Please fill: ') + missing; return; }
        if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(form.email)) { err.textContent = AR ? '⚠️ الإيميل مش صح' : '⚠️ Invalid email'; return; }
        err.textContent = '';
        e.target.disabled = true;
        e.target.textContent = AR ? 'جاري الإرسال…' : 'Sending…';
        try {
          const r = await fetch('/api/requests/new', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ service: chosen.id, form }) });
          const j = await r.json();
          if (!j.ok) throw new Error(j.error || 'حصل خطأ');
          drawThanks(j.id);
        } catch (er) {
          err.textContent = '⚠️ ' + er.message;
          e.target.disabled = false;
          e.target.textContent = AR ? 'إرسال الطلب 🚀' : 'Send Request 🚀';
        }
      } }),
    ]));
    wrap.appendChild(el('footer', { class: 'tp-foot', text: 'MEE M — Creative Office' }));
  }

  function drawThanks(id) {
    const AR = getLang() === 'ar';
    wrap.innerHTML = '';
    wrap.appendChild(el('div', { class: 'pr-thanks' }, [
      el('div', { class: 'tp-logo', text: 'MEE M' }),
      el('div', { class: 'pr-thanks-ic', text: '✅' }),
      el('h2', { text: AR ? 'طلبك وصلنا!' : 'Request received!' }),
      el('p', { class: 'tp-dim', text: AR ? 'فريق خدمة العملاء هيراجع طلبك ويتواصل معاك في أقل من 24 ساعة.' : 'Our CS team will review it and contact you within 24 hours.' }),
      el('div', { class: 'pr-ref', text: (AR ? 'رقم الطلب: ' : 'Reference: ') + id }),
    ]));
  }

  draw();
  const onLang = () => { if (host.isConnected) renderPubRequest(host); else window.removeEventListener('langchange', onLang); };
  window.addEventListener('langchange', onLang);
}
