/* ============================================================
   MEEM | Creative Office — الفريق
   ============================================================ */
import { t, getLang } from '../i18n.js';
import { state, isOverdue, isDueToday } from '../store.js';
import { el, icon, clear, avatarHTML, escapeHTML, toast, modal } from '../ui.js';
import { api } from '../api.js';

const ROLES = {
  admin: ['مدير', 'Admin'],
  designer: ['مصمم', 'Designer'],
  content: ['كاتب محتوى', 'Copywriter'],
  voice: ['فويس أوفر', 'Voice Over'],
  cs: ['خدمة عملاء', 'Client Success'],
  dev: ['مطوّر', 'Developer'],
};

export function renderTeam(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');

  const isSuper = state.user.role === 'superadmin';
  host.append(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('users') + ' ' + t('nav_team'), style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'أعضاء مساحة العمل وأحمالهم الحالية — إنشاء الحسابات من هنا فقط (مفيش تسجيل ذاتي)' }),
    ]),
    /* V2-4: الإدارة تنشئ الحسابات */
    el('button', { class: 'btn primary', html: icon('plus') + '<span>حساب جديد</span>', onclick: () => userModal(null, host, isSuper) }),
  ]));

  const grid = el('div', { class: 'cards-grid', style: { gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))' } });
  (state.users || []).forEach((u) => {
    const tasks = state.tasks.filter((x) => x.assignee === u.id);
    const open = tasks.filter((x) => !['done', 'delivered'].includes(x.status));
    const done = tasks.filter((x) => ['done', 'delivered'].includes(x.status));
    const late = tasks.filter(isOverdue);
    const today = tasks.filter(isDueToday);
    const r = ROLES[u.role] || [u.role, u.role];
    const pct = tasks.length ? Math.round((done.length / tasks.length) * 100) : 0;

    grid.appendChild(el('div', { class: 'card', style: { padding: '16px' } }, [
      el('div', { class: 'row', style: { gap: '11px', marginBottom: '13px' } }, [
        el('div', { html: avatarHTML(u, 'lg') }),
        el('div', { class: 'grow' }, [
          el('div', { style: { fontWeight: '800', fontSize: '15.5px' }, text: getLang() === 'ar' ? u.name : (u.nameEn || u.name) }),
          el('div', { class: 'dim', style: { fontSize: '12px' }, text: getLang() === 'ar' ? u.title : (u.titleEn || u.title) }),
          el('div', { style: { marginTop: '5px' } }, [el('span', { class: 'badge brand', text: getLang() === 'ar' ? r[0] : r[1] })]),
        ]),
      ]),
      el('div', { class: 'kpis', style: { gridTemplateColumns: 'repeat(4,1fr)', gap: '7px', marginBottom: '12px' } }, [
        mini('مفتوحة', open.length, 'var(--brand)'),
        mini('اليوم', today.length, 'var(--warn)'),
        mini('متأخرة', late.length, late.length ? 'var(--danger)' : ''),
        mini('مكتملة', done.length, 'var(--ok)'),
      ]),
      el('div', { class: 'between', style: { fontSize: '12px', marginBottom: '5px' } }, [
        el('span', { class: 'dim', text: 'نسبة الإنجاز' }),
        el('span', { class: 'num', text: pct + '%' }),
      ]),
      el('div', { class: 'bar thin' }, [el('i', { style: { width: pct + '%' } })]),
      el('div', { class: 'dim ltr', style: { fontSize: '11.5px', marginTop: '10px' }, text: u.email }),
      u.phone ? el('div', { class: 'dim ltr', style: { fontSize: '11.5px' }, text: u.phone }) : null,
      /* V2-4: حالة الحساب + أزرار الإدارة (الأدمن ما يلمسش الحسابات الإدارية) */
      u.active === false ? el('div', { style: { marginTop: '6px' } }, [el('span', { class: 'badge danger', text: 'معطّل' })]) : null,
      (isSuper || (u.role !== 'admin' && u.role !== 'superadmin')) ? el('div', { class: 'row', style: { gap: '6px', marginTop: '10px' } }, [
        el('button', { class: 'btn sm', text: u.active === false ? 'تفعيل' : 'تعطيل', onclick: async () => {
          await api.user({ id: u.id, active: u.active === false });
          toast(u.active === false ? 'تم التفعيل ✓' : 'تم التعطيل', 'ok');
        } }),
        el('button', { class: 'btn sm', html: icon('lock') + '<span>باسورد</span>', onclick: () => passModal(u) }),
        el('button', { class: 'btn sm ghost', html: icon('edit'), onclick: () => userModal(u, host, isSuper) }),
      ]) : null,
    ]));
  });
  host.appendChild(grid);
}

/* ---- V2-4: مودالات الإدارة ---- */
function userModal(u, host, isSuper) {
  const isNew = !u;
  const f = {};
  const inp = (k, label, val, type = 'text') => {
    const i = el('input', { class: 'input', type, value: val || '', placeholder: label });
    f[k] = i;
    return el('label', { class: 'fld' }, [el('span', { text: label }), i]);
  };
  const roleList = isSuper ? ['designer', 'content', 'voice', 'dev', 'cs', 'editor', 'admin'] : ['designer', 'content', 'voice', 'dev', 'cs', 'editor'];
  const m = modal({
    title: isNew ? 'حساب موظف جديد' : 'تعديل: ' + u.name,
    body: el('div', { class: 'col', style: { gap: '10px' } }, [
      inp('name', 'الاسم', u && u.name),
      inp('nameEn', 'الاسم (إنجليزي)', u && u.nameEn),
      inp('email', 'البريد الإلكتروني', u && u.email, 'email'),
      inp('title', 'الوظيفة', u && u.title),
      (() => {
        const sel = el('select', { class: 'select' }, null);
        roleList.forEach((r) => {
          const o = el('option', { value: r, text: (ROLES[r] ? ROLES[r][0] : r) });
          if (u && u.role === r) o.selected = true;
          sel.appendChild(o);
        });
        f.role = sel;
        return el('label', { class: 'fld' }, [el('span', { text: 'الدور' }), sel]);
      })(),
      ...(isNew ? [inp('password', 'كلمة المرور المؤقتة', '123456')] : []),
    ]),
    footer: [
      el('button', { class: 'btn', text: 'إلغاء', onclick: () => m.close() }),
      el('button', { class: 'btn primary', text: isNew ? 'إنشاء الحساب' : 'حفظ', onclick: async () => {
        const payload = { name: f.name.value.trim(), nameEn: f.nameEn.value.trim(), email: f.email.value.trim(), title: f.title.value.trim(), role: f.role.value };
        if (!payload.name || !payload.email) { toast('الاسم والإيميل مطلوبين', 'err'); return; }
        if (isNew) payload.password = f.password.value || '123456';
        if (u) payload.id = u.id;
        try {
          await api.user(payload);
          m.close();
          toast(isNew ? 'تم إنشاء الحساب ✓' : 'تم الحفظ ✓', 'ok');
        } catch (e) { toast(e && e.error ? e.error : 'حصل خطأ', 'err'); }
      } }),
    ],
  });
}

function passModal(u) {
  const i = el('input', { class: 'input', type: 'password', placeholder: 'كلمة المرور الجديدة' });
  const m = modal({
    title: 'تغيير باسورد: ' + u.name,
    body: el('div', { class: 'col', style: { gap: '10px' } }, [i]),
    footer: [
      el('button', { class: 'btn', text: 'إلغاء', onclick: () => m.close() }),
      el('button', { class: 'btn primary', text: 'تغيير', onclick: async () => {
        if (String(i.value).length < 6) { toast('6 حروف على الأقل', 'err'); return; }
        await api.user({ id: u.id, password: i.value });
        m.close();
        toast('تم تغيير كلمة المرور ✓', 'ok');
      } }),
    ],
  });
}

function mini(label, value, color) {
  return el('div', { style: { textAlign: 'center', padding: '8px 4px', borderRadius: '10px', background: 'var(--panel-2)' } }, [
    el('div', { class: 'num', text: String(value), style: { fontSize: '19px', fontWeight: '800', color: color || 'inherit' } }),
    el('div', { class: 'dim', style: { fontSize: '10.5px' }, text: label }),
  ]);
}
