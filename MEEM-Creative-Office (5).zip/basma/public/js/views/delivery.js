/* ============================================================
   MEEM | Creative Office — خدمة العملاء والتسليمات
   ============================================================ */
import { t, getLang } from '../i18n.js';
import { state, save, userById, projectById, clientById, todayStr } from '../store.js';
import { el, icon, clear, avatarHTML, statusBadge, formatDate, timeAgo, escapeHTML, toast, modal, promptDialog } from '../ui.js';
import { uid } from '../api.js';
import { openTaskDetails, openTaskModal } from '../taskform.js';

const CHANNELS = [
  { id: 'email', label: 'بريد إلكتروني', icon: 'mail' },
  { id: 'whatsapp', label: 'واتساب', icon: 'whatsapp' },
  { id: 'drive', label: 'رابط Drive', icon: 'drive' },
  { id: 'hand', label: 'تسليم يدوي', icon: 'delivery' },
];

const DSTATUS = [
  { id: 'draft', label: 'قيد التجهيز', color: '' },
  { id: 'waiting_client', label: 'بانتظار رد العميل', color: 'warn' },
  { id: 'revision', label: 'العميل يريد تعديل', color: 'danger' },
  { id: 'approved', label: 'تم الاعتماد', color: 'ok' },
];

export function renderDelivery(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');

  const list = state.deliveries || [];
  const counts = DSTATUS.map((s) => ({ ...s, n: list.filter((d) => d.status === s.id).length }));

  host.append(
    el('div', { class: 'page-head' }, [
      el('div', {}, [
        el('h1', { html: icon('delivery') + ' ' + t('nav_delivery'), style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
        el('div', { class: 'ph-sub', text: 'تابع كل تسليم، أكّد مع العميل، وسجّل الاعتماد أو طلب التعديل' }),
      ]),
      el('button', { class: 'btn primary', html: icon('plus') + `<span>تسليم جديد</span>`, onclick: () => openDeliveryModal(null, refresh) }),
    ]),

    el('div', { class: 'kpis' }, counts.map((c) => el('div', { class: 'kpi' }, [
      el('div', { class: 'k-label', text: c.label }),
      el('div', { class: 'k-value num', text: String(c.n), style: c.color ? { color: `var(--${c.color})` } : {} }),
    ]))),
  );

  /* ---- بطاقات التسليم ---- */
  const grid = el('div', { class: 'col', style: { gap: '12px' } });

  if (!list.length) {
    grid.appendChild(el('div', { class: 'empty card', style: { padding: '50px' } }, [
      el('div', { html: icon('delivery'), style: { width: '54px', height: '54px', margin: '0 auto 12px', opacity: '.4' } }),
      el('div', { text: 'لا توجد تسليمات بعد' }),
    ]));
  }

  list.forEach((d) => {
    const project = projectById(d.projectId);
    const client = clientById(d.clientId);
    const st = DSTATUS.find((x) => x.id === d.status) || DSTATUS[0];
    const ch = CHANNELS.find((x) => x.id === d.channel) || CHANNELS[0];

    const card = el('div', { class: 'card', style: { padding: '16px' } }, [
      el('div', { class: 'between wrap', style: { marginBottom: '10px' } }, [
        el('div', { class: 'row', style: { gap: '10px' } }, [
          el('div', { style: { width: '40px', height: '40px', borderRadius: '11px', background: 'var(--brand-soft)', color: 'var(--brand)', display: 'grid', placeItems: 'center' }, html: icon(ch.icon) }),
          el('div', {}, [
            el('div', { style: { fontWeight: '800', fontSize: '15.5px' }, text: d.title }),
            el('div', { class: 'dim', style: { fontSize: '12px' }, text: `${client ? (getLang() === 'ar' ? client.name : client.nameEn) : '—'} · ${project ? project.title : '—'}` }),
          ]),
        ]),
        el('div', { class: 'row', style: { gap: '7px' } }, [
          el('span', { class: 'badge ' + st.color, html: `<i class="dot"></i>${st.label}` }),
          el('span', { class: 'badge', text: ch.label }),
          d.revisions ? el('span', { class: 'badge warn', text: `${d.revisions} تعديل` }) : null,
        ]),
      ]),

      el('div', { class: 'row wrap', style: { gap: '7px', marginBottom: '12px' } }, [
        ...(d.items || []).map((f) => el('span', { class: 'badge', html: icon('file') + `<span>${escapeHTML(f)}</span>` })),
        d.auto ? el('span', { class: 'badge', text: '🤖 أوتوماتيك' }) : null,
      ]),

      /* ---- قائمة التحقق قبل الإرسال ---- */
      (d.checklist && d.checklist.length) ? (() => {
        const doneN = d.checklist.filter((x) => x.done).length;
        const pct = Math.round((doneN / d.checklist.length) * 100);
        const box = el('div', { class: 'checklist', style: { marginBottom: '12px' } }, [
          el('div', { class: 'row', style: { gap: '8px', marginBottom: '8px' } }, [
            el('b', { style: { fontSize: '13px' }, text: `✅ قائمة التسليم (${doneN}/${d.checklist.length})` }),
            el('div', { class: 'grow' }),
            el('span', { class: 'dim num', style: { fontSize: '12px' }, text: pct + '%' }),
          ]),
          el('div', { class: 'pbar', style: { marginBottom: '10px' } }, [el('i', { style: { width: pct + '%' } })]),
          ...d.checklist.map((item, i) => el('label', { class: 'ck-row' }, [
            el('input', {
              type: 'checkbox', checked: !!item.done,
              onchange: async (e) => { item.done = e.target.checked; await save('deliveries', d); refresh(); },
            }),
            el('span', { style: item.done ? { textDecoration: 'line-through', opacity: '.55' } : {}, text: item.label }),
          ])),
        ]);
        return box;
      })() : null,

      d.clientFeedback ? el('div', { class: 'card card-pad', style: { background: 'var(--panel-2)', marginBottom: '12px' } }, [
        el('div', { class: 'row', style: { gap: '6px', marginBottom: '4px' } }, [
          el('span', { html: icon('chat'), style: { color: 'var(--text-3)' } }),
          el('b', { text: t('dlv_feedback'), style: { fontSize: '12.5px' } }),
        ]),
        el('div', { text: d.clientFeedback, style: { fontSize: '13.5px' } }),
      ]) : null,

      d.signoff ? el('div', { class: 'badge ok', style: { marginBottom: '10px' }, html: icon('checkCircle') + `<span>اعتماد: ${escapeHTML(d.signoff.by)} — ${formatDate(d.signoff.at, true)}</span>` }) : null,

      el('div', { class: 'row wrap', style: { gap: '7px' } }, [
        el('button', { class: 'btn sm', html: icon('edit') + `<span>${t('edit')}</span>`, onclick: () => openDeliveryModal(d, refresh) }),
        d.status !== 'approved' ? el('button', {
          class: 'btn sm ok', html: icon('check') + `<span>${t('dlv_approve')}</span>`,
          onclick: async () => {
            const name = await promptDialog('اسم من اعتمد من جهة العميل', client ? client.contact : '', { title: t('dlv_approve') });
            if (name == null) return;
            d.status = 'approved';
            d.signoff = { by: name, at: new Date().toISOString() };
            await save('deliveries', d);
            // إغلاق المهمة المرتبطة
            const task = state.tasks.find((x) => x.projectId === d.projectId && x.dept === 'delivery');
            if (task) { task.status = 'done'; await save('tasks', task); }
            toast('تم تسجيل الاعتماد ✓', 'ok');
            refresh();
          },
        }) : null,
        d.status !== 'revision' ? el('button', {
          class: 'btn sm danger ghost', html: icon('refresh') + `<span>${t('dlv_requestChanges')}</span>`,
          onclick: async () => {
            const fb = await promptDialog('ملاحظات العميل المطلوبة للتعديل', '', { title: t('dlv_requestChanges'), textarea: true });
            if (fb == null) return;
            d.status = 'revision';
            d.clientFeedback = fb;
            d.revisions = (d.revisions || 0) + 1;
            await save('deliveries', d);
            // إعادة فتح مهام التصميم المرتبطة
            const tasks = state.tasks.filter((x) => x.projectId === d.projectId && ['design', 'content', 'voice'].includes(x.dept));
            for (const tk of tasks) {
              tk.status = 'revision';
              tk.comments = tk.comments || [];
              tk.comments.push({ id: uid('cmt'), userId: state.user.id, text: 'ملاحظات العميل: ' + fb, at: new Date().toISOString() });
              await save('tasks', tk);
            }
            toast('تم إرسال التعديل للأقسام المعنية', 'warn');
            refresh();
          },
        }) : null,
        (d.checklist && d.checklist.length) ? el('button', {
          class: 'btn sm primary', html: icon('send') + `<span>إرسال للعميل</span>`,
          onclick: async () => {
            const left = d.checklist.filter((x) => !x.done).length;
            if (left) { toast('فاضل ' + left + ' بنود في قائمة التسليم', 'warn'); return; }
            d.status = 'waiting_client';
            if (!d.deliveredAt) d.deliveredAt = new Date().toISOString();
            await save('deliveries', d);
            toast('اترسل للعميل — الحالة: بانتظار رده ✓', 'ok');
            refresh();
          },
        }) : null,
        el('button', {
          class: 'btn sm ghost', html: icon('send') + `<span>إرسال تذكير</span>`,
          onclick: () => { d.status = 'waiting_client'; save('deliveries', d).then(() => { toast('تم إرسال التذكير', 'ok'); refresh(); }); },
        }),
        el('div', { class: 'grow' }),
        el('span', { class: 'dim', style: { fontSize: '11.5px' }, text: d.deliveredAt ? 'سُلّم ' + timeAgo(d.deliveredAt) : '' }),
      ]),
    ]);
    grid.appendChild(card);
  });

  host.appendChild(grid);

  /* ---- مهام القسم ---- */
  host.appendChild(el('h3', { text: 'مهام خدمة العملاء', style: { fontSize: '16px', margin: '22px 0 12px' } }));
  const tasksHost = el('div');
  host.appendChild(tasksHost);
  import('./dept.js').then((m) => m.renderDept('delivery', tasksHost));

  function refresh() { host.innerHTML = ''; renderDelivery(host); }
}

/* ---------------- نموذج تسليم ---------------- */
export function openDeliveryModal(d, onDone) {
  const isNew = !d;
  const doc = Object.assign({
    title: '', projectId: state.projects[0] ? state.projects[0].id : '',
    clientId: '', channel: 'email', status: 'draft', items: [],
    clientFeedback: '', revisions: 0, signoff: null, deliveredAt: null,
  }, d || {});

  const itemsInput = el('input', { class: 'input', value: (doc.items || []).join('، '), placeholder: 'اسم الملف 1، اسم الملف 2' });
  const projectSel = el('select', {
    class: 'select',
    html: state.projects.map((p) => `<option value="${p.id}" ${p.id === doc.projectId ? 'selected' : ''}>${escapeHTML(p.title)}</option>`).join(''),
    onchange: (e) => {
      doc.projectId = e.target.value;
      const p = projectById(doc.projectId);
      if (p) { doc.clientId = p.clientId; clientSel.value = p.clientId; }
    },
  });
  const clientSel = el('select', {
    class: 'select',
    html: state.clients.map((c) => `<option value="${c.id}" ${c.id === doc.clientId ? 'selected' : ''}>${escapeHTML(getLang() === 'ar' ? c.name : c.nameEn)}</option>`).join(''),
    onchange: (e) => { doc.clientId = e.target.value; },
  });
  const fbInput = el('textarea', { class: 'textarea', oninput: (e) => doc.clientFeedback = e.target.value });
  fbInput.value = doc.clientFeedback || '';
  const titleInput = el('input', { class: 'input', value: doc.title, oninput: (e) => doc.title = e.target.value });
  const chSel = el('select', { class: 'select', html: CHANNELS.map((c) => `<option value="${c.id}" ${c.id === doc.channel ? 'selected' : ''}>${c.label}</option>`).join(''), onchange: (e) => doc.channel = e.target.value });
  const stSel = el('select', { class: 'select', html: DSTATUS.map((c) => `<option value="${c.id}" ${c.id === doc.status ? 'selected' : ''}>${c.label}</option>`).join(''), onchange: (e) => doc.status = e.target.value });

  const m = modal({
    title: isNew ? 'تسليم جديد' : t('edit'),
    size: 'wide',
    body: [
      el('div', { class: 'field' }, [el('label', { text: 'عنوان التسليم *' }), titleInput]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: t('project') }), projectSel]),
        el('div', { class: 'field' }, [el('label', { text: t('client') }), clientSel]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: t('dlv_channel') }), chSel]),
        el('div', { class: 'field' }, [el('label', { text: t('status') }), stSel]),
      ]),
      el('div', { class: 'field' }, [el('label', { text: t('dlv_items') }), itemsInput]),
      el('div', { class: 'field' }, [el('label', { text: t('dlv_feedback') }), fbInput]),
    ],
    footer: [
      isNew ? null : el('button', {
        class: 'btn danger ghost', text: t('delete'),
        onclick: async () => { const { remove } = await import('../store.js'); await remove('deliveries', doc.id); m.close(); refresh(); },
      }),
      el('div', { class: 'grow' }),
      el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: t('save'),
        onclick: async () => {
          if (!doc.title.trim()) { toast(t('required'), 'warn'); return; }
          doc.items = itemsInput.value.split(/[،,]/).map((s) => s.trim()).filter(Boolean);
          if (doc.status !== 'draft' && !doc.deliveredAt) doc.deliveredAt = new Date().toISOString();
          await save('deliveries', doc);
          m.close();
          toast(t('saved'), 'ok');
          onDone && onDone();
        },
      }),
    ],
  });
  function refresh() { onDone && onDone(); }
}
