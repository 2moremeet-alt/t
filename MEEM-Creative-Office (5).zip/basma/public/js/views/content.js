/* ============================================================
   MEEM | Creative Office — Phase 4: Content Studio
   مكتبة + محرر كامل + AI Toolbar + Brand Voice + دورة مراجعة
   ============================================================ */
import { t, getLang } from '../i18n.js';
import { state, save, remove, userById, clientById, projectById } from '../store.js';
import { el, icon, clear, avatarHTML, timeAgo, escapeHTML, toast, modal, confirmDialog } from '../ui.js';
import { runAI, isPro, localGenerate } from '../ai.js';
import { api } from '../api.js';

export const CONTENT_TYPES = [
  ['caption', 'كابشن سوشيال'],
  ['script30', 'سكربت 30 ثانية'],
  ['script60', 'سكربت 60 ثانية'],
  ['article', 'مقال'],
  ['ad', 'نص إعلان'],
  ['email', 'إيميل'],
  ['seo', 'محتوى SEO'],
];
export const CSTATUS = {
  draft: ['مسودة', ''],
  review: ['في المراجعة', 'warn'],
  approved: ['معتمد', 'ok'],
  changes: ['تعديلات مطلوبة', 'danger'],
};
const typeName = (k) => (CONTENT_TYPES.find((x) => x[0] === k) || ['', k])[1];

export function renderContent(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  let tab = 'library';

  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('content') + ' استوديو المحتوى', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'اكتب، ولّد بالـ AI بصوت البراند، ابعت للمراجعة، واعتمد — كله من مكان واحد' }),
    ]),
    el('button', { class: 'btn primary', html: icon('plus') + `<span>محتوى جديد</span>`, onclick: () => openContentEditor(null, () => draw()) }),
  ]));

  const tabs = el('div', { class: 'tabs' });
  const area = el('div');
  tabs.append(...[['library', '📚 المكتبة'], ['tasks', '📋 المهام']].map(([k, lb]) => el('button', {
    class: k === tab ? 'active' : '', text: lb,
    onclick: (e) => { tab = k; tabs.querySelectorAll('button').forEach((b) => b.classList.remove('active')); e.currentTarget.classList.add('active'); draw(); },
  })));
  host.append(tabs, area);

  function draw() {
    clear(area);
    if (tab === 'tasks') { import('./dept.js').then((m) => m.renderDept('content', area)); return; }
    drawLibrary(area, draw);
  }
  draw();
}

function drawLibrary(host, refresh) {
  const list = state.contents || [];
  const counts = ['draft', 'review', 'approved', 'changes'].map((k) => ({ k, n: list.filter((c) => c.status === k).length }));
  host.appendChild(el('div', { class: 'kpis' }, counts.map((c) => el('div', { class: 'kpi' }, [
    el('div', { class: 'k-label', text: CSTATUS[c.k][0] }),
    el('div', { class: 'k-value num', text: String(c.n), style: { color: `var(--${CSTATUS[c.k][1] || 'text-2'})` } }),
  ]))));

  const grid = el('div', { class: 'col', style: { gap: '9px' } });
  if (!list.length) grid.appendChild(el('div', { class: 'empty card', style: { padding: '40px' }, text: 'لا محتوى بعد — اكتب أول قطعة أو ولّدها بالـ AI ✨' }));
  [...list].sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || '')).forEach((c) => {
    const client = clientById(c.clientId);
    const owner = userById(c.owner);
    const [lb, cl] = CSTATUS[c.status] || ['', ''];
    grid.appendChild(el('div', { class: 'card row wrap', style: { padding: '13px 15px', gap: '10px', cursor: 'pointer' }, onclick: () => openContentEditor(c.id, refresh) }, [
      el('div', { style: { width: '38px', height: '38px', borderRadius: '10px', background: 'var(--brand-soft)', color: 'var(--brand)', display: 'grid', placeItems: 'center', fontSize: '17px' }, text: { caption: '💬', script30: '🎬', script60: '🎥', article: '📝', ad: '📢', email: '✉️', seo: '🔎' }[c.type] || '📄' }),
      el('div', { class: 'grow', style: { minWidth: '200px' } }, [
        el('div', { style: { fontWeight: '800', fontSize: '14.5px' }, text: c.title }),
        el('div', { class: 'dim', style: { fontSize: '12px' }, text: `${typeName(c.type)} · ${client ? client.name : '—'} · ${(c.body || '').trim().split(/\s+/).filter(Boolean).length} كلمة · ${timeAgo(c.updatedAt || c.createdAt)}` }),
      ]),
      el('div', { class: 'row', style: { gap: '6px' } }, [
        c.versions && c.versions.length ? el('span', { class: 'badge', text: 'V' + c.versions.length }) : null,
        (c.comments || []).filter((x) => !x.resolved).length ? el('span', { class: 'badge danger', text: '💬 ' + c.comments.filter((x) => !x.resolved).length }) : null,
        el('span', { class: 'badge ' + cl, text: lb }),
        el('div', { html: avatarHTML(owner, 'sm') }),
      ]),
    ]));
  });
  host.appendChild(grid);
}

/* ---------------- المحرر ---------------- */
export function openContentEditor(id, onDone) {
  const existing = (state.contents || []).find((x) => x.id === id) || null;
  const doc = Object.assign({
    id: null, title: '', type: 'caption', body: '', lang: 'ar', status: 'draft',
    clientId: '', projectId: '', owner: state.user.id, comments: [], versions: [],
  }, existing ? JSON.parse(JSON.stringify(existing)) : {});
  if (!doc.owner) doc.owner = state.user.id;

  const overlay = el('div', { class: 'studio' });
  document.body.appendChild(overlay);
  const close = () => { overlay.remove(); onDone && onDone(); };

  const titleInput = el('input', { class: 'input ct-title', placeholder: 'عنوان المحتوى…', value: doc.title, oninput: (e) => { doc.title = e.target.value; dirty = true; } });
  const bodyTa = el('textarea', { class: 'ct-body', placeholder: 'اكتب هنا… أو جرّب ✨ توليد مسودة', spellcheck: 'false' });
  bodyTa.value = doc.body || '';
  bodyTa.addEventListener('input', () => { doc.body = bodyTa.value; dirty = true; updateStats(); });

  const stats = el('div', { class: 'ct-stats dim' });
  const statusPill = el('span', { class: 'badge' });
  let dirty = false;

  function updateStats() {
    const text = bodyTa.value || '';
    const words = text.trim() ? text.trim().split(/\s+/).length : 0;
    const readSec = Math.round((words / 130) * 60);
    stats.innerHTML = '';
    stats.append(
      el('span', { text: `${words} كلمة` }),
      el('span', { text: `${text.length} حرف` }),
      el('span', { text: doc.type.startsWith('script') ? `≈ ${Math.max(1, Math.round(words / 2.2))} ثانية أداء` : `≈ ${readSec < 60 ? readSec + ' ث' : Math.round(readSec / 60) + ' د'} قراءة` }),
      dirty ? el('span', { class: 'warn', text: '● غير محفوظ' }) : el('span', { class: 'ok', text: '✓ محفوظ' }),
    );
  }
  function updateStatus() {
    const [lb, cl] = CSTATUS[doc.status] || ['', ''];
    statusPill.className = 'badge ' + cl;
    statusPill.textContent = lb;
  }

  async function doSave(silent) {
    if (!doc.title.trim()) doc.title = typeName(doc.type) + ' — بدون عنوان';
    doc.body = bodyTa.value;
    const saved = await save('contents', doc);
    Object.assign(doc, saved);
    dirty = false;
    updateStats();
    if (!silent) toast('اتحفظ ✓', 'ok');
    return saved;
  }

  async function sendReview() {
    await doSave(true);
    try {
      const res = await api_docSubmit(doc.id, '');
      Object.assign(doc, res.doc);
      if (res.version) toast(`اترسل للمراجعة ✓ (نسخة V${res.version.v})`, 'ok', 3500);
      updateStatus(); drawSide();
    } catch (e) { toast('تعذّر الإرسال: ' + e.message, 'err'); }
  }

  /* ---- AI toolbar ---- */
  const pro = isPro(state.settings);
  const aiBtn = (action, label, ico) => el('button', {
    class: 'btn sm ai-btn', html: ico + `<span>${label}</span>` + (pro ? '' : '<i class="pro-chip">Pro</i>'),
    title: pro ? 'موصول بمفتاح API' : 'المولّد المحلي — فعّل Pro من الإعدادات',
    onclick: async (e) => {
      const btn = e.currentTarget;
      btn.disabled = true;
      const old = btn.innerHTML;
      btn.innerHTML = '<span class="spin"></span>';
      try {
        const client = clientById(doc.clientId);
        const res = await runAI(action, {
          type: doc.type, lang: doc.lang, text: bodyTa.value,
          voice: client ? client.brandVoice : null,
        }, state.settings);
        applyAI(action, res.text, res.pro);
      } finally { btn.disabled = false; btn.innerHTML = old; }
    },
  });

  function applyAI(action, text, wasPro) {
    if (!text) return;
    if (action === 'improve' || action === 'shorten' || action === 'voice') {
      const put = () => { bodyTa.value = text; doc.body = text; dirty = true; updateStats(); };
      if (bodyTa.value.trim() && action !== 'voice') {
        const m = modal({
          title: 'استبدال النص الحالي؟',
          body: [el('div', { class: 'ct-diff' }, [
            el('div', {}, [el('b', { text: 'قبل:' }), el('pre', { text: bodyTa.value.slice(0, 400) })]),
            el('div', {}, [el('b', { text: 'بعد:' }), el('pre', { text: text.slice(0, 400) })]),
          ])],
          footer: [
            el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
            el('button', { class: 'btn primary', text: 'استبدال', onclick: () => { m.close(); put(); } }),
          ],
        });
      } else put();
    } else if (action === 'draft') {
      if (bodyTa.value.trim()) { bodyTa.value = bodyTa.value.trimEnd() + '\n\n' + text; }
      else bodyTa.value = text;
      doc.body = bodyTa.value; dirty = true; updateStats();
    } else {
      bodyTa.value = bodyTa.value.trimEnd() + (bodyTa.value.trim() ? '\n\n' : '') + text;
      doc.body = bodyTa.value; dirty = true; updateStats();
    }
    toast(wasPro ? '✨ جاهز (Pro)' : '✨ جاهز — مولّد محلي (فعّل Pro لمفتاح API)', 'ok', 3200);
  }

  /* ---- البناء ---- */
  const typeSel = el('select', {
    class: 'select', style: { width: 'auto' },
    html: CONTENT_TYPES.map(([k, v]) => `<option value="${k}" ${k === doc.type ? 'selected' : ''}>${v}</option>`).join(''),
    onchange: (e) => { doc.type = e.target.value; dirty = true; updateStats(); },
  });
  const clientSel = el('select', {
    class: 'select', style: { width: 'auto' },
    html: `<option value="">— بدون عميل —</option>` + (state.clients || []).map((c) => `<option value="${c.id}" ${c.id === doc.clientId ? 'selected' : ''}>${escapeHTML(c.name)}</option>`).join(''),
    onchange: (e) => { doc.clientId = e.target.value; dirty = true; drawVoice(); },
  });

  const side = el('div', { class: 'ct-side' });
  function drawSide() {
    clear(side);
    // المراجعة
    const isOwner = doc.owner === state.user.id;
    const canDecide = doc.status === 'review' && (!isOwner || state.user.role === 'admin');
    side.appendChild(el('div', { class: 'ct-panel' }, [
      el('div', { class: 'ct-panel-title', text: '🔍 المراجعة' }),
      doc.review && doc.review.note ? el('div', { class: 'ct-note', text: '📝 ' + doc.review.note }) : null,
      doc.review && doc.review.decision ? el('div', { class: 'ct-note ' + (doc.review.decision === 'approve' ? 'ok' : 'danger'), text: (doc.review.decision === 'approve' ? '✅ اعتمده ' : '✏️ طلب تعديل: ') + (doc.review.decidedByName || '') + (doc.review.decision === 'changes' && doc.review.note ? ' — ' + doc.review.note : '') }) : null,
      canDecide ? el('div', { class: 'row', style: { gap: '7px', marginTop: '8px' } }, [
        el('button', {
          class: 'btn sm ok grow', html: icon('check') + `<span>اعتماد</span>`,
          onclick: () => decide('approve'),
        }),
        el('button', {
          class: 'btn sm danger grow', html: icon('edit') + `<span>طلب تعديل</span>`,
          onclick: () => decide('changes'),
        }),
      ]) : (doc.status === 'review' ? el('div', { class: 'dim', style: { fontSize: '12px' }, text: isOwner ? 'شغلك في المراجعة — القرار لزميل أو مدير' : '' }) : null),
      doc.status === 'changes' && isOwner ? el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'ظبط الملاحظات واعمل «إعادة إرسال» من فوق ↩' }) : null,
    ]));
    // النسخ
    if ((doc.versions || []).length) {
      side.appendChild(el('div', { class: 'ct-panel' }, [
        el('div', { class: 'ct-panel-title', text: `🗂 النسخ (${doc.versions.length})` }),
        ...doc.versions.slice(-5).reverse().map((v) => el('div', { class: 'ct-ver', onclick: () => showVersion(v) }, [
          el('b', { text: 'V' + v.v }),
          el('span', { class: 'dim', text: timeAgo(v.at) + ' · ' + (v.byName || '') }),
        ])),
      ]));
    }
    // التعليقات
    const cmts = doc.comments || [];
    const addInput = el('input', { class: 'input', placeholder: 'اكتب تعليقًا…' });
    const cmtList = el('div', { class: 'col', style: { gap: '6px' } });
    function drawComments() {
      clear(cmtList);
      cmts.forEach((c) => cmtList.appendChild(el('div', { class: 'ct-cmt' + (c.resolved ? ' resolved' : '') }, [
        el('div', { class: 'row', style: { gap: '6px' } }, [
          el('b', { style: { fontSize: '12px' }, text: c.byName || '' }),
          el('span', { class: 'dim', style: { fontSize: '10.5px' }, text: timeAgo(c.at) }),
          el('div', { class: 'grow' }),
          !c.resolved ? el('button', { class: 'btn ghost sm', text: 'تم ✓', onclick: async () => { await api_docComment(doc.id, { id: c.id, op: 'resolve' }); c.resolved = true; drawComments(); } }) : null,
        ]),
        el('div', { style: { fontSize: '13px', margin: '3px 0' }, text: c.text }),
        ...(c.replies || []).map((r) => el('div', { class: 'dim', style: { fontSize: '12px' }, text: '↩ ' + (r.byName || '') + ': ' + r.text })),
      ])));
      if (!cmts.length) cmtList.appendChild(el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'لا تعليقات' }));
    }
    drawComments();
    side.appendChild(el('div', { class: 'ct-panel' }, [
      el('div', { class: 'ct-panel-title', text: `💬 التعليقات (${cmts.length})` }),
      cmtList,
      el('div', { class: 'row', style: { gap: '6px', marginTop: '8px' } }, [
        addInput,
        el('button', {
          class: 'btn sm primary', html: icon('send'),
          onclick: async () => {
            const text = addInput.value.trim();
            if (!text) return;
            const res = await api_docComment(doc.id, { text });
            doc.comments = res.comments; addInput.value = ''; drawSide();
          },
        }),
      ]),
    ]));
  }

  async function decide(decision) {
    let note = '';
    if (decision === 'changes') {
      const r = await new Promise((resolve) => {
        const inp = el('textarea', { class: 'textarea', placeholder: 'ملاحظاتك للتعديل…' });
        const m = modal({
          title: 'طلب تعديل',
          body: [inp],
          footer: [
            el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => { m.close(); resolve(null); } }),
            el('button', { class: 'btn danger', text: 'إرسال', onclick: () => { m.close(); resolve(inp.value.trim()); } }),
          ],
        });
      });
      if (r == null) return;
      note = r;
      if (!note) { toast('اكتب ملاحظات التعديل', 'warn'); return; }
    }
    try {
      const res = await api_docDecision(doc.id, decision, note);
      Object.assign(doc, res.doc);
      updateStatus(); drawSide();
      toast(decision === 'approve' ? 'اتعتمد ✓' : 'اترسلت ملاحظات التعديل', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  }

  function showVersion(v) {
    const m = modal({
      title: 'نسخة V' + v.v + ' — ' + timeAgo(v.at),
      size: 'wide',
      body: [el('pre', { class: 'ct-ver-body', text: v.body || '' })],
      footer: [
        el('button', { class: 'btn ghost', text: 'إغلاق', onclick: () => m.close() }),
        el('button', {
          class: 'btn primary', text: 'استرجاع النص ده',
          onclick: () => { m.close(); bodyTa.value = v.body || ''; doc.body = bodyTa.value; dirty = true; updateStats(); toast('اتحط في المحرر — افتكر تحفظ', 'ok', 3000); },
        }),
      ],
    });
  }

  /* ---- Brand Voice panel ---- */
  const voiceBox = el('div');
  function drawVoice() {
    clear(voiceBox);
    const c = clientById(doc.clientId);
    if (!c) { voiceBox.appendChild(el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'اختار عميل عشان يتفعّل صوت البراند في التوليد ✨' })); return; }
    const bv = c.brandVoice || {};
    voiceBox.append(
      el('div', { class: 'badge ok', style: { marginBottom: '8px' }, text: '🎙 صوت البراند مفعّل' }),
      el('div', { class: 'kv' }, [
        bv.tone ? el('div', { class: 'kv-row' }, [el('b', { text: 'النبرة' }), el('span', { class: 'dim', text: bv.tone })]) : null,
        bv.keywords ? el('div', { class: 'kv-row' }, [el('b', { text: 'كلمات' }), el('span', { class: 'dim', text: bv.keywords })]) : null,
        bv.donts ? el('div', { class: 'kv-row' }, [el('b', { text: 'ممنوع' }), el('span', { class: 'dim', text: bv.donts })]) : null,
      ].filter(Boolean)),
      bv.sample ? el('div', { class: 'ct-note', style: { marginTop: '8px' }, text: '💬 «' + bv.sample + '»' }) : null,
    );
  }

  overlay.append(
    el('div', { class: 'ct-top' }, [
      el('button', { class: 'btn ghost icon', html: icon('chevronRight'), onclick: async () => { if (dirty && !await confirmDialog('فيه تغييرات مش محفوظة — قفل؟')) return; close(); } }),
      titleInput,
      statusPill,
      el('div', { class: 'grow' }),
      el('button', { class: 'btn sm', html: '💾<span>حفظ</span>', onclick: () => doSave(false) }),
      doc.owner === state.user.id || state.user.role === 'admin' ? el('button', {
        class: 'btn sm primary', html: icon('send') + `<span>${['review', 'approved'].includes(doc.status) ? 'إعادة إرسال' : 'للمراجعة'}</span>`,
        onclick: sendReview,
      }) : null,
      existing ? el('button', {
        class: 'btn ghost icon sm', html: icon('trash'), title: 'حذف',
        onclick: async () => { if (await confirmDialog('حذف المحتوى؟', { danger: true })) { await remove('contents', doc.id); close(); } },
      }) : null,
    ]),
    el('div', { class: 'ct-main' }, [
      el('div', { class: 'ct-editor' }, [
        el('div', { class: 'row wrap', style: { gap: '8px', marginBottom: '10px' } }, [
          typeSel, clientSel,
          el('div', { class: 'grow' }),
          el('span', { class: 'ai-sep dim', text: '✨ أدوات AI:' }),
        ]),
        el('div', { class: 'row wrap', style: { gap: '6px', marginBottom: '10px' } }, [
          aiBtn('draft', 'توليد مسودة', icon('sparkles') || '✨'),
          aiBtn('improve', 'تحسين', '🪄'),
          aiBtn('shorten', 'تقصير', '✂️'),
          aiBtn('titles', '5 عناوين', '🔠'),
          aiBtn('hashtags', 'هاشتاجات', '#️⃣'),
          aiBtn('voice', 'بصمة الصوت', '🎙'),
        ]),
        bodyTa,
        stats,
      ]),
      el('div', { class: 'ct-side-wrap' }, [
        el('div', { class: 'ct-panel' }, [el('div', { class: 'ct-panel-title', text: '🎨 صوت البراند' }), voiceBox]),
        side,
      ]),
    ]),
  );

  updateStats(); updateStatus(); drawVoice(); drawSide();

  /* اختصارات */
  const onKey = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); doSave(false); }
    if (e.key === 'Escape' && e.target === document.body) { if (!dirty) close(); }
  };
  window.addEventListener('keydown', onKey);
  const origRemove = overlay.remove.bind(overlay);
  overlay.remove = () => { window.removeEventListener('keydown', onKey); origRemove(); };
}

const api_docSubmit = (id, note) => api.docSubmit('contents', id, note);
const api_docDecision = (id, decision, note) => api.docDecision('contents', id, decision, note);
const api_docComment = (id, payload) => api.docComment('contents', id, payload);
