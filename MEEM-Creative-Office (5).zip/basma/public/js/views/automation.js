/* ============================================================
   MEEM | Creative Office — Phase 3: الأتمتة (trigger → action)
   ============================================================ */
import { t } from '../i18n.js';
import { state, save } from '../store.js';
import { el, icon, clear, escapeHTML, toast, modal, confirmDialog } from '../ui.js';

const TRIGGERS = [
  ['design_submitted', 'تصميم اتبعت للمراجعة'],
  ['internal_approved', 'اعتماد داخلي لتصميم'],
  ['client_approved', 'العميل اعتمد تصميم'],
  ['client_changes', 'العميل طلب تعديل'],
  ['client_link_created', 'اتعمل رابط اعتماد للعميل'],
];
const ACTIONS = [
  ['create_delivery', 'إنشاء تسليم جاهز (بـ checklist)'],
  ['create_task_delivery', 'مهمة متابعة لخدمة العملاء'],
  ['create_task_revision', 'مهمة تعديل للمصمم'],
  ['log', 'تسجيل في سجل النشاط'],
];

function cfg() {
  return (state.settings || []).find((s) => s.id === 'automation') || { id: 'automation', rules: [] };
}

export function renderAutomation(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  const doc = cfg();

  host.append(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('bolt') + ' الأتمتة', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'قواعد «لو حصل كذا → اعمل كذا» بتشتغل تلقائيًا في المكتب كله' }),
    ]),
    el('button', { class: 'btn primary', html: icon('plus') + `<span>قاعدة جديدة</span>`, onclick: () => openRuleModal(null, refresh) }),
  ]));

  /* ---- إعدادات AI (Pro) ---- */
  const aiCfg = Object.assign({ id: 'ai', provider: 'openai', key: '', model: 'gpt-4o-mini', baseUrl: 'https://api.openai.com/v1' }, (state.settings || []).find((s) => s.id === 'ai') || {});
  const keyInp = el('input', { class: 'input', type: 'password', value: aiCfg.key, placeholder: 'sk-…' });
  const modelInp = el('input', { class: 'input', value: aiCfg.model });
  host.appendChild(el('div', { class: 'card', style: { padding: '14px 16px', maxWidth: '760px', marginBottom: '14px' } }, [
    el('div', { class: 'row', style: { gap: '8px', marginBottom: '10px' } }, [
      el('b', { text: '🔑 توصيل الـ AI (Pro)' }),
      el('span', { class: 'badge ' + (aiCfg.key ? 'ok' : ''), text: aiCfg.key ? 'Pro مفعّل ✓' : 'المولّد المحلي شغال' }),
    ]),
    el('div', { class: 'grid2' }, [
      el('div', { class: 'field' }, [el('label', { text: 'مفتاح API (OpenAI أو أي provider متوافق)' }), keyInp]),
      el('div', { class: 'field' }, [el('label', { text: 'الموديل' }), modelInp]),
    ]),
    el('div', { class: 'row', style: { gap: '8px' } }, [
      el('button', {
        class: 'btn sm primary', text: 'حفظ المفتاح',
        onclick: async () => {
          aiCfg.key = keyInp.value.trim();
          aiCfg.model = modelInp.value.trim() || 'gpt-4o-mini';
          await save('settings', aiCfg);
          toast(aiCfg.key ? 'Pro اتفعّل ✨ — التوليد هيتم عبر الـ API' : 'اتحفظ — المولّد المحلي هو اللي شغال', 'ok', 3500);
          refresh();
        },
      }),
      el('span', { class: 'dim', style: { fontSize: '11.5px' }, text: 'من غير مفتاح: كل أدوات الـ AI شغالة بمولّد محلي + شارة Pro' }),
    ]),
  ]));

  const grid = el('div', { class: 'col', style: { gap: '10px', maxWidth: '760px' } });
  if (!(doc.rules || []).length) grid.appendChild(el('div', { class: 'empty card', style: { padding: '40px' }, text: 'لا قواعد — أضف أول قاعدة أتمتة' }));
  (doc.rules || []).forEach((r) => {
    const trig = (TRIGGERS.find((x) => x[0] === r.trigger) || [])[1] || r.trigger;
    const act = (ACTIONS.find((x) => x[0] === r.action) || [])[1] || r.action;
    grid.appendChild(el('div', { class: 'card row wrap', style: { padding: '14px 16px', gap: '10px', opacity: r.on ? 1 : .55 } }, [
      el('div', { style: { width: '40px', height: '40px', borderRadius: '11px', background: 'rgba(34,211,238,.12)', color: 'var(--accent, #22d3ee)', display: 'grid', placeItems: 'center', fontSize: '19px' }, text: '🤖' }),
      el('div', { class: 'grow', style: { minWidth: '200px' } }, [
        el('div', { style: { fontWeight: '800', fontSize: '14px', marginBottom: '4px' }, text: r.label }),
        el('div', { class: 'row wrap', style: { gap: '6px' } }, [
          el('span', { class: 'badge warn', text: 'لما: ' + trig }),
          el('span', { html: icon('chevronLeft'), class: 'dim', style: { fontSize: '12px' } }),
          el('span', { class: 'badge ok', text: 'اعمل: ' + act }),
        ]),
      ]),
      el('label', { class: 'switch', title: r.on ? 'شغالة' : 'موقوفة' }, [
        el('input', { type: 'checkbox', checked: !!r.on, onchange: async (e) => { r.on = e.target.checked; await save('settings', doc); toast(r.on ? 'القاعدة شغالة ✓' : 'القاعدة موقوفة', 'ok'); refresh(); } }),
        el('span', { class: 'sl' }),
      ]),
      el('button', {
        class: 'btn ghost icon sm', html: icon('trash'),
        onclick: async () => {
          if (!await confirmDialog('حذف القاعدة؟', { danger: true })) return;
          doc.rules = doc.rules.filter((x) => x.id !== r.id);
          await save('settings', doc);
          refresh();
        },
      }),
    ]));
  });
  host.appendChild(grid);

  host.appendChild(el('div', { class: 'ed-hintbox', style: { maxWidth: '760px', marginTop: '16px' }, html: '💡 الأتمتة بتنفذ على السيرفر نفسه — يعني أي اعتماد من البورتال أو رابط العميل بيولّد تسليمات ومهام فورًا لكل الفريق، حتى لو مفيش حد فاتح المنصة.' }));

  function refresh() { renderAutomation(host); }
}

function openRuleModal(rule, onDone) {
  const doc = cfg();
  const r = Object.assign({ id: 'rule_' + Math.random().toString(36).slice(2, 7), trigger: 'client_approved', action: 'create_delivery', on: true, label: '' }, rule || {});
  const trigSel = el('select', { class: 'select', html: TRIGGERS.map(([k, v]) => `<option value="${k}" ${k === r.trigger ? 'selected' : ''}>${v}</option>`).join(''), onchange: (e) => { r.trigger = e.target.value; autoLabel(); } });
  const actSel = el('select', { class: 'select', html: ACTIONS.map(([k, v]) => `<option value="${k}" ${k === r.action ? 'selected' : ''}>${v}</option>`).join(''), onchange: (e) => { r.action = e.target.value; autoLabel(); } });
  const labelInp = el('input', { class: 'input', value: r.label });
  function autoLabel() {
    if (!labelInp.value.trim()) {
      const tg = (TRIGGERS.find((x) => x[0] === r.trigger) || [])[1] || '';
      const ac = (ACTIONS.find((x) => x[0] === r.action) || [])[1] || '';
      labelInp.value = tg + ' → ' + ac;
      r.label = labelInp.value;
    }
  }
  autoLabel();
  labelInp.addEventListener('input', () => r.label = labelInp.value);

  const m = modal({
    title: 'قاعدة أتمتة',
    body: [
      el('div', { class: 'field' }, [el('label', { text: 'لما يحصل (Trigger)' }), trigSel]),
      el('div', { class: 'field' }, [el('label', { text: 'اعمل (Action)' }), actSel]),
      el('div', { class: 'field' }, [el('label', { text: 'الوصف' }), labelInp]),
    ],
    footer: [
      el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: t('save'),
        onclick: async () => {
          const i = doc.rules.findIndex((x) => x.id === r.id);
          if (i >= 0) doc.rules[i] = r; else doc.rules.push(r);
          await save('settings', doc);
          m.close(); toast('القاعدة اتحفظت ✓', 'ok'); onDone && onDone();
        },
      }),
    ],
  });
}
