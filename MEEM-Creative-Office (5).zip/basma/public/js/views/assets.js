/* ============================================================
   MEEM | Creative Office — الأصول والمكتبة
   ============================================================ */
import { t } from '../i18n.js';
import { state, save } from '../store.js';
import { el, icon, clear, toast, confirmDialog, timeAgo, escapeHTML } from '../ui.js';
import { readFileAsDataURL } from '../api.js';
import { STOCK } from '../editor/index.js';

export function renderAssets(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');

  host.append(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('folder') + ' ' + t('nav_files'), style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'كل الصور والملفات المرفوعة — متاحة في محرر التصميم' }),
    ]),
    el('button', { class: 'btn primary', html: icon('upload') + `<span>${t('upload')}</span>`, onclick: () => pick() }),
  ]));

  const drop = el('div', {
    class: 'ed-dropzone', style: { marginBottom: '16px' },
    html: icon('upload') + `<div><b>اسحب الملفات هنا</b> أو اضغط للاختيار</div>`,
    onclick: () => pick(),
  });
  ['dragenter', 'dragover'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
  drop.addEventListener('dragleave', () => drop.classList.remove('over'));
  drop.addEventListener('drop', async (e) => {
    e.preventDefault();
    drop.classList.remove('over');
    for (const f of e.dataTransfer.files) await upload(f);
  });
  host.appendChild(drop);

  host.appendChild(el('h3', { text: 'الملفات المرفوعة', style: { fontSize: '15px', marginBottom: '10px' } }));
  const grid = el('div', { class: 'cards-grid', style: { gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))' } });
  const mine = state.assets || [];
  if (!mine.length) grid.appendChild(el('div', { class: 'empty', text: t('noData') }));
  mine.forEach((a) => {
    grid.appendChild(el('div', { class: 'card', style: { overflow: 'hidden' } }, [
      el('div', { class: 'dc-thumb', style: { aspectRatio: '1', background: 'var(--panel-3)', display: 'grid', placeItems: 'center' } }, [
        el('div', { class: 'dim', html: icon('file'), style: { width: '34px', height: '34px' } }),
      ]),
      el('div', { style: { padding: '9px' } }, [
        el('div', { class: 'truncate', style: { fontSize: '12.5px', fontWeight: '600' }, text: a.name }),
        el('div', { class: 'dim', style: { fontSize: '10.5px' }, text: `${Math.round((a.size || 0) / 1024)} KB · ${timeAgo(a.createdAt)}` }),
        el('div', { class: 'row', style: { gap: '5px', marginTop: '7px' } }, [
          el('button', {
            class: 'btn ghost icon sm', html: icon('download'), title: t('download'),
            onclick: async () => {
              const { api } = await import('../api.js');
              const full = await api.asset(a.id);
              if (full.asset && full.asset.data) {
                const a2 = document.createElement('a');
                a2.href = full.asset.data; a2.download = a.name; a2.click();
              }
            },
          }),
          el('button', {
            class: 'btn ghost icon sm', html: icon('trash'), title: t('delete'),
            onclick: async () => {
              if (!await confirmDialog(t('cantUndo'), { danger: true })) return;
              const { remove } = await import('../store.js');
              await remove('assets', a.id);
              toast('تم الحذف', 'ok');
              refresh();
            },
          }),
        ]),
      ]),
    ]));
  });
  host.appendChild(grid);

  host.appendChild(el('h3', { text: 'مكتبة الاستوديو', style: { fontSize: '15px', margin: '20px 0 10px' } }));
  const sg = el('div', { class: 'cards-grid', style: { gridTemplateColumns: 'repeat(auto-fill,minmax(180px,1fr))' } });
  STOCK.forEach((src) => {
    sg.appendChild(el('div', { class: 'dcard' }, [
      el('div', { class: 'dc-thumb' }, [el('img', { src, loading: 'lazy', alt: '' })]),
      el('div', { class: 'dc-body' }, [el('div', { class: 'dc-sub ltr', text: src.split('/').pop() })]),
    ]));
  });
  host.appendChild(sg);

  async function upload(file) {
    try {
      const data = await readFileAsDataURL(file);
      await save('assets', { name: file.name, type: file.type.startsWith('image') ? 'image' : 'file', size: file.size, data });
      toast('تم الرفع ✓', 'ok');
      refresh();
    } catch (e) {
      toast('تعذّر الرفع (الملف كبير؟)', 'err');
    }
  }

  function pick() {
    const inp = el('input', { type: 'file', multiple: true, accept: 'image/*,.pdf,.mp3,.wav', style: { display: 'none' } });
    document.body.appendChild(inp);
    inp.addEventListener('change', async () => { for (const f of inp.files) await upload(f); inp.remove(); });
    inp.click();
  }

  function refresh() { host.innerHTML = ''; renderAssets(host); }
}
