/* ============================================================
   MEEM | Creative Office — Phase 3: التقويم (مواعيد + تسليمات + اجتماعات)
   ============================================================ */
import { t } from '../i18n.js';
import { state, userById } from '../store.js';
import { el, icon, clear, escapeHTML, modal } from '../ui.js';
import { openTaskModal } from '../taskform.js';
import { openNewMeetingModal } from './meetings.js';

const WD = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

export function renderCalendar(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  let cur = new Date();
  cur.setDate(1);

  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('calendar') + ' التقويم', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'مواعيد تسليم المهام والمشاريع + الاجتماعات في مكان واحد' }),
    ]),
    el('div', { class: 'row', style: { gap: '7px' } }, [
      el('button', { class: 'btn sm', html: icon('plus') + `<span>مهمة بموعد</span>`, onclick: () => openTaskModal(null, () => renderCalendar(host)) }),
      el('button', { class: 'btn sm', html: icon('meet') + `<span>اجتماع</span>`, onclick: () => openNewMeetingModal(() => renderCalendar(host)) }),
    ]),
  ]));

  const head = el('div', { class: 'row', style: { marginBottom: '12px', gap: '10px' } });
  const grid = el('div', { class: 'cal-grid' });
  host.append(head, grid);

  function draw() {
    clear(head); clear(grid);
    const y = cur.getFullYear(), mo = cur.getMonth();
    head.append(
      el('button', { class: 'btn ghost icon', html: icon('chevron'), onclick: () => { cur.setMonth(mo - 1); draw(); } }),
      el('h2', { text: cur.toLocaleDateString('ar-EG', { month: 'long', year: 'numeric' }), style: { margin: 0, minWidth: '150px', textAlign: 'center' } }),
      el('button', { class: 'btn ghost icon', html: icon('chevron'), style: { transform: 'rotate(180deg)' }, onclick: () => { cur.setMonth(mo + 1); draw(); } }),
      el('button', { class: 'btn ghost sm', text: 'النهاردة', onclick: () => { cur = new Date(); cur.setDate(1); draw(); } }),
    );

    // أحداث الشهر
    const dstr = (d) => d.toISOString().slice(0, 10);
    const events = [];
    (state.tasks || []).forEach((tk) => { if (tk.due && !['done', 'delivered'].includes(tk.status)) events.push({ date: tk.due, label: tk.title, kind: 'task', color: 'var(--brand)', ref: tk }); });
    (state.projects || []).forEach((p) => { if (p.due && !['done', 'delivered'].includes(p.status)) events.push({ date: p.due, label: '🏁 ' + p.title, kind: 'project', color: 'var(--warn, #f59e0b)', ref: p }); });
    (state.meetings || []).forEach((m) => { if (m.scheduledAt) events.push({ date: m.scheduledAt.slice(0, 10), label: '🎥 ' + m.title, kind: 'meeting', color: 'var(--accent, #22d3ee)', ref: m }); });

    WD.forEach((d) => grid.appendChild(el('div', { class: 'cal-wd', text: d })));
    const first = new Date(y, mo, 1);
    const startDow = first.getDay(); // الأحد=0
    const days = new Date(y, mo + 1, 0).getDate();
    for (let i = 0; i < startDow; i++) grid.appendChild(el('div', { class: 'cal-cell empty' }));
    const today = dstr(new Date());
    for (let d = 1; d <= days; d++) {
      const ds = `${y}-${String(mo + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const dayEvents = events.filter((e) => e.date === ds);
      const cell = el('div', { class: 'cal-cell' + (ds === today ? ' today' : '') }, [
        el('div', { class: 'cal-num', text: String(d) }),
      ]);
      dayEvents.slice(0, 3).forEach((ev) => {
        cell.appendChild(el('button', {
          class: 'cal-ev', style: { borderColor: ev.color },
          text: ev.label,
          title: ev.label,
          onclick: (e) => {
            e.stopPropagation();
            dayModal(ds, dayEvents);
          },
        }));
      });
      if (dayEvents.length > 3) cell.appendChild(el('div', { class: 'dim', style: { fontSize: '10.5px' }, text: '+' + (dayEvents.length - 3) }));
      cell.addEventListener('click', () => dayModal(ds, dayEvents, true));
      grid.appendChild(cell);
    }
  }

  function dayModal(ds, evs, canAdd) {
    const body = el('div');
    if (!evs.length) body.appendChild(el('div', { class: 'dim', text: 'مفيش حاجة اليوم ده.' }));
    evs.forEach((ev) => {
      body.appendChild(el('div', { class: 'card row', style: { padding: '10px 12px', gap: '8px', marginBottom: '7px', cursor: 'pointer' }, onclick: () => {
        if (ev.kind === 'task') import('../taskform.js').then((m) => m.openTaskDetails(ev.ref, () => {}));
        else if (ev.kind === 'project') location.hash = '#/projects/' + ev.ref.id;
        else location.hash = '#/meetings';
      } }, [
        el('span', { style: { width: '8px', height: '8px', borderRadius: '50%', background: ev.color, flex: 'none' } }),
        el('div', { class: 'grow', style: { fontSize: '13.5px', fontWeight: '600' }, text: ev.label }),
        el('span', { class: 'badge', text: ev.kind === 'task' ? 'مهمة' : ev.kind === 'project' ? 'مشروع' : 'اجتماع' }),
      ]));
    });
    if (canAdd) {
      body.appendChild(el('div', { class: 'row', style: { gap: '7px', marginTop: '10px' } }, [
        el('button', { class: 'btn sm primary grow', html: icon('plus') + `<span>مهمة في اليوم ده</span>`, onclick: () => { m.close(); openTaskModal({ due: ds }, () => renderCalendar(host)); } }),
        el('button', { class: 'btn sm grow', html: icon('meet') + `<span>اجتماع</span>`, onclick: () => { m.close(); openNewMeetingModal(() => renderCalendar(host)); } }),
      ]));
    }
    const m = modal({ title: '📅 ' + ds, body: [body] });
  }

  draw();
}
