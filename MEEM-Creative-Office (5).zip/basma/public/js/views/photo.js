/* ============================================================
   MEEM | Creative Office — Phase 5: Photography — Shoots + Shot List
   ============================================================ */
import { t } from '../i18n.js';
import { state, save, remove, userById, clientById } from '../store.js';
import { el, icon, clear, avatarHTML, timeAgo, escapeHTML, toast, modal, confirmDialog } from '../ui.js';
import { api } from '../api.js';

const SSTATUS = {
  planned: ['مخططَة', 'info'],
  shooting: ['جارٍ التصوير', 'warn'],
  editing: ['في المونتاج', ''],
  delivered: ['اتسلّمت', 'ok'],
};
const PRIO = { high: ['danger', 'عالية'], medium: ['warn', 'متوسطة'], low: ['', 'منخفضة'] };

export function renderPhoto(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');

  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('image') + ' التصوير', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'جلسات التصوير بـ Shot List كاملة — كل لقطة محسوبة ومتعلّمة' }),
    ]),
    el('button', { class: 'btn primary', html: icon('plus') + `<span>جلسة جديدة</span>`, onclick: () => openShootModal(null, draw) }),
  ]));

  const area = el('div');
  host.appendChild(area);

  function draw() {
    clear(area);
    const list = state.shoots || [];
    const grid = el('div', { class: 'cards-grid' });
    if (!list.length) grid.appendChild(el('div', { class: 'empty', style: { gridColumn: '1/-1' }, text: 'لا جلسات تصوير — ابدأ واحدة' }));
    list.forEach((s) => {
      const client = clientById(s.clientId);
      const ph = userById(s.photographer);
      const done = (s.shots || []).filter((x) => x.done).length;
      const pct = s.shots && s.shots.length ? Math.round((done / s.shots.length) * 100) : 0;
      const [lb, cl] = SSTATUS[s.status] || ['', ''];
      grid.appendChild(el('div', { class: 'dcard', style: { cursor: 'pointer' }, onclick: () => openShoot(s.id, draw) }, [
        el('div', { class: 'dc-body', style: { padding: '14px' } }, [
          el('div', { class: 'row', style: { gap: '8px', marginBottom: '6px' } }, [
            el('div', { class: 'dc-title grow', text: s.title }),
            el('span', { class: 'badge ' + cl, text: lb }),
          ]),
          el('div', { class: 'dc-sub', text: `${client ? client.name : '—'} · 📅 ${s.date || '—'} · 📍 ${s.location || '—'}` }),
          el('div', { class: 'pbar', style: { margin: '10px 0 6px' } }, [el('i', { style: { width: pct + '%' } })]),
          el('div', { class: 'row', style: { gap: '6px', fontSize: '11.5px' } }, [
            el('span', { class: 'dim', text: `${done}/${(s.shots || []).length} لقطة` }),
            el('span', { class: 'dim', text: `· 🖼 ${(s.photos || []).length} صورة` }),
            el('div', { class: 'grow' }),
            ph ? el('div', { html: avatarHTML(ph, 'sm') }) : null,
          ]),
        ]),
      ]));
    });
    area.appendChild(grid);
  }
  draw();
}

function openShootModal(s, onDone) {
  const doc = Object.assign({ title: '', clientId: (state.clients[0] || {}).id || '', projectId: '', photographer: state.user.id, date: '', location: '', status: 'planned', notes: '', shots: [], photos: [] }, s ? JSON.parse(JSON.stringify(s)) : {});
  const m = modal({
    title: s ? 'تعديل الجلسة' : 'جلسة تصوير جديدة',
    size: 'wide',
    body: [
      el('div', { class: 'field' }, [el('label', { text: 'اسم الجلسة *' }), el('input', { class: 'input', value: doc.title, oninput: (e) => doc.title = e.target.value })]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: t('client') }), el('select', { class: 'select', html: (state.clients || []).map((c) => `<option value="${c.id}" ${c.id === doc.clientId ? 'selected' : ''}>${escapeHTML(c.name)}</option>`).join(''), onchange: (e) => doc.clientId = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'المصور' }), el('select', { class: 'select', html: (state.users || []).filter((u) => u.role !== 'client').map((u) => `<option value="${u.id}" ${u.id === doc.photographer ? 'selected' : ''}>${escapeHTML(u.name)}</option>`).join(''), onchange: (e) => doc.photographer = e.target.value })]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'التاريخ' }), el('input', { class: 'input', type: 'date', value: doc.date || '', oninput: (e) => doc.date = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'المكان' }), el('input', { class: 'input', value: doc.location || '', oninput: (e) => doc.location = e.target.value })]),
      ]),
      el('div', { class: 'field' }, [el('label', { text: 'الحالة' }), el('select', { class: 'select', html: Object.entries(SSTATUS).map(([k, v]) => `<option value="${k}" ${k === doc.status ? 'selected' : ''}>${v[0]}</option>`).join(''), onchange: (e) => doc.status = e.target.value })]),
      (() => { const ta = el('textarea', { class: 'textarea', rows: 2, oninput: (e) => doc.notes = e.target.value }); ta.value = doc.notes || ''; return el('div', { class: 'field' }, [el('label', { text: 'ملاحظات' }), ta]); })(),
    ],
    footer: [
      s ? el('button', { class: 'btn danger ghost', text: t('delete'), onclick: async () => { if (await confirmDialog('حذف الجلسة؟', { danger: true })) { await remove('shoots', doc.id); m.close(); onDone(); } } }) : null,
      el('div', { class: 'grow' }),
      el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: t('save'),
        onclick: async () => {
          if (!doc.title.trim()) { toast(t('required'), 'warn'); return; }
          await save('shoots', doc);
          m.close(); toast(t('saved'), 'ok'); onDone();
        },
      }),
    ],
  });
}

function openShoot(id, onDone) {
  const s = (state.shoots || []).find((x) => x.id === id);
  if (!s) return;
  const client = clientById(s.clientId);

  const shotsBox = el('div', { class: 'col', style: { gap: '7px' } });
  function drawShots() {
    clear(shotsBox);
    (s.shots || []).forEach((sh) => {
      const [pcl, plb] = PRIO[sh.priority] || ['', ''];
      shotsBox.appendChild(el('div', { class: 'ph-shot' + (sh.done ? ' done' : '') }, [
        el('input', {
          type: 'checkbox', checked: !!sh.done,
          onchange: async (e) => { sh.done = e.target.checked; await save('shoots', s); drawShots(); onDone && onDone(); },
        }),
        el('div', { class: 'grow' }, [
          el('div', { style: { fontWeight: '700', fontSize: '13.5px' }, text: sh.desc }),
          el('div', { class: 'row wrap', style: { gap: '6px', marginTop: '3px' } }, [
            el('span', { class: 'badge', text: sh.type || '' }),
            sh.framing ? el('span', { class: 'badge', text: sh.framing }) : null,
            el('span', { class: 'badge ' + pcl, text: plb }),
          ]),
        ]),
        el('button', { class: 'btn ghost icon sm', html: icon('trash'), onclick: async () => { s.shots = s.shots.filter((x) => x.id !== sh.id); await save('shoots', s); drawShots(); } }),
      ]));
    });
    if (!(s.shots || []).length) shotsBox.appendChild(el('div', { class: 'dim', style: { fontSize: '12.5px' }, text: 'لا لقطات في اللستة' }));
  }

  const addBtn = el('button', {
    class: 'btn sm', html: icon('plus') + `<span>لقطة</span>`,
    onclick: () => {
      const desc = el('input', { class: 'input', placeholder: 'وصف اللقطة…' });
      const type = el('input', { class: 'input', placeholder: 'النوع (منتج/بورتريه/…)' });
      const framing = el('input', { class: 'input', placeholder: 'التأطير (Close-up/Wide/…)' });
      const prio = el('select', { class: 'select', html: ['high', 'medium', 'low'].map((k) => `<option value="${k}">${PRIO[k][1]}</option>`).join('') });
      const m = modal({
        title: 'لقطة جديدة',
        body: [
          el('div', { class: 'field' }, [el('label', { text: 'الوصف *' }), desc]),
          el('div', { class: 'grid2' }, [
            el('div', { class: 'field' }, [el('label', { text: 'النوع' }), type]),
            el('div', { class: 'field' }, [el('label', { text: 'التأطير' }), framing]),
          ]),
          el('div', { class: 'field' }, [el('label', { text: 'الأولوية' }), prio]),
        ],
        footer: [
          el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
          el('button', {
            class: 'btn primary', text: t('add'),
            onclick: async () => {
              if (!desc.value.trim()) { toast(t('required'), 'warn'); return; }
              s.shots = s.shots || [];
              s.shots.push({ id: 'sh_' + Math.random().toString(36).slice(2, 7), desc: desc.value.trim(), type: type.value.trim(), framing: framing.value.trim(), priority: prio.value, done: false });
              await save('shoots', s);
              m.close(); drawShots();
            },
          }),
        ],
      });
    },
  });

  /* معرض الصور */
  const gallery = el('div', { class: 'ph-gallery' });
  function drawGallery() {
    clear(gallery);
    (s.photos || []).forEach((p) => {
      gallery.appendChild(el('div', { class: 'ph-photo' }, [
        el('img', { src: p.url, loading: 'lazy' }),
        el('button', { class: 'ph-x', text: '×', onclick: async () => { s.photos = s.photos.filter((x) => x.id !== p.id); await save('shoots', s); drawGallery(); } }),
      ]));
    });
    if (!(s.photos || []).length) gallery.appendChild(el('div', { class: 'dim', style: { fontSize: '12.5px' }, text: 'لسه مفيش صور مرفوعة' }));
  }
  const photoInput = el('input', {
    type: 'file', accept: 'image/*', multiple: true, style: { display: 'none' },
    onchange: async (e) => {
      for (const f of [...e.target.files]) {
        if (f.size > 15 * 1024 * 1024) { toast(f.name + ' أكبر من 15MB', 'err'); continue; }
        const up = await api.uploadFile(f.name, f);
        s.photos = s.photos || [];
        s.photos.push({ id: 'ph_' + Math.random().toString(36).slice(2, 7), url: up.url, name: f.name, at: new Date().toISOString() });
      }
      await save('shoots', s);
      drawGallery();
      toast('اترفعت الصور ✓', 'ok');
      e.target.value = '';
    },
  });

  const done = (s.shots || []).filter((x) => x.done).length;
  const m = modal({
    title: '📸 ' + s.title,
    size: 'wide',
    body: [
      el('div', { class: 'row wrap', style: { gap: '8px', marginBottom: '10px' } }, [
        el('span', { class: 'badge', text: client ? client.name : '—' }),
        el('span', { class: 'badge', text: '📅 ' + (s.date || '—') }),
        el('span', { class: 'badge', text: '📍 ' + (s.location || '—') }),
        el('span', { class: 'badge info', text: `${done}/${(s.shots || []).length} لقطة ✓` }),
      ]),
      s.notes ? el('div', { class: 'ct-note', style: { marginBottom: '10px' }, text: '📝 ' + s.notes }) : null,
      el('div', { class: 'row', style: { marginBottom: '8px' } }, [
        el('b', { class: 'grow', style: { fontSize: '14px' }, text: '🎯 Shot List' }),
        addBtn,
      ]),
      shotsBox,
      el('div', { class: 'row', style: { margin: '16px 0 8px' } }, [
        el('b', { class: 'grow', style: { fontSize: '14px' }, text: '🖼 لقطات الجلسة' }),
        el('button', { class: 'btn sm primary', html: icon('upload') + `<span>ارفع صور</span>`, onclick: () => photoInput.click() }),
        photoInput,
      ]),
      gallery,
    ],
    footer: [
      el('button', { class: 'btn ghost', text: 'تعديل البيانات', onclick: () => { m.close(); openShootModal(s, () => { onDone && onDone(); openShoot(s.id, onDone); }); } }),
      el('div', { class: 'grow' }),
      el('button', { class: 'btn ghost', text: 'إغلاق', onclick: () => { m.close(); onDone && onDone(); } }),
    ],
  });
  drawShots(); drawGallery();
}
