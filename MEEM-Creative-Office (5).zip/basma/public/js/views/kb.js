/* ============================================================
   MEEM | Creative Office — Phase 6: Knowledge
   تبويبان: مكتبة البرومبت + قاعدة المعرفة (مقالات)
   ============================================================ */
import { state, save, remove } from '../store.js';
import { el, icon, clear, escapeHTML, toast, modal, confirmDialog } from '../ui.js';

const PCATS = ['محتوى', 'تصميم', 'صوت', 'فيديو', 'تسويق'];
const ACATS = ['براند', 'سير العمل', 'تقني', 'أخرى'];
let kbTab = 'prompts'; // يتحمل إعادة التصيير بعد الحفظ

export function renderKB(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('template') + ' المعرفة', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'برومبتات جاهزة لكل الأقسام + قاعدة معرفة الفريق' }),
    ]),
  ]));
  const tabs = el('div', { class: 'tabs' });
  const area = el('div');
  host.append(tabs, area);
  tabs.append(...[['prompts', '✨ مكتبة البرومبت'], ['articles', '📚 قاعدة المعرفة']].map(([k, lb]) => el('button', {
    class: k === kbTab ? 'active' : '', text: lb,
    onclick: (e) => { kbTab = k; tabs.querySelectorAll('button').forEach((b) => b.classList.remove('active')); e.currentTarget.classList.add('active'); draw(); },
  })));

  function draw() {
    clear(area);
    if (kbTab === 'prompts') drawPrompts(area, draw);
    else drawArticles(area, draw);
  }
  draw();
}

/* ---------------- البرومبت ---------------- */
function drawPrompts(area, onDone) {
  let q = '';
  let cat = '';
  const search = el('input', { class: 'input', style: { maxWidth: '320px' }, placeholder: '🔍 دور في البرومبتات…', oninput: (e) => { q = e.target.value.trim(); list(); } });
  const chips = el('div', { class: 'row wrap', style: { gap: '6px' } });
  const grid = el('div', { class: 'col', style: { gap: '9px' } });
  area.append(
    el('div', { class: 'row wrap', style: { gap: '10px', marginBottom: '10px' } }, [
      search, chips, el('div', { class: 'grow' }),
      el('button', { class: 'btn primary', html: icon('plus') + `<span>برومبت جديد</span>`, onclick: () => openPromptModal(null, onDone) }),
    ]),
    grid,
  );
  function chipsDraw() {
    clear(chips);
    ['', ...PCATS].forEach((c) => chips.appendChild(el('button', {
      class: 'btn sm ' + (cat === c ? 'primary' : 'ghost'), text: c || 'الكل',
      onclick: () => { cat = c; chipsDraw(); list(); },
    })));
  }
  function list() {
    clear(grid);
    const items = (state.prompts || []).filter((p) =>
      (!cat || p.category === cat) &&
      (!q || (p.title + ' ' + (p.body || '')).toLowerCase().includes(q.toLowerCase())));
    if (!items.length) { grid.appendChild(el('div', { class: 'empty card', style: { padding: '30px' }, text: 'مفيش برومبتات مطابقة' })); return; }
    items.forEach((p) => {
      grid.appendChild(el('div', { class: 'card kb-card', style: { padding: '13px 15px' } }, [
        el('div', { class: 'row', style: { gap: '8px', marginBottom: '6px' } }, [
          el('span', { class: 'badge', text: p.category || '' }),
          el('b', { class: 'grow', style: { fontSize: '14px' }, text: p.title }),
          el('button', { class: 'btn sm ghost', html: icon('copy') + `<span>نسخ</span>`, onclick: async () => { try { await navigator.clipboard.writeText(p.body || ''); toast('اتنسخ ✓', 'ok'); } catch (e) { toast('انسخه يدوي', 'info'); } } }),
          el('button', { class: 'btn sm ghost icon', html: icon('edit'), onclick: () => openPromptModal(p, onDone) }),
          el('button', { class: 'btn sm danger ghost icon', html: icon('trash'), onclick: async () => { if (await confirmDialog('حذف البرومبت؟')) { await remove('prompts', p.id); onDone(); } } }),
        ]),
        el('div', { class: 'kb-body dim', text: p.body || '' }),
      ]));
    });
  }
  chipsDraw();
  list();
}

function openPromptModal(p, onDone) {
  const isNew = !p;
  const doc = Object.assign({ title: '', category: 'محتوى', body: '', tags: [] }, p ? JSON.parse(JSON.stringify(p)) : {});
  const m = modal({
    title: isNew ? '✨ برومبت جديد' : '✨ ' + doc.title,
    size: 'wide',
    body: [
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'العنوان *' }), el('input', { class: 'input', value: doc.title, oninput: (e) => doc.title = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'القسم' }), el('select', { class: 'select', html: PCATS.map((c) => `<option ${c === doc.category ? 'selected' : ''}>${c}</option>`).join(''), onchange: (e) => doc.category = e.target.value })]),
      ]),
      (() => { const ta = el('textarea', { class: 'textarea', rows: 6, oninput: (e) => doc.body = e.target.value }); ta.value = doc.body || ''; return el('div', { class: 'field' }, [el('label', { text: 'البرومبت * — استخدم {{متغير}} للأجزاء المتغيرة' }), ta]); })(),
    ],
    footer: [
      el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: 'حفظ',
        onclick: async () => {
          if (!doc.title.trim() || !doc.body.trim()) { toast('اكمل العنوان والبرومبت', 'warn'); return; }
          const saved = await save('prompts', doc);
          doc.id = saved.id;
          m.close(); toast('اتحفظ ✓', 'ok'); onDone();
        },
      }),
    ],
  });
}

/* ---------------- المقالات ---------------- */
function drawArticles(area, onDone) {
  let q = '';
  let cat = '';
  const search = el('input', { class: 'input', style: { maxWidth: '320px' }, placeholder: '🔍 دور في المقالات…', oninput: (e) => { q = e.target.value.trim(); list(); } });
  const chips = el('div', { class: 'row wrap', style: { gap: '6px' } });
  const grid = el('div', { class: 'col', style: { gap: '9px' } });
  area.append(
    el('div', { class: 'row wrap', style: { gap: '10px', marginBottom: '10px' } }, [
      search, chips, el('div', { class: 'grow' }),
      el('button', { class: 'btn primary', html: icon('plus') + `<span>مقال جديد</span>`, onclick: () => openArticleModal(null, onDone) }),
    ]),
    grid,
  );
  function chipsDraw() {
    clear(chips);
    ['', ...ACATS].forEach((c) => chips.appendChild(el('button', {
      class: 'btn sm ' + (cat === c ? 'primary' : 'ghost'), text: c || 'الكل',
      onclick: () => { cat = c; chipsDraw(); list(); },
    })));
  }
  function list() {
    clear(grid);
    const items = (state.articles || []).filter((a) =>
      (!cat || a.category === cat) &&
      (!q || (a.title + ' ' + (a.body || '')).toLowerCase().includes(q.toLowerCase())));
    if (!items.length) { grid.appendChild(el('div', { class: 'empty card', style: { padding: '30px' }, text: 'مفيش مقالات مطابقة' })); return; }
    items.forEach((a) => {
      grid.appendChild(el('div', { class: 'card row', style: { padding: '13px 15px', gap: '10px', cursor: 'pointer' }, onclick: () => openArticleModal(a, onDone) }, [
        el('div', { style: { width: '38px', height: '38px', borderRadius: '10px', background: 'rgba(96,165,250,.12)', color: '#60a5fa', display: 'grid', placeItems: 'center', fontSize: '17px' }, text: '📄' }),
        el('div', { class: 'grow' }, [
          el('div', { style: { fontWeight: '800', fontSize: '14px' }, text: a.title }),
          el('div', { class: 'dim', style: { fontSize: '12px', marginTop: '2px' }, text: (a.body || '').slice(0, 90) + '…' }),
        ]),
        el('span', { class: 'badge', text: a.category || '' }),
      ]));
    });
  }
  chipsDraw();
  list();
}

function openArticleModal(a, onDone) {
  const isNew = !a;
  const doc = Object.assign({ title: '', category: 'سير العمل', body: '', tags: [] }, a ? JSON.parse(JSON.stringify(a)) : {});
  const m = modal({
    title: isNew ? '📄 مقال جديد' : '📄 ' + doc.title,
    size: 'wide',
    body: [
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'العنوان *' }), el('input', { class: 'input', value: doc.title, oninput: (e) => doc.title = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'القسم' }), el('select', { class: 'select', html: ACATS.map((c) => `<option ${c === doc.category ? 'selected' : ''}>${c}</option>`).join(''), onchange: (e) => doc.category = e.target.value })]),
      ]),
      (() => { const ta = el('textarea', { class: 'textarea', rows: 8, oninput: (e) => doc.body = e.target.value }); ta.value = doc.body || ''; return el('div', { class: 'field' }, [el('label', { text: 'المحتوى *' }), ta]); })(),
    ],
    footer: [
      !isNew ? el('button', { class: 'btn danger ghost', text: 'حذف', onclick: async () => { if (await confirmDialog('حذف المقال؟', { danger: true })) { await remove('articles', doc.id); m.close(); onDone(); } } }) : null,
      el('div', { class: 'grow' }),
      el('button', { class: 'btn ghost', text: 'إغلاق', onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: 'حفظ',
        onclick: async () => {
          if (!doc.title.trim() || !doc.body.trim()) { toast('اكمل العنوان والمحتوى', 'warn'); return; }
          const saved = await save('articles', doc);
          doc.id = saved.id;
          m.close(); toast('اتحفظ ✓', 'ok'); onDone();
        },
      }),
    ],
  });
}
