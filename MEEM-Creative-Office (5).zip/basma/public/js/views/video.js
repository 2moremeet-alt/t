/* ============================================================
   MEEM | Creative Office — Phase 5: Video Studio
   Media bin + Timeline (ترتيب/قص/نص) + Preview على Canvas + تصدير WebM
   ============================================================ */
import { t } from '../i18n.js';
import { state, save, remove, userById, clientById } from '../store.js';
import { el, icon, clear, avatarHTML, timeAgo, escapeHTML, toast, modal, confirmDialog } from '../ui.js';
import { api } from '../api.js';

const VSTATUS = {
  draft: ['مسودة', ''],
  review: ['في المراجعة', 'warn'],
  approved: ['معتمد', 'ok'],
  changes: ['تعديلات مطلوبة', 'danger'],
};
const PRESETS = [['1080', '1920', 'ستوري 9:16'], ['1080', '1080', 'بوست 1:1'], ['1920', '1080', 'عريض 16:9']];

export function renderVideo(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('code') + ' استوديو الفيديو', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'ارفع كليبات، رتبهم على التايم لاين، قصّ وضيف نص — وصدّر فيديو WebM حقيقي' }),
    ]),
    el('button', { class: 'btn primary', html: icon('plus') + `<span>مشروع مونتاج جديد</span>`, onclick: () => openVideoEditor(null, () => draw()) }),
  ]));
  const area = el('div');
  host.appendChild(area);
  function draw() {
    clear(area);
    const list = state.videos || [];
    const grid = el('div', { class: 'col', style: { gap: '9px' } });
    if (!list.length) grid.appendChild(el('div', { class: 'empty card', style: { padding: '40px' }, text: 'لا مشاريع مونتاج — ابدأ واحد جديد 🎬' }));
    [...list].sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || '')).forEach((v) => {
      const [lb, cl] = VSTATUS[v.status] || ['', ''];
      const dur = (v.clips || []).reduce((s, c) => s + (c.kind === 'image' ? (c.dur || 3) : (c.trimOut || 0) - (c.trimIn || 0)), 0);
      grid.appendChild(el('div', { class: 'card row wrap', style: { padding: '13px 15px', gap: '10px', cursor: 'pointer' }, onclick: () => openVideoEditor(v.id, draw) }, [
        el('div', { style: { width: '38px', height: '38px', borderRadius: '10px', background: 'rgba(244,63,94,.12)', color: '#fb7185', display: 'grid', placeItems: 'center', fontSize: '17px' }, text: '🎬' }),
        el('div', { class: 'grow', style: { minWidth: '200px' } }, [
          el('div', { style: { fontWeight: '800', fontSize: '14.5px' }, text: v.title }),
          el('div', { class: 'dim', style: { fontSize: '12px' }, text: `${(v.clips || []).length} كليبات · ${Math.round(dur)} ثانية · ${v.w}×${v.h} · ${timeAgo(v.updatedAt || v.createdAt)}` }),
        ]),
        v.exportUrl ? el('span', { class: 'badge ok', text: '🎞 مُصدَّر' }) : null,
        el('span', { class: 'badge ' + cl, text: lb }),
      ]));
    });
    area.appendChild(grid);
  }
  draw();
}

/* ================= المحرر ================= */
export async function openVideoEditor(id, onDone) {
  let doc = {
    id: null, title: '', projectId: '', clientId: '', w: 1080, h: 1920, fps: 30,
    media: [], clips: [], audioId: null, audioTrimIn: 0,
    status: 'draft', owner: state.user.id, comments: [], review: null, exportUrl: null,
  };
  if (id) {
    const local = (state.videos || []).find((x) => x.id === id);
    doc = Object.assign(doc, JSON.parse(JSON.stringify(local || {})));
  }

  const overlay = el('div', { class: 'studio' });
  document.body.appendChild(overlay);
  const close = () => { player.stop(); overlay.remove(); onDone && onDone(); };
  let dirty = false, selIdx = -1;

  const titleInput = el('input', { class: 'input ct-title', placeholder: 'اسم المشروع…', value: doc.title, oninput: (e) => { doc.title = e.target.value; dirty = true; } });
  const statusPill = el('span', { class: 'badge' });
  function updateStatus() {
    const [lb, cl] = VSTATUS[doc.status] || ['', ''];
    statusPill.className = 'badge ' + cl;
    statusPill.textContent = lb;
  }
  async function doSave(silent) {
    if (!doc.title.trim()) doc.title = 'مونتاج — ' + new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    const saved = await save('videos', doc);
    doc.id = saved.id;
    dirty = false;
    if (!silent) toast('اتحفظ ✓', 'ok');
  }

  /* ---------- عناصر العرض ---------- */
  const canvas = el('canvas', { class: 'vd-canvas' });
  const vel = document.createElement('video');
  vel.playsInline = true; vel.preload = 'auto'; vel.style.display = 'none';
  const ael = document.createElement('audio');
  ael.style.display = 'none';
  overlay.append(vel, ael);
  const imgs = new Map();
  function getImg(url) {
    if (!imgs.has(url)) { const im = new Image(); im.src = url; imgs.set(url, im); }
    return imgs.get(url);
  }

  /* ---------- محرك التتابع ---------- */
  const player = (() => {
    let playing = false, t0 = 0, startAt = 0, raf = 0;
    const clipTimes = () => {
      const out = []; let acc = 0;
      (doc.clips || []).forEach((c, i) => {
        const d = c.kind === 'image' ? (c.dur || 3) : Math.max(0.1, (c.trimOut || 0) - (c.trimIn || 0));
        out.push({ c, i, start: acc, end: acc + d, d });
        acc += d;
      });
      return { segs: out, total: acc };
    };
    function drawFrame(cv, tt) {
      const g = cv.getContext('2d');
      g.fillStyle = '#000';
      g.fillRect(0, 0, cv.width, cv.height);
      const { segs, total } = clipTimes();
      const seg = segs.find((s) => tt >= s.start && tt < s.end);
      if (seg) {
        const c = seg.c;
        if (c.kind === 'video') {
          if (vel.readyState >= 2) drawCover(g, vel, cv);
        } else {
          const im = getImg(mediaById(c.mediaId)?.url || '');
          if (im.complete && im.naturalWidth) drawCover(g, im, cv);
        }
        if (c.text) drawText(g, cv, c);
      } else if (total > 0 && tt >= total) {
        // النهاية
      }
      return { segs, total, seg };
    }
    function drawCover(g, src, cv) {
      const sw = src.videoWidth || src.naturalWidth, sh = src.videoHeight || src.naturalHeight;
      if (!sw) return;
      const r = Math.max(cv.width / sw, cv.height / sh);
      const w = sw * r, h = sh * r;
      g.drawImage(src, (cv.width - w) / 2, (cv.height - h) / 2, w, h);
    }
    function drawText(g, cv, c) {
      const size = (c.textSize || 42) * (cv.width / 1080);
      g.font = `800 ${size}px Cairo, sans-serif`;
      g.textAlign = 'center';
      g.fillStyle = c.textColor || '#ffffff';
      g.shadowColor = 'rgba(0,0,0,.7)';
      g.shadowBlur = size * 0.25;
      const y = c.textPos === 'top' ? cv.height * 0.14 : c.textPos === 'middle' ? cv.height * 0.5 : cv.height * 0.86;
      const lines = String(c.text).split('\n');
      lines.forEach((ln, i) => g.fillText(ln, cv.width / 2, y + i * size * 1.25));
      g.shadowBlur = 0;
    }
    function tick() {
      const tt = (performance.now() - startAt) / 1000 + t0;
      const { segs, total, seg } = drawFrame(canvas, tt);
      // بدّل مصدر الفيديو حسب الكليب النشط
      if (seg && seg.c.kind === 'video') {
        const m = mediaById(seg.c.mediaId);
        if (m && vel.src !== location.origin + m.url && !vel.src.endsWith(m.url)) { vel.src = m.url; vel.play().catch(() => {}); }
        const local = seg.c.trimIn + (tt - seg.start);
        if (Math.abs(vel.currentTime - local) > 0.35) vel.currentTime = local;
      }
      updatePlayhead(tt, total);
      if (tt >= total) { stop(); return; }
      raf = requestAnimationFrame(tick);
    }
    function play() {
      const { total } = clipTimes();
      if (!total) { toast('ضيف كليبات الأول', 'warn'); return; }
      playing = true;
      startAt = performance.now();
      playBtn.innerHTML = '⏸';
      // صوت خلفي
      const am = doc.audioId ? mediaById(doc.audioId) : null;
      if (am) { ael.src = am.url; ael.currentTime = doc.audioTrimIn || 0; ael.play().catch(() => {}); }
      raf = requestAnimationFrame(tick);
    }
    function stop() {
      playing = false;
      cancelAnimationFrame(raf);
      vel.pause(); ael.pause();
      playBtn.innerHTML = '▶';
    }
    return {
      play, stop, drawFrame, clipTimes,
      get playing() { return playing; },
      seek(tt) { t0 = tt; startAt = performance.now(); drawFrame(canvas, tt); },
    };
  })();

  const playBtn = el('button', { class: 'btn sm primary', html: '▶', style: { width: '40px' } });
  playBtn.onclick = () => { player.playing ? player.stop() : player.play(); };
  const timeLbl = el('span', { class: 'num dim', style: { fontSize: '12px' }, text: '0:00 / 0:00' });
  const playheadBar = el('div', { class: 'vd-playbar' });
  const playhead = el('i');
  playheadBar.appendChild(playhead);
  playheadBar.onclick = (e) => {
    const r = playheadBar.getBoundingClientRect();
    const { total } = player.clipTimes();
    player.seek(Math.max(0, Math.min(total, ((e.clientX - r.left) / r.width) * total)));
  };
  function updatePlayhead(tt, total) {
    playhead.style.right = (total ? (tt / total) * 100 : 0) + '%';
    const f = (s) => Math.floor(s / 60) + ':' + String(Math.floor(s % 60)).padStart(2, '0');
    timeLbl.textContent = f(tt) + ' / ' + f(total);
  }

  function mediaById(mid) { return (doc.media || []).find((m) => m.id === mid); }
  const clipDur = (c) => c.kind === 'image' ? (c.dur || 3) : Math.max(0.1, (c.trimOut || 0) - (c.trimIn || 0));

  /* ---------- Media bin ---------- */
  const bin = el('div', { class: 'vd-bin' });
  function drawBin() {
    clear(bin);
    if (!(doc.media || []).length) bin.appendChild(el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'ارفع فيديوهات/صور/صوت — هتظهر هنا' }));
    (doc.media || []).forEach((m) => {
      bin.appendChild(el('div', { class: 'vd-media' }, [
        el('span', { text: { video: '🎞', image: '🖼', audio: '🎵' }[m.kind] || '📄' }),
        el('div', { class: 'grow', style: { minWidth: 0 } }, [
          el('div', { style: { fontSize: '12px', fontWeight: '700', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }, text: m.name }),
          el('div', { class: 'dim', style: { fontSize: '10.5px' }, text: m.kind === 'audio' ? 'صوت' : (m.dur ? Math.round(m.dur) + ' ث' : '') }),
        ]),
        m.kind !== 'audio' ? el('button', {
          class: 'btn ghost sm', text: '+ تايم لاين',
          onclick: () => {
            const clip = { id: 'cl_' + Math.random().toString(36).slice(2, 8), mediaId: m.id, kind: m.kind, trimIn: 0, trimOut: m.kind === 'video' ? (m.dur || 5) : 0, dur: 3, text: '', textSize: 42, textColor: '#ffffff', textPos: 'bottom' };
            doc.clips.push(clip);
            selIdx = doc.clips.length - 1;
            dirty = true; drawTimeline(); drawInspector(); player.drawFrame(canvas, 0);
          },
        }) : el('button', {
          class: 'btn ghost sm', text: doc.audioId === m.id ? '✓ الصوت الخلفي' : 'صوت خلفي',
          onclick: () => { doc.audioId = doc.audioId === m.id ? null : m.id; dirty = true; drawBin(); },
        }),
      ]));
    });
  }

  const fileInput = el('input', {
    type: 'file', accept: 'video/*,image/*,audio/*', multiple: true, style: { display: 'none' },
    onchange: async (e) => {
      for (const f of [...e.target.files]) {
        if (f.size > 20 * 1024 * 1024) { toast(`${f.name} أكبر من 20MB — مش هيرفع`, 'err'); continue; }
        toast('جارٍ رفع ' + f.name + '…', 'info', 2000);
        try {
          const up = await api.uploadFile(f.name, f);
          const kind = f.type.startsWith('video') ? 'video' : f.type.startsWith('image') ? 'image' : 'audio';
          const m = { id: 'md_' + Math.random().toString(36).slice(2, 8), url: up.url, kind, name: f.name, dur: 0 };
          if (kind !== 'image') {
            await new Promise((resolve) => {
              const probe = kind === 'video' ? document.createElement('video') : document.createElement('audio');
              probe.preload = 'metadata';
              probe.onloadedmetadata = () => { m.dur = probe.duration; resolve(); };
              probe.onerror = resolve;
              probe.src = up.url;
            });
          }
          doc.media.push(m);
          dirty = true; drawBin();
        } catch (err) { toast('رفع فشل: ' + err.message, 'err'); }
      }
      e.target.value = '';
    },
  });

  /* ---------- Timeline ---------- */
  const track = el('div', { class: 'vd-track' });
  function drawTimeline() {
    clear(track);
    if (!(doc.clips || []).length) track.appendChild(el('div', { class: 'dim', style: { fontSize: '12px', padding: '12px' }, text: 'التايم لاين فاضي — ضيف كليبات من المكتبة ↑' }));
    const total = (doc.clips || []).reduce((s, c) => s + clipDur(c), 0) || 1;
    (doc.clips || []).forEach((c, i) => {
      const m = mediaById(c.mediaId);
      const block = el('button', {
        class: 'vd-clip' + (i === selIdx ? ' sel' : ''),
        style: { flexGrow: String(clipDur(c)) },
        onclick: () => { selIdx = i; drawTimeline(); drawInspector(); },
      }, [
        el('span', { text: ({ video: '🎞', image: '🖼' }[c.kind] || '') }),
        el('span', { class: 'vd-clip-name', text: (m ? m.name : '?').slice(0, 14) }),
        el('span', { class: 'num', style: { fontSize: '10px' }, text: Math.round(clipDur(c)) + 'ث' }),
      ]);
      track.appendChild(block);
    });
    // تحديث شريط التشغيل
    updatePlayhead(player.playing ? 0 : parseFloat(playhead.style.right) / 100 * total, total);
  }

  /* ---------- Inspector ---------- */
  const inspector = el('div', { class: 'vd-inspector' });
  function drawInspector() {
    clear(inspector);
    const c = doc.clips[selIdx];
    if (!c) { inspector.appendChild(el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'اختار كليب من التايم لاين للقص والنص' })); return; }
    const m = mediaById(c.mediaId);
    inspector.appendChild(el('b', { style: { fontSize: '13px' }, text: (m ? m.name : 'كليب') }));

    if (c.kind === 'video' && m && m.dur) {
      const a = el('input', { type: 'range', min: 0, max: 100, value: Math.round((c.trimIn / m.dur) * 100) });
      const b = el('input', { type: 'range', min: 0, max: 100, value: Math.round((c.trimOut / m.dur) * 100) });
      const lbl = el('div', { class: 'dim num', style: { fontSize: '11px' }, text: `${c.trimIn.toFixed(1)}ث → ${c.trimOut.toFixed(1)}ث` });
      const sync = () => {
        c.trimIn = Math.min(+a.value, +b.value - 2) / 100 * m.dur;
        c.trimOut = Math.max(+b.value, +a.value + 2) / 100 * m.dur;
        lbl.textContent = `${c.trimIn.toFixed(1)}ث → ${c.trimOut.toFixed(1)}ث`;
        dirty = true; drawTimeline();
      };
      a.oninput = sync; b.oninput = sync;
      inspector.append(
        el('label', { class: 'vd-lbl' }, [el('span', { text: '✂️ بداية القص' }), a]),
        el('label', { class: 'vd-lbl' }, [el('span', { text: '✂️ نهاية القص' }), b]),
        lbl,
      );
    }
    if (c.kind === 'image') {
      const dIn = el('input', { class: 'input', type: 'number', min: 1, max: 30, value: c.dur || 3, style: { width: '80px' }, oninput: (e) => { c.dur = Math.max(1, +e.target.value || 3); dirty = true; drawTimeline(); } });
      inspector.append(el('label', { class: 'vd-lbl' }, [el('span', { text: '⏱ مدة الظهور (ث)' }), dIn]));
    }

    const txt = el('input', { class: 'input', value: c.text || '', placeholder: 'نص على الكليب…', oninput: (e) => { c.text = e.target.value; dirty = true; } });
    const sizeIn = el('input', { type: 'range', min: 20, max: 110, value: c.textSize || 42, oninput: (e) => { c.textSize = +e.target.value; dirty = true; } });
    const colIn = el('input', { type: 'color', value: c.textColor || '#ffffff', oninput: (e) => { c.textColor = e.target.value; dirty = true; } });
    const posSel = el('select', { class: 'select', style: { width: 'auto' }, html: [['top', 'فوق'], ['middle', 'وسط'], ['bottom', 'تحت']].map(([k, v]) => `<option value="${k}" ${(c.textPos || 'bottom') === k ? 'selected' : ''}>${v}</option>`).join(''), onchange: (e) => { c.textPos = e.target.value; dirty = true; } });
    inspector.append(
      el('div', { class: 'vd-sep' }),
      el('label', { class: 'vd-lbl' }, [el('span', { text: '📝 نص Overlay' }), txt]),
      el('label', { class: 'vd-lbl' }, [el('span', { text: 'حجم' }), sizeIn, colIn, posSel]),
    );

    inspector.append(
      el('div', { class: 'vd-sep' }),
      el('div', { class: 'row', style: { gap: '6px' } }, [
        el('button', { class: 'btn ghost sm', text: '◀ قدّم', onclick: () => move(-1) }),
        el('button', { class: 'btn ghost sm', text: '▶ أخّر', onclick: () => move(1) }),
        el('button', {
          class: 'btn danger ghost sm', html: icon('trash'),
          onclick: () => { doc.clips.splice(selIdx, 1); selIdx = -1; dirty = true; drawTimeline(); drawInspector(); },
        }),
      ]),
    );
    function move(dir) {
      const j = selIdx + dir;
      if (j < 0 || j >= doc.clips.length) return;
      [doc.clips[selIdx], doc.clips[j]] = [doc.clips[j], doc.clips[selIdx]];
      selIdx = j; dirty = true; drawTimeline(); drawInspector();
    }
  }

  /* ---------- مراجعة وتعليقات ---------- */
  const side = el('div', { class: 'col', style: { gap: '12px' } });
  function drawSide() {
    clear(side);
    const isOwner = doc.owner === state.user.id;
    const canDecide = doc.status === 'review' && (!isOwner || state.user.role === 'admin');
    side.appendChild(el('div', { class: 'ct-panel' }, [
      el('div', { class: 'ct-panel-title', text: '🔍 المراجعة' }),
      doc.review && doc.review.decision ? el('div', { class: 'ct-note ' + (doc.review.decision === 'approve' ? 'ok' : 'danger'), text: (doc.review.decision === 'approve' ? '✅ اعتمده ' : '✏️ ') + (doc.review.decidedByName || '') + (doc.review.decision === 'changes' && doc.review.note ? ' — ' + doc.review.note : '') }) : null,
      canDecide ? el('div', { class: 'row', style: { gap: '7px', marginTop: '6px' } }, [
        el('button', { class: 'btn sm ok grow', html: icon('check') + `<span>اعتماد</span>`, onclick: () => decide('approve') }),
        el('button', { class: 'btn sm danger grow', html: icon('edit') + `<span>تعديل</span>`, onclick: () => decide('changes') }),
      ]) : null,
      doc.exportUrl ? el('a', { class: 'btn sm primary', style: { marginTop: '8px' }, href: doc.exportUrl, download: (doc.title || 'video') + '.webm', html: '🎞 تحميل النسخة المصدرة' }) : null,
    ]));
    const cmts = doc.comments || [];
    const addInput = el('input', { class: 'input', placeholder: 'تعليق…' });
    const list = el('div', { class: 'col', style: { gap: '6px' } });
    cmts.forEach((cm) => list.appendChild(el('div', { class: 'ct-cmt' + (cm.resolved ? ' resolved' : '') }, [
      el('b', { style: { fontSize: '12px' }, text: (cm.byName || '') + ' — ' }),
      el('span', { style: { fontSize: '12.5px' }, text: cm.text }),
    ])));
    if (!cmts.length) list.appendChild(el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'لا تعليقات' }));
    side.appendChild(el('div', { class: 'ct-panel' }, [
      el('div', { class: 'ct-panel-title', text: `💬 التعليقات (${cmts.length})` }),
      list,
      el('div', { class: 'row', style: { gap: '6px', marginTop: '8px' } }, [
        addInput,
        el('button', { class: 'btn sm primary', html: icon('send'), onclick: async () => { const t2 = addInput.value.trim(); if (!t2) return; const r = await api.docComment('videos', doc.id, { text: t2 }); doc.comments = r.comments; addInput.value = ''; drawSide(); } }),
      ]),
    ]));
  }
  async function decide(decision) {
    let note = '';
    if (decision === 'changes') {
      const inp = el('textarea', { class: 'textarea', placeholder: 'ملاحظاتك…' });
      const r = await new Promise((resolve) => {
        const m = modal({
          title: 'طلب تعديل', body: [inp],
          footer: [
            el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => { m.close(); resolve(null); } }),
            el('button', { class: 'btn danger', text: 'إرسال', onclick: () => { m.close(); resolve(inp.value.trim()); } }),
          ],
        });
      });
      if (r == null) return;
      note = r;
      if (!note) { toast('اكتب ملاحظات', 'warn'); return; }
    }
    const res = await api.docDecision('videos', doc.id, decision, note);
    Object.assign(doc, { status: res.doc.status, review: res.doc.review });
    updateStatus(); drawSide();
  }

  /* ---------- التصدير ---------- */
  async function exportWebM(btn) {
    const { total } = player.clipTimes();
    if (!total) { toast('مفيش كليبات', 'warn'); return; }
    player.stop();
    btn.disabled = true;
    const old = btn.innerHTML;
    const expCanvas = document.createElement('canvas');
    expCanvas.width = doc.w; expCanvas.height = doc.h;
    const stream = expCanvas.captureStream(doc.fps || 30);
    let rec;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      const actx = new AC();
      const dest = actx.createMediaStreamDestination();
      if (!vel.__src) vel.__src = actx.createMediaElementSource(vel);
      vel.__src.connect(dest); vel.__src.connect(actx.destination);
      if (!ael.__src) ael.__src = actx.createMediaElementSource(ael);
      ael.__src.connect(dest);
      dest.stream.getAudioTracks().forEach((tr) => stream.addTrack(tr));
      rec = new MediaRecorder(stream, { mimeType: MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus') ? 'video/webm;codecs=vp9,opus' : 'video/webm' });
    } catch (e) {
      rec = new MediaRecorder(stream);
    }
    const chunks = [];
    rec.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
    const done = new Promise((resolve) => { rec.onstop = resolve; });

    // شغّل التتابع على كانفس التصدير
    const am = doc.audioId ? mediaById(doc.audioId) : null;
    if (am) { ael.src = am.url; ael.currentTime = doc.audioTrimIn || 0; ael.play().catch(() => {}); }
    rec.start(500);
    const startedAt = performance.now();
    let raf2;
    await new Promise((resolve) => {
      const step = () => {
        const tt = (performance.now() - startedAt) / 1000;
        player.drawFrame(expCanvas, tt);
        player.drawFrame(canvas, tt);
        const { segs } = player.clipTimes();
        const seg = segs.find((s) => tt >= s.start && tt < s.end);
        if (seg && seg.c.kind === 'video') {
          const m = mediaById(seg.c.mediaId);
          if (m && !vel.src.endsWith(m.url)) { vel.src = m.url; vel.play().catch(() => {}); }
          const local = seg.c.trimIn + (tt - seg.start);
          if (Math.abs(vel.currentTime - local) > 0.35) vel.currentTime = local;
        }
        btn.innerHTML = `⏺ ${Math.min(100, Math.round((tt / total) * 100))}%`;
        if (tt >= total) { resolve(); return; }
        raf2 = requestAnimationFrame(step);
      };
      raf2 = requestAnimationFrame(step);
    });
    cancelAnimationFrame(raf2);
    vel.pause(); ael.pause();
    rec.stop();
    await done;
    const blob = new Blob(chunks, { type: 'video/webm' });
    btn.innerHTML = '📤 رفع…';
    try {
      const up = await api.uploadFile((doc.title || 'video') + '.webm', blob);
      doc.exportUrl = up.url;
      await doSave(true);
      toast('اتصدّر الفيديو ✓ (' + (blob.size / 1048576).toFixed(1) + 'MB)', 'ok', 4200);
      drawSide();
      // تحميل فوري كمان
      const a2 = document.createElement('a');
      a2.href = URL.createObjectURL(blob);
      a2.download = (doc.title || 'video') + '.webm';
      a2.click();
    } catch (e) { toast('رفع التصدير فشل: ' + e.message, 'err'); }
    btn.disabled = false;
    btn.innerHTML = old;
  }

  /* ---------- البناء ---------- */
  const presetSel = el('select', {
    class: 'select', style: { width: 'auto' },
    html: PRESETS.map(([w, h, lb]) => `<option value="${w}x${h}" ${+w === doc.w && +h === doc.h ? 'selected' : ''}>${lb} (${w}×${h})</option>`).join(''),
    onchange: (e) => { const [w, h] = e.target.value.split('x'); doc.w = +w; doc.h = +h; dirty = true; canvas.width = doc.w; canvas.height = doc.h; player.drawFrame(canvas, 0); },
  });

  overlay.append(
    el('div', { class: 'ct-top' }, [
      el('button', { class: 'btn ghost icon', html: icon('chevronRight'), onclick: async () => { if (dirty && !await confirmDialog('فيه تغييرات مش محفوظة — قفل؟')) return; close(); } }),
      titleInput, statusPill, presetSel,
      el('div', { class: 'grow' }),
      el('button', { class: 'btn sm', html: '💾<span>حفظ</span>', onclick: () => doSave(false) }),
      el('button', { class: 'btn sm ok', html: '🎬<span>تصدير WebM</span>', onclick: (e) => exportWebM(e.currentTarget) }),
      el('button', {
        class: 'btn sm primary', html: icon('send') + `<span>للمراجعة</span>`,
        onclick: async () => {
          if (!doc.clips.length) { toast('ضيف كليب واحد على الأقل', 'warn'); return; }
          await doSave(true);
          const res = await api.docSubmit('videos', doc.id, '');
          Object.assign(doc, { status: res.doc.status, review: res.doc.review });
          updateStatus(); drawSide();
          toast('اترسل للمراجعة ✓', 'ok');
        },
      }),
      id ? el('button', { class: 'btn ghost icon sm', html: icon('trash'), onclick: async () => { if (await confirmDialog('حذف المشروع؟', { danger: true })) { await remove('videos', doc.id); close(); } } }) : null,
    ]),
    el('div', { class: 'vd-main' }, [
      el('div', { class: 'vd-left' }, [
        el('div', { class: 'ct-panel' }, [
          el('div', { class: 'row', style: { marginBottom: '8px' } }, [
            el('div', { class: 'ct-panel-title grow', text: '📼 مكتبة الميديا' }),
            el('button', { class: 'btn sm primary', html: icon('upload') + `<span>رفع</span>`, onclick: () => fileInput.click() }),
            fileInput,
          ]),
          bin,
        ]),
        el('div', { class: 'ct-panel' }, [el('div', { class: 'ct-panel-title', text: '⚙️ الكليب المحدد' }), inspector]),
      ]),
      el('div', { class: 'vd-center' }, [
        el('div', { class: 'vd-preview' }, [canvas]),
        el('div', { class: 'row', style: { gap: '10px', margin: '10px 0' } }, [playBtn, timeLbl, el('div', { class: 'grow' })]),
        playheadBar,
        el('div', { class: 'ct-panel-title', style: { margin: '10px 0 6px' }, text: '🎞 التايم لاين' }),
        track,
      ]),
      side,
    ]),
  );

  canvas.width = doc.w; canvas.height = doc.h;
  updateStatus(); drawBin(); drawTimeline(); drawInspector(); drawSide();
  player.drawFrame(canvas, 0);
  if (doc.clips.length) selIdx = 0, drawTimeline(), drawInspector();
}
