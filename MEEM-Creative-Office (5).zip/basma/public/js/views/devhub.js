/* ============================================================
   MEEM | Creative Office — Phase 5: Dev Hub + Bug Tracker
   ============================================================ */
import { t } from '../i18n.js';
import { state, save, remove, userById, projectById } from '../store.js';
import { el, icon, clear, avatarHTML, timeAgo, escapeHTML, toast, modal, confirmDialog } from '../ui.js';

const BSTATUS = [
  ['new', 'جديد', 'info'],
  ['inprogress', 'شغالين عليه', 'warn'],
  ['testing', 'في الاختبار', ''],
  ['fixed', 'اتصلّح', 'ok'],
  ['closed', 'مقฟول', ''],
];
const SEV = {
  critical: ['danger', '🔥 حرجة'],
  high: ['warn', 'عالية'],
  medium: ['info', 'متوسطة'],
  low: ['', 'منخفضة'],
};
const bLabel = (k) => (BSTATUS.find((x) => x[0] === k) || [k, k])[1];

let devTab = 'bugs';

export function renderDevHub(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  // devTab على مستوى الموديول (يتحمل إعادة التصيير بعد الحفظ)

  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('code') + ' Dev Hub', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'باجات الفريق بـ severity وحالات — جنب بورد مهام البرمجة' }),
    ]),
    el('button', { class: 'btn primary', html: icon('plus') + `<span>الإبلاغ عن باج</span>`, onclick: () => openBugModal(null, draw) }),
  ]));

  const tabs = el('div', { class: 'tabs' });
  const area = el('div');
  tabs.append(...[['bugs', '🐞 الباجات'], ['tasks', '📋 المهام']].map(([k, lb]) => el('button', {
    class: k === devTab ? 'active' : '', text: lb,
    onclick: (e) => { devTab = k; tabs.querySelectorAll('button').forEach((b) => b.classList.remove('active')); e.currentTarget.classList.add('active'); draw(); },
  })));
  host.append(tabs, area);

  function draw() {
    clear(area);
    if (devTab === 'tasks') { import('./dept.js').then((m) => m.renderDept('dev', area)); return; }
    drawBugs(area, draw);
  }
  draw();
}

function drawBugs(host, onDone) {
  const list = state.bugs || [];
  const open = list.filter((b) => !['fixed', 'closed'].includes(b.status));
  const crit = open.filter((b) => b.severity === 'critical');
  host.appendChild(el('div', { class: 'kpis' }, [
    el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'مفتوح' }), el('div', { class: 'k-value num', text: String(open.length) })]),
    el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'حرجة 🔥' }), el('div', { class: 'k-value num', style: { color: 'var(--danger)' }, text: String(crit.length) })]),
    el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'اتصلّحت' }), el('div', { class: 'k-value num', style: { color: 'var(--ok)' }, text: String(list.filter((b) => b.status === 'fixed').length) })]),
    el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'مقفولة' }), el('div', { class: 'k-value num', text: String(list.filter((b) => b.status === 'closed').length) })]),
  ]));

  const cols = el('div', { class: 'bug-cols' });
  BSTATUS.forEach(([k, lb, cl]) => {
    const items = list.filter((b) => b.status === k);
    const col = el('div', { class: 'bug-col' }, [
      el('div', { class: 'bug-col-head' }, [
        el('span', { class: 'badge ' + cl, text: lb }),
        el('span', { class: 'dim num', style: { fontSize: '11px' }, text: String(items.length) }),
      ]),
    ]);
    items.forEach((b) => {
      const [scl, slb] = SEV[b.severity] || ['', ''];
      const asg = userById(b.assignee);
      col.appendChild(el('div', { class: 'bug-card', onclick: () => openBugModal(b, onDone) }, [
        el('div', { class: 'row', style: { gap: '6px', marginBottom: '4px' } }, [
          el('span', { class: 'badge ' + scl, style: { fontSize: '10px' }, text: slb }),
          el('div', { class: 'grow' }),
          el('span', { class: 'dim num', style: { fontSize: '10px' }, text: '#' + b.id.slice(-4) }),
        ]),
        el('div', { style: { fontWeight: '700', fontSize: '13px', marginBottom: '4px' }, text: b.title }),
        el('div', { class: 'row', style: { gap: '6px' } }, [
          asg ? el('div', { html: avatarHTML(asg, 'sm') }) : null,
          el('span', { class: 'dim', style: { fontSize: '10.5px' }, text: timeAgo(b.createdAt) }),
          (b.comments || []).length ? el('span', { class: 'dim', style: { fontSize: '10.5px' }, text: '💬' + b.comments.length }) : null,
        ]),
      ]));
    });
    cols.appendChild(col);
  });
  host.appendChild(cols);
}

function openBugModal(b, onDone) {
  const isNew = !b;
  const doc = Object.assign({
    title: '', desc: '', severity: 'medium', status: 'new',
    reporter: state.user.id, assignee: 'usr_dev', projectId: '', comments: [],
  }, b ? JSON.parse(JSON.stringify(b)) : {});

  const descTa = el('textarea', { class: 'textarea', rows: 3, placeholder: 'الباج بيحصل إزاي؟ خطوات الإعادة…' });
  descTa.value = doc.desc || '';

  const cmtBox = el('div', { class: 'col', style: { gap: '6px' } });
  function drawComments() {
    clear(cmtBox);
    (doc.comments || []).forEach((c) => cmtBox.appendChild(el('div', { class: 'ct-cmt' }, [
      el('b', { style: { fontSize: '11.5px' }, text: (c.byName || '') + ': ' }),
      el('span', { style: { fontSize: '12.5px' }, text: c.text }),
      el('span', { class: 'dim', style: { fontSize: '10px' }, text: ' · ' + timeAgo(c.at) }),
    ])));
  }
  drawComments();
  const cmtIn = el('input', { class: 'input', placeholder: 'تعليق…' });

  const m = modal({
    title: isNew ? '🐞 باج جديد' : '🐞 ' + doc.title,
    size: 'wide',
    body: [
      el('div', { class: 'field' }, [el('label', { text: 'العنوان *' }), el('input', { class: 'input', value: doc.title, oninput: (e) => doc.title = e.target.value })]),
      el('div', { class: 'field' }, [el('label', { text: 'الوصف' }), descTa]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'الخطورة' }), el('select', { class: 'select', html: Object.entries(SEV).map(([k, v]) => `<option value="${k}" ${k === doc.severity ? 'selected' : ''}>${v[1]}</option>`).join(''), onchange: (e) => doc.severity = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'الحالة' }), el('select', { class: 'select', html: BSTATUS.map(([k, lb]) => `<option value="${k}" ${k === doc.status ? 'selected' : ''}>${lb}</option>`).join(''), onchange: (e) => doc.status = e.target.value })]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'مسند لـ' }), el('select', { class: 'select', html: (state.users || []).filter((u) => u.role !== 'client').map((u) => `<option value="${u.id}" ${u.id === doc.assignee ? 'selected' : ''}>${escapeHTML(u.name)}</option>`).join(''), onchange: (e) => doc.assignee = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: t('project') }), el('select', { class: 'select', html: `<option value="">—</option>` + (state.projects || []).map((p) => `<option value="${p.id}" ${p.id === doc.projectId ? 'selected' : ''}>${escapeHTML(p.title)}</option>`).join(''), onchange: (e) => doc.projectId = e.target.value })]),
      ]),
      !isNew ? el('div', {}, [
        el('label', { text: '💬 التعليقات', style: { fontSize: '12.5px', fontWeight: '700', display: 'block', marginBottom: '6px' } }),
        cmtBox,
        el('div', { class: 'row', style: { gap: '6px', marginTop: '8px' } }, [
          cmtIn,
          el('button', {
            class: 'btn sm primary', html: icon('send'),
            onclick: async () => {
              const text = cmtIn.value.trim(); if (!text) return;
              doc.comments = doc.comments || [];
              doc.comments.push({ id: 'bc_' + Math.random().toString(36).slice(2, 7), text, by: state.user.id, byName: state.user.name, at: new Date().toISOString() });
              await save('bugs', doc);
              cmtIn.value = ''; drawComments();
            },
          }),
        ]),
      ]) : null,
    ],
    footer: [
      !isNew ? el('button', { class: 'btn danger ghost', text: t('delete'), onclick: async () => { if (await confirmDialog('حذف الباج؟', { danger: true })) { await remove('bugs', doc.id); m.close(); onDone(); } } }) : null,
      el('div', { class: 'grow' }),
      el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: t('save'),
        onclick: async () => {
          if (!doc.title.trim()) { toast(t('required'), 'warn'); return; }
          doc.desc = descTa.value;
          await save('bugs', doc);
          m.close(); toast(t('saved'), 'ok'); onDone();
        },
      }),
    ],
  });
}
