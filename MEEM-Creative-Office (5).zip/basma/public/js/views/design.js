/* ============================================================
   MEEM | Creative Office — قسم التصميم (أنواع + تصاميمي + البورد)
   ============================================================ */
import { t, getLang } from '../i18n.js';
import { state, save, userById, projectById, deptStats } from '../store.js';
import { el, icon, clear, avatarHTML, timeAgo, escapeHTML, toast, modal } from '../ui.js';
import { openTaskModal, openTaskDetails, DESIGN_SUBS } from '../taskform.js';
import { renderDept } from './dept.js';
import { TEMPLATES } from '../editor/templates.js';
import { PAGE_PRESETS } from '../editor/model.js';

const DESIGN_TYPES = [
  { key: 'سوشيال', icon: 'sparkles', desc: ['بوستات، ستوري، كاروسيل، إعلانات', 'Posts, stories, carousels, ads'] },
  { key: 'مطبوعات', icon: 'print', desc: ['فلاير، بروشور، منيو، كروت، رول أب', 'Flyers, brochures, menus, cards, roll-ups'] },
  { key: 'براندينج', icon: 'palette', desc: ['شعارات، هوية بصرية، قرطاسية', 'Logos, identity, stationery'] },
  { key: 'موشن', icon: 'video', desc: ['موشن جرافيك، أنيميشن، ريلز', 'Motion graphics, animation, reels'] },
  { key: 'تغليف', icon: 'box', desc: ['علب، أكياس، ليبلات', 'Boxes, bags, labels'] },
  { key: 'واجهات UI/UX', icon: 'code', desc: ['شاشات ويب وموبايل', 'Web & mobile screens'] },
  { key: 'رسم توضيحي', icon: 'design', desc: ['إليستريشن وأيقونات', 'Illustration & icons'] },
  { key: 'فيديو', icon: 'meet', desc: ['مونتاج وتحرير', 'Editing & post-production'] },
];

export function renderDesignDept(host, { param } = {}) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');

  const tabs = el('div', { class: 'tabs' }, [
    tabBtn('board', 'لوحة المهام', 'kanban'),
    tabBtn('types', t('designTypes'), 'shapes'),
    tabBtn('gallery', t('myDesigns'), 'layers'),
    tabBtn('templates', t('templates'), 'template'),
  ]);

  const area = el('div');
  host.append(
    el('div', { class: 'page-head' }, [
      el('div', {}, [
        el('h1', { html: icon('design') + ' ' + t('nav_design'), style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
        el('div', { class: 'ph-sub', text: 'كل أنواع التصميمات بفروعها — مع محرر تصميم كامل داخل المنصة' }),
      ]),
      el('button', {
        class: 'btn primary', html: icon('plus') + `<span>${t('newDesign')}</span>`,
        onclick: () => newSizeDialog(),
      }),
    ]),
    tabs,
    area,
  );

  function tabBtn(key, label, ic) {
    return el('button', {
      html: icon(ic) + `<span style="margin-inline-start:6px">${label}</span>`,
      style: { display: 'inline-flex', alignItems: 'center' },
      class: key === (param || 'board') ? 'active' : '',
      onclick: () => {
        location.hash = '#/design/' + key;
        tabs.querySelectorAll('button').forEach((b) => b.classList.remove('active'));
        renderTab(key);
      },
    });
  }

  function renderTab(key) {
    clear(area);
    tabs.querySelectorAll('button').forEach((b, i) => b.classList.toggle('active', ['board', 'types', 'gallery', 'templates'][i] === key));
    if (key === 'board') renderDept('design', area);
    else if (key === 'types') renderTypes(area);
    else if (key === 'gallery') renderGallery(area);
    else renderTemplates(area);
  }

  renderTab(param || 'board');
}

/* ---------------- أنواع التصميمات ---------------- */
function renderTypes(host) {
  const grid = el('div', { class: 'cards-grid' });
  DESIGN_TYPES.forEach((dt) => {
    const tasks = state.tasks.filter((x) => x.dept === 'design' && x.type === dt.key);
    const subs = DESIGN_SUBS[dt.key] || [];
    grid.appendChild(el('div', { class: 'card', style: { padding: '16px' } }, [
      el('div', { class: 'row', style: { marginBottom: '10px' } }, [
        el('div', { style: { width: '42px', height: '42px', borderRadius: '12px', background: 'var(--brand-soft)', color: 'var(--brand)', display: 'grid', placeItems: 'center' }, html: icon(dt.icon) }),
        el('div', { class: 'grow' }, [
          el('div', { style: { fontWeight: '800', fontSize: '15px' }, text: dt.key }),
          el('div', { class: 'dim', style: { fontSize: '11.5px' }, text: getLang() === 'ar' ? dt.desc[0] : dt.desc[1] }),
        ]),
        el('span', { class: 'badge num', text: String(tasks.length) }),
      ]),
      subs.length ? el('div', { class: 'row wrap', style: { gap: '5px', marginBottom: '11px' } },
        subs.slice(0, 5).map((s) => el('span', { class: 'badge', text: s.label.split(' ').slice(-2).join(' ') }))) : null,
      el('div', { class: 'row', style: { gap: '7px' } }, [
        el('button', {
          class: 'btn sm primary grow', html: icon('plus') + `<span>مهمة ${dt.key}</span>`,
          onclick: () => openTaskModal({ dept: 'design', type: dt.key }, () => renderDesignDept(document.querySelector('.view'))),
        }),
        el('button', {
          class: 'btn sm', html: icon('design') + `<span>تصميم</span>`,
          onclick: () => newSizeDialog(dt.key, subs[0]),
        }),
      ]),
    ]));
  });
  host.appendChild(el('div', { class: 'col' }, [
    el('p', { class: 'muted', text: 'كل نوع فيه فروعه ومقاساته الجاهزة — اختار النوع وابدأ التصميم فورًا.', style: { marginBottom: '4px' } }),
    grid,
  ]));
}

/* ---------------- تصاميمي ---------------- */
const DESIGN_STATUS = {
  progress: ['مسودة', ''],
  draft: ['مسودة', ''],
  review: ['في المراجعة', 'warn'],
  changes: ['تعديلات مطلوبة', 'danger'],
  approved: ['معتمد داخليًا', 'ok'],
  client: ['عند العميل', 'pink'],
  client_approved: ['اعتمده العميل', 'ok'],
};

function renderGallery(host) {
  const all = state.designs || [];
  let filter = 'all';

  if (!all.length) {
    host.appendChild(el('div', { class: 'empty card', style: { padding: '50px' } }, [
      el('div', { html: icon('layers'), style: { width: '54px', height: '54px', margin: '0 auto 12px', opacity: '.4' } }),
      el('div', { text: 'لسه مفيش تصاميم محفوظة' }),
      el('div', { class: 'dim', style: { fontSize: '13px', margin: '6px 0 14px' }, text: 'ابدأ من قالب جاهز أو من صفحة فاضية' }),
      el('button', { class: 'btn primary', html: icon('plus') + `<span>${t('newDesign')}</span>`, onclick: () => newSizeDialog() }),
    ]));
    return;
  }

  const counts = {
    all: all.length,
    review: all.filter((d) => d.status === 'review').length,
    changes: all.filter((d) => d.status === 'changes').length,
    approved: all.filter((d) => ['approved', 'client', 'client_approved'].includes(d.status)).length,
  };

  const seg = el('div', { class: 'seg brand', style: { marginBottom: '14px' } }, [
    ['all', `الكل (${counts.all})`],
    ['review', `مراجعة (${counts.review})`],
    ['changes', `تعديلات (${counts.changes})`],
    ['approved', `معتمدة (${counts.approved})`],
  ].map(([k, lab]) => el('button', {
    text: lab, class: k === filter ? 'active' : '',
    onclick: (e) => {
      filter = k;
      [...e.target.parentNode.children].forEach((b) => b.classList.remove('active'));
      e.target.classList.add('active');
      draw();
    },
  })));

  const grid = el('div', { class: 'cards-grid' });
  host.append(seg, grid);

  function draw() {
    clear(grid);
    const designs = all.filter((d) => filter === 'all'
      || (filter === 'approved' ? ['approved', 'client', 'client_approved'].includes(d.status) : d.status === filter));
    if (!designs.length) {
      grid.appendChild(el('div', { class: 'empty', style: { gridColumn: '1/-1', padding: '30px' }, text: 'مفيش تصاميم في التبويب ده' }));
      return;
    }
    designs.forEach((d) => {
      const owner = userById(d.owner);
      const [stLabel, stCls] = DESIGN_STATUS[d.status || 'progress'] || ['مسودة', ''];
      const unresolved = (d.comments || []).filter((c) => !c.resolved).length;
      const canReview = d.status === 'review' && state.user && (d.owner !== state.user.id || state.user.role === 'admin');
      grid.appendChild(el('div', {
        class: 'dcard',
        onclick: async () => { const { openEditor } = await import('../editor/index.js'); openEditor(d.id, { review: canReview }); },
      }, [
        el('div', { class: 'dc-thumb' }, d.thumb
          ? el('img', { src: d.thumb, alt: d.title })
          : el('div', { class: 'dim', html: icon('image') })),
        el('div', { class: 'dc-body' }, [
          el('div', { class: 'dc-title', text: d.title }),
          el('div', { class: 'dc-sub', text: `${d.w || '?'}×${d.h || '?'} · ${(d.layerCount != null ? d.layerCount : (d.layers || []).length)} ${t('ed_layersCount')}` }),
          el('div', { class: 'row wrap', style: { marginTop: '7px', gap: '5px' } }, [
            el('span', { class: 'badge ' + stCls, text: stLabel }),
            (d.versionCount || 0) > 0 ? el('span', { class: 'badge', text: `V${d.versionCount}` }) : null,
            unresolved ? el('span', { class: 'badge danger', text: `💬 ${unresolved}` }) : null,
          ]),
          el('div', { class: 'row', style: { marginTop: '8px', gap: '6px' } }, [
            el('div', { html: avatarHTML(owner, 'sm') }),
            el('span', { class: 'dim', style: { fontSize: '11.5px' }, text: timeAgo(d.updatedAt || d.createdAt) }),
            el('div', { class: 'grow' }),
            canReview ? el('button', {
              class: 'btn sm primary', text: 'مراجعة',
              onclick: async (e) => {
                e.stopPropagation();
                const { openEditor } = await import('../editor/index.js');
                openEditor(d.id, { review: true });
              },
            }) : null,
            el('button', {
              class: 'btn ghost icon sm', html: icon('trash'), title: t('delete'),
              onclick: async (e) => {
                e.stopPropagation();
                const { remove } = await import('../store.js');
                await remove('designs', d.id);
                toast('تم الحذف', 'ok');
                renderDesignDept(document.querySelector('.view'), { param: 'gallery' });
              },
            }),
          ]),
        ]),
      ]));
    });
  }
  draw();
}

/* ---------------- القوالب ---------------- */
function renderTemplates(host) {
  const wrap = el('div', { class: 'col' });

  // قوالب الفريق (من تصاميم حقيقية محفوظة)
  const team = (state.templates || []).filter((x) => x.custom);
  if (team.length) {
    wrap.appendChild(el('h3', { text: '⭐ قوالب الفريق', style: { fontSize: '15px', marginTop: '6px' } }));
    const grid = el('div', { class: 'cards-grid' });
    team.forEach((tpl) => {
      const card = el('div', { class: 'dcard' }, [
        el('div', { class: 'dc-thumb', style: { background: '#fff' } }),
        el('div', { class: 'dc-body' }, [
          el('div', { class: 'dc-title', text: tpl.name }),
          el('div', { class: 'dc-sub', text: `${tpl.w || '?'} × ${tpl.h || '?'}` }),
          el('button', {
            class: 'btn sm primary', style: { marginTop: '9px', width: '100%' },
            html: icon('design') + `<span>استخدم القالب</span>`,
            onclick: async () => {
              const { openEditor } = await import('../editor/index.js');
              const ed = openEditor(null, {});
              await new Promise((r) => setTimeout(r, 50));
              ed.doc.pages = JSON.parse(JSON.stringify(tpl.pages || []));
              ed.pageIndex = 0;
              ed.doc.title = tpl.name;
              ed.titleInput.value = tpl.name;
              ed.pushHistory(true);
              await ed.refresh(true);
            },
          }),
        ]),
      ]);
      grid.appendChild(card);
      const holder = card.querySelector('.dc-thumb');
      (async () => {
        try {
          const page = (tpl.pages || [])[0];
          if (!page) return;
          const { renderPage } = await import('../editor/render.js');
          const { ensureFonts } = await import('../editor/fonts.js');
          await ensureFonts(page.layers);
          const c = document.createElement('canvas');
          await renderPage(c, page, Math.min(1, 340 / Math.max(page.w, page.h)));
          c.style.width = '100%';
          c.style.height = '100%';
          c.style.objectFit = 'cover';
          holder.appendChild(c);
        } catch (e) { /* ignore */ }
      })();
    });
    wrap.appendChild(grid);
  }

  const cats = [...new Set(TEMPLATES.map((x) => x.cat))];
  cats.forEach((cat) => {
    wrap.appendChild(el('h3', { text: cat, style: { fontSize: '15px', marginTop: '6px' } }));
    const grid = el('div', { class: 'cards-grid' });
    TEMPLATES.filter((x) => x.cat === cat).forEach((tpl) => {
      const card = el('div', { class: 'dcard' }, [
        el('div', { class: 'dc-thumb', style: { background: '#fff' } }),
        el('div', { class: 'dc-body' }, [
          el('div', { class: 'dc-title', text: tpl.name }),
          el('div', { class: 'dc-sub', text: `${tpl.w} × ${tpl.h}` }),
          el('button', {
            class: 'btn sm primary', style: { marginTop: '9px', width: '100%' },
            html: icon('design') + `<span>استخدم القالب</span>`,
            onclick: async () => {
              const { openEditor } = await import('../editor/index.js');
              const ed = openEditor(null, {});
              await new Promise((r) => setTimeout(r, 50));
              ed.doc.pages = [];
              const { buildTemplate } = await import('../editor/templates.js');
              ed.doc.pages.push(buildTemplate(tpl));
              ed.pageIndex = 0;
              ed.doc.title = tpl.name;
              ed.titleInput.value = tpl.name;
              ed.pushHistory(true);
              await ed.refresh(true);
            },
          }),
        ]),
      ]);
      grid.appendChild(card);
      const holder = card.querySelector('.dc-thumb');
      import('../editor/templates.js').then(async (m) => {
        const { renderPage } = await import('../editor/render.js');
        const { ensureFonts } = await import('../editor/fonts.js');
        const page = m.buildTemplate(tpl);
        await ensureFonts(page.layers);
        const c = document.createElement('canvas');
        await renderPage(c, page, Math.min(1, 340 / Math.max(page.w, page.h)));
        c.style.width = '100%';
        c.style.height = '100%';
        c.style.objectFit = 'cover';
        holder.appendChild(c);
      });
    });
    wrap.appendChild(grid);
  });
  host.appendChild(wrap);
}

/* ---------------- حوار تصميم جديد ---------------- */
export function newSizeDialog(presetType, presetSub) {
  const tabs = el('div', { class: 'tabs' });
  const body = el('div');
  let chosen = null;
  let customW = 1080, customH = 1080;

  function draw() {
    clear(body);
    if (chosen === 'custom') {
      body.appendChild(el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: t('width') }), el('input', { class: 'input num', type: 'number', value: customW, oninput: (e) => customW = +e.target.value || 100 })]),
        el('div', { class: 'field' }, [el('label', { text: t('height') }), el('input', { class: 'input num', type: 'number', value: customH, oninput: (e) => customH = +e.target.value || 100 })]),
      ]));
      body.appendChild(el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'بكسل — للطباعة استخدم 300dpi (مثال A4 = 2480×3508)' }));
      return;
    }
    PAGE_PRESETS.forEach((g) => {
      body.appendChild(el('div', { class: 'ed-sec-title', text: g.group, style: { marginTop: '10px' } }));
      const grid = el('div', { class: 'cards-grid', style: { gridTemplateColumns: 'repeat(auto-fill,minmax(150px,1fr))' } });
      g.items.forEach((p) => {
        grid.appendChild(el('button', {
          class: 'btn outline sm', style: { height: 'auto', flexDirection: 'column', padding: '10px', alignItems: 'flex-start', gap: '4px' },
          onclick: () => create(p.w, p.h, p.label),
        }, [
          el('div', { style: { width: Math.min(34, 34 * p.w / p.h) + 'px', height: Math.min(34, 34 * p.h / p.w) + 'px', border: '1.5px solid var(--text-3)', borderRadius: '3px' } }),
          el('div', { style: { fontSize: '12px', fontWeight: '600', textAlign: 'start' }, text: p.label }),
          el('div', { class: 'dim', style: { fontSize: '10.5px' }, text: `${p.w}×${p.h}` }),
        ]));
      });
      body.appendChild(grid);
    });
  }

  const m = modal({
    title: t('newDesign'),
    size: 'wide',
    body: [
      el('div', { class: 'seg brand' }, [
        el('button', { text: 'مقاسات جاهزة', class: 'active', onclick: (e) => { chosen = null; seg(e); draw(); } }),
        el('button', { text: t('customSize'), onclick: (e) => { chosen = 'custom'; seg(e); draw(); } }),
      ]),
      body,
    ],
    footer: [
      el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
      el('button', { class: 'btn primary', text: t('startFromScratch'), onclick: () => create(customW, customH, 'مقاس مخصص') }),
    ],
  });

  function seg(e) { [...e.target.parentNode.children].forEach((b) => b.classList.remove('active')); e.target.classList.add('active'); }

  async function create(w, h, label) {
    m.close();
    const { openEditor } = await import('../editor/index.js');
    const { makeDoc } = await import('../editor/model.js');
    const doc = makeDoc(label + ' — بدون عنوان', w, h, { type: 'color', color: '#ffffff' });
    doc.type = presetType || 'سوشيال';
    openEditor(null, { doc });
  }

  draw();
}
