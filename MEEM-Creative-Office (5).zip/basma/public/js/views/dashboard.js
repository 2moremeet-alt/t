/* ============================================================
   MEEM | Creative Office — لوحة التحكم
   ============================================================ */
import { t, getLang } from '../i18n.js';
import { state, stats, deptStats, DEPTS, userById, isOverdue, isDueToday, todayStr, projectById } from '../store.js';
import { el, icon, clear, avatarHTML, statusBadge, dueLabel, timeAgo, escapeHTML } from '../ui.js';
import { openTaskModal, openTaskDetails } from '../taskform.js';
import { openNewMeetingModal } from './meetings.js';

export function renderDashboard(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  const s = stats();
  const ds = deptStats();
  const u = state.user;
  const name = getLang() === 'ar' ? u.name : (u.nameEn || u.name);

  const hour = new Date().getHours();
  const greeting = getLang() === 'ar'
    ? (hour < 12 ? 'صباح الخير' : hour < 18 ? 'مساء الخير' : 'مساء الخير')
    : (hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening');

  host.append(
    el('div', { class: 'page-head' }, [
      el('div', {}, [
        el('h1', { text: `${greeting}، ${name} 👋` }),
        el('div', { class: 'ph-sub', text: getLang() === 'ar'
          ? `${s.open} مهمة مفتوحة · ${s.dueToday} تسليم اليوم · ${s.overdue} متأخرة`
          : `${s.open} open tasks · ${s.dueToday} due today · ${s.overdue} overdue` }),
      ]),
      el('div', { class: 'row wrap', style: { gap: '8px' } }, [
        el('button', { class: 'btn sm', html: icon('plus') + `<span>${t('newTask')}</span>`, onclick: () => openTaskModal(null, refresh) }),
        el('button', { class: 'btn sm', html: icon('meet') + `<span>${t('newMeeting')}</span>`, onclick: () => openNewMeetingModal(refresh) }),
        el('button', {
          class: 'btn primary sm', html: icon('design') + `<span>${t('openEditor')}</span>`,
          onclick: async () => { const { openEditor } = await import('../editor/index.js'); openEditor(null); },
        }),
      ]),
    ]),

    el('div', { class: 'kpis' }, [
      kpi('bolt', t('openTasks'), s.open, 'var(--brand)'),
      kpi('clock', t('dueToday'), s.dueToday, 'var(--warn)'),
      kpi('warning', t('overdue'), s.overdue, s.overdue ? 'var(--danger)' : ''),
      kpi('eye', t('inReview'), s.review, 'var(--accent)'),
      kpi('checkCircle', t('delivered'), s.delivered, 'var(--ok)'),
      kpi('folder', t('activeProjects'), s.projects, ''),
    ]),

    myDesk(),

    el('div', { style: { display: 'grid', gridTemplateColumns: 'minmax(0,2fr) minmax(0,1fr)', gap: '14px' }, class: 'dash-grid' }, [
      leftColumn(ds),
      rightColumn(),
    ]),
  );

  function leftColumn(ds) {
    const mine = state.tasks
      .filter((x) => x.assignee === u.id && !['done'].includes(x.status))
      .sort((a, b) => (a.due || '9999').localeCompare(b.due || '9999'))
      .slice(0, 8);

    const myCard = el('div', { class: 'card' }, [
      el('div', { class: 'between', style: { padding: '14px 16px', borderBottom: '1px solid var(--line)' } }, [
        el('h3', { html: icon('users') + ' ' + t('myTasks'), style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '15px' } }),
        el('span', { class: 'badge brand num', text: String(mine.length) }),
      ]),
      el('div', { style: { padding: '12px 16px', display: 'flex', flexDirection: 'column', gap: '9px' } },
        mine.length ? mine.map((task) => {
          const p = projectById(task.projectId);
          return el('button', {
            class: 'tcard', style: { width: '100%', textAlign: 'start', border: '1px solid var(--line)' },
            onclick: () => openTaskDetails(task.id, refresh),
          }, [
            el('div', { class: 'row', style: { justifyContent: 'space-between', gap: '8px' } }, [
              el('span', { class: 'tc-type', text: `${t('dept_' + task.dept)} · ${(task.type || '').toUpperCase()}` }),
              el('span', { html: statusBadge(task.status) }),
            ]),
            el('div', { class: 'tc-title', text: task.title }),
            el('div', { class: 'tc-meta' }, [
              p ? el('span', { html: icon('folder') + ' ' + escapeHTML(p.title) }) : null,
              task.due ? el('span', { class: isOverdue(task) ? 'badge danger' : '', html: icon('clock') + ' ' + dueLabel(task.due) }) : null,
            ]),
          ]);
        }) : [el('div', { class: 'empty', text: t('noData') })],
      ),
    ]);

    const deptCard = el('div', { class: 'card card-pad' }, [
      el('h3', { html: icon('kanban') + ' ' + t('byDepartment'), style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '15px', marginBottom: '14px' } }),
      ...DEPTS.map((d) => {
        const x = ds[d];
        const pct = x.total ? Math.round((x.done / x.total) * 100) : 0;
        return el('div', { style: { marginBottom: '13px' } }, [
          el('div', { class: 'between', style: { marginBottom: '5px', fontSize: '13.5px' } }, [
            el('span', { html: deptIcon(d) + ' ' + t('dept_' + d), style: { display: 'inline-flex', alignItems: 'center', gap: '7px', fontWeight: '600' } }),
            el('span', { class: 'dim num', text: `${x.done}/${x.total}` }),
          ]),
          el('div', { class: 'bar thin' }, [el('i', { style: { width: pct + '%' } })]),
        ]);
      }),
    ]);

    return el('div', { class: 'col' }, [myCard, deptCard]);
  }

  function rightColumn() {
    const meetings = state.meetings
      .filter((m) => new Date(m.scheduledAt) >= new Date(Date.now() - 3600e3))
      .sort((a, b) => a.scheduledAt.localeCompare(b.scheduledAt))
      .slice(0, 4);

    const meetCard = el('div', { class: 'card' }, [
      el('div', { class: 'between', style: { padding: '14px 16px', borderBottom: '1px solid var(--line)' } }, [
        el('h3', { html: icon('calendar') + ' ' + t('upcomingMeetings'), style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '15px' } }),
        el('a', { class: 'btn ghost sm', href: '#/meetings', text: t('all') }),
      ]),
      el('div', { style: { padding: '12px 14px', display: 'flex', flexDirection: 'column', gap: '9px' } },
        meetings.length ? meetings.map((m) => el('div', { class: 'meet-card', style: { padding: '10px' } }, [
          el('div', { class: 'mc-icon', html: icon('meet') }),
          el('div', { class: 'grow' }, [
            el('div', { style: { fontWeight: '700', fontSize: '13.5px' }, text: getLang() === 'ar' ? m.title : (m.titleEn || m.title) }),
            el('div', { class: 'dim', style: { fontSize: '11.5px' }, text: new Date(m.scheduledAt).toLocaleString(getLang() === 'ar' ? 'ar-EG' : 'en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) }),
          ]),
          el('a', { class: 'btn primary sm', href: `#/meetings/${m.id}`, text: t('meet_join') }),
        ])) : [el('div', { class: 'empty', text: t('noData') })],
      ),
    ]);

    const actCard = el('div', { class: 'card' }, [
      el('div', { style: { padding: '14px 16px', borderBottom: '1px solid var(--line)' } }, [
        el('h3', { html: icon('clock') + ' ' + t('recentActivity'), style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '15px' } }),
      ]),
      el('div', { style: { padding: '6px 16px', maxHeight: '320px', overflow: 'auto' } },
        (state.activity || []).slice(0, 14).map((a) => {
          const who = userById(a.userId);
          return el('div', { class: 'act-item' }, [
            el('div', { html: avatarHTML(who, 'sm') }),
            el('div', { class: 'grow' }, [
              el('div', { text: getLang() === 'ar' ? a.text : (a.textEn || a.text), style: { fontSize: '13px' } }),
              el('div', { class: 'act-time', text: timeAgo(a.at) }),
            ]),
          ]);
        }),
      ),
    ]);

    const teamCard = el('div', { class: 'card card-pad' }, [
      el('h3', { html: icon('users') + ' ' + t('workload'), style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '15px', marginBottom: '12px' } }),
      ...state.users.map((usr) => {
        const load = state.tasks.filter((x) => x.assignee === usr.id && !['done', 'delivered'].includes(x.status)).length;
        return el('div', { class: 'row', style: { marginBottom: '9px' } }, [
          el('div', { html: avatarHTML(usr, 'sm') }),
          el('div', { class: 'grow', style: { fontSize: '13px' }, text: getLang() === 'ar' ? usr.name : (usr.nameEn || usr.name) }),
          el('span', { class: 'badge num' + (load > 4 ? ' warn' : ''), text: String(load) }),
        ]);
      }),
    ]);

    return el('div', { class: 'col' }, [meetCard, actCard, teamCard]);
  }

  function refresh() { host.innerHTML = ''; renderDashboard(host); }
}

function deptIcon(d) {
  const map = { content: 'content', voice: 'voice', design: 'design', delivery: 'delivery', dev: 'code' };
  return icon(map[d] || 'folder');
}

/* ================= My Desk — المكتب الشخصي للمستخدم ================= */
function myDesk() {
  const u = state.user;
  const mine = state.tasks.filter((x) => x.assignee === u.id);
  const open = (arr) => arr.filter((x) => !['done', 'delivered'].includes(x.status));

  // عدّادات حسب الدور: المصمم يرى تصميماته، غيرهم يرى مهامه
  const myDesigns = open(state.tasks.filter((x) => x.assignee === u.id && x.dept === 'design')).length;
  const myTasks = open(mine).length;
  const myReview = state.tasks.filter((x) => x.status === 'review').length;
  const myRevisions = open(mine.filter((x) => x.status === 'revision')).length;
  const myDeliveries = state.tasks.filter((x) => x.status === 'delivered').length;
  const myMeetings = state.meetings.filter((m) => new Date(m.scheduledAt) >= new Date(Date.now() - 3600e3)).length;

  const tile = (ic, label, value, color, onclick) => el('button', {
    class: 'desk-tile', onclick,
  }, [
    el('div', { class: 'dt-ic', html: icon(ic), style: color ? { color } : {} }),
    el('div', { class: 'dt-val num', text: String(value) }),
    el('div', { class: 'dt-label', text: label }),
  ]);

  // مشاريعي مع نسبة الإنجاز
  const myProjects = state.projects
    .filter((p) => {
      const tasks = state.tasks.filter((x) => x.projectId === p.id);
      return tasks.some((x) => x.assignee === u.id) || ['admin', 'pm', 'cs'].includes(u.role);
    })
    .slice(0, 6)
    .map((p) => {
      const tasks = state.tasks.filter((x) => x.projectId === p.id);
      const done = tasks.filter((x) => ['done', 'delivered'].includes(x.status)).length;
      const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
      return el('div', { class: 'desk-proj' }, [
        el('div', { class: 'between', style: { fontSize: '13px', marginBottom: '4px' } }, [
          el('span', { style: { fontWeight: '600' }, text: p.title }),
          el('span', { class: 'dim num', text: pct + '%' }),
        ]),
        el('div', { class: 'bar thin' }, [el('i', { style: { width: pct + '%' } })]),
      ]);
    });

  return el('div', { class: 'card card-pad desk' }, [
    el('div', { class: 'between', style: { marginBottom: '12px' } }, [
      el('h3', { html: icon('dashboard') + ' مكتبي — My Desk', style: { display: 'flex', alignItems: 'center', gap: '8px', fontSize: '15px' } }),
      el('span', { class: 'dim', style: { fontSize: '12px' }, text: 'كل ما يخصك في مكان واحد' }),
    ]),
    el('div', { class: 'desk-tiles' }, [
      tile('design', u.role === 'designer' ? 'تصميماتي المفتوحة' : 'مهامي المفتوحة', u.role === 'designer' ? myDesigns : myTasks, 'var(--brand)', () => { location.hash = '#/design'; }),
      tile('eye', 'في انتظار المراجعة', myReview, 'var(--accent)', () => { location.hash = '#/delivery'; }),
      tile('edit', 'تعديلات عليّ', myRevisions, 'var(--warn)', () => { location.hash = '#/design'; }),
      tile('delivery', 'تسليمات', myDeliveries, 'var(--ok)', () => { location.hash = '#/delivery'; }),
      tile('meet', 'اجتماعات قادمة', myMeetings, '', () => { location.hash = '#/meetings'; }),
    ]),
    el('div', { class: 'desk-grid' }, [
      el('div', {}, [
        el('div', { class: 'desk-sub', text: 'إجراءات سريعة' }),
        el('div', { class: 'desk-quick' }, [
          el('button', { class: 'btn sm primary', html: icon('design') + '<span>تصميم جديد</span>', onclick: async () => { const { openEditor } = await import('../editor/index.js'); openEditor(null); } }),
          el('button', { class: 'btn sm', html: icon('plus') + '<span>مهمة جديدة</span>', onclick: () => openTaskModal(null) }),
          el('button', { class: 'btn sm', html: icon('meet') + '<span>اجتماع جديد</span>', onclick: () => openNewMeetingModal() }),
          el('button', { class: 'btn sm', html: icon('folder') + '<span>الملفات</span>', onclick: () => { location.hash = '#/assets'; } }),
        ]),
      ]),
      el('div', {}, [
        el('div', { class: 'desk-sub', text: 'مشاريعي' }),
        myProjects.length ? el('div', { class: 'desk-projs' }, myProjects) : el('div', { class: 'dim', style: { fontSize: '12.5px' }, text: 'لا مشاريع مسندة إليك بعد' }),
      ]),
    ]),
  ]);
}

function kpi(ic, label, value, color) {
  return el('div', { class: 'kpi' }, [
    el('div', { class: 'k-label', html: icon(ic) + `<span>${escapeHTML(label)}</span>` }),
    el('div', { class: 'k-value num', text: String(value), style: color ? { color } : {} }),
  ]);
}

/* responsive fix for dashboard grid */
const styleTag = document.createElement('style');
styleTag.textContent = '@media (max-width: 1080px){ .dash-grid{ grid-template-columns: 1fr !important; } }';
document.head.appendChild(styleTag);
