/* ============================================================
   MEE M — Client Token Portal (V2-11)
   صفحة العميل باللينك الآمن — بدون تسجيل دخول
   /client/project/TOKEN
   ============================================================ */
import { el, statusBadge, formatDate, toast, modal, confirmDialog } from '../ui.js';
import { getLang, setLang } from '../i18n.js';

const ST_AR = { client: 'بانتظار مراجعتك', client_approved: 'معتمد ✓', client_changes: 'تعديلاتك وصلت', approved: 'معتمد', delivered: 'اتسلّم', draft: 'قيد التجهيز', review: 'مراجعة داخلية', changes: 'تعديلات', waiting_client: 'بانتظار ردك', revision: 'تعديلات', done: 'مكتمل' };

export async function renderTPortal(host, token) {
  const AR = getLang() === 'ar';
  host.innerHTML = '';
  host.hidden = false;
  host.classList.add('tp-scope');

  const wrap = el('div', { class: 'tp-wrap' });
  host.appendChild(wrap);
  wrap.appendChild(el('div', { class: 'tp-loading', text: 'جاري فتح المشروع…' }));

  let data;
  try {
    const r = await fetch('/api/tportal/' + encodeURIComponent(token));
    const j = await r.json();
    if (!r.ok || !j.ok) throw Object.assign(new Error(j.error || 'لينك غير صالح'), { status: r.status });
    data = j.data;
  } catch (e) {
    wrap.innerHTML = '';
    wrap.appendChild(el('div', { class: 'tp-err' }, [
      el('div', { class: 'tp-logo', text: 'MEE M' }),
      el('h2', { text: AR ? '🔗 اللينك مش شغال' : '🔗 Link not working' }),
      el('p', { class: 'tp-dim', text: e.message || (AR ? 'اللينك غير صالح أو منتهي — راجع فريق خدمة العملاء' : 'Invalid or expired link — contact our CS team') }),
    ]));
    return;
  }

  const { project, clientName, designs, deliveries, tasks } = data;
  const appr = designs.filter((d) => ['client_approved', 'approved', 'delivered'].includes(d.status)).length;
  const pend = designs.filter((d) => d.status === 'client').length;

  /* ---- الرأس ---- */
  wrap.appendChild(el('header', { class: 'tp-head' }, [
    el('button', { class: 'pr-lang', text: AR ? 'EN' : 'عربي', onclick: () => setLang(AR ? 'en' : 'ar') }),
    el('div', { class: 'tp-logo', text: 'MEE M' }),
    el('div', { class: 'grow' }, [
      el('h1', { text: AR ? project.title : (project.titleEn || project.title) }),
      el('div', { class: 'tp-dim', text: ((AR ? clientName : (data.clientNameEn || clientName)) ? (AR ? clientName : (data.clientNameEn || clientName)) + ' · ' : '') + (project.type || '') + (project.due ? (AR ? ' · التسليم: ' : ' · Due: ') + formatDate(project.due) : '') }),
    ]),
    el('div', { class: 'tp-stat' }, [
      el('b', { class: 'num', text: appr + '/' + designs.length }),
      el('span', { class: 'tp-dim', text: AR ? 'تصميم معتمد' : 'approved' }),
    ]),
  ]));

  /* ---- شريط التقدم ---- */
  const pct = designs.length ? Math.round((appr / designs.length) * 100) : 0;
  wrap.appendChild(el('div', { class: 'tp-progress' }, [
    el('div', { class: 'tp-bar' }, [el('div', { class: 'tp-fill', style: { width: pct + '%' } })]),
    el('span', { class: 'num tp-dim', text: pct + '%' }),
  ]));
  if (pend) wrap.appendChild(el('div', { class: 'tp-notice', text: AR ? '⏳ فيه ' + pend + ' تصميم بانتظار مراجعتك' : '⏳ ' + pend + ' design(s) waiting for your review' }));

  /* ---- التصاميم (V2-12: معاينة/اعتماد/تعديل) ---- */
  const api2 = (path, body) => fetch('/api/tportal/' + encodeURIComponent(token) + path, body ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) } : undefined).then(async (r) => {
    const j = await r.json().catch(() => ({}));
    if (!r.ok || !j.ok) throw Object.assign(new Error(j.error || 'حصل خطأ'), { status: r.status });
    return j;
  });

  function watermarkBox() {
    return el('div', { class: 'tp-wm-layer' }, Array.from({ length: 9 }, () => el('span', { class: 'tp-wm', text: 'MEE M' })));
  }

  function previewModal(d) {
    const m = modal({
      title: d.title,
      size: 'wide',
      body: el('div', { class: 'tp-preview' }, [
        d.url ? el('img', { src: d.url, alt: d.title }) : el('div', { class: 'tp-noimg', style: { height: '300px' }, text: '🎨' }),
        watermarkBox(),
      ]),
      footer: [el('button', { class: 'btn', text: 'إغلاق', onclick: () => m.close() })],
    });
  }

  async function decide(d, decision) {
    if (decision === 'approve') {
      const yes = await confirmDialog('بتعتمد «' + d.title + '» — الاعتماد هيتسجل ومش هيتراجع. متأكد؟', { title: 'اعتماد نهائي ✓', okLabel: 'أيوة، اعتماد' });
      if (!yes) return;
      try {
        await api2('/decision', { designId: d.id, decision: 'approve' });
        toast('اتسجل اعتمادك ✓', 'ok');
        renderTPortal(host, token);
      } catch (e) { toast(e.message, 'err'); }
      return;
    }
    /* طلب تعديل */
    const note = el('textarea', { class: 'textarea', rows: 3, placeholder: 'اكتب التعديلات المطلوبة بالتفصيل…' });
    const filesList = [];
    const filesBox = el('div', { class: 'col', style: { gap: '4px' } });
    const fileInput = el('input', { type: 'file', multiple: true, style: { display: 'none' } });
    fileInput.onchange = async () => {
      for (const f of [...fileInput.files].slice(0, 8)) {
        if (f.size > 10 * 1024 * 1024) { toast(f.name + ' أكبر من 10MB', 'err'); continue; }
        try {
          const fd = await fetch('/api/tportal/' + encodeURIComponent(token) + '/upload?name=' + encodeURIComponent(f.name), { method: 'POST', body: f }).then((r) => r.json());
          if (!fd.ok) throw new Error(fd.error || 'رفع فشل');
          filesList.push({ name: f.name, url: fd.url });
          filesBox.appendChild(el('div', { class: 'tp-dim', style: { fontSize: '12px' }, text: '📎 ' + f.name }));
        } catch (e) { toast(e.message, 'err'); }
      }
      fileInput.value = '';
    };
    const m = modal({
      title: '✏️ طلب تعديل — ' + d.title,
      body: el('div', { class: 'col', style: { gap: '10px' } }, [
        note,
        el('button', { class: 'btn sm', html: '📎<span>إرفاق ملفات (صور/PDF/ZIP)</span>', onclick: () => fileInput.click() }),
        filesBox, fileInput,
      ]),
      footer: [
        el('button', { class: 'btn', text: 'إلغاء', onclick: () => m.close() }),
        el('button', { class: 'btn primary', text: 'إرسال الطلب', onclick: async () => {
          if (!note.value.trim()) { toast('اكتب ملاحظاتك الأول', 'err'); return; }
          try {
            await api2('/decision', { designId: d.id, decision: 'changes', note: note.value.trim(), files: filesList });
            m.close();
            toast('طلبك وصل الفريق ✓', 'ok');
            renderTPortal(host, token);
          } catch (e) { toast(e.message, 'err'); }
        } }),
      ],
    });
  }

  wrap.appendChild(el('h2', { class: 'tp-sec', text: AR ? '🎨 التصاميم' : '🎨 Designs' }));
  if (!designs.length) wrap.appendChild(el('div', { class: 'tp-empty', text: AR ? 'لسه مفيش تصاميم جاهزة للعرض' : 'No designs ready yet' }));
  const grid = el('div', { class: 'tp-grid' });
  designs.forEach((d) => {
    const pending = d.status === 'client';
    grid.appendChild(el('div', { class: 'tp-card' }, [
      el('div', { class: 'tp-thumb' }, [
        d.url ? el('img', { src: d.url, alt: d.title, loading: 'lazy' }) : el('div', { class: 'tp-noimg', text: '🎨' }),
        el('span', { class: 'tp-wm-mini', text: 'MEE M' }),
      ]),
      el('div', { class: 'tp-card-b' }, [
        el('b', { text: d.title }),
        el('span', { class: 'tp-st', html: statusBadge(d.status) }),
      ]),
      el('div', { class: 'tp-card-acts' }, [
        el('button', { class: 'btn sm ghost', text: AR ? '👁 معاينة' : '👁 Preview', onclick: () => previewModal(d) }),
        pending ? el('button', { class: 'btn sm primary', text: AR ? '✓ اعتماد' : '✓ Approve', onclick: () => decide(d, 'approve') }) : null,
        pending ? el('button', { class: 'btn sm ghost', text: AR ? '✏️ تعديل' : '✏️ Revise', onclick: () => decide(d, 'changes') }) : null,
      ]),
      d.client && d.client.decision === 'changes' && d.client.note ? el('div', { class: 'tp-dim', style: { fontSize: '11px', padding: '0 12px 10px' }, text: (AR ? 'ملاحظاتك: ' : 'Your notes: ') + d.client.note }) : null,
    ]));
  });
  wrap.appendChild(grid);

  /* ---- التسليمات ---- */
  if ((deliveries || []).length) {
    wrap.appendChild(el('h2', { class: 'tp-sec', text: AR ? '📦 التسليمات' : '📦 Deliveries' }));
    wrap.appendChild(el('div', { class: 'tp-list' }, deliveries.map((x) => el('div', { class: 'tp-row' }, [
      el('b', { text: x.title || x.channel || (AR ? 'تسليم' : 'Delivery') }),
      el('span', { class: 'tp-st', html: statusBadge(x.status) }),
    ]))));
  }

  /* ---- خطوات الشغل ---- */
  if ((tasks || []).length) {
    wrap.appendChild(el('h2', { class: 'tp-sec', text: AR ? '🗂️ خطوات التنفيذ' : '🗂️ Progress Steps' }));
    wrap.appendChild(el('div', { class: 'tp-list' }, tasks.map((x) => el('div', { class: 'tp-row' }, [
      el('b', { text: x.title }),
      el('span', { class: 'tp-st badge', text: (AR ? ST_AR[x.status] : x.status) || x.status }),
    ]))));
  }

  wrap.appendChild(el('footer', { class: 'tp-foot', text: AR ? 'MEE M — Creative Office · صفحة العميل الآمنة' : 'MEE M — Creative Office · Secure client page' }));
  const onLang = () => { if (host.isConnected) renderTPortal(host, token); else window.removeEventListener('langchange', onLang); };
  window.addEventListener('langchange', onLang);
}
