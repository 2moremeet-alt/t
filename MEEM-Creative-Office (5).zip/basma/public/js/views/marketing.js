/* ============================================================
   MEEM | Creative Office — Phase 6: Marketing
   حملات (قناة/ميزانية/مصروف/leads/تحويلات/إيراد) + ROI
   ============================================================ */
import { state, save, remove, clientById } from '../store.js';
import { el, icon, clear, escapeHTML, toast, modal, confirmDialog, money } from '../ui.js';

const CHANNELS = {
  facebook: ['فيسبوك', '📘'],
  instagram: ['إنستجرام', '📸'],
  google: ['جوجل', '🔍'],
  tiktok: ['تيك توك', '🎵'],
  other: ['أخرى', '📣'],
};
const CSTATUS = { active: ['شغالة', 'ok'], paused: ['موقوفة', 'warn'], done: ['خلصت', ''] };
const roi = (c) => (c.spent > 0 ? Math.round(((c.revenue - c.spent) / c.spent) * 100) : 0);

export function renderMarketing(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('sparkles') + ' التسويق', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'حملات بميزانياتها ونتائجها — والـ ROI محسوب لوحده' }),
    ]),
    el('button', { class: 'btn primary', html: icon('plus') + `<span>حملة جديدة</span>`, onclick: () => openCampaignModal(null, draw) }),
  ]));
  const kpis = el('div', { class: 'kpis', style: { marginBottom: '12px' } });
  const area = el('div');
  host.append(kpis, area);

  function draw() {
    const list = state.campaigns || [];
    const sum = (k) => list.reduce((s, c) => s + (+c[k] || 0), 0);
    const spent = sum('spent'), rev = sum('revenue');
    clear(kpis);
    kpis.append(
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'ميزانيات' }), el('div', { class: 'k-value num', text: money(sum('budget')) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'مصروف' }), el('div', { class: 'k-value num', text: money(spent) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'عملاء محتملون' }), el('div', { class: 'k-value num', text: String(sum('leads')) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'تحويلات' }), el('div', { class: 'k-value num', text: String(sum('conversions')) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'إيراد' }), el('div', { class: 'k-value num', style: { color: 'var(--ok)' }, text: money(rev) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'ROI إجمالي' }), el('div', { class: 'k-value num', style: { color: rev - spent >= 0 ? 'var(--ok)' : 'var(--danger)' }, text: (spent ? Math.round(((rev - spent) / spent) * 100) : 0) + '%' })]),
    );
    clear(area);
    if (!list.length) { area.appendChild(el('div', { class: 'empty card', style: { padding: '40px' }, text: 'لا حملات — ابدأ واحدة 📣' })); return; }
    const grid = el('div', { class: 'cards-grid' });
    list.forEach((c) => {
      const ch = CHANNELS[c.channel] || CHANNELS.other;
      const cl = clientById(c.clientId);
      const [slb, scl] = CSTATUS[c.status] || ['', ''];
      const pct = c.budget ? Math.min(100, Math.round((c.spent / c.budget) * 100)) : 0;
      grid.appendChild(el('div', { class: 'dcard', style: { cursor: 'pointer' }, onclick: () => openCampaignModal(c, draw) }, [
        el('div', { class: 'dc-body', style: { padding: '14px' } }, [
          el('div', { class: 'row', style: { gap: '8px', marginBottom: '6px' } }, [
            el('span', { style: { fontSize: '18px' }, text: ch[1] }),
            el('div', { class: 'dc-title grow', text: c.title }),
            el('span', { class: 'badge ' + scl, text: slb }),
          ]),
          el('div', { class: 'dc-sub', text: `${cl ? cl.name : '—'} · بدأت ${c.start || '—'}` }),
          el('div', { class: 'row', style: { gap: '6px', fontSize: '11.5px', margin: '8px 0 4px' } }, [
            el('span', { class: 'dim num', text: `مصروف ${money(c.spent)} / ${money(c.budget)}` }),
          ]),
          el('div', { class: 'pbar' }, [el('i', { style: { width: pct + '%', background: pct > 90 ? 'var(--danger)' : 'var(--brand)' } })]),
          el('div', { class: 'row wrap', style: { gap: '6px', fontSize: '11.5px', marginTop: '8px' } }, [
            el('span', { class: 'badge', text: '👥 ' + (c.leads || 0) + ' leads' }),
            el('span', { class: 'badge', text: '✓ ' + (c.conversions || 0) + ' تحويل' }),
            el('span', { class: 'badge ok', text: money(c.revenue) }),
            el('div', { class: 'grow' }),
            el('span', { class: 'badge ' + (roi(c) >= 0 ? 'ok' : 'danger'), text: 'ROI ' + roi(c) + '%' }),
          ]),
        ]),
      ]));
    });
    area.appendChild(grid);
  }
  draw();
}

function openCampaignModal(c, onDone) {
  const isNew = !c;
  const doc = Object.assign({
    title: '', channel: 'facebook', clientId: (state.clients[0] || {}).id || '', status: 'active',
    budget: 0, spent: 0, leads: 0, conversions: 0, revenue: 0,
    start: new Date().toISOString().slice(0, 10), notes: '',
  }, c ? JSON.parse(JSON.stringify(c)) : {});
  const m = modal({
    title: isNew ? '📣 حملة جديدة' : '📣 ' + doc.title,
    size: 'wide',
    body: [
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'اسم الحملة *' }), el('input', { class: 'input', value: doc.title, oninput: (e) => doc.title = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'القناة' }), el('select', { class: 'select', html: Object.entries(CHANNELS).map(([k, v]) => `<option value="${k}" ${k === doc.channel ? 'selected' : ''}>${v[1]} ${v[0]}</option>`).join(''), onchange: (e) => doc.channel = e.target.value })]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'العميل' }), el('select', { class: 'select', html: (state.clients || []).map((x) => `<option value="${x.id}" ${x.id === doc.clientId ? 'selected' : ''}>${escapeHTML(x.name)}</option>`).join(''), onchange: (e) => doc.clientId = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'الحالة' }), el('select', { class: 'select', html: Object.entries(CSTATUS).map(([k, v]) => `<option value="${k}" ${k === doc.status ? 'selected' : ''}>${v[0]}</option>`).join(''), onchange: (e) => doc.status = e.target.value })]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'الميزانية' }), el('input', { class: 'input num', type: 'number', value: doc.budget, oninput: (e) => doc.budget = +e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'المصروف حتى الآن' }), el('input', { class: 'input num', type: 'number', value: doc.spent, oninput: (e) => doc.spent = +e.target.value })]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'عملاء محتملون (leads)' }), el('input', { class: 'input num', type: 'number', value: doc.leads, oninput: (e) => doc.leads = +e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'تحويلات' }), el('input', { class: 'input num', type: 'number', value: doc.conversions, oninput: (e) => doc.conversions = +e.target.value })]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'إيراد الحملة' }), el('input', { class: 'input num', type: 'number', value: doc.revenue, oninput: (e) => doc.revenue = +e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'تاريخ البداية' }), el('input', { class: 'input', type: 'date', value: doc.start, oninput: (e) => doc.start = e.target.value })]),
      ]),
      el('div', { class: 'field' }, [el('label', { text: 'ملاحظات' }), el('input', { class: 'input', value: doc.notes || '', oninput: (e) => doc.notes = e.target.value })]),
    ],
    footer: [
      !isNew ? el('button', { class: 'btn danger ghost', text: 'حذف', onclick: async () => { if (await confirmDialog('حذف الحملة؟', { danger: true })) { await remove('campaigns', doc.id); m.close(); onDone(); } } }) : null,
      el('div', { class: 'grow' }),
      el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: 'حفظ',
        onclick: async () => {
          if (!doc.title.trim()) { toast('اكتب اسم الحملة', 'warn'); return; }
          const saved = await save('campaigns', doc);
          doc.id = saved.id;
          m.close(); toast('اتحفظت ✓', 'ok'); onDone();
        },
      }),
    ],
  });
}
