/* ============================================================
   MEEM | Creative Office — Phase 4: Voice Studio
   تسجيل + Waveform + Trim/Volume/Fade/EQ + دورة مراجعة
   ============================================================ */
import { t } from '../i18n.js';
import { state, save, remove, userById, clientById, contentById } from '../store.js';
import { el, icon, clear, avatarHTML, timeAgo, escapeHTML, toast, modal, confirmDialog } from '../ui.js';
import { api } from '../api.js';
import * as AU from '../audio.js';

export const VSTATUS = {
  draft: ['مسودة', ''],
  review: ['في المراجعة', 'warn'],
  approved: ['معتمد', 'ok'],
  changes: ['تعديلات مطلوبة', 'danger'],
};

export function renderVoice(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  let tab = 'studio';

  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('voice') + ' استوديو الصوت', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'سجّل من الميكروفون، ظبط القص والصوت والـ EQ، واربط التسجيل بسكربت معتمد' }),
    ]),
    el('button', { class: 'btn primary', html: icon('mic') + `<span>تسجيل جديد</span>`, onclick: () => openVoiceStudio(null, () => draw()) }),
  ]));

  const tabs = el('div', { class: 'tabs' });
  const area = el('div');
  tabs.append(...[['studio', '🎙 الاستوديو'], ['tasks', '📋 المهام']].map(([k, lb]) => el('button', {
    class: k === tab ? 'active' : '', text: lb,
    onclick: (e) => { tab = k; tabs.querySelectorAll('button').forEach((b) => b.classList.remove('active')); e.currentTarget.classList.add('active'); draw(); },
  })));
  host.append(tabs, area);

  function draw() {
    clear(area);
    if (tab === 'tasks') { import('./dept.js').then((m) => m.renderDept('voice', area)); return; }
    drawStudioList(area, draw);
  }
  draw();
}

function drawStudioList(host, refresh) {
  const list = state.voices || [];
  const grid = el('div', { class: 'col', style: { gap: '9px' } });
  if (!list.length) grid.appendChild(el('div', { class: 'empty card', style: { padding: '40px' }, text: 'لا تسجيلات بعد — اضغط «تسجيل جديد» وابدأ 🎙' }));
  [...list].sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || '')).forEach((v) => {
    const [lb, cl] = VSTATUS[v.status] || ['', ''];
    const script = contentById(v.contentId);
    const totalDur = (v.takes || []).reduce((s, tk) => s + (tk.dur || 0), 0);
    grid.appendChild(el('div', { class: 'card row wrap', style: { padding: '13px 15px', gap: '10px', cursor: 'pointer' }, onclick: () => openVoiceStudio(v.id, refresh) }, [
      el('div', { style: { width: '38px', height: '38px', borderRadius: '10px', background: 'rgba(34,211,238,.12)', color: '#22d3ee', display: 'grid', placeItems: 'center', fontSize: '17px' }, text: '🎙' }),
      el('div', { class: 'grow', style: { minWidth: '200px' } }, [
        el('div', { style: { fontWeight: '800', fontSize: '14.5px' }, text: v.title }),
        el('div', { class: 'dim', style: { fontSize: '12px' }, text: `${(v.takes || []).length} takes · ${AU.formatTime(totalDur)} · سكربت: ${script ? script.title : '—'} · ${timeAgo(v.updatedAt || v.createdAt)}` }),
      ]),
      el('span', { class: 'badge ' + cl, text: lb }),
    ]));
  });
  host.appendChild(grid);
}

/* ---------------- الاستوديو ---------------- */
export async function openVoiceStudio(id, onDone) {
  let doc = {
    id: null, title: '', contentId: '', projectId: '', clientId: '', owner: state.user.id,
    status: 'draft', takes: [], mainTakeId: null, comments: [], review: null,
  };
  if (id) {
    try {
      const res = await api.docGet('voices', id);
      doc = Object.assign(doc, res.doc);
    } catch (e) { toast('تعذّر فتح التسجيل', 'err'); return; }
  }

  const overlay = el('div', { class: 'studio' });
  document.body.appendChild(overlay);
  const close = () => { overlay.remove(); onDone && onDone(); };
  let dirty = false;

  const titleInput = el('input', { class: 'input ct-title', placeholder: 'اسم التسجيل…', value: doc.title, oninput: (e) => { doc.title = e.target.value; dirty = true; } });
  const statusPill = el('span', { class: 'badge' });
  function updateStatus() {
    const [lb, cl] = VSTATUS[doc.status] || ['', ''];
    statusPill.className = 'badge ' + cl;
    statusPill.textContent = lb;
  }

  async function doSave(silent) {
    if (!doc.title.trim()) doc.title = 'تسجيل — ' + new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    const saved = await save('voices', doc); // الرد stripped — ناخد الـ id ونحتفظ بنسختنا الكاملة
    doc.id = saved.id;
    dirty = false;
    if (!silent) toast('اتحفظ ✓', 'ok');
  }

  /* ---------- السكربت ---------- */
  const scriptSel = el('select', {
    class: 'select', style: { width: '100%' },
    html: `<option value="">— اختر سكربت/محتوى —</option>` + (state.contents || []).map((c) => `<option value="${c.id}" ${c.id === doc.contentId ? 'selected' : ''}>${c.status === 'approved' ? '✅ ' : ''}${escapeHTML(c.title)}</option>`).join(''),
    onchange: (e) => { doc.contentId = e.target.value; dirty = true; drawScript(); },
  });
  const scriptBox = el('div', { class: 'vs-script' });
  function drawScript() {
    clear(scriptBox);
    const c = contentById(doc.contentId);
    if (!c) { scriptBox.appendChild(el('div', { class: 'dim', style: { fontSize: '12.5px' }, text: 'اربط التسجيل بمحتوى من المكتبة — المعتمد منه بيظهر بعلامة ✅' })); return; }
    scriptBox.append(
      el('div', { class: 'row', style: { gap: '6px', marginBottom: '6px' } }, [
        el('b', { style: { fontSize: '13px' }, text: c.title }),
        el('span', { class: 'badge ' + (c.status === 'approved' ? 'ok' : ''), text: VSTATUS[c.status] ? (c.status === 'approved' ? 'معتمد' : c.status) : c.status }),
      ]),
      el('pre', { class: 'vs-script-body', text: c.body || '' }),
    );
  }

  /* ---------- التسجيل ---------- */
  const micBtn = el('button', { class: 'vs-mic', html: '🎙', title: 'تسجيل' });
  const timer = el('span', { class: 'vs-timer num', text: '0:00' });
  const meterFill = el('i');
  const meter = el('div', { class: 'vs-meter' }, [meterFill]);
  let recording = false, recStart = 0, recTimer = null;

  micBtn.onclick = async () => {
    if (!recording) {
      if (!AU.micSupported()) { toast('المتصفح مش بيدعم التسجيل — ارفع ملف صوتي بدلها', 'err'); return; }
      try {
        await AU.startRecording((peak) => { meterFill.style.width = Math.round(peak * 100) + '%'; });
      } catch (e) { toast('مفيش إذن ميكروفون: ' + e.message, 'err'); return; }
      recording = true; recStart = Date.now();
      micBtn.classList.add('rec');
      recTimer = setInterval(() => { timer.textContent = AU.formatTime((Date.now() - recStart) / 1000); }, 250);
      toast('جارٍ التسجيل… اضغط تاني للوقوف', 'info', 2500);
    } else {
      recording = false;
      clearInterval(recTimer);
      micBtn.classList.remove('rec');
      meterFill.style.width = '0%';
      const blob = await AU.stopRecording();
      if (!blob || !blob.size) { toast('مفيش صوت اتسجل', 'warn'); return; }
      const data = await AU.blobToDataURL(blob);
      const dur = (Date.now() - recStart) / 1000;
      const take = { id: 'tk_' + Math.random().toString(36).slice(2, 9), data, dur, at: new Date().toISOString(), name: 'Take ' + (doc.takes.length + 1), processed: false };
      doc.takes.push(take);
      if (!doc.mainTakeId) doc.mainTakeId = take.id;
      dirty = true;
      drawTakes();
      toast('اتسجل Take ✓ — اسمعه وظبطه', 'ok');
    }
  };

  const upInput = el('input', {
    type: 'file', accept: 'audio/*', style: { display: 'none' },
    onchange: async (e) => {
      const f = e.target.files[0]; if (!f) return;
      const { readFileAsDataURL } = await import('../api.js');
      const data = await readFileAsDataURL(f);
      let dur = 0;
      try { const buf = await AU.decodeAudio(data); dur = buf.duration; } catch (err) {}
      const take = { id: 'tk_' + Math.random().toString(36).slice(2, 9), data, dur, at: new Date().toISOString(), name: f.name, processed: false };
      doc.takes.push(take);
      if (!doc.mainTakeId) doc.mainTakeId = take.id;
      dirty = true; drawTakes();
      toast('اترفع الملف ✓', 'ok');
    },
  });

  /* ---------- الـ Takes ---------- */
  const takesBox = el('div', { class: 'col', style: { gap: '12px' } });
  function drawTakes() {
    clear(takesBox);
    if (!doc.takes.length) {
      takesBox.appendChild(el('div', { class: 'dim', style: { fontSize: '13px', padding: '10px 0' }, text: 'لا takes — سجّل من الميكروفون أو ارفع ملف صوتي' }));
    }
    doc.takes.forEach((tk) => takesBox.appendChild(takeCard(tk)));
  }

  function takeCard(tk) {
    const card = el('div', { class: 'vs-take' + (tk.id === doc.mainTakeId ? ' main' : '') });
    const canvas = el('canvas', { class: 'vs-wave' });
    let peaks = null;
    const audio = new Audio();
    audio.src = tk.data;

    const playBtn = el('button', { class: 'btn ghost icon sm', html: icon('play') || '▶' });
    playBtn.onclick = () => {
      if (audio.paused) { audio.play(); playBtn.innerHTML = '⏸'; }
      else { audio.pause(); playBtn.innerHTML = '▶'; }
    };
    audio.addEventListener('ended', () => { playBtn.innerHTML = '▶'; });
    audio.addEventListener('timeupdate', () => {
      if (peaks) AU.drawWaveform(canvas, peaks, { progress: audio.currentTime / (audio.duration || tk.dur || 1), trimA: trimA / (tk.dur || 1), trimB: trimB / (tk.dur || 1) });
    });

    /* controls */
    let trimA = 0, trimB = tk.dur || 0;
    const trim1 = el('input', { type: 'range', min: 0, max: 100, value: 0, class: 'grow' });
    const trim2 = el('input', { type: 'range', min: 0, max: 100, value: 100, class: 'grow' });
    const gainIn = el('input', { type: 'range', min: 0, max: 200, value: Math.round((tk.opts?.gain ?? 1) * 100) });
    const fiIn = el('input', { type: 'range', min: 0, max: 3000, value: (tk.opts?.fadeIn || 0) * 1000 });
    const foIn = el('input', { type: 'range', min: 0, max: 3000, value: (tk.opts?.fadeOut || 0) * 1000 });
    const bassIn = el('input', { type: 'range', min: -12, max: 12, value: tk.opts?.bass || 0 });
    const trebIn = el('input', { type: 'range', min: -12, max: 12, value: tk.opts?.treble || 0 });

    const syncTrim = () => {
      const d = tk.dur || 1;
      trimA = Math.min(+trim1.value, +trim2.value - 2) / 100 * d;
      trimB = Math.max(+trim2.value, +trim1.value + 2) / 100 * d;
      if (peaks) AU.drawWaveform(canvas, peaks, { trimA: trimA / d, trimB: trimB / d });
    };
    trim1.oninput = syncTrim; trim2.oninput = syncTrim;

    const applyBtn = el('button', {
      class: 'btn sm primary', html: '⚙️ معالجة وتطبيق',
      onclick: async () => {
        applyBtn.disabled = true;
        applyBtn.textContent = '…جارٍ المعالجة';
        try {
          const opts = {
            trimStart: trimA, trimEnd: trimB,
            gain: +gainIn.value / 100,
            fadeIn: +fiIn.value / 1000, fadeOut: +foIn.value / 1000,
            bass: +bassIn.value, treble: +trebIn.value,
          };
          const processed = await AU.renderProcessed(tk.data, opts);
          tk.data = processed;
          tk.processed = true;
          tk.opts = opts;
          const buf = await AU.decodeAudio(processed);
          tk.dur = buf.duration;
          dirty = true;
          peaks = AU.computePeaks(buf, 140);
          AU.drawWaveform(canvas, peaks, {});
          toast('اتعالج الـ take ✓', 'ok');
          drawTakes();
        } catch (e) { toast('فشلت المعالجة: ' + e.message, 'err'); applyBtn.disabled = false; applyBtn.textContent = '⚙️ معالجة وتطبيق'; }
      },
    });

    card.append(
      el('div', { class: 'row', style: { gap: '8px', marginBottom: '6px' } }, [
        playBtn,
        el('b', { style: { fontSize: '13px' }, text: tk.name + (tk.id === doc.mainTakeId ? ' ★' : '') }),
        el('span', { class: 'dim num', style: { fontSize: '11.5px' }, text: AU.formatTime(tk.dur) }),
        tk.processed ? el('span', { class: 'badge ok', text: 'معالَج' }) : null,
        el('div', { class: 'grow' }),
        tk.id !== doc.mainTakeId ? el('button', { class: 'btn ghost sm', text: '★ الأساسي', onclick: () => { doc.mainTakeId = tk.id; dirty = true; drawTakes(); } }) : null,
        el('button', {
          class: 'btn ghost icon sm', html: icon('trash'),
          onclick: async () => {
            if (!await confirmDialog('حذف الـ take؟', { danger: true })) return;
            doc.takes = doc.takes.filter((x) => x.id !== tk.id);
            if (doc.mainTakeId === tk.id) doc.mainTakeId = (doc.takes[0] || {}).id || null;
            dirty = true; drawTakes();
          },
        }),
      ]),
      canvas,
      el('div', { class: 'vs-ctrls' }, [
        el('label', {}, [el('span', { text: '✂️ قص من' }), trim1]),
        el('label', {}, [el('span', { text: 'إلى' }), trim2]),
        el('label', {}, [el('span', { text: '🔊 Volume' }), gainIn]),
        el('label', {}, [el('span', { text: '🌅 Fade In' }), fiIn]),
        el('label', {}, [el('span', { text: '🌇 Fade Out' }), foIn]),
        el('label', {}, [el('span', { text: '🎚 Bass' }), bassIn]),
        el('label', {}, [el('span', { text: '🎛 Treble' }), trebIn]),
        applyBtn,
      ]),
    );

    // ارسم الموجة
    AU.decodeAudio(tk.data).then((buf) => {
      tk.dur = tk.dur || buf.duration;
      peaks = AU.computePeaks(buf, 140);
      AU.drawWaveform(canvas, peaks, {});
      trimB = tk.dur;
    }).catch(() => {});

    return card;
  }

  /* ---------- المراجعة والتعليقات ---------- */
  const side = el('div', { class: 'col', style: { gap: '12px' } });
  function drawSide() {
    clear(side);
    const isOwner = doc.owner === state.user.id;
    const canDecide = doc.status === 'review' && (!isOwner || state.user.role === 'admin');
    side.appendChild(el('div', { class: 'ct-panel' }, [
      el('div', { class: 'ct-panel-title', text: '🔍 المراجعة' }),
      doc.review && doc.review.note ? el('div', { class: 'ct-note', text: '📝 ' + doc.review.note }) : null,
      doc.review && doc.review.decision ? el('div', { class: 'ct-note ' + (doc.review.decision === 'approve' ? 'ok' : 'danger'), text: (doc.review.decision === 'approve' ? '✅ اعتمده ' : '✏️ ') + (doc.review.decidedByName || '') + (doc.review.decision === 'changes' && doc.review.note ? ' — ' + doc.review.note : '') }) : null,
      canDecide ? el('div', { class: 'row', style: { gap: '7px', marginTop: '8px' } }, [
        el('button', { class: 'btn sm ok grow', html: icon('check') + `<span>اعتماد</span>`, onclick: () => decide('approve') }),
        el('button', { class: 'btn sm danger grow', html: icon('edit') + `<span>طلب تعديل</span>`, onclick: () => decide('changes') }),
      ]) : null,
    ]));

    const cmts = doc.comments || [];
    const addInput = el('input', { class: 'input', placeholder: 'تعليق…' });
    const cmtList = el('div', { class: 'col', style: { gap: '6px' } });
    cmts.forEach((c) => cmtList.appendChild(el('div', { class: 'ct-cmt' + (c.resolved ? ' resolved' : '') }, [
      el('div', { class: 'row', style: { gap: '6px' } }, [
        el('b', { style: { fontSize: '12px' }, text: c.byName || '' }),
        el('span', { class: 'dim', style: { fontSize: '10.5px' }, text: timeAgo(c.at) }),
        el('div', { class: 'grow' }),
        !c.resolved ? el('button', { class: 'btn ghost sm', text: 'تم ✓', onclick: async () => { const r = await api.docComment('voices', doc.id, { id: c.id, op: 'resolve' }); doc.comments = r.comments; drawSide(); } }) : null,
      ]),
      el('div', { style: { fontSize: '13px', margin: '3px 0' }, text: c.text }),
    ])));
    if (!cmts.length) cmtList.appendChild(el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'لا تعليقات' }));
    side.appendChild(el('div', { class: 'ct-panel' }, [
      el('div', { class: 'ct-panel-title', text: `💬 التعليقات (${cmts.length})` }),
      cmtList,
      el('div', { class: 'row', style: { gap: '6px', marginTop: '8px' } }, [
        addInput,
        el('button', {
          class: 'btn sm primary', html: icon('send'),
          onclick: async () => {
            const text = addInput.value.trim(); if (!text) return;
            const r = await api.docComment('voices', doc.id, { text });
            doc.comments = r.comments; drawSide();
          },
        }),
      ]),
    ]));
  }

  async function decide(decision) {
    let note = '';
    if (decision === 'changes') {
      const inp = el('textarea', { class: 'textarea', placeholder: 'ملاحظاتك…' });
      const r = await new Promise((resolve) => {
        const m = modal({
          title: 'طلب تعديل',
          body: [inp],
          footer: [
            el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => { m.close(); resolve(null); } }),
            el('button', { class: 'btn danger', text: 'إرسال', onclick: () => { m.close(); resolve(inp.value.trim()); } }),
          ],
        });
      });
      if (r == null) return;
      note = r;
      if (!note) { toast('اكتب ملاحظات', 'warn'); return; }
    }
    try {
      const res = await api.docDecision('voices', doc.id, decision, note);
      Object.assign(doc, { status: res.doc.status, review: res.doc.review });
      updateStatus(); drawSide();
      toast(decision === 'approve' ? 'اتعتمد ✓' : 'اترسلت الملاحظات', 'ok');
    } catch (e) { toast(e.message, 'err'); }
  }

  /* ---------- البناء ---------- */
  overlay.append(
    el('div', { class: 'ct-top' }, [
      el('button', { class: 'btn ghost icon', html: icon('chevronRight'), onclick: async () => { if (dirty && !await confirmDialog('فيه تغييرات مش محفوظة — قفل؟')) return; close(); } }),
      titleInput,
      statusPill,
      el('div', { class: 'grow' }),
      el('button', { class: 'btn sm', html: icon('send') + `<span>حفظ</span>`, onclick: () => doSave(false) }),
      el('button', {
        class: 'btn sm primary', html: icon('check') + `<span>للمراجعة</span>`,
        onclick: async () => {
          if (!doc.takes.length) { toast('سجّل take الأول', 'warn'); return; }
          await doSave(true);
          try {
            const res = await api.docSubmit('voices', doc.id, '');
            Object.assign(doc, { status: res.doc.status, review: res.doc.review });
            updateStatus(); drawSide();
            toast('اترسل للمراجعة ✓', 'ok');
          } catch (e) { toast(e.message, 'err'); }
        },
      }),
      id ? el('button', {
        class: 'btn ghost icon sm', html: icon('trash'), title: 'حذف',
        onclick: async () => { if (await confirmDialog('حذف التسجيل؟', { danger: true })) { await remove('voices', doc.id); close(); } },
      }) : null,
    ]),
    el('div', { class: 'ct-main' }, [
      el('div', { class: 'ct-editor' }, [
        el('div', { class: 'row wrap', style: { gap: '10px', marginBottom: '12px' } }, [
          el('button', { class: 'btn sm', html: icon('upload') + `<span>ارفع ملف صوتي</span>`, onclick: () => upInput.click() }),
          upInput,
          el('div', { class: 'grow' }),
          el('span', { class: 'dim', style: { fontSize: '12px' }, text: 'السكربت:' }),
          el('div', { style: { minWidth: '220px', flex: '1' } }, [scriptSel]),
        ]),
        scriptBox,
        el('div', { class: 'vs-rec' }, [
          micBtn,
          el('div', { class: 'grow' }, [
            el('div', { class: 'row', style: { gap: '8px' } }, [timer, el('span', { class: 'dim', style: { fontSize: '12px' }, text: recording ? 'جارٍ التسجيل…' : 'اضغط الميكروفون وابدأ' })]),
            meter,
          ]),
        ]),
        takesBox,
      ]),
      side,
    ]),
  );

  updateStatus(); drawScript(); drawTakes(); drawSide();
}
