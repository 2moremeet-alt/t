/* ============================================================
   MEEM — صفحة اعتماد العميل (عامة، بدون تسجيل دخول)
   /approve.html?t=<token>
   ============================================================ */
import { renderPage } from './editor/render.js';
import { ensureFonts } from './editor/fonts.js';

const main = document.getElementById('main');
const token = new URLSearchParams(location.search).get('t') || '';

function h(html) {
  const d = document.createElement('div');
  d.innerHTML = html;
  return d.firstElementChild;
}
function esc(s) {
  return String(s || '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

async function boot() {
  if (!token) return showError('الرابط ناقص — اطلب الرابط الصحيح من فريق MEEM');
  let data;
  try {
    const res = await fetch('/api/share/' + encodeURIComponent(token));
    data = await res.json();
    if (!res.ok || !data.ok) return showError(data.error || 'الرابط غير صالح أو تم إيقافه');
  } catch (e) {
    return showError('تعذّر الاتصال — حاول مرة أخرى');
  }
  render(data);
}

function showError(msg) {
  main.innerHTML = '';
  main.appendChild(h(`<div class="err"><div class="big">🔒</div><div>${esc(msg)}</div></div>`));
}

async function render(data) {
  main.innerHTML = '';
  const decided = data.client && data.client.decision;

  const chipCls = data.status === 'client_approved' ? 'approved' : data.status === 'changes' ? 'changes' : '';
  const chipText = data.status === 'client_approved' ? '✅ تم الاعتماد — شكرًا لك!'
    : data.status === 'changes' ? '✏️ استلمنا ملاحظاتك والفريق شغّال عليها'
      : 'بانتظار رأيك';

  main.appendChild(h(`<div class="chip ${chipCls}">${chipText}</div>`));
  main.appendChild(h(`<h1>${esc(data.title)}</h1>`));
  main.appendChild(h(`<p class="muted">من فريق MEEM Creative Office — شوف التصميم، ولو عاجبك اعتمده، ولو عايز تعديل اكتب ملاحظاتك وهتوصلنا فورًا.</p>`));

  // المعاينة بعلامة مائية
  const prev = h('<div class="preview"></div>');
  main.appendChild(prev);
  main.appendChild(h('<div class="wm-note">🔏 المعاينة بعلامة مائية — النسخة النهائية تُسلَّم بعد الاعتماد</div>'));
  try {
    const page = (data.pages || [])[0];
    if (page) {
      await ensureFonts(page.layers);
      const c = document.createElement('canvas');
      await renderPage(c, page, Math.min(1.4, 1400 / Math.max(page.w, page.h)));
      drawWatermark(c);
      prev.appendChild(c);
    } else {
      prev.appendChild(h('<div class="err">لا توجد معاينة</div>'));
    }
  } catch (e) {
    prev.appendChild(h(`<div class="err">تعذّر رسم المعاينة</div>`));
  }

  // نتيجة قرار سابق
  if (decided) {
    main.appendChild(h(`<div class="done"><div class="big">${decided === 'approve' ? '🎉' : '📨'}</div>
      <div style="font-weight:800;font-size:17px">${decided === 'approve' ? 'اعتمدت التصميم — شكرًا!' : 'وصلتنا ملاحظاتك'}</div>
      ${data.client.note ? `<p class="muted" style="margin-top:8px">«${esc(data.client.note)}»</p>` : ''}
      <p class="note">تقدر تغيّر رأيك من نفس الصفحة دي في أي وقت.</p></div>`));
  }

  // نموذج القرار
  const savedName = (() => { try { return localStorage.getItem('meem_client_name') || ''; } catch (e) { return ''; } })();
  const nameInp = h(`<input placeholder="اسمك (مثال: أ. أحمد)" value="${esc(savedName)}">`);
  const noteInp = h('<textarea rows="3" placeholder="ملاحظاتك (مطلوبة مع طلب التعديل)…"></textarea>');

  main.appendChild(h('<div class="field"><label>اسمك</label></div>')).appendChild(nameInp);
  main.appendChild(h('<div class="field"><label>ملاحظات</label></div>')).appendChild(noteInp);

  const btnA = h('<button class="approve">✓ اعتماد التصميم</button>');
  const btnC = h('<button class="changes">✏️ طلب تعديلات</button>');
  const btns = h('<div class="btns"></div>');
  btns.append(btnA, btnC);
  main.appendChild(btns);
  main.appendChild(h('<div class="note">قراراتك تُسجَّل باسمك وتوصل فريق MEEM لحظيًا</div>'));

  const send = async (decision) => {
    const name = nameInp.value.trim();
    const note = noteInp.value.trim();
    if (!name) { nameInp.focus(); nameInp.style.borderColor = '#fb7185'; return; }
    if (decision === 'changes' && !note) { noteInp.focus(); noteInp.style.borderColor = '#fb7185'; return; }
    btnA.disabled = btnC.disabled = true;
    try {
      localStorage.setItem('meem_client_name', name);
    } catch (e) { /* ignore */ }
    try {
      const res = await fetch('/api/share/' + encodeURIComponent(token) + '/decision', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, decision, note }),
      });
      const json = await res.json();
      if (!res.ok || !json.ok) throw new Error(json.error || 'HTTP ' + res.status);
      location.reload();
    } catch (e) {
      alert('تعذّر الإرسال: ' + e.message);
      btnA.disabled = btnC.disabled = false;
    }
  };
  btnA.onclick = () => send('approve');
  btnC.onclick = () => send('changes');
}

/* علامة مائية مائلة متكررة */
function drawWatermark(canvas) {
  const ctx = canvas.getContext('2d');
  ctx.save();
  ctx.globalAlpha = 0.16;
  ctx.fillStyle = '#ffffff';
  ctx.strokeStyle = 'rgba(0,0,0,.55)';
  ctx.lineWidth = Math.max(1, canvas.width / 900);
  const fs = Math.max(16, Math.round(canvas.width / 22));
  ctx.font = `800 ${fs}px Cairo, sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.translate(canvas.width / 2, canvas.height / 2);
  ctx.rotate(-Math.PI / 7);
  const step = fs * 4.4;
  for (let y = -canvas.height; y < canvas.height; y += step) {
    for (let x = -canvas.width; x < canvas.width; x += step * 1.9) {
      ctx.strokeText('MEEM · للمعاينة', x, y);
      ctx.fillText('MEEM · للمعاينة', x, y);
    }
  }
  ctx.restore();
}

boot();
