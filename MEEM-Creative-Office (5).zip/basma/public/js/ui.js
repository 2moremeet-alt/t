/* ============================================================
   MEEM | Creative Office — أدوات الواجهة (DOM / أيقونات / توست / مودال)
   ============================================================ */
import { t, getLang } from './i18n.js';
import { STATUS_COLOR, PRIORITY_COLOR } from './store.js';

/* ---------------- أيقونات (SVG inline) ---------------- */
const P = {
  brush: 'M9.06 11.9l8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08-4.04-4.05zM7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04 0-1.66-1.35-3.02-3-3.02z',
  eraser: 'M16.24 3.56l4.95 4.94c.78.79.78 2.05 0 2.84L12 20.53a4.008 4.008 0 0 1-5.66 0L2.81 17c-.78-.79-.78-2.05 0-2.84l10.6-10.6c.79-.78 2.05-.78 2.83 0M4.22 15.58l3.54 3.53c.78.79 2.04.79 2.83 0l3.53-3.53-4.95-4.95-4.95 4.95z',
  wand: 'M7.5 5.6L10 7 8.6 4.5 10 2 7.5 3.4 5 2l1.4 2.5L5 7zm12 9.8L17 14l1.4 2.5L17 19l2.5-1.4L22 19l-1.4-2.5L22 14zM22 2l-2.5 1.4L17 2l1.4 2.5L17 7l2.5-1.4L22 7l-1.4-2.5zm-7.63 5.29a.996.996 0 0 0-1.41 0L1.29 18.96a.996.996 0 0 0 0 1.41l2.34 2.34c.39.39 1.02.39 1.41 0L16.7 11.05a.996.996 0 0 0 0-1.41l-2.33-2.35z',
  dashboard: 'M4 13h6V4H4v9Zm0 7h6v-5H4v5Zm10 0h6v-9h-6v9Zm0-16v5h6V4h-6Z',
  content: 'M6 3h9l5 5v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Zm8 1.5V9h4.5L14 4.5ZM8 12h8v1.6H8V12Zm0 3.4h8V17H8v-1.6Zm0 3.4h5v1.6H8v-1.6Z',
  voice: 'M12 3a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V6a3 3 0 0 1 3-3Zm5 9a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V22h2v-3.08A7 7 0 0 0 19 12h-2Z',
  design: 'M12 2a10 10 0 0 0 0 20c1.1 0 2-.9 2-2v-1.5a2 2 0 0 1 2-2H18a4 4 0 0 0 4-4C22 6.5 17.5 2 12 2ZM6.5 12a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm3-4.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm3 4.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Z',
  delivery: 'M3 6h11v9H3V6Zm12 2h3.2l2.8 3.4V15h-6V8ZM6.5 19a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Zm11 0a1.8 1.8 0 1 0 0-3.6 1.8 1.8 0 0 0 0 3.6Z',
  code: 'M9.4 16.6 4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4Zm5.2 0 4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4Z',
  meet: 'M17 10.5V7a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3.5l4 4v-11l-4 4Z',
  users: 'M16 11a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm-8 1a3.5 3.5 0 1 0-3.5-3.5A3.5 3.5 0 0 0 8 12Zm0 2c-2.7 0-8 1.34-8 4v2h9v-2c0-1.1.6-2.1 1.6-2.9A15 15 0 0 0 8 14Zm8 0c-3.3 0-9 1.66-9 4v2h18v-2c0-2.34-5.7-4-9-4Z',
  clients: 'M12 2 3 6v6c0 5 3.8 9.7 9 11 5.2-1.3 9-6 9-11V6l-9-4Zm0 4.2 5 2.2v3.6c0 3.6-2.5 6.9-5 7.8-2.5-.9-5-4.2-5-7.8V8.4l5-2.2Z',
  folder: 'M4 5h6l2 2h8a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1Z',
  plus: 'M11 5h2v6h6v2h-6v6h-2v-6H5v-2h6V5Z',
  search: 'M10 3a7 7 0 1 0 4.2 12.6l4.6 4.6 1.4-1.4-4.6-4.6A7 7 0 0 0 10 3Zm0 2a5 5 0 1 1 0 10 5 5 0 0 1 0-10Z',
  close: 'm6.4 5 5.6 5.6L17.6 5 19 6.4 13.4 12 19 17.6 17.6 19 12 13.4 6.4 19 5 17.6 10.6 12 5 6.4 6.4 5Z',
  check: 'm9 16.2-4.2-4.2L3.4 13.4 9 19 20.6 7.4l-1.4-1.4L9 16.2Z',
  checkCircle: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm-1.2 14.2-4-4 1.4-1.4 2.6 2.6 5.6-5.6 1.4 1.4-7 7Z',
  edit: 'M3 17.2V21h3.8L17.8 10 14 6.2 3 17.2ZM20.7 7.1a1 1 0 0 0 0-1.4l-2.4-2.4a1 1 0 0 0-1.4 0L15 5.2 18.8 9l1.9-1.9Z',
  trash: 'M6 7h12l-1 13a1 1 0 0 1-1 1H8a1 1 0 0 1-1-1L6 7Zm3-4h6l1 2h4v2H4V5h4l1-2Z',
  download: 'M12 3v10.2l3.6-3.6 1.4 1.4L11 17l-6-6 1.4-1.4L10 13.2V3h2ZM4 19h16v2H4v-2Z',
  upload: 'M12 21V10.8l-3.6 3.6L7 13l6-6 6 6-1.4 1.4L14 10.8V21h-2ZM4 3h16v2H4V3Z',
  send: 'M2 21 23 12 2 3l4 8-4 10Zm4.5-9L5 8.6 17 12 5 15.4 6.5 12Z',
  mic: 'M12 3a3 3 0 0 1 3 3v6a3 3 0 0 1-6 0V6a3 3 0 0 1 3-3Zm5 9a5 5 0 0 1-10 0H5a7 7 0 0 0 6 6.92V22h2v-3.08A7 7 0 0 0 19 12h-2Z',
  micOff: 'M19 12h-2a5 5 0 0 1-1.5 3.6l1.4 1.4A7 7 0 0 0 19 12ZM9 6a3 3 0 0 1 5.8-1.1L9.7 10A3 3 0 0 1 9 6Zm-6.3-.9 1.4-1.4 16.2 16.2-1.4 1.4-3-3A7 7 0 0 1 5 12H7a5 5 0 0 0 6.6 4.8l-1.9-1.9a3 3 0 0 1-3.7-3V9.7L2.7 5.1Z',
  video: 'M17 10.5V7a1 1 0 0 0-1-1H4a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-3.5l4 4v-11l-4 4Z',
  videoOff: 'M21 6.5 17 10.5V7a1 1 0 0 0-1-1h-3.2L21 14.2V6.5ZM3.3 2 19 17.7 17.6 19l-1.8-1.8A1 1 0 0 1 16 18H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h1.2L2 3.4 3.3 2Z',
  screen: 'M3 4h18a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-6v2h3v2H8v-2h3v-2H3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Zm1 2v8h16V6H4Z',
  phone: 'M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.2 11 11 0 0 0 3.5.6 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1 11 11 0 0 0 .6 3.5 1 1 0 0 1-.3 1l-2.2 2.3Z',
  phoneOff: 'M12 9c2.4 0 4.7.5 6.8 1.4l-1.6 1.6a11 11 0 0 0-3-.5c-.4-1.5-.5-2.5-.5-2.5H12ZM2.7 2 21 20.3 19.6 21.7l-2.3-2.3A16.9 16.9 0 0 1 3 4h3.5a11 11 0 0 0 .5 2.7L5 8.7a1 1 0 0 1-1 .2A11 11 0 0 1 .5 8.4a1 1 0 0 1-1-1V4A17 17 0 0 0 5.6 18.3L2 20.3 3.3 21.7 21 4l-1.4-1.4L2.7 2Z',
  chat: 'M4 4h16a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H8l-5 4V5a1 1 0 0 1 1-1Z',
  calendar: 'M7 2v2H5a1 1 0 0 0-1 1v15a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V5a1 1 0 0 0-1-1h-2V2h-2v2H9V2H7Zm12 8v10H5V10h14Zm-9 3H8v2h2v-2Zm4 0h-2v2h2v-2Zm4 0h-2v2h2v-2Z',
  clock: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm1 10.6 4 2.3-1 1.7-5-2.9V6h2v6.6Z',
  bell: 'M12 2a6 6 0 0 1 6 6v4l2 3H4l2-3V8a6 6 0 0 1 6-6Zm-2 16h4a2 2 0 1 1-4 0Z',
  settings: 'M19.4 13a7.8 7.8 0 0 0 0-2l2-1.6-2-3.4-2.4 1a7.6 7.6 0 0 0-1.7-1L15 3H9l-.3 2.6a7.6 7.6 0 0 0-1.7 1l-2.4-1-2 3.4L4.6 11a7.8 7.8 0 0 0 0 2l-2 1.6 2 3.4 2.4-1a7.6 7.6 0 0 0 1.7 1L9 21h6l.3-2.6a7.6 7.6 0 0 0 1.7-1l2.4 1 2-3.4-2-1.6ZM12 15.5A3.5 3.5 0 1 1 12 8.5a3.5 3.5 0 0 1 0 7Z',
  layers: 'm12 2 10 5.5L12 13 2 7.5 12 2Zm7.5 8.3L22 11.7 12 17.2 2 11.7l2.5-1.4L12 14.4l7.5-4.1Zm0 4.5L22 16.2 12 21.7 2 16.2l2.5-1.4 7.5 4.1 7.5-4.1Z',
  text: 'M5 4h14v3h-2V6h-4v12h2v2H9v-2h2V6H7v1H5V4Z',
  image: 'M4 4h16a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Zm1 2v9.2l4-4 3.5 3.5L16 11l4 4V6H5Zm3 4a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Z',
  shapes: 'M4 4h8v8H4V4Zm10 0 5 4.5L14 13V4ZM8 14a4 4 0 1 1 0 8 4 4 0 0 1 0-8Z',
  star: 'm12 2 2.9 6.3 6.9.8-5.1 4.7 1.4 6.8L12 17.3 5.9 20.6l1.4-6.8L2.2 9.1l6.9-.8L12 2Z',
  undo: 'M9 7V3L3 8l6 5V9h5a5 5 0 1 1 0 10h-4v2h4a7 7 0 1 0 0-14H9Z',
  redo: 'M15 7V3l6 5-6 5V9h-5a5 5 0 1 0 0 10H6v2h4a7 7 0 1 1 0-14h5Z',
  lock: 'M12 2a4 4 0 0 1 4 4v3h1a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V10a1 1 0 0 1 1-1h1V6a4 4 0 0 1 4-4Zm0 2a2 2 0 0 0-2 2v3h4V6a2 2 0 0 0-2-2Z',
  eye: 'M12 5c5 0 9 4.5 10 7-1 2.5-5 7-10 7S3 14.5 2 12c1-2.5 5-7 10-7Zm0 3.5A3.5 3.5 0 1 0 12 15.5 3.5 3.5 0 0 0 12 8.5Z',
  eyeOff: 'M2 4.3 3.4 2.9 21.1 20.6 19.7 22l-3.4-3.4A11.5 11.5 0 0 1 12 19C7 19 3 14.5 2 12c.5-1.2 1.6-2.9 3.2-4.3L2 4.3Zm10 4.2a3.5 3.5 0 0 0 3.4 4.3l-3.4-4.3ZM12 5c5 0 9 4.5 10 7-.4 1-1.3 2.4-2.6 3.7L16.8 13A3.5 3.5 0 0 0 12 8.4l-1.6-1.6A10.6 10.6 0 0 1 12 5Z',
  grid: 'M4 4h7v7H4V4Zm9 0h7v7h-7V4ZM4 13h7v7H4v-7Zm9 0h7v7h-7v-7Z',
  ruler: 'M3 8h18v8H3V8Zm2 2v1.5h1.5V10H5Zm3 0v3h1.5v-3H8Zm3 0v1.5h1.5V10h-1.5Zm3 0v3H15.5v-3H14Zm3 0v1.5h1.5V10h-1.5Z',
  copy: 'M8 2h10a1 1 0 0 1 1 1v12h-2V4H8V2Zm-4 4h10a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1Zm1 2v11h8V8H5Z',
  play: 'M7 4l12 8-12 8V4Z',
  pause: 'M7 4h4v16H7V4Zm6 0h4v16h-4V4Z',
  stop: 'M6 6h12v12H6V6Z',
  hand: 'M7 11V5.5a1.5 1.5 0 0 1 3 0V11h.5V4a1.5 1.5 0 0 1 3 0v7h.5V5.5a1.5 1.5 0 0 1 3 0V16a6 6 0 0 1-6 6h-1a6 6 0 0 1-6-6v-3.5a1.5 1.5 0 0 1 3 0V11Z',
  filter: 'M3 5h18l-7 8v6l-4 2v-8L3 5Z',
  menu: 'M3 6h18v2H3V6Zm0 5h18v2H3v-2Zm0 5h18v2H3v-2Z',
  chevron: 'm12 8 6 6-1.4 1.4L12 10.8l-4.6 4.6L6 14l6-6Z',
  chevronRight: 'm10 6 6 6-6 6-1.4-1.4L13.2 12 8.6 7.4 10 6Z',
  chevronLeft: 'm14 6 1.4 1.4L10.8 12l4.6 4.6L14 18l-6-6 6-6Z',
  arrowUp: 'M12 4 4 12h5v8h6v-8h5L12 4Z',
  refresh: 'M12 4V1L8 5l4 4V6a6 6 0 1 1-6 6H4a8 8 0 1 0 8-8Z',
  logout: 'M16 13v-2H7V8l-5 4 5 4v-3h9Zm3-9H12v2h7v12h-7v2h7a1 1 0 0 0 1-1V5a1 1 0 0 0-1-1Z',
  globe: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm6.9 6h-2.6a15 15 0 0 0-1.4-3.4A8 8 0 0 1 18.9 8ZM12 4.1c.7 1 1.3 2.3 1.7 3.9h-3.4c.4-1.6 1-2.9 1.7-3.9ZM4.3 14a8.3 8.3 0 0 1 0-4h3a17 17 0 0 0 0 4h-3Zm.8 2h2.6c.4 1.3.8 2.5 1.4 3.4A8 8 0 0 1 5.1 16Zm2.6-8H5.1a8 8 0 0 1 4-3.4A15 15 0 0 0 7.7 8ZM12 19.9c-.7-1-1.3-2.3-1.7-3.9h3.4c-.4 1.6-1 2.9-1.7 3.9ZM14 14H10a15 15 0 0 1 0-4h4a15 15 0 0 1 0 4Zm1 5.4c.5-.9 1-2.1 1.3-3.4h2.6a8 8 0 0 1-4 3.4ZM16.7 14a17 17 0 0 0 0-4h3a8.3 8.3 0 0 1 0 4h-3Z',
  moon: 'M12 3a9 9 0 1 0 9 9 7 7 0 0 1-9-9Z',
  sun: 'M12 6a6 6 0 1 0 0 12 6 6 0 0 0 0-12Zm-1-6h2v3h-2V0Zm0 21h2v3h-2v-3ZM0 11h3v2H0v-2Zm21 0h3v2h-3v-2ZM4.2 2.8l1.4-1.4 2.1 2.1-1.4 1.4L4.2 2.8Zm12 12 1.4-1.4 2.1 2.1-1.4 1.4-2.1-2.1ZM16.2 4.9l2.1-2.1 1.4 1.4-2.1 2.1-1.4-1.4ZM4.2 16.9l2.1-2.1 1.4 1.4-2.1 2.1-1.4-1.4Z',
  kanban: 'M4 3h4v18H4V3Zm6 0h4v12h-4V3Zm6 0h4v15h-4V3Z',
  template: 'M3 3h18v6H3V3Zm0 8h8v10H3V11Zm10 0h8v4h-8v-4Zm0 6h8v4h-8v-4Z',
  sparkles: 'm12 2 1.8 5.2L19 9l-5.2 1.8L12 16l-1.8-5.2L5 9l5.2-1.8L12 2Zm7 11 .9 2.6 2.6.9-2.6.9L19 20l-.9-2.6-2.6-.9 2.6-.9.9-2.6ZM5 13l.7 2 2 .7-2 .7-.7 2-.7-2-2-.7 2-.7.7-2Z',
  print: 'M6 3h12v5H6V3Zm-3 6h18a1 1 0 0 1 1 1v7h-4v4H6v-4H2v-7a1 1 0 0 1 1-1Zm5 5v4h8v-4H8Z',
  file: 'M6 2h8l5 5v13a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1Zm7 1.5V8h4.5L13 3.5Z',
  money: 'M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Zm1 13.9V19h-2v-2.1a3 3 0 0 1-2-2.8h2a1 1 0 1 0 1-1 3 3 0 0 1 1-5.8V6h2v1.3a3 3 0 0 1 2 2.8h-2a1 1 0 1 0-1 1 3 3 0 0 1-1 5.8Z',
  warning: 'M12 2 1 21h22L12 2Zm-1 7h2v6h-2V9Zm0 8h2v2h-2v-2Z',
  info: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm-1 5h2v2h-2V7Zm0 4h2v6h-2v-6Z',
  drag: 'M9 4h2v2H9V4Zm4 0h2v2h-2V4ZM9 9h2v2H9V9Zm4 0h2v2h-2V9Zm-4 5h2v2H9v-2Zm4 0h2v2h-2v-2Zm-4 5h2v2H9v-2Zm4 0h2v2h-2v-2Z',
  palette: 'M12 2a10 10 0 0 0 0 20c1.1 0 2-.9 2-2v-1a2 2 0 0 1 2-2h1a4 4 0 0 0 4-4C21 6.5 17 2 12 2ZM6.5 12a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm3-4.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm5 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Zm3 4.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3Z',
  align: 'M3 4h18v2H3V4Zm4 4h10v2H7V8Zm-4 4h18v2H3v-2Zm4 4h10v2H7v-2Zm-4 4h18v2H3v-2Z',
  crop: 'M7 3h2v14h12v2H7V3Zm10 4h2v14H5v-2h12V7Z',
  zoom: 'M10 3a7 7 0 1 0 4.2 12.6l4.6 4.6 1.4-1.4-4.6-4.6A7 7 0 0 0 10 3Zm0 2a5 5 0 1 1 0 10 5 5 0 0 1 0-10ZM9 8h2v2h2v2h-2v2H9v-2H7v-2h2V8Z',
  bolt: 'M13 2 4 14h6l-1 8 9-12h-6l1-8Z',
  target: 'M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20Zm0 4a6 6 0 1 1 0 12 6 6 0 0 1 0-12Zm0 4a2 2 0 1 0 0 4 2 2 0 0 0 0-4Z',
  box: 'M12 2 3 7v10l9 5 9-5V7l-9-5Zm0 2.3 6.5 3.6L12 11.5 5.5 7.9 12 4.3ZM5 9.6l6 3.3v6.8l-6-3.3V9.6Zm8 10.1v-6.8l6-3.3v6.8l-6 3.3Z',
  wave: 'M2 12h2l2-7 3 14 3-11 2 6 2-2h4v2h-3l-3.4 3.4L11.4 10 8.6 20 5.6 6 4.2 14H2v-2Z',
  building: 'M4 21V3h10v18H4Zm2-16h2v2H6V5Zm4 0h2v2h-2V5Zm-4 4h2v2H6V9Zm4 0h2v2h-2V9Zm-4 4h2v2H6v-2Zm4 0h2v2h-2v-2Zm4-9h4v16h-4V5Z',
  whatsapp: 'M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm0 2a8 8 0 1 1-4.2 14.8l-.4-.2-2.6.7.7-2.5-.2-.4A8 8 0 0 1 12 4Zm-3 4c-.3 0-.6.1-.8.4-.3.3-.9.9-.9 2.1s.9 2.4 1 2.6c.1.2 1.7 2.8 4.3 3.8 2.1.8 2.6.7 3 .6.6-.1 1.7-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.1-.3-.2-.6-.3l-2-1c-.3-.1-.5-.1-.7.1l-.7.9c-.2.2-.3.2-.6.1-.3-.2-1.3-.5-2.4-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.6l.5-.6c.1-.2.2-.3.3-.5v-.5l-.8-2c-.2-.5-.4-.4-.6-.4h-.4Z',
  drive: 'M8.8 3h6.4L23 16h-6.4L8.8 3Zm-.9 1.6L1.3 16h6.4l6.8-11.4H7.9ZM2.4 18l3.2 5.5h12.8l3.2-5.5H2.4Z',
  mail: 'M3 4h18a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Zm1 3.2V18h16V7.2l-8 5-8-5ZM4.6 6l7.4 4.6L19.4 6H4.6Z',
  qr: 'M3 3h8v8H3V3Zm2 2v4h4V5H5Zm9-2h8v8h-8V3Zm2 2v4h4V5h-4ZM3 13h8v8H3v-8Zm2 2v4h4v-4H5Zm13-2h3v3h-3v-3Zm-4 0h3v3h-3v-3Zm4 4h3v3h-3v-3Zm-4 0h3v3h-3v-3Zm4 4h3v3h-3v-3Zm-8-8h3v3h-3v-3Z',
  history: 'M12 2a10 10 0 1 0 9.95 9h-2.01A8 8 0 1 1 12 4V1L8 5l4 4V6a6 6 0 1 1-6 6H4a8 8 0 1 0 8-10Zm-1 5v5.4l4.3 2.6.8-1.3-3.6-2.1V7h-1.5Z',
};

export function icon(name, cls) {
  const d = P[name];
  if (!d) return `<svg viewBox="0 0 24 24" class="${cls || ''}"></svg>`;
  return `<svg viewBox="0 0 24 24" class="${cls || ''}" fill="currentColor" aria-hidden="true"><path d="${d}"/></svg>`;
}

/* ---------------- DOM helpers ---------------- */

export function el(tag, attrs, children) {
  const node = document.createElement(tag);
  if (attrs) {
    for (const k of Object.keys(attrs)) {
      const v = attrs[k];
      if (v == null || v === false) continue;
      if (k === 'class') node.className = v;
      else if (k === 'html') node.innerHTML = v;
      else if (k === 'text') node.textContent = v;
      else if (k === 'style' && typeof v === 'object') { for (const sk of Object.keys(v)) { if (sk.startsWith('--')) node.style.setProperty(sk, v[sk]); else node.style[sk] = v[sk]; } }
      else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === 'dataset') Object.assign(node.dataset, v);
      else node.setAttribute(k, v === true ? '' : v);
    }
  }
  if (children != null) append(node, children);
  return node;
}

export function append(parent, children) {
  const list = Array.isArray(children) ? children : [children];
  list.forEach((c) => {
    if (c == null || c === false) return;
    parent.appendChild(typeof c === 'string' || typeof c === 'number' ? document.createTextNode(String(c)) : c);
  });
  return parent;
}

export function h(strings, ...vals) {
  const tpl = document.createElement('template');
  tpl.innerHTML = strings.reduce((acc, s, i) => acc + s + (vals[i - 1] == null ? '' : vals[i - 1]), '');
  return tpl.content.firstElementChild;
}

export function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }

/* ---------------- Toast ---------------- */

export function toast(message, kind = 'info', ms = 3200) {
  const host = document.getElementById('toasts');
  const ic = { ok: 'checkCircle', err: 'warning', warn: 'warning', info: 'info' }[kind] || 'info';
  const node = el('div', { class: `toast ${kind}` }, [
    el('span', { class: 'ti', html: icon(ic) }),
    el('span', { text: message }),
  ]);
  host.appendChild(node);
  setTimeout(() => {
    node.classList.add('out');
    setTimeout(() => node.remove(), 260);
  }, ms);
  return node;
}

/* ---------------- Modal ---------------- */

let modalStack = [];

export function modal(opts) {
  const { title, body, footer, size = '', onClose } = opts;
  const backdrop = el('div', { class: 'modal-backdrop', onclick: (e) => { if (e.target === backdrop) close(); } });
  const box = el('div', { class: 'modal ' + size });
  const head = el('div', { class: 'modal-head' }, [
    el('h3', { text: title || '' }),
    el('button', { class: 'btn ghost icon sm', 'aria-label': 'close', onclick: close, html: icon('close') }),
  ]);
  const bodyNode = el('div', { class: 'modal-body' });
  append(bodyNode, body);
  box.append(head, bodyNode);
  if (footer) {
    const foot = el('div', { class: 'modal-foot' });
    append(foot, footer);
    box.appendChild(foot);
  }
  backdrop.appendChild(box);
  document.getElementById('modal-root').appendChild(backdrop);
  modalStack.push(backdrop);
  function close() {
    backdrop.remove();
    modalStack = modalStack.filter((m) => m !== backdrop);
    if (onClose) onClose();
  }
  const onEsc = (e) => { if (e.key === 'Escape' && modalStack[modalStack.length - 1] === backdrop) close(); };
  document.addEventListener('keydown', onEsc);
  const origClose = close;
  return { close: () => { document.removeEventListener('keydown', onEsc); origClose(); }, body: bodyNode, box };
}

export function confirmDialog(message, { title, danger = false, okLabel, cancelLabel } = {}) {
  return new Promise((resolve) => {
    const m = modal({
      title: title || t('areYouSure'),
      size: '',
      body: [el('p', { class: 'muted', text: message })],
      footer: [
        el('button', { class: 'btn ghost', text: cancelLabel || t('cancel'), onclick: () => { resolve(false); m.close(); } }),
        /* V2-12 fix: resolve قبل close — لأن close() بينادي onClose (resolve(false)) sync */
        el('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), text: okLabel || t('confirm'), onclick: () => { resolve(true); m.close(); } }),
      ],
      onClose: () => resolve(false),
    });
  });
}

export function promptDialog(label, value = '', { title, placeholder, textarea = false } = {}) {
  return new Promise((resolve) => {
    const input = el(textarea ? 'textarea' : 'input', { class: textarea ? 'textarea' : 'input', value, placeholder });
    const m = modal({
      title: title || label,
      body: [el('div', { class: 'field' }, [el('label', { text: label }), input])],
      footer: [
        el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => { m.close(); resolve(null); } }),
        el('button', { class: 'btn primary', text: t('ok'), onclick: () => { m.close(); resolve(input.value); } }),
      ],
      onClose: () => resolve(null),
    });
    setTimeout(() => input.focus(), 60);
  });
}

/* ---------------- Formatting ---------------- */

export function avatarHTML(user, size = '') {
  if (!user) return `<div class="avatar ${size}" style="background:var(--text-3)">؟</div>`;
  const letter = getLang() === 'ar' ? (user.initials || (user.name || '?')[0]) : (user.nameEn || user.name || '?')[0].toUpperCase();
  return `<div class="avatar ${size}" style="background:${user.avatarColor || 'var(--brand)'}" title="${escapeHTML(user.name)}">${escapeHTML(letter)}</div>`;
}

export function statusBadge(status) {
  return `<span class="badge ${STATUS_COLOR[status] || ''}"><i class="dot"></i>${t('st_' + status)}</span>`;
}

export function priorityBadge(p) {
  if (!p) return '';
  return `<span class="badge ${PRIORITY_COLOR[p] || ''}">${t(p)}</span>`;
}

export function formatDate(d, withTime = false) {
  if (!d) return '—';
  const date = new Date(d);
  if (isNaN(date)) return '—';
  const loc = getLang() === 'ar' ? 'ar-EG' : 'en-GB';
  const opts = { day: 'numeric', month: 'short' };
  if (withTime) Object.assign(opts, { hour: '2-digit', minute: '2-digit' });
  try { return new Intl.DateTimeFormat(loc, opts).format(date); } catch (e) { return date.toISOString().slice(0, 10); }
}

export function dueLabel(due) {
  if (!due) return '';
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const d = new Date(due + 'T00:00:00');
  const diff = Math.round((d - today) / 86400000);
  if (diff === 0) return t('today');
  if (diff === 1) return t('tomorrow');
  if (diff === -1) return t('yesterday');
  if (diff < 0) return `${Math.abs(diff)}${getLang() === 'ar' ? ' يوم متأخر' : 'd overdue'}`;
  return formatDate(due);
}

export function timeAgo(iso) {
  if (!iso) return '';
  const s = Math.floor((Date.now() - new Date(iso)) / 1000);
  const ar = getLang() === 'ar';
  if (s < 60) return ar ? 'الآن' : 'just now';
  if (s < 3600) return ar ? `منذ ${Math.floor(s / 60)} دقيقة` : `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return ar ? `منذ ${Math.floor(s / 3600)} ساعة` : `${Math.floor(s / 3600)}h ago`;
  if (s < 86400 * 7) return ar ? `منذ ${Math.floor(s / 86400)} يوم` : `${Math.floor(s / 86400)}d ago`;
  return formatDate(iso);
}

export function escapeHTML(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export function debounce(fn, ms = 250) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}

export function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }

/* ---------------- Phase 6: helpers مالية ---------------- */
export function money(n) {
  return Math.round(+n || 0).toLocaleString('en-US') + ' ج.م';
}
export function invSubtotal(inv) {
  return (inv.items || []).reduce((s, i) => s + (+i.qty || 0) * (+i.price || 0), 0);
}
export function invTotal(inv) {
  return Math.round(invSubtotal(inv) * (1 + (+inv.tax || 0) / 100) - (+inv.discount || 0));
}
