/* ============================================================
   MEEM | Creative Office — Phase 4: محرك الصوت
   تسجيل + Waveform + Trim + Gain + Fade + EQ → WAV
   ============================================================ */

let recorder = null;
let chunks = [];

export function micSupported() {
  return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);
}

export async function startRecording(onLevel) {
  const stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
  chunks = [];
  const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : (MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : '');
  recorder = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
  recorder.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
  recorder.start(200);
  // level meter
  let ctx, analyser, raf;
  try {
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    const src = ctx.createMediaStreamSource(stream);
    analyser = ctx.createAnalyser();
    analyser.fftSize = 512;
    src.connect(analyser);
    const buf = new Uint8Array(analyser.frequencyBinCount);
    const tick = () => {
      analyser.getByteTimeDomainData(buf);
      let peak = 0;
      for (let i = 0; i < buf.length; i++) peak = Math.max(peak, Math.abs(buf[i] - 128) / 128);
      onLevel && onLevel(peak);
      raf = requestAnimationFrame(tick);
    };
    tick();
  } catch (e) { /* no meter */ }
  recorder.__cleanup = () => {
    cancelAnimationFrame(raf);
    stream.getTracks().forEach((t) => t.stop());
    if (ctx && ctx.state !== 'closed') ctx.close().catch(() => {});
  };
  return recorder;
}

export function stopRecording() {
  return new Promise((resolve) => {
    if (!recorder) return resolve(null);
    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: recorder.mimeType || 'audio/webm' });
      recorder.__cleanup && recorder.__cleanup();
      recorder = null;
      resolve(blob);
    };
    recorder.stop();
  });
}

export function blobToDataURL(blob) {
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(fr.result);
    fr.onerror = reject;
    fr.readAsDataURL(blob);
  });
}

export async function decodeAudio(dataUrl) {
  const b64 = dataUrl.split(',')[1] || '';
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const ctx = new (window.OfflineAudioContext || window.AudioContext)(1, 44100, 44100);
  const buf = await ctx.decodeAudioData(bytes.buffer.slice(0));
  try { ctx.close && ctx.close(); } catch (e) {}
  return buf;
}

export function computePeaks(buffer, n = 120) {
  const data = buffer.getChannelData(0);
  const block = Math.max(1, Math.floor(data.length / n));
  const peaks = [];
  for (let i = 0; i < n; i++) {
    let max = 0;
    const start = i * block;
    const end = Math.min(data.length, start + block);
    for (let j = start; j < end; j += 8) max = Math.max(max, Math.abs(data[j]));
    peaks.push(max);
  }
  return peaks;
}

export function formatTime(sec) {
  sec = Math.max(0, Math.floor(sec || 0));
  const m = Math.floor(sec / 60), s = sec % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

/* معالجة: trim + gain + fades + EQ → WAV dataURL */
export async function renderProcessed(dataUrl, opts = {}) {
  const { trimStart = 0, trimEnd = null, gain = 1, fadeIn = 0, fadeOut = 0, bass = 0, treble = 0 } = opts;
  const src = await decodeAudio(dataUrl);
  const start = Math.max(0, Math.min(trimStart, src.duration - 0.05));
  const end = Math.min(trimEnd == null ? src.duration : trimEnd, src.duration);
  const dur = Math.max(0.05, end - start);
  const rate = src.sampleRate;
  const ctx = new OfflineAudioContext(1, Math.ceil(dur * rate), rate);

  const node = ctx.createBufferSource();
  node.buffer = src;

  let tail = node;
  if (bass) {
    const f = ctx.createBiquadFilter();
    f.type = 'lowshelf'; f.frequency.value = 200; f.gain.value = bass;
    tail.connect(f); tail = f;
  }
  if (treble) {
    const f = ctx.createBiquadFilter();
    f.type = 'highshelf'; f.frequency.value = 3200; f.gain.value = treble;
    tail.connect(f); tail = f;
  }
  const g = ctx.createGain();
  g.gain.setValueAtTime(gain, 0);
  if (fadeIn > 0) { g.gain.setValueAtTime(0.0001, 0); g.gain.linearRampToValueAtTime(gain, Math.min(fadeIn, dur / 2)); }
  if (fadeOut > 0) {
    const fo = Math.min(fadeOut, dur / 2);
    g.gain.setValueAtTime(gain, Math.max(0, dur - fo));
    g.gain.linearRampToValueAtTime(0.0001, dur);
  }
  tail.connect(g);
  g.connect(ctx.destination);

  node.start(0, start, dur);
  const rendered = await ctx.startRendering();
  return audioBufferToWavURL(rendered);
}

export function audioBufferToWavURL(buffer) {
  const numCh = buffer.numberOfChannels;
  const len = buffer.length;
  const sampleRate = buffer.sampleRate;
  const bytes = 44 + len * numCh * 2;
  const ab = new ArrayBuffer(bytes);
  const view = new DataView(ab);
  const wstr = (off, s) => { for (let i = 0; i < s.length; i++) view.setUint8(off + i, s.charCodeAt(i)); };
  wstr(0, 'RIFF'); view.setUint32(4, bytes - 8, true); wstr(8, 'WAVE');
  wstr(12, 'fmt '); view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); view.setUint16(22, numCh, true);
  view.setUint32(24, sampleRate, true); view.setUint32(28, sampleRate * numCh * 2, true);
  view.setUint16(32, numCh * 2, true); view.setUint16(34, 16, true);
  wstr(36, 'data'); view.setUint32(40, len * numCh * 2, true);
  const chans = [];
  for (let c = 0; c < numCh; c++) chans.push(buffer.getChannelData(c));
  let off = 44;
  for (let i = 0; i < len; i++) {
    for (let c = 0; c < numCh; c++) {
      let v = Math.max(-1, Math.min(1, chans[c][i]));
      view.setInt16(off, v < 0 ? v * 0x8000 : v * 0x7fff, true);
      off += 2;
    }
  }
  const blob = new Blob([ab], { type: 'audio/wav' });
  return blobToDataURL(blob);
}

export function drawWaveform(canvas, peaks, opts = {}) {
  const { progress = 0, color = '#0066ff', bg = 'rgba(255,255,255,.08)', trimA = null, trimB = null } = opts;
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth || 300, h = canvas.clientHeight || 48;
  canvas.width = w * dpr; canvas.height = h * dpr;
  const g = canvas.getContext('2d');
  g.scale(dpr, dpr);
  g.clearRect(0, 0, w, h);
  g.fillStyle = bg;
  g.fillRect(0, 0, w, h);
  if (trimA != null && trimB != null) {
    g.fillStyle = 'rgba(0,102,255,.14)';
    g.fillRect(trimA * w, 0, (trimB - trimA) * w, h);
  }
  const n = peaks.length;
  const bw = w / n;
  for (let i = 0; i < n; i++) {
    const amp = Math.max(0.02, peaks[i]);
    const bh = amp * (h - 6);
    g.fillStyle = i / n <= progress ? color : 'rgba(255,255,255,.35)';
    g.fillRect(i * bw, (h - bh) / 2, Math.max(1, bw - 1), bh);
  }
}
