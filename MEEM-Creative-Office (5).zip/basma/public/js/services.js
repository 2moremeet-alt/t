/* ============================================================
   MEE M — Services Config (V2-13)
   الفورمات الديناميكية لكل خدمة — صفحة «اطلب مشروع» العامة
   ============================================================ */
export const SERVICES = [
  {
    id: 'design', ar: 'تصميم جرافيك', en: 'Graphic Design', ic: '🎨',
    fields: [
      { k: 'designType', label: 'نوع التصميم', labelEn: 'Design type', type: 'select', required: true, options: ['لوجو/هوية', 'سوشيال ميديا', 'مطبوعات', 'تغليف', 'واجهات UI/UX', 'موشن'] },
      { k: 'qty', label: 'عدد التصميمات', labelEn: 'Quantity', type: 'number', required: true },
      { k: 'sizes', label: 'مقاسات/تفاصيل مطلوبة', labelEn: 'Sizes / details', type: 'textarea' },
      { k: 'deadline', label: 'التسليم المطلوب', labelEn: 'Deadline', type: 'date' },
    ],
  },
  {
    id: 'content', ar: 'كتابة محتوى', en: 'Content Writing', ic: '✍️',
    fields: [
      { k: 'contentType', label: 'نوع المحتوى', labelEn: 'Content type', type: 'select', required: true, options: ['بوستات سوشيال', 'مقال/مدونة', 'سكربت فيديو', 'نصوص موقع', 'حملة إعلانية'] },
      { k: 'count', label: 'العدد المطلوب', labelEn: 'Quantity', type: 'number', required: true },
      { k: 'lang', label: 'اللغة', labelEn: 'Language', type: 'select', required: true, options: ['عربي', 'إنجليزي', 'الاتنين'] },
      { k: 'topic', label: 'الموضوع/الكلمات المفتاحية', labelEn: 'Topic / keywords', type: 'textarea' },
    ],
  },
  {
    id: 'voice', ar: 'فويس أوفر', en: 'Voice Over', ic: '🎙️',
    fields: [
      { k: 'voiceType', label: 'نوع التسجيل', labelEn: 'Recording type', type: 'select', required: true, options: ['إعلان', 'IVR/رد آلي', 'وثائقي', 'دبلجة', 'بودكاست'] },
      { k: 'duration', label: 'المدة', labelEn: 'Duration', type: 'select', required: true, options: ['15 ثانية', '30 ثانية', '60 ثانية', 'أكتر'] },
      { k: 'lang', label: 'اللغة/اللهجة', labelEn: 'Language / accent', type: 'select', required: true, options: ['عربي فصحى', 'مصري', 'خليجي', 'إنجليزي'] },
      { k: 'script', label: 'السكربت (لو جاهز)', labelEn: 'Script (if ready)', type: 'textarea' },
    ],
  },
  {
    id: 'dev', ar: 'موقع/تطبيق', en: 'Web & Apps', ic: '💻',
    fields: [
      { k: 'projectType', label: 'نوع المشروع', labelEn: 'Project type', type: 'select', required: true, options: ['صفحة هبوط', 'موقع كامل', 'متجر إلكتروني', 'تطبيق موبايل', 'نظام إداري'] },
      { k: 'pages', label: 'عدد الصفحات التقريبي', labelEn: 'Approx. pages', type: 'number' },
      { k: 'features', label: 'الخصائص المطلوبة', labelEn: 'Required features', type: 'textarea', required: true },
      { k: 'deadline', label: 'التسليم المطلوب', labelEn: 'Deadline', type: 'date' },
    ],
  },
  {
    id: 'social', ar: 'إدارة سوشيال ميديا', en: 'Social Media', ic: '📱',
    fields: [
      { k: 'platforms', label: 'المنصات', labelEn: 'Platforms', type: 'select', required: true, options: ['فيسبوك + إنستجرام', 'تيك توك', 'لينكدإن', 'كل المنصات'] },
      { k: 'pkg', label: 'الباقة', labelEn: 'Package', type: 'select', required: true, options: ['8 بوستات/شهر', '12 بوست/شهر', '20 بوست/شهر', 'مخصصة'] },
      { k: 'goals', label: 'أهدافك من الإدارة', labelEn: 'Your goals', type: 'textarea' },
    ],
  },
];

/* الحقول المشتركة لكل الطلبات */
export const COMMON_FIELDS = [
  { k: 'name', label: 'الاسم *', labelEn: 'Name *', type: 'text', required: true },
  { k: 'company', label: 'اسم الشركة', labelEn: 'Company', type: 'text' },
  { k: 'email', label: 'البريد الإلكتروني *', labelEn: 'Email *', type: 'email', required: true },
  { k: 'phone', label: 'رقم الموبايل/واتساب *', labelEn: 'Phone / WhatsApp *', type: 'tel', required: true },
  { k: 'budget', label: 'الميزانية التقريبية', labelEn: 'Budget range', type: 'select', options: ['أقل من 5,000 ج', '5,000 - 15,000 ج', '15,000 - 50,000 ج', 'أكتر من 50,000 ج', 'محتاج عرض سعر'] },
  { k: 'details', label: 'تفاصيل إضافية *', labelEn: 'Details *', type: 'textarea', required: true },
];
