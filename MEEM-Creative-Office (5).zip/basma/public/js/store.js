/* ============================================================
   MEEM | Creative Office — حالة التطبيق المركزية
   ============================================================ */
import { api, socket, setToken, getToken, forgotCreds } from './api.js';

export const DEPTS = ['content', 'voice', 'design', 'delivery', 'dev'];

export const STATUS = ['new', 'progress', 'review', 'client', 'revision', 'delivered', 'done'];

export const STATUS_COLOR = {
  new: 'info',
  progress: 'brand',
  review: 'warn',
  client: 'pink',
  revision: 'danger',
  delivered: 'ok',
  done: '',
};

export const PRIORITIES = ['urgent', 'high', 'medium', 'low'];
export const PRIORITY_COLOR = { urgent: 'danger', high: 'warn', medium: 'info', low: '' };

export const state = {
  user: null,
  pos: {},      // V2-8: مواقع أفاتارات الفريق في المكتب
  online: [],   // V2-6: المتصلون الآن
  users: [],
  clients: [],
  projects: [],
  tasks: [],
  designs: [],
  deliveries: [],
  meetings: [],
  assets: [],
  invoices: [],
  templates: [],
  settings: [],
  requests: [],
  contents: [],
  voices: [],
  videos: [],
  shoots: [],
  bugs: [],
  payments: [],
  expenses: [],
  timeentries: [],
  campaigns: [],
  prompts: [],
  articles: [],
  chats: [],
  activity: [],
  connected: false,
  loading: true,
};

const subs = new Set();
export function subscribe(fn) { subs.add(fn); return () => subs.delete(fn); }
export function notify(what) { subs.forEach((f) => { try { f(what); } catch (e) { console.error(e); } }); }

/* ------------------------ selectors ------------------------ */
export const byId = (arr, id) => arr.find((x) => x.id === id) || null;
export const userById = (id) => byId(state.users, id);
export const clientById = (id) => byId(state.clients, id);
export const projectById = (id) => byId(state.projects, id);
export const contentById = (id) => byId(state.contents || [], id);

export function userName(id) {
  const u = userById(id);
  return u ? u.name : '—';
}
export function tasksOfDept(dept, extra = {}) {
  return state.tasks
    .filter((t) => t.dept === dept && match(t, extra))
    .sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
}
export function match(obj, extra) {
  return Object.keys(extra).every((k) => extra[k] == null || extra[k] === '' || obj[k] === extra[k]);
}

export function isOverdue(task) {
  if (!task.due || task.status === 'done' || task.status === 'delivered') return false;
  return task.due < todayStr();
}
export function isDueToday(task) {
  return task.due === todayStr() && task.status !== 'done';
}
export function todayStr(offset = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offset);
  return d.toISOString().slice(0, 10);
}

export function roleHome(role) {
  return {
    admin: '#/office',
    designer: '#/office',
    content: '#/office',
    voice: '#/office',
    cs: '#/office',
    dev: '#/office',
    client: '#/portal',
    superadmin: '#/owner',
  }[role] || '#/office';
}

/* ------------------------ actions ------------------------ */

export async function login(email, password) {
  const res = await api.login(email, password);
  setToken(res.token);
  state.user = res.user;
  socket.connect();
  await loadState();
  return res.user;
}

export async function logout() {
  try { await api.logout(); } catch (e) {}
  forgotCreds();
  setToken('');
  state.user = null;
  location.hash = '#/login';
  location.reload();
}

export async function loadState() {
  const res = await api.state();
  state.user = res.user;
  Object.assign(state, res.data);
  state.loading = false;
  notify('state');
  return state;
}

export async function save(collection, doc) {
  const res = await api.upsert(collection, doc);
  applySync({ collection, op: 'upsert', doc: res.doc });
  return res.doc;
}

export async function remove(collection, id) {
  await api.remove(collection, id);
  applySync({ collection, op: 'delete', id });
}

export async function saveDesign(design) {
  // التصميم الكامل (بطبقاته) يُرسل هنا — /api/mutate يدعم designs
  const res = await api.upsert('designs', design);
  return res.doc;
}

export async function loadDesign(id) {
  const res = await api.design(id);
  return res.design;
}

export async function loadAsset(id) {
  const res = await api.asset(id);
  return res.asset;
}

export function applySync(msg) {
  const { collection, op } = msg;
  if (!state[collection]) return;
  if (op === 'delete') {
    state[collection] = state[collection].filter((d) => d.id !== msg.id);
  } else if (op === 'upsert') {
    const i = state[collection].findIndex((d) => d.id === msg.doc.id);
    if (i >= 0) {
      // لا نستبدل تصميمًا مفتوحًا ببيانات مختصرة
      state[collection][i] = Object.assign({}, state[collection][i], msg.doc);
    } else state[collection].unshift(msg.doc);
  } else if (op === 'bulk') {
    (msg.docs || []).forEach((d) => {
      const i = state[collection].findIndex((x) => x.id === d.id);
      if (i >= 0) state[collection][i] = Object.assign({}, state[collection][i], d);
      else state[collection].unshift(d);
    });
  }
  notify(collection);
}

export function initRealtime() {
  socket.on((msg) => {
    if (msg.type === 'ws-state') {
      state.connected = msg.connected;
      notify('connection');
    } else if (msg.type === 'chat') {
      if (!state.chats.find((m) => m.id === msg.doc.id)) state.chats.push(msg.doc);
      notify('chats');
    } else if (msg.type === 'sync') {
      applySync(msg);
    } else if (msg.type === 'presence') {
      /* V2-6: المتصلون الآن — لحظي */
      state.online = msg.users || [];
      notify('presence');
    } else if (msg.type === 'posinit') {
      /* V2-8: خريطة مواقع الفريق في المكتب */
      state.pos = {};
      (msg.users || []).forEach((u) => { state.pos[u.userId] = u; });
      notify('pos');
    } else if (msg.type === 'pos') {
      if (msg.userId && msg.userId !== (state.user && state.user.id)) {
        state.pos = state.pos || {};
        state.pos[msg.userId] = Object.assign({}, state.pos[msg.userId], msg);
        notify('pos');
      }
    } else if (msg.type === 'status') {
      if (msg.userId && state.pos && state.pos[msg.userId]) { state.pos[msg.userId].status = msg.status; notify('pos'); }
    } else if (msg.type === 'posleave') {
      if (state.pos && state.pos[msg.userId] && !(state.online || []).includes(msg.userId)) {
        delete state.pos[msg.userId];
        notify('pos');
      }
    } else if (msg.type === 'refresh-state') {
      // الأتمتة أنشأت عناصر جديدة → إعادة سحب الحالة كاملة
      loadState().catch(() => {});
    }
  });
  if (getToken()) socket.connect();
}

/* ------------------------ إحصاءات ------------------------ */
export function stats() {
  const open = state.tasks.filter((t) => !['done', 'delivered'].includes(t.status));
  return {
    total: state.tasks.length,
    open: open.length,
    review: state.tasks.filter((t) => t.status === 'review').length,
    delivered: state.tasks.filter((t) => t.status === 'delivered').length,
    revision: state.tasks.filter((t) => t.status === 'revision').length,
    dueToday: state.tasks.filter(isDueToday).length,
    overdue: state.tasks.filter(isOverdue).length,
    projects: state.projects.filter((p) => p.status !== 'done').length,
    clients: state.clients.length,
  };
}

export function deptStats() {
  const out = {};
  DEPTS.forEach((d) => {
    const list = state.tasks.filter((t) => t.dept === d);
    out[d] = {
      total: list.length,
      open: list.filter((t) => !['done', 'delivered'].includes(t.status)).length,
      done: list.filter((t) => ['done', 'delivered'].includes(t.status)).length,
      overdue: list.filter(isOverdue).length,
    };
  });
  return out;
}
