/* ============================================================
   MEEM | Creative Office — نقطة التشغيل
   ============================================================ */
import { setLang, applyRootLang, t } from './i18n.js';
import { api, socket, getToken, tryAutoLogin } from './api.js';
import { state, loadState, initRealtime, subscribe } from './store.js';
import { toast, icon } from './ui.js';
import { renderShell } from './shell.js';
import { renderLogin } from './views/login.js';
import { renderTPortal } from './views/tportal.js';
import { renderPubRequest } from './views/pubreq.js';
import { renderDashboard } from './views/dashboard.js';
import { renderDept } from './views/dept.js';
import { renderDesignDept } from './views/design.js';
import { renderDelivery } from './views/delivery.js';
import { renderMeetings } from './views/meetings.js';
import { renderClients } from './views/clients.js';
import { renderTeam } from './views/team.js';
import { renderAssets } from './views/assets.js';
import { renderProjects } from './views/projects.js';
import { renderRequests } from './views/requests.js';
import { renderCalendar } from './views/calendar.js';
import { renderActivity } from './views/activity.js';
import { renderAutomation } from './views/automation.js';
import { renderPortal } from './views/portal.js';
import { renderContent } from './views/content.js';
import { renderVoice } from './views/voice.js';
import { renderVideo } from './views/video.js';
import { renderPhoto } from './views/photo.js';
import { renderFinance } from './views/finance.js';
import { renderTime } from './views/time.js';
import { renderReports } from './views/reports.js';
import { renderMarketing } from './views/marketing.js';
import { renderKB } from './views/kb.js';
import { renderChat } from './views/chat.js';
import { renderOwner } from './views/owner.js';
import { renderOffice } from './views/office.js';
import { renderTasks } from './views/tasks.js';
import { renderDevHub } from './views/devhub.js';

const app = document.getElementById('app');
const boot = document.getElementById('boot');

export const ROUTES = {
  dashboard: { title: 'nav_dashboard', icon: 'dashboard', render: renderDashboard },
  content: { title: 'استوديو المحتوى', icon: 'content', render: renderContent, roles: ['content', 'editor', 'admin', 'superadmin'] },
  voice: { title: 'استوديو الصوت', icon: 'voice', render: renderVoice, roles: ['voice', 'editor', 'admin', 'superadmin'] },
  design: { title: 'nav_design', icon: 'design', render: renderDesignDept, roles: ['designer', 'admin', 'superadmin'] },
  delivery: { title: 'nav_delivery', icon: 'delivery', render: renderDelivery },
  dev: { title: 'Dev Hub', icon: 'code', render: renderDevHub, roles: ['dev', 'admin', 'superadmin'] },
  meetings: { title: 'nav_meet', icon: 'meet', render: renderMeetings },
  clients: { title: 'nav_clients', icon: 'clients', render: renderClients, roles: ['cs', 'admin', 'superadmin'] },
  assets: { title: 'nav_files', icon: 'folder', render: renderAssets },
  team: { title: 'nav_team', icon: 'users', render: renderTeam, admin: true },
  /* Phase 3 */
  projects: { title: 'المشاريع', icon: 'kanban', render: renderProjects },
  requests: { title: 'الطلبات', icon: 'bell', render: renderRequests, roles: ['cs', 'admin', 'superadmin'] },
  calendar: { title: 'التقويم', icon: 'calendar', render: renderCalendar },
  activity: { title: 'سجل النشاط', icon: 'clock', render: renderActivity },
  video: { title: 'استوديو الفيديو', icon: 'code', render: renderVideo },
  photo: { title: 'التصوير', icon: 'image', render: renderPhoto, roles: ['designer', 'admin', 'superadmin'] },
  automation: { title: 'الأتمتة', icon: 'bolt', render: renderAutomation, admin: true },
  /* Phase 6 */
  finance: { title: 'المالية', icon: 'money', render: renderFinance, admin: true },
  time: { title: 'تتبع الوقت', icon: 'clock', render: renderTime },
  reports: { title: 'التقارير', icon: 'target', render: renderReports, admin: true },
  marketing: { title: 'التسويق', icon: 'sparkles', render: renderMarketing, admin: true },
  kb: { title: 'المعرفة', icon: 'template', render: renderKB },
  /* Phase 7 */
  chat: { title: 'MEE M Chat', icon: 'chat', render: renderChat },
  /* V2-3 */
  owner: { title: 'OWNER CONTROL', icon: 'lock', render: renderOwner, super: true },
  /* V2-7 */
  office: { title: 'المكتب الافتراضي', icon: 'grid', render: renderOffice },
  /* V2-10 */
  tasks: { title: 'المهام', icon: 'kanban', render: renderTasks },
  portal: { title: 'لوحتي', icon: 'clients', render: renderPortal },
};

let currentRoute = null;
let shell = null;

function hashRoute() {
  const h = (location.hash || (state.user && state.user.role === 'client' ? '#/portal' : '#/dashboard')).replace(/^#\/?/, '');
  const [name, param] = h.split('/');
  const clean = (name || '').split('?')[0];
  let resolved = ROUTES[clean] ? clean : (state.user && state.user.role === 'client' ? 'portal' : state.user && state.user.role === 'superadmin' ? 'owner' : 'office');
  // العميل يدخل بورتاله ومشاريعه بس
  if (state.user && state.user.role === 'client' && !['portal', 'projects', 'chat', 'office', 'meetings'].includes(resolved)) resolved = 'portal';
  return { name: resolved, param: (param || '').split('?')[0] || null, raw: h };
}

export function navigate(hash) {
  if (location.hash === hash) render();
  else location.hash = hash;
}

export function render() {
  if (!state.user) { renderLogin(); return; }
  if (state.user.role === 'client' && !location.hash) location.hash = '#/portal';
  // أي محرر overlay مفتوح يقفل مع تغيير الصفحة (Phase 5)
  document.querySelectorAll('body > .studio').forEach((o) => o.remove());
  const { name, param } = hashRoute();
  if (!shell) shell = renderShell(app, { onNav: render });
  shell.setActive(name);
  currentRoute = name;
  const route = ROUTES[name];
  /* V2-2: حارس أدوار على مستوى الـ Routes (الحماية الحقيقية server-side) */
  if (route && state.user) {
    const me = state.user.role;
    const isAdm = me === 'admin' || me === 'superadmin';
    if ((route.super && me !== 'superadmin') || (route.admin && !isAdm) || (route.roles && !route.roles.includes(me))) {
      location.replace('#/' + (me === 'client' ? 'portal' : 'dashboard'));
      return;
    }
  }
  document.title = `${t(route.title)} — MEE M | Creative Office`;
  shell.setTitle(t(route.title), '');
  try {
    route.render(shell.content, { param });
  } catch (e) {
    console.error(e);
    shell.content.innerHTML = '';
    shell.content.appendChild(Object.assign(document.createElement('div'), {
      className: 'empty',
      innerHTML: `${icon('warning')}<div>حدث خطأ: ${e.message}</div>`,
    }));
  }
}

async function bootApp() {
  const savedLang = localStorage.getItem('basma_lang') || 'ar';
  setLang(savedLang);
  applyRootLang();

  /* V2-11: بوابة العميل بالتوكن — /client/project/TOKEN من غير تسجيل */
  const tp = location.pathname.match(/^\/client\/project\/([a-zA-Z0-9]+)\/?$/);
  if (tp) { finishBoot(); renderTPortal(app, tp[1]); return; }

  /* V2-13: صفحة اطلب مشروع — عامة */
  if (/^\/request\/?$/.test(location.pathname)) { finishBoot(); renderPubRequest(app); return; }

  initRealtime();

  if (!getToken()) {
    const auto = await tryAutoLogin();
    if (!auto) { finishBoot(); renderLogin(); return; }
  }
  try {
    await loadState();
    finishBoot();
    render();
  } catch (e) {
    finishBoot();
    if (e.status === 401) {
      localStorage.removeItem('basma_token');
      renderLogin();
    } else {
      toast('تعذّر الاتصال بالسيرفر — تأكد أنه شغال', 'err', 6000);
      renderLogin();
    }
  }
}

function finishBoot() {
  boot.classList.add('gone');
  setTimeout(() => { boot.style.display = 'none'; }, 400);
  app.hidden = false;
}

window.addEventListener('hashchange', () => { if (state.user) render(); });

// انتهاء الجلسة في أي نقطة → رجوع لطيف لشاشة الدخول
let expShown = 0;
window.addEventListener('auth-expired', () => {
  state.user = null;
  const editorOpen = document.querySelector('.ed');
  if (editorOpen) editorOpen.remove();
  if (location.hash !== '#/login') location.hash = '#/login';
  renderLogin();
  const now = Date.now();
  if (now - expShown > 4000) {
    expShown = now;
    toast('انتهت الجلسة — سجّل الدخول من جديد', 'warn', 4500);
  }
});
window.addEventListener('langchange', () => { if (state.user) render(); });

// إعادة التصيير عند وصول تحديثات
subscribe((what) => {
  if (what === 'connection') { if (shell) shell.setConnection(state.connected); return; }
  if (what === 'pos') return; // V2-8: المكتب بيتعامل معاها بنفسه —Pages التانية ماتترندرش مع كل حركة
  if (!state.user) return;
  const live = document.querySelector('[data-live]');
  if (live) {
    clearTimeout(window.__liveT);
    window.__liveT = setTimeout(() => {
      const { name, param } = hashRoute();
      if (ROUTES[name]) {
        shell.setTitle(t(ROUTES[name].title), '');
        ROUTES[name].render(shell.content, { param });
      }
    }, 220);
  }
});

// اختصارات عامة
window.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
    e.preventDefault();
    const s = document.querySelector('.tb-search input');
    if (s) s.focus();
  }
});

bootApp();
