/* ============================================================
   MEEM | Creative Office — Phase 4: محرك الـ AI
   Pipeline كامل: مفتاح API → بروكسي السيرفر | من غير مفتاح → مولّد محلي ذكي
   ============================================================ */
import { api } from './api.js';

export function isPro(settings) {
  const cfg = (settings || []).find((s) => s.id === 'ai');
  return !!(cfg && cfg.key);
}

/* ---------------- المولد المحلي ---------------- */
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

const HOOKS = {
  caption: ['مش كل يوم بييجي عرض يستاهل الانتظار 👀', 'في حاجات بتتعمل بحب… ودي واحدة منها ❤️', 'وقف سكرول لحظة — دي ليك انت 🫵', 'اللي يدوق مرة… هيرجع تاني أكيد 😄'],
  script30: ['«سؤال بسيط: آخر مرة حسيت إن الخدمة اتعملت عشانت انت — كانت إمتى؟»', '«في مكان ما… فيه فريق بيشتغل على تفاصيل انت مش شايفها.»', '«كل حاجة بتبدأ بفكرة… وإحنا بنحولها لواقع.»'],
  script60: ['«تخيل يومك من غير التعقيد ده… comfortable صح؟»', '«فيه حاجات بتفرق في اليوم — وإحنا بنشتغل عليها كل يوم.»'],
  article: ['في عالم بيتغير كل يوم، بقى مهم نعرف نختار الصح.', 'كتير مننا بيدور على الأفضل — بس مش دايمًا عارفين نبدأ منين.'],
  ad: ['⚡ عرض مايتفوتش!', '🔥 لفترة محدودة بس:', '💥 الجديد وصل!'],
  email: ['أهلًا بيك 👋 — جهزنا لك حاجة مخصوص.', 'وحشتنا! ودي آخر أخبارنا ليك.'],
  seo: ['البحث عن الأفضل بيبدأ هنا.', 'دليلك الكامل — خطوة بخطوة.'],
};
const CLOSERS = ['اطلب دلوقتي واستمتع بفرق حقيقي ❤️', 'مستني إيه؟ التجربة على بعد رسالة واحدة 📩', 'كلمنا النهاردة وسيب الباقي علينا 🤝', 'جرّب مرة — والقرار هتاخده بنفسك ✨'];

function hashtagsFor(keywords, type) {
  const base = (keywords || 'جودة، ثقة، تميّز').split(/[،,]/).map((s) => s.trim()).filter(Boolean);
  const tags = base.slice(0, 3).map((k) => '#' + k.replace(/\s+/g, '_'));
  tags.push(pick(['#مصر', '#الافضل_دايمًا', '#تجربة_تفرق', '#جديدنا_ليك']));
  if (type === 'caption') tags.push('#عرض_خاص');
  return tags.join(' ');
}

export function localGenerate(action, ctx = {}) {
  const { type = 'caption', text = '', lang = 'ar' } = ctx;
  const voice = ctx.voice || {};
  const tone = voice.tone || 'ودود ومحترف';
  const kws = voice.keywords || '';
  const donts = voice.donts || '';
  const sample = voice.sample || '';

  if (action === 'draft') {
    const hook = pick(HOOKS[type] || HOOKS.caption);
    const kwLine = kws ? `\n\n${kws.split(/[،,]/).slice(0, 3).map((k) => '✅ ' + k.trim()).join('\n')}` : '';
    const cta = pick(CLOSERS);
    const tags = type === 'caption' || type === 'ad' ? '\n\n' + hashtagsFor(kws, type) : '';
    const voiceNote = sample ? `\n\n(بصوت البراند: «${sample}»)` : '';
    return `${hook}\n\nنص مكتوب بنبرة ${tone} — مسودة أولى جاهزة للتعديل.${kwLine}\n\n${cta}${tags}${voiceNote}`;
  }

  if (action === 'improve') {
    const t = (text || '').trim();
    if (!t) return 'اكتب النص الأول وبعدين اضغط تحسين ✍️';
    return `${t.replace(/\s+/g, ' ')}\n\n— بصراحة؟ دي نسخة أقوى: نفس المعنى بكلمات أوضح، وجملة ختافية بتشد القارئ.\n${pick(CLOSERS)}`;
  }

  if (action === 'shorten') {
    const t = (text || '').trim();
    if (!t) return 'مفيش نص للتقصير';
    const sentences = t.split(/(?<=[.!؟\n])/).filter((s) => s.trim());
    const kept = sentences.slice(0, Math.max(1, Math.ceil(sentences.length / 2)));
    return kept.join(' ').trim() + ` ${pick(CLOSERS)}`;
  }

  if (action === 'hashtags') return hashtagsFor(kws, type);

  if (action === 'titles') {
    const topic = (text || '').trim().split('\n')[0].slice(0, 60) || 'عرضنا الجديد';
    return [
      `1) ${topic} — بشكل ما شفتوش قبل كده`,
      `2) ليه ${topic} هو اختيار ${pick(['السنة دي', 'الذواقين', 'العيلة كلها'])}؟`,
      `3) ${topic}: ${pick(['التفاصيل بتفرق', 'الجودة مش صدفة', 'تجربة تستاهل'])}`,
      `4) سر ${topic} اللي محدش بيقولك عليه`,
      `5) ${topic} — ${pick(['جرّب', 'شوف', 'اكتشف'])} الفرق بنفسك`,
    ].join('\n');
  }

  if (action === 'voice') {
    const t = (text || '').trim();
    const lines = [`🎯 الصوت المطلوب: ${tone}`];
    if (kws) lines.push(`🔑 كلمات مفتاحية: ${kws}`);
    if (donts) lines.push(`🚫 ممنوعات: ${donts}`);
    if (sample) lines.push(`💬 مثال: «${sample}»`);
    lines.push('', t ? '✍️ مراجعة نصك على الصوت ده:\n' + t.split('\n').map((l) => (l.trim() ? '• ' + l.trim() : l)).join('\n') : 'اكتب النص وهنراجع التزامه بالصوت.');
    return lines.join('\n');
  }

  return 'أمر غير معروف';
}

/* ---------------- الواجهة الموحدة ---------------- */
export async function runAI(action, ctx = {}, settings = []) {
  if (isPro(settings)) {
    try {
      const res = await api.ai({ action, ...ctx });
      if (res && res.text) return { text: res.text, pro: true };
    } catch (e) { /* fallthrough */ }
  }
  return { text: localGenerate(action, ctx), pro: false };
}
