# 🚀 نشر MEEM على الإنترنت — دليل كامل

> التطبيق **zero-dependencies**: مفيش `npm install` خالص — Node.js 18+ وخلاص.
> كل البيانات في فولدر واحد: `data/` (قاعدة البيانات `db.json` + الملفات المرفوعة `uploads/`).

---

## ⚠️ قبل ما تختاري استضافة — 3 حقائق لازم تعرفيها

1. **الاستضافة المشتركة (cPanel اللي بـ 30 جنيه/شهر) مش هتشغّله** — دي PHP غالبًا، وإحنا محتاجين Node.js شغال 24/7 + WebSocket (الشات والاجتماعات).
2. **الاجتماعات (WebRTC) وتسجيل المايك محتاجين HTTPS** — يعني لازم دومين + شهادة (مجانية وأوتوماتيك، هتشوفي إزاي تحت).
3. **لازم تخزين دائم** — قاعدة البيانات والملفات المرفوعة على الديسك، فأي منصة "بتنضّف الديسك" هتضيّع بياناتك.

---

## 1️⃣ تشغيله على جهازك (تجربة محلية)

```bash
# 1) ثبّتي Node.js LTS من nodejs.org
# 2) في فولدر المشروع:
cd basma
npm start
# ➜ http://localhost:3000
```

تجريبيه من موبايلك على نفس الواي فاي: `http://IP-جهازك:3000`
(على ويندوز: اسمحي بـ Node.js في الـ Firewall أول مرة).

---

## 2️⃣ الخيار الموصى به: VPS (سيرفر خاص) — 4-6$ شهريًا

أفضل توازن: رخيص + بياناتك عندك + تحكم كامل.
شركات كويسة: **Hetzner** (أرخص وأقوى، ألمانيا) · **Contabo** · **DigitalOcean** · **Vultr**
اختاري: Ubuntu 22.04 أو 24.04 — أصغر خطة كفاية (2GB RAM).

### الخطوات (انسخي Commands كما هي):

```bash
# من جهازك — ارفعي المشروع (بعد ما تعمليه zip):
scp basma.zip root@IP_السيرفر:/root/

# ادخلي السيرفر:
ssh root@IP_السيرفر

# ── على السيرفر ──
apt update && apt install -y unzip curl
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt install -y nodejs
npm i -g pm2

# فكّي الضغط وشغّلي:
mkdir -p /var/www && cd /var/www
unzip /root/basma.zip -d /var/www/ && mv /var/www/basma /var/www/meem
cd /var/www/meem
pm2 start deploy/ecosystem.config.js
pm2 save && pm2 startup    # ← يشتغل أوتوماتيك بعد أي ريستارت للسيرفر

# Caddy (HTTPS أوتوماتيك):
apt install -y debian-keyring debian-archive-keyring apt-transport-https
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
apt update && apt install -y caddy

# عدّلي الدومين في deploy/Caddyfile لدومينك، وبعدين:
cp deploy/Caddyfile /etc/caddy/Caddyfile
systemctl reload caddy
```

**الدومين**: في لوحة تحكم شركة الدومين، اعملي **A Record** بـ `@` (و www) على IP السيرفر — يستغرق دقائق لساعات.
بعدها افتحي `https://دومينك.com` — Caddy هيجيب شهادة Let's Encrypt ويجددها لوحده للأبد ✅

> بديل Caddy: ملف `deploy/nginx-meem.conf` جاهز مع certbot.
> بديل PM2: ملف `deploy/meem.service` لـ systemd.

---

## 3️⃣ الخيار الأسهل (من غير إدارة سيرفر): Railway أو Render

1. ارفعي المشروع على **GitHub** (repo خاص).
2. **Railway.app**: New Project → Deploy from GitHub Repo → Done.
   (بيديكي دومين مجاني شكله `xxx.up.railway.app` بـ HTTPS — الاجتماعات والمايك هيشتغلوا عليه).
3. **Render.com**: استخدمي `deploy/render.yaml` (New Blueprint).

**⚠️ الأهم في الخيار ده: Persistent Disk.**
لازم تربطي Disk (مدفوع — حوالي 1$ شهريًا لـ 1GB) على مسار `data/` داخل المشروع،
وإلا **كل deploy أو ريستارت هيمسح قاعدة البيانات والملفات المرفوعة**.
(الخطة المجانية في Render = بيانات بتضيع — بلاش لمشروع حقيقي).

---

## 4️⃣ الدومين و"تفعيله"

- **دومين عالمي (.com)**: من Namecheap أو Porkbun — حوالي 10$ سنويًا (بطاقة بنكية).
- **دومين مصري (.com.eg / .eg)**: من الشركات المعتمدة محليًا (زي TE Data أو Domain Registration Egypt) — يحتاج سجل تجاري للأسماء التجارية.
- **التفعيل** = تربطي الدومين بالاستضافة:
  - VPS: A Record على IP السيرفر + Caddy (فوق).
  - Railway/Render: Custom Domain من إعدادات الخدمة → يعطيكِ الـ CNAME المطلوب.
- HTTPS بييجي أوتوماتيك في الحالتين.

---

## 5️⃣ 🔐 قبل النشر — غيّري الباسوردات (مهم جدًا!)

كل الحسابات التجريبية باسوردها `123456` — مينفعش تنشري كده.
الأداة جاهزة في المشروع:

```bash
node tools/set-password.js admin@meem.studio "باسورد-قوي-جديد"
node tools/set-password.js designer@meem.studio "باسورد-قوي-جديد"
# ... وهكذا لكل الحسابات (هتطبع لك قائمة الحسابات لو نسيتي إيميل)
pm2 restart meem   # أو ريستارت السيرفر
```

> القاعدة: 8 حروف+ أرقام ورموز. الحسابات التجريبية اللي مش هتستخدميها (client@، niletech@...) — غيّري باسورداتها أو اتركيها للعرض بس وإنتي عارفة إنها مكشوفة.

---

## 6️⃣ بياناتك الحالية

- **تنقلي كل حاجة زي ما هي**: ارفعي المشروع **ومعاه فولدر `data/`** — كل المشاريع والتصاميم والفيديوهات هتفضل موجودة.
- **تبدأي نظيفة**: ارفعي من غير `data/` — السيرفر هيزرع ديمو جديد تلقائيًا أول تشغيل.
- **مفتاح AI Pro**: بعد النشر ادخلي الإعدادات وحطي مفتاح الـ API — الأدوات هتشتغل بالذكاء الحقيقي بدل البدائل المحلية.

---

## 7️⃣ النسخ الاحتياطي (متهمليهاش)

كل حاجة في فولدر `data/` — نسخة أسبوعية تكفي:

```bash
# على الـ VPS — cron أسبوعي:
crontab -e
# أضيفي السطر ده (كل أحد الساعة 3 الفجر):
0 3 * * 0 tar czf /root/meem-backup-$(date +\%F).tar.gz -C /var/www/meem data
```

ونزّلي نسخة على جهازك أو Google Drive كل فترة.

---

## ✅ تشيك ليست النشر

- [ ] VPS أو Railway/Render شغال
- [ ] `pm2 list` يوري `meem` بحالة online (أو الـ service active)
- [ ] دومين مربوط + HTTPS شغال (القفل الأخضر في المتصفح)
- [ ] **كل الباسوردات اتغيرت**
- [ ] تسجيل المايك شغال (Voice Studio) ← لو مش شغال فمعناها HTTPS مش مضبوط
- [ ] الشات اللحظي شغال بين تابين ← لو مش شغال فمعناها البروкси مش بيمرر WebSocket (الملفات الجاهزة بتمرره)
- [ ] نسخة احتياطية أولى من `data/` اتعملت
