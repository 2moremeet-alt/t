/* PM2 — تشغيل MEEM كخدمة دائمة على VPS
 * الاستخدام على السيرفر:
 *   npm i -g pm2
 *   cd /var/www/meem
 *   pm2 start deploy/ecosystem.config.js
 *   pm2 save && pm2 startup   (تشغيل تلقائي بعد أي restart للسيرفر)
 */
module.exports = {
  apps: [
    {
      name: 'meem',
      script: 'server/server.js',
      cwd: __dirname + '/..',
      env: { PORT: 3000, HOST: '127.0.0.1', NODE_ENV: 'production' },
      autorestart: true,
      max_memory_restart: '400M',
      out_file: 'data/logs/out.log',
      error_file: 'data/logs/err.log',
      time: true,
    },
  ],
};
