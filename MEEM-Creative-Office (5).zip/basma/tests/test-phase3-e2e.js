/* MEEM — Phase 3 E2E: مشاريع + طلبات + تقويم + نشاط + أتمتة + CRM + بورتال + تسليم */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = { a: [], c: [] };

async function api(path, token, body) {
  const res = await fetch(BASE + '/api' + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return res.json();
}

(async () => {
  /* ---------- تحضير: رجع تصميم الديمو لحالة «عند العميل» ---------- */
  const adm = await api('/login', null, { email: 'admin@meem.studio', password: '123456' });
  const T = adm.token;
  const st0 = await api('/state', T);
  const demo = st0.data.designs.find((d) => d.id === 'des_efb1ada037ce');
  if (demo && !['client', 'approved'].includes(demo.status)) {
    await api(`/design/${demo.id}/submit`, T, { note: 'E2E prep' });
    await api(`/design/${demo.id}/decision`, T, { decision: 'approve', note: 'E2E' });
  }
  const st1 = await api('/state', T);
  const demoNow = st1.data.designs.find((d) => d.id === 'des_efb1ada037ce');
  ok('تحضير: التصميم عند العميل', ['client', 'approved'].includes(demoNow.status));

  const b = await chromium.launch({ args: ['--no-sandbox'] });

  /* ============ جلسة الأدمن ============ */
  const ac = await b.newContext({ viewport: { width: 1600, height: 950 } });
  const a = await ac.newPage();
  a.on('pageerror', (e) => errs.a.push(e.message));
  a.on('console', (m) => { if (m.type() === 'error') errs.a.push(m.text()); });

  await a.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await a.waitForSelector('.login-card', { timeout: 20000 });
  await a.fill('input[type=email]', 'admin@meem.studio');
  await a.click('.login-card .btn.primary');
  await a.waitForSelector('.sidebar .nav-item', { timeout: 20000 });
  const navTxt = await a.textContent('.side-nav');
  ok('أدمن: التنقل فيه المشاريع/الطلبات/التقويم/النشاط/الأتمتة', ['المشاريع', 'الطلبات', 'التقويم', 'سجل النشاط', 'الأتمتة'].every((x) => navTxt.includes(x)));

  /* --- المشاريع --- */
  await a.goto(BASE + '/#/projects?r=' + Date.now(), { waitUntil: 'networkidle' });
  await a.waitForSelector('.cards-grid .dcard', { timeout: 15000 });
  const nCards = await a.locator('.cards-grid .dcard').count();
  ok('مشاريع: الكروت بتظهر (' + nCards + ')', nCards >= 6);

  await a.locator('.cards-grid .dcard').first().click();
  await a.waitForSelector('.tabs button', { timeout: 8000 });
  const tabsTxt = await a.textContent('.tabs');
  ok('تفاصيل مشروع: 6 تبويبات', ['نظرة عامة', 'المهام', 'التصاميم', 'الملفات', 'التسليمات', 'النشاط'].every((x) => tabsTxt.includes(x)));
  const ovTxt = await a.textContent('.view');
  ok('نظرة عامة: Brand Kit + Voice', ovTxt.includes('هوية العميل') && ovTxt.includes('صوت البراند'));
  await a.locator('.tabs button', { hasText: 'المهام' }).click();
  await a.waitForTimeout(400);
  ok('تبويب المهام بيشتغل', (await a.textContent('.view')).includes('تسليم'));
  await a.screenshot({ path: '/tmp/shots/p3-project.png' });

  /* --- الطلبات --- */
  await a.goto(BASE + '/#/requests?r=' + Date.now(), { waitUntil: 'networkidle' });
  await a.waitForSelector('.page-head .btn.primary', { timeout: 10000 });
  await a.click('.page-head .btn.primary');
  await a.waitForSelector('#modal-root input.input', { timeout: 8000 });
  await a.fill('#modal-root input.input', 'حملة E2E — بوستات أسبوعية');
  await a.locator('#modal-root button', { hasText: 'حفظ' }).click();
  await a.waitForTimeout(700);
  ok('طلبات: إنشاء طلب', (await a.textContent('.view')).includes('حملة E2E'));
  const card = a.locator('.card', { hasText: 'حملة E2E' }).first();
  await card.locator('button', { hasText: 'إسناد' }).click();
  await a.waitForSelector('#modal-root .select', { timeout: 5000 });
  await a.locator('#modal-root button', { hasText: 'إسناد' }).click();
  await a.waitForTimeout(700);
  ok('طلبات: إسناد', (await a.textContent('.view')).includes('تم الإسناد'));
  await a.locator('.card', { hasText: 'حملة E2E' }).first().locator('button', { hasText: 'تحويل لمشروع' }).click();
  await a.waitForTimeout(1500);
  ok('طلبات: تحويل لمشروع (فتح تفاصيل المشروع)', a.url().includes('#/projects/pro'));
  await a.goto(BASE + '/#/requests', { waitUntil: 'networkidle' });
  await a.waitForTimeout(400);
  await a.screenshot({ path: '/tmp/shots/p3-requests.png' });

  /* --- التقويم --- */
  await a.goto(BASE + '/#/calendar?r=' + Date.now(), { waitUntil: 'networkidle' });
  await a.waitForSelector('.cal-grid .cal-cell', { timeout: 10000 });
  const cells = await a.locator('.cal-grid .cal-cell:not(.empty)').count();
  const evs = await a.locator('.cal-ev').count();
  ok('تقويم: شبكة شهر (' + cells + ' يوم) + أحداث (' + evs + ')', cells >= 28 && evs >= 1);
  await a.locator('.page-head button', { hasText: 'chevron' }).first();
  await a.screenshot({ path: '/tmp/shots/p3-calendar.png' });

  /* --- سجل النشاط --- */
  await a.goto(BASE + '/#/activity?r=' + Date.now(), { waitUntil: 'networkidle' });
  await a.waitForSelector('.act-row', { timeout: 10000 });
  const nAct = await a.locator('.act-row').count();
  ok('نشاط: صفوف (' + nAct + ')', nAct >= 5);
  await a.fill('.view .tb-search input', 'zzzzz-مفيش-كده');
  await a.waitForTimeout(400);
  ok('نشاط: الفلتر بيشتغل', (await a.locator('.act-row').count()) === 0);

  /* --- الأتمتة --- */
  await a.goto(BASE + '/#/automation?r=' + Date.now(), { waitUntil: 'networkidle' });
  await a.waitForSelector('.switch', { timeout: 10000 });
  const nRules = await a.locator('.switch').count();
  ok('أتمتة: قواعد (' + nRules + ')', nRules >= 4);
  await a.locator('.switch .sl').first().click();
  await a.waitForTimeout(700);
  let stA = await api('/state', T);
  let rulesA = stA.data.settings.find((s) => s.id === 'automation').rules;
  const offOk = rulesA.filter((r) => !r.on).length === 1;
  await a.locator('.switch .sl').first().click();
  await a.waitForTimeout(700);
  stA = await api('/state', T);
  rulesA = stA.data.settings.find((s) => s.id === 'automation').rules;
  ok('أتمتة: إطفاء/تشغيل قاعدة محفوظ', offOk && rulesA.every((r) => r.on));
  await a.screenshot({ path: '/tmp/shots/p3-automation.png' });

  /* --- CRM: Brand Kit --- */
  await a.goto(BASE + '/#/clients?r=' + Date.now(), { waitUntil: 'networkidle' });
  await a.waitForSelector('.tbl tbody tr', { timeout: 10000 });
  await a.locator('.tbl tbody tr').first().locator('.btn.ghost.icon.sm').first().click();
  await a.waitForSelector('#modal-root .tabs button', { timeout: 8000 });
  await a.locator('#modal-root .tabs button', { hasText: 'هوية البراند' }).click();
  await a.waitForTimeout(400);
  const sw = await a.locator('#modal-root .swatch-view').count();
  ok('CRM: سواتشات Brand Kit (' + sw + ')', sw >= 2);
  await a.locator('#modal-root .tabs button', { hasText: 'صوت البراند' }).click();
  await a.waitForTimeout(300);
  const ta = a.locator('#modal-root textarea').last();
  await ta.fill('جملة E2E من صوت البراند');
  await a.locator('#modal-root button', { hasText: 'حفظ' }).click();
  await a.waitForTimeout(800);
  stA = await api('/state', T);
  const cli = stA.data.clients[0];
  ok('CRM: حفظ Brand Voice', cli.brandVoice.sample.includes('E2E'));
  await a.screenshot({ path: '/tmp/shots/p3-clients.png' });

  /* --- التسليم: checklist (self-contained: تسليم بقائمة من غير اعتماد على suites تانية) --- */
  await api('/mutate', T, {
    collection: 'deliveries', op: 'upsert',
    doc: {
      title: 'تسليم E2E — checklist', projectId: 'prj_3', clientId: 'cli_bahary', channel: 'email',
      status: 'draft', items: ['final-v1.pdf'], clientFeedback: '', revisions: 0,
      checklist: [
        { id: 'ck1', label: 'مراجعة نهائية', done: false },
        { id: 'ck2', label: 'تصدير النسخ', done: false },
        { id: 'ck3', label: 'تأكيد Client', done: false },
      ],
    },
  });
  await a.goto(BASE + '/#/delivery?r=' + Date.now(), { waitUntil: 'networkidle' });
  await a.waitForSelector('.checklist', { timeout: 12000 });
  const cks = a.locator('.checklist input[type=checkbox]');
  const nCk = await cks.count();
  for (let i = 0; i < nCk; i++) { if (!(await cks.nth(i).isChecked())) await cks.nth(i).check(); }
  await a.waitForTimeout(1200);
  const sendBtn = a.locator('button', { hasText: 'إرسال للعميل' }).first();
  ok('تسليم: كل البنود متعلمة', await sendBtn.isEnabled());
  await sendBtn.click();
  await a.waitForTimeout(900);
  stA = await api('/state', T);
  const dl = stA.data.deliveries.find((d) => d.checklist && d.status === 'waiting_client');
  ok('تسليم: إرسال للعميل → بانتظار رد العميل', !!dl);
  await a.screenshot({ path: '/tmp/shots/p3-delivery.png' });

  /* ============ جلسة العميل (البورتال) ============ */
  const cc = await b.newContext({ viewport: { width: 1440, height: 900 } });
  const c = await cc.newPage();
  c.on('pageerror', (e) => errs.c.push(e.message));
  c.on('console', (m) => { if (m.type() === 'error') errs.c.push(m.text()); });

  await c.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await c.waitForSelector('.login-card', { timeout: 20000 });
  await c.fill('input[type=email]', 'client@meem.studio');
  await c.click('.login-card .btn.primary');
  await c.waitForSelector('.sidebar .nav-item', { timeout: 20000 });
  const navC = await c.locator('.sidebar .nav-item').count();
  ok('بورتال: قائمة جانبية مخصصة (لوحتي + مشاريعي + الدردشة = ' + navC + ')', navC === 3);
  ok('بورتال: مفيش زر مهمة جديدة', (await c.locator('.topbar .btn.primary').count()) === 0);
  ok('بورتال: الصفحة الافتراضية = لوحتي', c.url().includes('#/portal'));

  await c.waitForSelector('.kpi', { timeout: 10000 });
  const portalTxt = await c.textContent('.view');
  ok('بورتال: KPI + بانتظار القرار', portalTxt.includes('بانتظار قرارك'));

  // الحظر: #/design يحوّله للبورتال
  await c.goto(BASE + '/#/design?r=' + Date.now(), { waitUntil: 'networkidle' });
  await c.waitForTimeout(800);
  ok('بورتال: #/design محجوب → لوحتي', c.url().includes('#/design') === false || (await c.textContent('.view')).includes('بانتظار'));

  // اعتماد التصميم من البورتال
  await c.goto(BASE + '/#/portal?r=' + Date.now(), { waitUntil: 'networkidle' });
  await c.waitForSelector('.dcard', { timeout: 12000 });
  await c.locator('.dcard button', { hasText: 'اعتماد' }).first().click();
  await c.waitForSelector('#modal-root .btn.ok', { timeout: 6000 });
  await c.locator('#modal-root .btn.ok').click();
  await c.waitForTimeout(1500);
  const stC = await (await fetch(BASE + '/api/state', { headers: { Authorization: 'Bearer ' + (await c.evaluate(() => localStorage.getItem('basma_token'))) } })).json();
  const dNow = stC.data.designs.find((d) => d.id === 'des_efb1ada037ce');
  ok('بورتال: اعتماد → client_approved', dNow && dNow.status === 'client_approved');
  const dlAuto = stC.data.deliveries.filter((d) => d.auto && d.checklist);
  ok('أتمتة من البورتال: تسليم أوتوماتيك جديد', dlAuto.length >= 1);
  ok('بورتال: زر تحميل PNG ظهر', (await c.textContent('.view')).includes('تحميل PNG'));
  await c.screenshot({ path: '/tmp/shots/p3-portal.png' });

  // مشاريعي
  await c.locator('.nav-item', { hasText: 'مشاريعي' }).click();
  await c.waitForTimeout(900);
  ok('بورتال: مشاريعي بتفتح', (await c.locator('.cards-grid .dcard').count()) >= 1);

  await b.close();

  console.log('\nأخطاء console أدمن:', errs.a.length ? errs.a.slice(0, 5) : 'لا');
  console.log('أخطاء console عميل:', errs.c.length ? errs.c.slice(0, 5) : 'لا');
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
