/* MEEM — Phase 6 API: Finance + Time + Marketing + KB + عزل العميل */
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' ' + n); };

async function api(path, token, body) {
  const res = await fetch(BASE + '/api' + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}
const login = (email) => api('/login', null, { email, password: '123456' }).then((r) => r.json.token);

(async () => {
  const admin = await login('admin@meem.studio');
  const client = await login('client@meem.studio');

  /* ---- البذرة ---- */
  let st = await api('/state', admin);
  const d = st.json.data;
  ok('invoices seeded (4)', (d.invoices || []).length === 4);
  ok('payments seeded (2)', (d.payments || []).length === 2);
  ok('expenses seeded (5)', (d.expenses || []).length === 5);
  ok('timeentries seeded (10)', (d.timeentries || []).length === 10);
  ok('campaigns seeded (3)', (d.campaigns || []).length === 3);
  ok('prompts seeded (6)', (d.prompts || []).length === 6);
  ok('articles seeded (4)', (d.articles || []).length === 4);
  const prj5 = (d.projects || []).find((p) => p.id === 'prj_5');
  ok('GitHub repo على prj_5', !!prj5 && (prj5.repo || '').includes('github.com'));

  /* ---- فاتورة + دفعة ---- */
  let r = await api('/mutate', admin, {
    collection: 'invoices', op: 'upsert',
    doc: { num: 'INV-TEST-1', clientId: 'cli_zahra', projectId: 'prj_1', title: 'فاتورة اختبار', status: 'sent', issuedAt: '2026-09-01', due: '2026-09-30', tax: 14, discount: 0, items: [{ desc: 'بند', qty: 2, price: 500 }] },
  });
  const inv = r.json.doc.id;
  ok('إنشاء فاتورة', !!inv);
  r = await api('/mutate', admin, { collection: 'payments', op: 'upsert', doc: { invoiceId: inv, amount: 1140, method: 'كاش', at: new Date().toISOString(), by: 'usr_admin' } });
  const pay = r.json.doc.id;
  ok('تسجيل دفعة (2×500 + 14% = 1140)', !!pay);

  /* ---- إدخال وقت ---- */
  r = await api('/mutate', admin, { collection: 'timeentries', op: 'upsert', doc: { taskId: 'x', taskTitle: 'اختبار', projectId: 'prj_1', userId: 'usr_admin', start: new Date().toISOString(), end: new Date().toISOString(), mins: 30, note: '' } });
  const te = r.json.doc.id;
  ok('إدخال وقت', !!te);

  /* ---- حملة + برومبت + مقال ---- */
  r = await api('/mutate', admin, { collection: 'campaigns', op: 'upsert', doc: { title: 'حملة اختبار', channel: 'facebook', budget: 1000, spent: 500, leads: 5, conversions: 1, revenue: 2000, status: 'active' } });
  const camp = r.json.doc.id;
  ok('حملة جديدة', !!camp);
  r = await api('/mutate', admin, { collection: 'prompts', op: 'upsert', doc: { title: 'برومبت اختبار', category: 'محتوى', body: 'x {{var}}' } });
  const pr = r.json.doc.id;
  ok('برومبت جديد', !!pr);
  r = await api('/mutate', admin, { collection: 'articles', op: 'upsert', doc: { title: 'مقال اختبار', category: 'تقني', body: 'y' } });
  const art = r.json.doc.id;
  ok('مقال جديد', !!art);

  /* ---- عزل العميل ---- */
  st = await api('/state', client);
  const cd = st.json.data;
  ok('العميل: كل أقسام الإدارة فاضية',
    cd.payments.length === 0 && cd.expenses.length === 0 && cd.timeentries.length === 0 &&
    cd.campaigns.length === 0 && cd.prompts.length === 0 && cd.articles.length === 0);

  /* ---- تنظيف ---- */
  for (const [col, id] of [['invoices', inv], ['payments', pay], ['timeentries', te], ['campaigns', camp], ['prompts', pr], ['articles', art]]) {
    await api('/mutate', admin, { collection: col, op: 'delete', id });
  }
  st = await api('/state', admin);
  ok('التنظيف تم', st.json.data.invoices.length === 4 && st.json.data.payments.length === 2 && st.json.data.timeentries.length === 10 && st.json.data.campaigns.length === 3 && st.json.data.prompts.length === 6 && st.json.data.articles.length === 4);

  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
