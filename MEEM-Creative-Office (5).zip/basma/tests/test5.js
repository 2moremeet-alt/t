/* MEEM — اختبار المحرر على الموبايل + رجعة سطح المكتب */
const { chromium, devices } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });

  /* ---------- موبايل ---------- */
  const mc = await b.newContext({ ...devices['iPhone 12'] });
  const p = await mc.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push(e.message));
  p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });

  await p.goto(BASE, { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card', { timeout: 20000 });
  await p.tap('.login-card .btn.primary');
  await p.waitForSelector('.sidebar .nav-item', { timeout: 20000 });
  await p.goto(BASE + '/#/dashboard', { waitUntil: 'networkidle' }); // V2-7: الهبوط بقى المكتب
  await p.locator('.desk-quick button', { hasText: 'تصميم جديد' }).tap();
  await p.waitForSelector('.ed', { timeout: 10000 });
  await p.waitForTimeout(400);

  // 1) افتراضيًا: لا لوحات مفتوحة فوق الكانفس + زر الإعدادات العائم ظاهر
  ok('موبايل: لا لوحة أدوات مفتوحة افتراضيًا', await p.locator('.ed-panel[data-role="tools"].open').count() === 0);
  ok('موبايل: الإعدادات مقفولة افتراضيًا', await p.locator('.ed-panel[data-role="props"].open').count() === 0);
  ok('موبايل: زر الإعدادات العائم ظاهر', await p.locator('.ed-props-toggle').isVisible());

  // 2) الضغط على أداة نص يفتح لوحة الأدوات
  await p.tap('.ed-tool[data-tool="text"]');
  await p.waitForTimeout(250);
  ok('موبايل: لوحة الأدوات فتحت بالضغط على نص', await p.locator('.ed-panel[data-role="tools"].open').isVisible());

  // 3) إضافة عنوان → الإعدادات تفتح تلقائيًا والأدوات تقفل
  await p.locator('.ed-panel[data-role="tools"] .ed-item').first().tap();
  await p.waitForTimeout(300);
  ok('موبايل: الإعدادات فتحت بعد إضافة عنصر', await p.locator('.ed-panel[data-role="props"].open').isVisible());
  ok('موبايل: لوحة الأدوات اقفلت تلقائيًا', await p.locator('.ed-panel[data-role="tools"].open').count() === 0);

  // 4) زر الإغلاق يقفل الإعدادات
  await p.locator('.ed-panel[data-role="props"] .ed-close').tap();
  await p.waitForTimeout(250);
  ok('موبايل: زر × قفل الإعدادات', await p.locator('.ed-panel[data-role="props"].open').count() === 0);

  // 5) أداة الطبقات تفتح وتعرض العنصر، والضغطة الثانية تقفل
  await p.tap('.ed-tool[data-tool="layers"]');
  await p.waitForTimeout(250);
  const hasLayer = (await p.textContent('.ed-panel[data-role="tools"]')).includes('عنوان رئيسي');
  ok('موبايل: لوحة الطبقات فتحت وفيها العنصر', hasLayer);
  await p.tap('.ed-tool[data-tool="layers"]');
  await p.waitForTimeout(250);
  ok('موبايل: ضغطة ثانية على نفس الأداة تقفل', await p.locator('.ed-panel[data-role="tools"].open').count() === 0);

  // 6) تحديد عنصر من لوحة الطبقات يفتح الإعدادات
  await p.tap('.ed-tool[data-tool="layers"]');
  await p.waitForTimeout(200);
  await p.locator('.ed-panel[data-role="tools"] .ed-layer').first().tap();
  await p.waitForTimeout(300);
  ok('موبايل: تحديد عنصر فتح الإعدادات', await p.locator('.ed-panel[data-role="props"].open').isVisible());

  // 7) زر الإعدادات العائم يفتح/يقفل
  await p.locator('.ed-panel[data-role="props"] .ed-close').tap();
  await p.waitForTimeout(200);
  await p.tap('.ed-props-toggle');
  await p.waitForTimeout(250);
  ok('موبايل: الزر العائم يفتح الإعدادات', await p.locator('.ed-panel[data-role="props"].open').isVisible());
  await p.tap('.ed-props-toggle');
  await p.waitForTimeout(250);
  ok('موبايل: الزر العائم يقفلها', await p.locator('.ed-panel[data-role="props"].open').count() === 0);

  // 8) الكانفس ظاهر بدون تغطية (الكانفس في منتصف الشاشة تقريبًا)
  const cv = await p.locator('.ed-canvas-holder').boundingBox();
  ok('موبايل: الكانفس ظاهر بعرض معقول', cv && cv.width > 200);
  await p.screenshot({ path: '/tmp/shots/meem-mobile-editor.png' });
  ok('موبايل: صفر أخطاء (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await mc.close();

  /* ---------- سطح المكتب (رجعة) ---------- */
  const dc = await b.newContext({ viewport: { width: 1600, height: 900 } });
  const d = await dc.newPage();
  const derr = [];
  d.on('pageerror', (e) => derr.push(e.message));
  await d.goto(BASE, { waitUntil: 'networkidle' });
  await d.waitForSelector('.login-card');
  await d.click('.login-card .btn.primary');
  await d.waitForSelector('.sidebar .nav-item');
  await d.evaluate(async () => { const { openEditor } = await import('/js/editor/index.js'); openEditor(null); });
  await d.waitForSelector('.ed');
  await d.waitForTimeout(400);
  // اللوحتان ظاهرتان ثابته بدون .open، وأزرار الإغلاق مخفية
  ok('ديسكتوب: لوحة الأدوات ثابتة وظاهرة', await d.locator('.ed-panel[data-role="tools"]').isVisible());
  ok('ديسكتوب: الإعدادات ثابتة وظاهرة', await d.locator('.ed-panel[data-role="props"]').isVisible());
  ok('ديسكتوب: زر × مخفي', !(await d.locator('.ed-close').first().isVisible()));
  ok('ديسكتوب: الزر العائم مخفي', !(await d.locator('.ed-props-toggle').isVisible()));
  // إضافة نص من اللوحة مباشرة
  await d.click('.ed-tool[data-tool="text"]');
  await d.locator('.ed-panel[data-role="tools"] .ed-item').first().click();
  await d.waitForTimeout(300);
  ok('ديسكتوب: إضافة نص تعمل', (await d.textContent('.ed-panel[data-role="props"]')).includes('المحتوى'));
  ok('ديسكتوب: صفر أخطاء', derr.length === 0);
  await dc.close();

  console.log('\n=== ' + R.filter(Boolean).length + '/' + R.length + ' ===');
  await b.close();
  process.exit(R.some((x) => !x) ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
