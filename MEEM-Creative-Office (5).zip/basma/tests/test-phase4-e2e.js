/* MEEM — Phase 4 E2E: Content Studio + Voice Studio (ميكروفون وهمي) */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = { c: [], a: [], v: [] };

(async () => {
  /* V2-3: الفيديو/الـ AI مخفيين افتراضيًا — المالك يتيحهم للاختبار */
  const setTools = async (on) => {
    const l = await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'owner@meem.studio', password: '123456' }) })).json();
    await fetch(BASE + '/api/mutate', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + l.token }, body: JSON.stringify({ collection: 'settings', op: 'upsert', doc: { id: 'tools', video: on, ai: on } }) });
  };
  await setTools(true);

  const b = await chromium.launch({ args: ['--no-sandbox', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'] });

  async function login(ctx, email) {
    const p = await ctx.newPage();
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    if (email === 'designer@meem.studio') {
      await p.click('.login-card .btn.primary');
    } else {
      await p.fill('input[type=email]', email);
      await p.click('.login-card .btn.primary');
    }
    await p.waitForSelector('.sidebar .nav-item');
    return p;
  }

  /* ============ كاتب المحتوى ============ */
  const c = await (await b.newContext({ viewport: { width: 1600, height: 950 } })).newPage();
  c.on('pageerror', (e) => errs.c.push(e.message));
  c.on('console', (m) => { if (m.type() === 'error') errs.c.push(m.text()); });
  await c.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await c.waitForSelector('.login-card');
  await c.fill('input[type=email]', 'content@meem.studio');
  await c.click('.login-card .btn.primary');
  await c.waitForSelector('.sidebar .nav-item');

  await c.goto(BASE + '/#/content', { waitUntil: 'networkidle' });
  await c.waitForSelector('.card, .empty', { timeout: 10000 });
  const nCards = await c.locator('.view .card').count();
  ok('مكتبة المحتوى بتظهر (' + nCards + ' كارت)', nCards >= 3);

  // محتوى جديد
  await c.click('.page-head .btn.primary');
  await c.waitForSelector('.studio .ct-body', { timeout: 8000 });
  ok('المحرر فتح (overlay كامل)', true);

  // AI: توليد مسودة (المولد المحلي — من غير مفتاح)
  await c.locator('.ai-btn', { hasText: 'توليد مسودة' }).click();
  await c.waitForTimeout(600);
  const bodyVal = await c.inputValue('.ct-body');
  ok('AI توليد مسودة → نص اتحط', bodyVal.length > 40);
  ok('شارة Pro ظاهرة (من غير مفتاح)', await c.locator('.pro-chip').first().isVisible());

  // AI: هاشتاجات
  await c.locator('.ai-btn', { hasText: 'هاشتاجات' }).click();
  await c.waitForTimeout(500);
  ok('AI هاشتاجات → # اتضافت', (await c.inputValue('.ct-body')).includes('#'));

  // عنوان + حفظ
  await c.fill('.ct-title', 'E2E كابشن Phase 4');
  await c.locator('.ct-top button', { hasText: 'حفظ' }).click();
  await c.waitForTimeout(800);
  ok('حفظ المحتوى', (await c.textContent('.ct-stats')).includes('محفوظ'));

  // Brand Voice: اختيار عميل
  await c.selectOption('.ct-editor select >> nth=1', 'cli_zahra');
  await c.waitForTimeout(400);
  ok('صوت البراند اتفعل', (await c.textContent('.studio')).includes('صوت البراند مفعّل'));

  // إرسال للمراجعة
  await c.locator('.ct-top button', { hasText: 'للمراجعة' }).click();
  await c.waitForTimeout(1000);
  ok('إرسال للمراجعة → شارة «في المراجعة»', (await c.textContent('.ct-top .badge')).includes('في المراجعة'));

  // قفل
  await c.click('.ct-top .btn.ghost.icon');
  await c.waitForTimeout(500);

  /* ============ الأدمن: اعتماد المحتوى ============ */
  const a = await (await b.newContext({ viewport: { width: 1600, height: 950 } })).newPage();
  a.on('pageerror', (e) => errs.a.push(e.message));
  a.on('console', (m) => { if (m.type() === 'error') errs.a.push(m.text()); });
  await a.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await a.waitForSelector('.login-card');
  await a.fill('input[type=email]', 'admin@meem.studio');
  await a.click('.login-card .btn.primary');
  await a.waitForSelector('.sidebar .nav-item');

  await a.goto(BASE + '/#/content', { waitUntil: 'networkidle' });
  await a.waitForTimeout(700);
  await a.locator('.view .card', { hasText: 'E2E كابشن Phase 4' }).first().click();
  await a.waitForSelector('.studio', { timeout: 8000 });
  await a.waitForTimeout(500);
  ok('المراجع شايف أزرار القرار', await a.locator('.ct-side button', { hasText: 'اعتماد' }).isVisible());
  await a.locator('.ct-side button', { hasText: 'اعتماد' }).click();
  await a.waitForTimeout(900);
  ok('اعتماد المحتوى → «معتمد»', (await a.textContent('.ct-top .badge')).includes('معتمد'));
  await a.screenshot({ path: '/tmp/shots/p4-content.png' });
  await a.click('.ct-top .btn.ghost.icon');
  await a.waitForTimeout(400);

  /* ============ الفويس: تسجيل حقيقي (ميكروفون وهمي) ============ */
  const v = await (await b.newContext({ viewport: { width: 1600, height: 950 }, permissions: ['microphone'] })).newPage();
  v.on('pageerror', (e) => errs.v.push(e.message));
  v.on('console', (m) => { if (m.type() === 'error') errs.v.push(m.text()); });
  await v.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await v.waitForSelector('.login-card');
  await v.fill('input[type=email]', 'voice@meem.studio');
  await v.click('.login-card .btn.primary');
  await v.waitForSelector('.sidebar .nav-item');

  await v.goto(BASE + '/#/voice', { waitUntil: 'networkidle' });
  await v.waitForSelector('.view .card, .view .empty', { timeout: 10000 });
  ok('استوديو الصوت بيظهر', true);

  await v.click('.page-head .btn.primary');
  await v.waitForSelector('.vs-mic', { timeout: 8000 });

  // ربط سكربت معتمد
  const opts = await v.locator('.ct-editor select option').allTextContents();
  ok('السكربتات المعتمدة في الاختيار', opts.some((t) => t.includes('✅')));

  // تسجيل 2.5 ثانية
  await v.click('.vs-mic');
  await v.waitForTimeout(2500);
  await v.click('.vs-mic');
  await v.waitForSelector('.vs-take', { timeout: 10000 });
  ok('اتسجل take والموجة ات رسمت', await v.locator('.vs-take canvas').isVisible());

  // معالجة: gain + fade
  await v.locator('.vs-ctrls button', { hasText: 'معالجة' }).click();
  await v.waitForTimeout(2500);
  ok('المعالجة تمت (شارة «معالَج»)', (await v.textContent('.vs-take')).includes('معالَج'));

  // عنوان + إرسال للمراجعة
  await v.fill('.ct-title', 'E2E فويس Phase 4');
  await v.locator('.ct-top button', { hasText: 'للمراجعة' }).click();
  await v.waitForTimeout(1200);
  ok('إرسال التسجيل للمراجعة', (await v.textContent('.ct-top .badge')).includes('في المراجعة'));
  await v.screenshot({ path: '/tmp/shots/p4-voice.png' });
  await v.click('.ct-top .btn.ghost.icon');
  await v.waitForTimeout(400);

  /* ============ الأدمن: اعتماد التسجيل ============ */
  await a.goto(BASE + '/#/voice?r=' + Date.now(), { waitUntil: 'networkidle' });
  await a.waitForTimeout(800);
  await a.locator('.view .card', { hasText: 'E2E فويس Phase 4' }).first().click();
  await a.waitForSelector('.studio', { timeout: 8000 });
  await a.waitForTimeout(900);
  await a.locator('.ct-panel button', { hasText: 'اعتماد' }).click();
  await a.waitForTimeout(900);
  ok('اعتماد التسجيل → «معتمد»', (await a.textContent('.ct-top .badge')).includes('معتمد'));

  await b.close();
  console.log('\nأخطاء console:', JSON.stringify({ content: errs.c.length, admin: errs.a.length, voice: errs.v.length }));
  if (errs.c.length) console.log(errs.c.slice(0, 3));
  if (errs.a.length) console.log(errs.a.slice(0, 3));
  if (errs.v.length) console.log(errs.v.slice(0, 3));
  await setTools(false);
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed || errs.c.length || errs.a.length || errs.v.length ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
