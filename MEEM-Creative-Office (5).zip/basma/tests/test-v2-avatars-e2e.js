/* MEEM V2-8 E2E — أفاتارات تتحرك لحظيًا: WASD · رؤية متبادلة · حالات · tap-to-move */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  async function login(email, ctxOpts) {
    const ctx = await b.newContext(Object.assign({ viewport: { width: 1500, height: 950 } }, ctxOpts || {}));
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errs.push(email + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(email + ': ' + m.text()); });
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    await p.fill('input[type=email]', email);
    await p.click('.login-card .btn.primary');
    await p.waitForSelector('.office-map');
    return p;
  }
  const avPos = async (p, sel) => p.evaluate((s) => { const e = document.querySelector(s); return e ? { l: e.style.left, t: e.style.top } : null; }, sel);

  /* ---- 1) المصمم والمحتوى في المكتب — يشوفوا بعض ---- */
  const d = await login('designer@meem.studio');
  const c = await login('content@meem.studio');
  await d.waitForTimeout(1200); await c.waitForTimeout(1200);
  ok('أفاتاري (me) موجود عند الاثنين', (await d.locator('.of-av.me').count()) === 1 && (await c.locator('.of-av.me').count()) === 1);
  ok('المصمم شايف أفاتار المحتوى', (await d.locator('.of-av:not(.me)').count()) >= 1);
  ok('المحتوى شايف أفاتار المصمم', (await c.locator('.of-av:not(.me)').count()) >= 1);

  /* ---- 2) WASD: المصمم يتحرك — المحتوى يشوفه لحظيًا ---- */
  const cSees = '.of-av:not(.me)';
  const before = await avPos(c, cSees);
  await d.keyboard.down('ArrowRight');
  await d.waitForTimeout(700);
  await d.keyboard.up('ArrowRight');
  await d.waitForTimeout(500);
  const after = await avPos(c, cSees);
  ok('الحركة وصلت لصفحة المحتوى لحظيًا (' + before.l + ' → ' + after.l + ')', before && after && before.l !== after.l);
  const myAfter = await avPos(d, '.of-av.me');
  ok('أفاتاري اتحرك عندي كمان', myAfter && myAfter.l !== '50%');

  /* ---- 3) الحالة: المصمم يقلب «مشغول» → المحتوى يشوف اللون ---- */
  await d.locator('.of-status-chip', { hasText: 'مشغول' }).click();
  await c.waitForTimeout(800);
  const ring = await c.evaluate(() => { const a = document.querySelector('.of-av:not(.me)'); return a ? getComputedStyle(a).getPropertyValue('--sc').trim() : null; });
  ok('حالة «مشغول» وصلت لحظيًا (#ef4444)', ring === '#ef4444');

  /* ---- 4) tap-to-move (لمس) ---- */
  const m = await login('voice@meem.studio', { viewport: { width: 390, height: 844 }, hasTouch: true });
  const mb = await avPos(m, '.of-av.me');
  await m.waitForTimeout(1600); // استنى أي toast يختفي
  const box = await m.locator('.office-map').boundingBox();
  await m.touchscreen.tap(box.x + box.width * 0.35, box.y + box.height * 0.88); // الساحة — بعيد عن أفاتار المحتوى الواقف في السبون (50,92)
  await m.waitForTimeout(2500);
  const ma = await avPos(m, '.of-av.me');
  ok('tap-to-move شغال على الموبايل', mb && ma && (mb.l !== ma.l || mb.t !== ma.t));

  /* ---- 5) الخروج: الأفاتار يختفي عند الباقي ---- */
  await c.close();
  await d.waitForTimeout(1200);
  ok('أفاتار المحتوى اختفى وفاضل voice بس', (await d.locator('.of-av:not(.me)').count()) === 1);
  await m.close();
  await d.waitForTimeout(1200);
  ok('كل الأفاتارات اتنضفت (باقي أنا بس)', (await d.locator('.of-av:not(.me)').count()) === 0);

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
