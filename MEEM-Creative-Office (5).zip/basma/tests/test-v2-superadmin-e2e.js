/* MEEM V2-3 E2E — لوحة المالك: دخول · tabs · Team · Tools · العزل عن الفريق */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });

  async function login(email) {
    const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errs.push(email + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error') errs.push(email + ': ' + m.text()); });
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    await p.fill('input[type=email]', email);
    await p.click('.login-card .btn.primary');
    await p.waitForSelector('.sidebar .nav-item');
    return p;
  }

  /* ---- 1) المالك يدخل ويهبط على لوحته ---- */
  const o = await login('owner@meem.studio');
  ok('المالك هبط على #/owner تلقائيًا', o.url().includes('#/owner'));
  await o.waitForSelector('.owner-head');
  ok('هوية OWNER CONTROL ظاهرة', (await o.locator('.owner-logo').innerText()).includes('MEE'));
  ok('KPIs النظرة العامة ≥ 9', (await o.locator('.owner-kpi').count()) >= 9);
  ok('9 تبويبات', (await o.locator('.owner-tab').count()) === 9);

  /* ---- 2) Team tab ---- */
  await o.locator('.owner-tab', { hasText: 'Team' }).click();
  await o.waitForSelector('.team-row');
  const rows = await o.locator('.team-row').count();
  ok('الفريق ظاهر في Team (≥8 صفوف)', rows >= 8);
  ok('المالك شايف نفسه (أنت)', (await o.locator('.team-row').filter({ hasText: '(أنت)' }).count()) === 1);

  /* ---- 3) Tools tab: toggle ---- */
  await o.locator('.owner-tab', { hasText: 'Tools' }).click();
  await o.waitForSelector('.owner-switch');
  ok('مفتاحان (فيديو + AI)', (await o.locator('.owner-switch').count()) === 2);
  const sw = o.locator('.owner-switch').nth(1); // AI
  await sw.click();
  await o.waitForSelector('.owner-switch.on', { timeout: 5000 });
  ok('toggle بيشتغل (AI بقى on)', true);
  await o.locator('.owner-switch.on').first().click(); // نرجعه off
  await o.waitForTimeout(700);

  /* ---- 4) الفريق: الفيديو/الاجتماعات مخفية + #/owner محجوب ---- */
  const d = await login('designer@meem.studio');
  const navTexts = (await d.locator('.sidebar .nav-item').allInnerTexts()).join('|');
  ok('designer: مفيش «الاجتماعات» في السايدبار', !navTexts.includes('الاجتماعات'));
  ok('designer: مفيش «استوديو الفيديو»', !navTexts.includes('استوديو الفيديو'));
  await d.goto(BASE + '/#/owner', { waitUntil: 'networkidle' });
  await d.waitForTimeout(600);
  ok('designer ⛔ #/owner → تحويل', !d.url().includes('#/owner'));

  /* ---- 5) رجّعنا الأدوات؟ نتأكد AI مخفي عن المصمم في المحرر ---- */
  // (اتأكدنا API-level في suite الصلاحيات — هنا nav بس)

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));

  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
