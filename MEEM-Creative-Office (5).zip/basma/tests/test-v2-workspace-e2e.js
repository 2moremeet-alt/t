/* MEEM V2-5 E2E — كل تخصص يشوف أدواته فقط (nav + routes) مع بقاء بيانات المشاريع المشتركة */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

/* الأسماء الحقيقية من i18n — مطابقة تامة لكل عنصر (أول سطر من الـ nav-item) */
const EXPECT = {
  'designer@meem.studio': { has: ['التصميم', 'التصوير', 'خدمة العملاء والتسليمات'], lacks: ['تجهيز المحتوى', 'الفويس أوفر', 'البرمجة', 'العملاء', 'الطلبات'] },
  'content@meem.studio':  { has: ['تجهيز المحتوى'], lacks: ['التصميم', 'الفويس أوفر', 'البرمجة', 'العملاء', 'الطلبات'] },
  'voice@meem.studio':    { has: ['الفويس أوفر'], lacks: ['التصميم', 'تجهيز المحتوى', 'البرمجة', 'العملاء'] },
  'dev@meem.studio':      { has: ['البرمجة'], lacks: ['التصميم', 'تجهيز المحتوى', 'الفويس أوفر', 'العملاء', 'الطلبات'] },
  'cs@meem.studio':       { has: ['العملاء', 'الطلبات', 'خدمة العملاء والتسليمات'], lacks: ['التصميم', 'تجهيز المحتوى', 'الفويس أوفر', 'البرمجة'] },
};

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });

  for (const [email, exp] of Object.entries(EXPECT)) {
    const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errs.push(email + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(email + ': ' + m.text()); });
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    await p.fill('input[type=email]', email);
    await p.click('.login-card .btn.primary');
    await p.waitForSelector('.sidebar .nav-item');
    const nav = (await p.locator('.sidebar .nav-item').allInnerTexts()).map((x) => x.split('\n')[0].trim());
    const who = email.split('@')[0];
    ok(`${who}: أدواته ظاهرة (${exp.has.join('،')})`, exp.has.every((h) => nav.includes(h)));
    ok(`${who}: أدوات غيره مخفية (${exp.lacks.join('،')})`, exp.lacks.every((l) => !nav.includes(l)));
    await ctx.close();
  }

  /* حارس الـ Routes: designer يحاول يفتح استوديو المحتوى */
  const ctx = await b.newContext();
  const p = await ctx.newPage();
  await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', 'designer@meem.studio');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.sidebar .nav-item');
  await p.goto(BASE + '/#/content', { waitUntil: 'networkidle' });
  await p.waitForTimeout(600);
  ok('designer ⛔ #/content → تحويل', !p.url().includes('#/content'));
  await p.goto(BASE + '/#/dev', { waitUntil: 'networkidle' });
  await p.waitForTimeout(600);
  ok('designer ⛔ #/dev → تحويل', !p.url().includes('#/dev'));

  /* بيانات المشاريع المشتركة لسه متاحة (مطلوبة للتعاون — §5/§6) */
  const l = await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'designer@meem.studio', password: '123456' }) })).json();
  const st = await (await fetch(BASE + '/api/state', { headers: { Authorization: 'Bearer ' + l.token } })).json();
  ok('بيانات التعاون متاحة: projects+tasks+contents في state المصمم', Array.isArray(st.data.projects) && Array.isArray(st.data.tasks) && Array.isArray(st.data.contents));

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
