/* MEEM — Phase 4 API: Content Studio + Voice Studio + AI pipeline */
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' ' + n + (c ? '' : ' ← ← ←')); };

async function api(path, token, body) {
  const res = await fetch(BASE + '/api' + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}
const login = (email) => api('/login', null, { email, password: '123456' }).then((r) => r.json.token);

(async () => {
  const content = await login('content@meem.studio');
  const admin = await login('admin@meem.studio');
  const owner = await login('owner@meem.studio'); // V2-3
  await api('/mutate', owner, { collection: 'settings', op: 'upsert', doc: { id: 'tools', video: true, ai: true } }); // إتاحة AI للاختبار
  const client = await login('client@meem.studio');
  const voice = await login('voice@meem.studio'); // V2-2: التسجيلات دور voice مش content

  /* ---- state فيه contents/voices ---- */
  let st = await api('/state', content);
  ok('state: فيه contents seeded', (st.json.data.contents || []).length >= 3);
  ok('state: فيه voices', Array.isArray(st.json.data.voices));
  ok('state: الـ voices مجردة من الـ payload', (st.json.data.voices || []).every((v) => (v.takes || []).every((t) => t.data === undefined)));

  /* ---- إنشاء محتوى ---- */
  let r = await api('/mutate', content, { collection: 'contents', op: 'upsert', doc: { title: 'كابشن اختبار P4', type: 'caption', body: 'نص تجريبي للاختبار', status: 'draft', clientId: 'cli_zahra', projectId: 'prj_1', owner: 'usr_content', comments: [], versions: [] } });
  const cid = r.json.doc.id;
  ok('إنشاء محتوى', !!cid);

  /* ---- دورة المراجعة ---- */
  r = await api(`/doc/contents/${cid}/submit`, content, { note: '' });
  ok('submit → review + نسخة V1', r.json.doc.status === 'review' && r.json.version && r.json.version.v === 1);

  r = await api(`/doc/contents/${cid}/decision`, content, { decision: 'approve' });
  ok('صاحب الشغل ما يقيمش نفسه (403)', r.status === 403);

  r = await api(`/doc/contents/${cid}/decision`, admin, { decision: 'changes' });
  ok('تعديل من غير ملاحظات → 400', r.status === 400);

  r = await api(`/doc/contents/${cid}/decision`, admin, { decision: 'changes', note: 'كبر الهوك' });
  ok('admin طلب تعديل → changes', r.json.doc.status === 'changes' && r.json.doc.review.note === 'كبر الهوك');

  await api('/mutate', content, { collection: 'contents', op: 'upsert', doc: { id: cid, body: 'نص معدّل أكبر وأقوى' } });
  r = await api(`/doc/contents/${cid}/submit`, content, {});
  ok('إعادة إرسال → نسخة V2', r.json.version.v === 2);

  r = await api(`/doc/contents/${cid}/decision`, admin, { decision: 'approve' });
  ok('اعتماد → approved', r.json.doc.status === 'approved');

  /* ---- تعليقات ---- */
  r = await api(`/doc/contents/${cid}/comment`, admin, { text: 'الهوك بقى أحلى 👌' });
  const cmId = r.json.comments[0].id;
  ok('تعليق جديد', !!cmId);
  r = await api(`/doc/contents/${cid}/comment`, content, { id: cmId, op: 'resolve' });
  ok('حل التعليق', r.json.comments[0].resolved === true);

  /* ---- AI pipeline ---- */
  r = await api('/ai', content, { action: 'draft', type: 'caption' });
  ok('AI من غير مفتاح → fallback', r.json.ok && r.json.fallback === true);

  await api('/mutate', admin, { collection: 'settings', op: 'upsert', doc: { id: 'ai', provider: 'openai', key: 'sk-test-mesh-sahih', model: 'gpt-4o-mini', baseUrl: 'https://api.openai.com/v1' } });
  r = await api('/ai', content, { action: 'draft', type: 'caption' });
  ok('AI بمفتاح غلط → fallback + providerError', r.json.fallback === true && !!r.json.providerError);
  await api('/mutate', admin, { collection: 'settings', op: 'upsert', doc: { id: 'ai', key: '' } });

  /* ---- Voice ---- */
  const fakeWav = 'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YQAAAAA=';
  r = await api('/mutate', voice, { collection: 'voices', op: 'upsert', doc: { title: 'تسجيل اختبار P4', contentId: cid, owner: 'usr_voice', status: 'draft', takes: [{ id: 'tk_1', data: fakeWav, dur: 2.5, at: new Date().toISOString(), name: 'Take 1' }], mainTakeId: 'tk_1', comments: [] } });
  const vid = r.json.doc.id;
  ok('إنشاء تسجيل صوتي', !!vid);
  ok('الرد stripped (مفيش data)', r.json.doc.takes[0].data === undefined && r.json.doc.takes[0].hasData === true);

  r = await api(`/doc/voices/${vid}/submit`, voice, {});
  ok('voice submit → review', r.json.doc.status === 'review');
  r = await api(`/doc/voices/${vid}/decision`, admin, { decision: 'approve' });
  ok('voice approve → approved', r.json.doc.status === 'approved');

  r = await api(`/doc/voices/${vid}`, content);
  ok('docGet كامل يرجّع الـ data', r.json.doc.takes[0].data === fakeWav);

  /* ---- عزل العميل ---- */
  st = await api('/state', client);
  ok('العميل: contents/voices فاضية', st.json.data.contents.length === 0 && st.json.data.voices.length === 0);
  r = await api('/mutate', client, { collection: 'contents', op: 'upsert', doc: { title: 'x' } });
  ok('العميل: mutate مرفوض 403', r.status === 403);

  /* ---- تنظيف ---- */
  await api('/mutate', admin, { collection: 'contents', op: 'delete', id: cid });
  await api('/mutate', admin, { collection: 'voices', op: 'delete', id: vid });

  await api('/mutate', owner, { collection: 'settings', op: 'upsert', doc: { id: 'tools', video: false, ai: false } }); // إرجاع الإخفاء
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
