/* MEEM V2-6 E2E — فريق المشروع: أعضاء بأدوار + حالة اتصال + إضافة/إزالة + بلوك التعديلات */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  async function login(email) {
    const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errs.push(email + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(email + ': ' + m.text()); });
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    await p.fill('input[type=email]', email);
    await p.click('.login-card .btn.primary');
    await p.waitForSelector('.sidebar .nav-item');
    return p;
  }

  /* ---- 1) فريق مزروع ظاهر في صفحة المشروع ---- */
  const a = await login('admin@meem.studio');
  await a.goto(BASE + '/#/projects/prj_1', { waitUntil: 'networkidle' });
  await a.waitForSelector('text=فريق المشروع');
  ok('قسم «فريق المشروع» ظاهر', true);
  const memberRows = a.locator('.pt-dot');
  ok('أعضاء مزروعين (≥3 نقاط حالة)', (await memberRows.count()) >= 3);
  ok('بلوك التعديلات والاعتمادات ظاهر', (await a.locator('text=التعديلات والاعتمادات').count()) >= 1);

  /* ---- 2) حالة الاتصال لحظية: المصمم يفتح تاب → نقطته تخضر ---- */
  const d = await login('designer@meem.studio');
  await a.waitForTimeout(1500);
  await a.goto(BASE + '/#/projects/prj_1?r=' + Date.now(), { waitUntil: 'networkidle' });
  await a.waitForSelector('.pt-dot');
  ok('فيه نقطة connected على الأقل (متصل واحد)', (await a.locator('.pt-dot.on').count()) >= 1);

  /* ---- 3) إضافة عضو ---- */
  const before = await a.locator('.pt-dot').count();
  await a.locator('button', { hasText: 'عضو' }).first().click();
  await a.waitForSelector('.modal');
  // نضيف أول موظف متاح مش في الفريق
  const opts = await a.locator('.modal select').first().locator('option').allInnerTexts();
  ok('مودال الإضافة فيه مرشحين', opts.length >= 2);
  await a.locator('.modal select').first().selectOption({ index: 1 });
  await a.locator('.modal select').nth(1).selectOption('dev');
  await a.locator('.modal button', { hasText: 'إضافة' }).click();
  await a.waitForTimeout(1200);
  const after = await a.locator('.pt-dot').count();
  ok('العضو الجديد اتضاف (' + before + '→' + after + ')', after === before + 1);

  /* ---- 4) إزالة عضو ---- */
  await a.locator('.card:has(.pt-dot) button[title="إزالة من المشروع"]').last().click();
  await a.waitForTimeout(1200);
  const afterRemove = await a.locator('.pt-dot').count();
  ok('الإزالة اشتغلت (' + after + '→' + afterRemove + ')', afterRemove === before);

  /* ---- 5) API: الـ members محفوظين في المشروع ---- */
  const l = await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'admin@meem.studio', password: '123456' }) })).json();
  const st = await (await fetch(BASE + '/api/state', { headers: { Authorization: 'Bearer ' + l.token } })).json();
  const p1 = st.data.projects.find((x) => x.id === 'prj_1');
  ok('prj_1 فيه members بأدوار', Array.isArray(p1.members) && p1.members.length >= 3 && p1.members.every((m) => m.userId && m.role));

  /* ---- 6) المصمم (عضو فريق) شايف صفحة المشروع المشتركة ---- */
  await d.goto(BASE + '/#/projects/prj_1', { waitUntil: 'networkidle' });
  await d.waitForSelector('text=فريق المشروع');
  ok('عضو الفريق (designer) شايف الصفحة الموحدة', true);
  ok('designer ما يقدرش يعدّل الفريق (مفيش زر إضافة)', (await d.locator('button', { hasText: 'عضو' }).count()) === 0);

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
