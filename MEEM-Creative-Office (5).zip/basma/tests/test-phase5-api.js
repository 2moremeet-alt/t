/* MEEM — Phase 5 API: Upload + Video review + Shoots + Bugs */
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' ' + n); };

async function api(path, token, body) {
  const res = await fetch(BASE + '/api' + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}
const login = (email) => api('/login', null, { email, password: '123456' }).then((r) => r.json.token);

(async () => {
  const dev = await login('dev@meem.studio');
  const admin = await login('admin@meem.studio');
  const design = await login('designer@meem.studio');
  const client = await login('client@meem.studio');

  /* ---- Upload ---- */
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
  let res = await fetch(BASE + '/api/upload?name=test.png', { method: 'POST', headers: { Authorization: 'Bearer ' + design, 'Content-Type': 'application/octet-stream' }, body: png });
  let up = await res.json();
  ok('upload → url', up.ok && /^\/uploads\/upl_[a-f0-9]+\.png$/.test(up.url));
  res = await fetch(BASE + up.url);
  ok('الملف المرفوع بيتحمّل (200 + bytes)', res.status === 200 && (await res.arrayBuffer()).byteLength === png.length);
  res = await fetch(BASE + '/uploads/%2e%2e%2fdb.json');
  ok('path traversal (encoded) مرفوض', res.status === 403 || res.status === 404);
  res = await fetch(BASE + '/uploads/../../db.json');
  const travBody = await res.text();
  ok('path traversal ما بيسرّبش db.json', !travBody.includes('"passwordHash"') && !travBody.includes('"users"'));

  /* ---- Video doc review cycle ---- */
  let r = await api('/mutate', design, {
    collection: 'videos', op: 'upsert',
    doc: { title: 'فيديو اختبار P5', w: 1080, h: 1920, fps: 30, owner: 'usr_design', status: 'draft', comments: [], media: [{ id: 'md_1', url: up.url, kind: 'image', name: 'test.png' }], clips: [{ id: 'cl_1', mediaId: 'md_1', kind: 'image', dur: 3, text: 'اختبار', textSize: 42, textColor: '#fff', textPos: 'bottom' }] },
  });
  const vid = r.json.doc.id;
  ok('إنشاء مشروع مونتاج', !!vid);
  r = await api('/doc/videos/' + vid + '/submit', design, {});
  ok('فيديو submit → review', r.json.doc.status === 'review');
  r = await api('/doc/videos/' + vid + '/decision', design, { decision: 'approve' });
  ok('صاحب الشغل ما يقيمش نفسه (403)', r.status === 403);
  r = await api('/doc/videos/' + vid + '/decision', admin, { decision: 'approve' });
  ok('فيديو approve → approved', r.json.doc.status === 'approved');
  r = await api('/doc/videos/' + vid + '/comment', admin, { text: 'الإيقاع مظبوط 👌' });
  ok('تعليق على الفيديو', (r.json.comments || []).length === 1);

  /* ---- Shoots ---- */
  let st = await api('/state', design);
  ok('shoots seeded (2)', (st.json.data.shoots || []).length === 2);
  const shoot = st.json.data.shoots[0];
  shoot.shots[0].done = true;
  r = await api('/mutate', design, { collection: 'shoots', op: 'upsert', doc: shoot });
  ok('تعليم لقطة في الـ Shot List', r.json.doc.shots[0].done === true);

  /* ---- Bugs ---- */
  st = await api('/state', dev);
  ok('bugs seeded (3+)', (st.json.data.bugs || []).length >= 3);
  r = await api('/mutate', dev, { collection: 'bugs', op: 'upsert', doc: { title: 'باج اختبار P5', desc: 'x', severity: 'critical', status: 'new', reporter: 'usr_dev', assignee: 'usr_dev', comments: [] } });
  const bid = r.json.doc.id;
  r = await api('/mutate', dev, { collection: 'bugs', op: 'upsert', doc: { id: bid, status: 'fixed' } });
  ok('باج: نقل الحالة new → fixed', r.json.doc.status === 'fixed');

  /* ---- عزل العميل ---- */
  st = await api('/state', client);
  ok('العميل: videos/shoots/bugs فاضية', st.json.data.videos.length === 0 && st.json.data.shoots.length === 0 && st.json.data.bugs.length === 0);

  /* ---- تنظيف ---- */
  await api('/mutate', admin, { collection: 'videos', op: 'delete', id: vid });
  await api('/mutate', admin, { collection: 'bugs', op: 'delete', id: bid });
  await api('/mutate', admin, { collection: 'shoots', op: 'upsert', doc: { id: shoot.id, shots: shoot.shots.map((s, i) => i === 0 ? { ...s, done: false } : s) } });

  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
