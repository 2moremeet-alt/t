/* MEEM V2-11 E2E — بوابة العميل بالتوكن: توليد · فتح بدون تسجيل · أمان · الحسابات القديمة */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  async function login(email) {
    const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errs.push(email + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(email + ': ' + m.text()); });
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    await p.fill('input[type=email]', email);
    await p.click('.login-card .btn.primary');
    await p.waitForSelector('.sidebar .nav-item');
    return p;
  }
  const loginApi = async (email) => (await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: '123456' }) })).json()).token;

  /* ---- 1) الأدمن يولد لينك العميل من صفحة المشروع ---- */
  const a = await login('admin@meem.studio');
  await a.goto(BASE + '/#/projects/prj_1', { waitUntil: 'networkidle' });
  await a.waitForSelector('button:has-text("لينك العميل")');
  await a.click('button:has-text("لينك العميل")');
  await a.waitForSelector('.modal input[readonly]');
  const fullUrl = await a.locator('.modal input[readonly]').inputValue();
  ok('لينك العميل اتولد: /client/project/…', /\/client\/project\/[a-f0-9]{48}$/.test(fullUrl));
  const token = fullUrl.split('/').pop();

  /* ---- 2) API: التوكن شغال بدون تسجيل ---- */
  const pub = await fetch(BASE + '/api/tportal/' + token);
  const pj = await pub.json();
  ok('tportal عام بيرد 200 + بيانات المشروع', pub.status === 200 && pj.data.project.id === 'prj_1');
  ok('بيانات العميل مش بتسرب أكتر من اللازم', pj.data.designs.every((d) => d.layers === undefined));

  /* ---- 3) متصفح جديد من غير لوجين يفتح اللينك ---- */
  const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
  const g = await ctx.newPage();
  const gerrs = [];
  g.on('pageerror', (e) => gerrs.push(e.message));
  g.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) gerrs.push(m.text()); });
  await g.goto(BASE + '/client/project/' + token, { waitUntil: 'networkidle' });
  await g.waitForSelector('.tp-head', { timeout: 15000 });
  ok('البوابة فتحت من غير تسجيل (مفيش login-card)', (await g.locator('.login-card').count()) === 0);
  ok('عنوان المشروع ظاهر', (await g.locator('.tp-head h1').textContent()).length > 3);
  ok('أقسام البوابة موجودة (تصاميم/خطوات)', (await g.locator('.tp-sec').count()) >= 2);

  /* ---- 4) توكن غلط → صفحة خطأ نظيفة ---- */
  await g.goto(BASE + '/client/project/' + 'f'.repeat(48), { waitUntil: 'networkidle' });
  await g.waitForSelector('.tp-err');
  ok('التوكن الغلط بيعرض «اللينك مش شغال»', true);
  const bad = await fetch(BASE + '/api/tportal/' + 'f'.repeat(48));
  ok('API: توكن غلط = 404', bad.status === 404);

  /* ---- 5) أمان: designer ما يقدرش يولد لينك ---- */
  const dTok = await loginApi('designer@meem.studio');
  const deny = await fetch(BASE + '/api/client-link', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + dTok }, body: JSON.stringify({ projectId: 'prj_1' }) });
  ok('designer مرفوض من توليد اللينك (403)', deny.status === 403);

  /* ---- 6) توليد جديد يوقف القديم ---- */
  const aTok = await loginApi('admin@meem.studio');
  const regen = await (await fetch(BASE + '/api/client-link', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + aTok }, body: JSON.stringify({ projectId: 'prj_1', regenerate: true }) })).json();
  const oldDead = await fetch(BASE + '/api/tportal/' + token);
  const newAlive = await fetch(BASE + '/api/tportal/' + regen.token);
  ok('التوليد الجديد وقف التوكن القديم (404) والجديد شغال (200)', oldDead.status === 404 && newAlive.status === 200);

  /* ---- 7) حسابات العملاء القديمة لسه شغالة ---- */
  const c = await login('client@meem.studio');
  await c.waitForTimeout(600);
  ok('العميل القديم دخل على بوابته (#/portal)', c.url().includes('#/portal'));

  ok('صفر أخطاء console في البوابة (' + gerrs.length + ')', gerrs.length === 0);
  if (gerrs.length) console.log(gerrs.slice(0, 3).join('\n'));
  ok('صفر أخطاء console في الأبلكيشن (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 3).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
