/* MEEM V2-13 E2E — صفحة اطلب مشروع: خدمات · فورم ديناميكي · تحقق · CS review · تحويل لمشروع */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });

  /* ---- 1) الصفحة العامة: 5 خدمات ---- */
  const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
  const g = await ctx.newPage();
  g.on('pageerror', (e) => errs.push(e.message));
  g.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()); });
  await g.goto(BASE + '/request', { waitUntil: 'networkidle' });
  await g.waitForSelector('.pr-svc');
  ok('الصفحة عامة (مفيش login-card)', (await g.locator('.login-card').count()) === 0);
  ok('5 خدمات معروضة', (await g.locator('.pr-svc').count()) === 5);

  /* ---- 2) الفورم الديناميكي بيتغير حسب الخدمة ---- */
  await g.locator('.pr-svc', { hasText: 'فويس أوفر' }).click();
  await g.waitForSelector('#prf_voiceType');
  ok('فورم الفويس فيه حقوله الخاصة (نوع/مدة/لهجة)', (await g.locator('#prf_voiceType').count()) === 1 && (await g.locator('#prf_duration').count()) === 1 && (await g.locator('#prf_lang').count()) === 1);
  ok('والحقول المشتركة (اسم/إيميل/موبايل/تفاصيل)', (await g.locator('#prf_name').count()) === 1 && (await g.locator('#prf_email').count()) === 1);
  await g.locator('.pr-back').click();
  await g.waitForSelector('.pr-svc');
  await g.locator('.pr-svc', { hasText: 'موقع/تطبيق' }).click();
  await g.waitForSelector('#prf_projectType');
  ok('فورم الديف مختلف (نوع المشروع/خصائص)', (await g.locator('#prf_projectType').count()) === 1 && (await g.locator('#prf_features').count()) === 1);

  /* ---- 3) التحقق: خانة ناقصة → رسالة ---- */
  await g.locator('.pr-send').click();
  await g.waitForTimeout(300);
  ok('الناقص بيترفض مع رسالة', /كمّل خانة/.test(await g.locator('.pr-err').textContent()));
  await g.fill('#prf_name', 'عمرو اختبار');
  await g.fill('#prf_email', 'عمرو@غلط');
  await g.fill('#prf_phone', '01099999999');
  await g.fill('#prf_details', 'عايز متجر إلكتروني بخاصية الدفع');
  await g.fill('#prf_features', 'دفع إلكتروني + لوحة تحكم');
  await g.selectOption('#prf_projectType', 'متجر إلكتروني');
  await g.locator('.pr-send').click();
  await g.waitForTimeout(300);
  ok('الإيميل الغلط بيترفض', /الإيميل مش صح/.test(await g.locator('.pr-err').textContent()));

  /* ---- 4) إرسال صحيح ---- */
  await g.fill('#prf_email', 'amr.test@example.com');
  await g.fill('#prf_company', 'شركة عمرو');
  await g.locator('.pr-send').click();
  await g.waitForSelector('.pr-thanks', { timeout: 10000 });
  const ref = await g.locator('.pr-ref').textContent();
  ok('الشكر + رقم الطلب ظاهر', /req_[a-f0-9]+/.test(ref));
  const reqId = ref.match(/req_[a-f0-9]+/)[0];

  /* ---- 5) الطلب وصل CS ---- */
  const loginApi = async (email) => (await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: '123456' }) })).json()).token;
  const csTok = await loginApi('cs@meem.studio');
  const st = async (tok) => (await (await fetch(BASE + '/api/state', { headers: { Authorization: 'Bearer ' + tok } })).json()).data;
  let d = await st(csTok);
  const req = d.requests.find((x) => x.id === reqId);
  ok('الطلب محفوظ بكل بياناته', !!req && req.service === 'dev' && req.form.projectType === 'متجر إلكتروني' && req.contact.email === 'amr.test@example.com');

  /* ---- 6) API: تحقق server-side ---- */
  const bad = await fetch(BASE + '/api/requests/new', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ service: 'dev', form: { name: 'x' } }) });
  ok('السيرفر بيرفض الناقص (400)', bad.status === 400);
  const badSvc = await fetch(BASE + '/api/requests/new', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ service: 'hacking', form: { name: 'a', email: 'a@b.co', phone: '1', details: 'x' } }) });
  ok('خدمة مش معروفة مرفوضة (400)', badSvc.status === 400);

  /* ---- 7) CS يحوّله لمشروع (عميل جديد بالإيميل) ---- */
  const cctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const c = await cctx.newPage();
  c.on('pageerror', (e) => errs.push('cs: ' + e.message));
  await c.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await c.waitForSelector('.login-card');
  await c.fill('input[type=email]', 'cs@meem.studio');
  await c.click('.login-card .btn.primary');
  await c.waitForSelector('.sidebar .nav-item');
  await c.goto(BASE + '/#/requests', { waitUntil: 'networkidle' });
  const card = c.locator('.card', { hasText: reqId ? 'شركة عمرو' : 'شركة عمرو' });
  await c.waitForSelector('text=من الموقع');
  ok('كارت الطلب فيه بيانات الاتصال من الموقع', (await c.locator('text=amr.test@example.com').count()) >= 1);
  await c.locator('.card', { hasText: 'شركة عمرو' }).locator('button', { hasText: 'تحويل لمشروع' }).click();
  await c.waitForTimeout(2500);
  ok('اتحوّل لمشروع (الصفحة فتحت)', c.url().includes('#/projects/'));
  d = await st(csTok);
  const newPrj = d.projects.find((p) => p.fromRequest === reqId);
  const newClient = d.clients.find((x) => x.email === 'amr.test@example.com');
  ok('مشروع اتعمل من الطلب', !!newPrj);
  ok('عميل جديد اتسجل بالإيميل وربط بالمشروع', !!newClient && newPrj.clientId === newClient.id);
  ok('الطلب حالته converted', d.requests.find((x) => x.id === reqId).status === 'converted');

  /* ---- تنظيف ---- */
  const aTok = await loginApi('admin@meem.studio');
  await fetch(BASE + '/api/mutate', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + aTok }, body: JSON.stringify({ collection: 'projects', op: 'delete', id: newPrj.id }) });
  await fetch(BASE + '/api/mutate', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + aTok }, body: JSON.stringify({ collection: 'clients', op: 'delete', id: newClient.id }) });
  await fetch(BASE + '/api/mutate', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + aTok }, body: JSON.stringify({ collection: 'requests', op: 'delete', id: reqId }) });

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
