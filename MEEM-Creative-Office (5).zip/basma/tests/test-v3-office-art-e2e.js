/* MEEM V3-1 E2E — المكتب البيكسلي: Tiles + أثاث + sprites + لوحة اسم + كاميرا */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()); });

  await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', 'designer@meem.studio');
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.office-map', { timeout: 15000 });
  await p.waitForTimeout(900);

  /* ---- 1) فن العالم ---- */
  ok('طبقة SVG للخريطة موجودة', await p.locator('svg.of-art').count() === 1);
  const art = await p.evaluate(() => {
    const svg = document.querySelector('svg.of-art');
    return {
      patterns: svg.querySelectorAll('pattern').length,
      furn: svg.querySelectorAll('use.of-furn').length,
      circles: svg.querySelectorAll('circle').length,
      walls: [...svg.querySelectorAll('rect')].filter((r) => r.getAttribute('fill') === '#39435a').length,
    };
  });
  ok('تكسات أرضيات ≥ 5 (بلاط/سجاد/خشب/خرسانة/عشب)', art.patterns >= 5);
  ok('قطع أثاث موزعة ≥ 25 (' + art.furn + ')', art.furn >= 25);
  ok('جدران وأبواب مرسومة ≥ 40 مقطع', art.walls >= 40);
  ok('شجر خارجي (دوائر خضرا)', art.circles >= 12);

  /* ---- 2) لوحات أسماء الغرف ---- */
  ok('6 لوحات غرف بالطابق ١ بأسلوب Gather', await p.locator('.or-label').count() === 6);

  /* ---- 3) الأفاتار: sprite + لوحة اسم ---- */
  ok('لوحة اسمي فوق الأفاتار (أنت + نقطة حالة)', await p.locator('.of-av.me .of-tag .of-tag-dot').count() === 1 && (await p.textContent('.of-av.me .of-tag')).includes('أنت'));
  ok('sprite بجسم ورأس', await p.locator('.of-av.me .of-sprite .of-head').count() === 1 && await p.locator('.of-av.me .of-sprite svg.of-body').count() === 1);

  /* ---- 4) المشي + الاتجاه ---- */
  const mapBox = async () => await p.locator('.office-map').boundingBox();
  const clickWorld = async (x, y) => {
    const mb = await mapBox();
    await p.mouse.click(mb.x + (x / 100) * mb.width, mb.y + (y / 100) * mb.height);
  };
  await clickWorld(50, 53);
  await p.waitForTimeout(600);
  ok('tap-to-move بيحرّك والـ sprite بيمشي (walking)', await p.locator('.of-av.me.walking').count() === 1);
  await p.waitForTimeout(2600);
  ok('بيوقف المشي لما يوصل', await p.locator('.of-av.me.walking').count() === 0);
  await clickWorld(33, 55);
  await p.waitForTimeout(600);
  ok('اتجاه الشمال — face-left', await p.locator('.of-av.me.face-left').count() === 1);
  await p.waitForTimeout(2600);

  /* ---- 5) الكاميرا والـ Zoom ---- */
  const getT = () => p.evaluate(() => document.querySelector('.office-map').style.transform);
  const scaleOf = (t) => { const m = /scale\(([\d.]+)\)/.exec(t || ''); return m ? +m[1] : 0; };
  const t0 = await getT();
  await p.locator('.of-hbtn', { hasText: '+' }).click();
  await p.locator('.of-hbtn', { hasText: '+' }).click();
  await p.waitForTimeout(300);
  const t1 = await getT();
  ok('زر + يكبّر (scale زاد)', scaleOf(t1) > scaleOf(t0));
  ok('مؤشر الزوم اتغير', (await p.textContent('.of-zlbl')) !== '⤢');
  await p.keyboard.down('d');
  await p.waitForTimeout(700);
  await p.keyboard.up('d');
  const t2 = await getT();
  const tx = (t) => { const m = /translate\((-?[\d.]+)px/.exec(t || ''); return m ? +m[1] : 0; };
  ok('الكاميرا بتتبع المشي (translate اتغير)', Math.abs(tx(t2) - tx(t1)) > 4);
  await p.locator('.of-hbtn', { hasText: '⤢' }).click();
  await p.waitForTimeout(200);
  ok('زر ⤢ يرجّع لكل المكتب', (await p.textContent('.of-zlbl')) === '⤢');

  /* ---- 6) رجعية: الغرف لسه بتفتح ---- */
  await p.locator('.office-room', { hasText: 'التصميم' }).click();
  await p.waitForTimeout(700);
  ok('رجعية — غرفة التصميم → #/design', p.url().includes('#/design'));

  ok('بدون أخطاء console', errs.length === 0);
  if (errs.length) console.log('ERRORS:\n' + errs.slice(0, 8).join('\n'));

  await b.close();
  const pass = R.filter(Boolean).length;
  console.log(`\nV3-1 Office Art: ${pass}/${R.length}`);
  process.exit(pass === R.length ? 0 : 1);
})();
