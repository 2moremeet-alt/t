/* MEEM — Phase 5 E2E: Video Studio (تصدير WebM حقيقي) + Photography + Bug Tracker */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const PNG = '/tmp/tc/p5img.png';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'] });

  async function login(email) {
    const ctx = await b.newContext({ viewport: { width: 1600, height: 950 }, acceptDownloads: true });
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errs.push(email + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error') errs.push(email + ': ' + m.text()); });
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    await p.fill('input[type=email]', email);
    await p.click('.login-card .btn.primary');
    await p.waitForSelector('.sidebar .nav-item');
    return p;
  }

  /* ============ 1) الفيديو — designer ============ */
  const d = await login('designer@meem.studio');
  await d.goto(BASE + '/#/video', { waitUntil: 'networkidle' });
  await d.waitForSelector('.page-head .btn.primary');
  await d.click('.page-head .btn.primary');
  await d.waitForSelector('.studio .ct-top', { timeout: 8000 });
  ok('محرر الفيديو فتح (overlay .studio)', true);

  await d.fill('.studio .ct-top input.input', 'ريل افتتاحي — E2E');
  await d.setInputFiles('.studio input[type=file]', PNG);
  await d.waitForSelector('.vd-bin .vd-media', { timeout: 15000 });
  ok('رفع ميديا → ظهرت في المكتبة', true);

  await d.click('.vd-media .btn');
  await d.waitForSelector('.vd-clip', { timeout: 5000 });
  ok('الكليب دخل التايم لاين', true);

  await d.click('.vd-clip');
  await d.waitForSelector('.vd-lbl:has(span:text("نص Overlay")) input', { timeout: 5000 });
  await d.fill('.vd-lbl:has(span:text("نص Overlay")) input', 'أهلاً من MEEM');
  ok('نص Overlay اتكتب', true);

  await d.click('.studio button:has-text("تصدير WebM")');
  await d.waitForSelector('.studio a[download]', { timeout: 60000 });
  ok('تصدير WebM حقيقي خلص + رابط تحميل ظهر', true);

  await d.click('.studio button:has-text("للمراجعة")');
  await d.waitForFunction(() => (document.querySelector('.studio .ct-top') || {}).innerText?.includes('في المراجعة'), null, { timeout: 10000 });
  ok('اترسل للمراجعة (في المراجعة)', true);

  /* ============ 2) الاعتماد — admin ============ */
  const a = await login('admin@meem.studio');
  await a.goto(BASE + '/#/video', { waitUntil: 'networkidle' });
  await a.waitForSelector('.view .card', { timeout: 8000 });
  await a.click('.view .card:has-text("ريل افتتاحي")');
  await a.waitForSelector('.studio .ct-top', { timeout: 8000 });
  await a.click('.studio button:has-text("اعتماد")');
  await a.waitForFunction(() => (document.querySelector('.studio .ct-top') || {}).innerText?.includes('معتمد'), null, { timeout: 15000 });
  ok('الأدمن اعتمد الفيديو (معتمد)', true);

  /* ============ 3) التصوير — designer ============ */
  /* V2-5 self-heal: رجّع جلسة المنيو لحالتها المزرعة (لقطات غير متعلمة) */
  {
    const l = await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'admin@meem.studio', password: '123456' }) })).json();
    const H = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + l.token };
    const st = await (await fetch(BASE + '/api/state', { headers: H })).json();
    const sh = (st.data.shoots || []).find((x) => /منيو/.test(x.title || ''));
    if (sh) await fetch(BASE + '/api/mutate', { method: 'POST', headers: H, body: JSON.stringify({ collection: 'shoots', op: 'upsert', doc: { id: sh.id, shots: (sh.shots || []).filter((q) => /^sh_\d+$/.test(q.id)).map((q) => Object.assign({}, q, { done: false })), photos: [] } }) });
  }
  await d.goto(BASE + '/#/photo?r=' + Date.now(), { waitUntil: 'networkidle' });
  await d.waitForSelector('.view .dcard', { timeout: 8000 });
  const nShoots = await d.locator('.view .dcard').count();
  ok('جلسات التصوير seeded (' + nShoots + ')', nShoots >= 2);
  await d.click('.view .dcard >> nth=0');
  await d.waitForSelector('.modal:has-text("Shot List")', { timeout: 8000 });

  const doneBefore = await d.locator('.ph-shot.done').count();
  await d.click('.ph-shot:not(.done) input >> nth=0');
  await d.waitForFunction((n) => document.querySelectorAll('.ph-shot.done').length > n, doneBefore, { timeout: 8000 });
  ok('لقطة اتعلّمت ✔ في الـ Shot List', true);

  const before = await d.locator('.ph-shot').count();
  await d.click('.modal button:has-text("لقطة")');
  await d.waitForSelector('.modal:has-text("لقطة جديدة")', { timeout: 5000 });
  await d.fill('input[placeholder="وصف اللقطة…"]', 'لقطة E2E جديدة');
  await d.click('.modal:has-text("لقطة جديدة") button:has-text("إضافة")');
  await d.waitForFunction((n) => document.querySelectorAll('.ph-shot').length > n, before, { timeout: 8000 });
  ok('لقطة جديدة اتضافت للستة', true);

  await d.setInputFiles('.modal input[type=file][accept="image/*"]', PNG);
  await d.waitForSelector('.ph-photo', { timeout: 15000 });
  ok('صورة اترفعت في الجاليري', true);

  await d.click('.modal button:has-text("إغلاق")');

  /* ============ 4) الباجات — dev ============ */
  const v = await login('dev@meem.studio');
  await v.goto(BASE + '/#/dev', { waitUntil: 'networkidle' });
  await v.waitForSelector('.bug-cols', { timeout: 8000 });
  const nCols = await v.locator('.bug-col').count();
  const nBugs = await v.locator('.bug-card').count();
  ok('بورد الباجات: ' + nCols + ' أعمدة و' + nBugs + ' باجات seeded', nCols === 5 && nBugs >= 3);

  await v.click('button:has-text("الإبلاغ عن باج")');
  await v.waitForSelector('.modal:has-text("باج جديد")', { timeout: 5000 });
  const bugTitle = 'باج E2E ' + Date.now();
  await v.fill('.modal .field input.input', bugTitle);
  await v.click('.modal button:has-text("حفظ")');
  await v.waitForSelector('.bug-card:has-text("باج E2E ")', { timeout: 8000 });
  ok('باج جديد اتسجل وظهر في عمود new', true);

  await v.click('.bug-card:has-text("باج E2E ")');
  await v.waitForSelector('.modal:has-text("باج E2E ")', { timeout: 5000 });
  await v.selectOption('.modal select.select >> nth=1', 'fixed');
  await v.click('.modal:has-text("باج E2E ") button:has-text("حفظ")');
  await v.waitForFunction(() => { const el = [...document.querySelectorAll('.kpi')][2]; return el && parseInt(el.querySelector('.k-value').textContent, 10) >= 1; }, null, { timeout: 8000 });
  ok('الباج اتنقل لـ fixed — KPI اتصلّحت = 1', true);

  /* ============ أخطاء؟ ============ */
  const realErrs = errs.filter((e) => !/favicon|DevTools/i.test(e));
  ok('مفيش أخطاء JS في أي صفحة', realErrs.length === 0);
  if (realErrs.length) console.log(realErrs.join('\n'));

  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
