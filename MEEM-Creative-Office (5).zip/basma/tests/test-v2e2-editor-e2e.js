/* MEEM V2-E2 E2E — المحرر المتقدم: فلاتر بكسلية + أقنعة + دمج + استيراد + استعادة بعد الانهيار */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];
const DRAFT_TITLE = 'مسودة اختبار E2 ' + Date.now();

const px = (p, x, y) => p.evaluate(([nx, ny]) => {
  const cv = document.querySelector('.ed-canvas-holder canvas.main');
  const d = cv.getContext('2d').getImageData(Math.round(nx * (cv.width - 1)), Math.round(ny * (cv.height - 1)), 1, 1).data;
  return [d[0], d[1], d[2], d[3]];
}, [x / 1080, y / 1080]);

const lum = (c) => 0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2];
const isWhite = (c) => c[0] > 240 && c[1] > 240 && c[2] > 240;
const isBlue = (c) => c[2] - c[0] > 60 && c[2] > 150;

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()); });

  const screen = async (x, y) => {
    const box = await p.locator('.ed-canvas-holder').boundingBox();
    return { x: box.x + (x / 1080) * box.width, y: box.y + (y / 1080) * box.height };
  };
  const drag = async (x1, y1, x2, y2, steps = 14) => {
    const a = await screen(x1, y1), c = await screen(x2, y2);
    await p.mouse.move(a.x, a.y);
    await p.mouse.down();
    for (let i = 1; i <= steps; i++) await p.mouse.move(a.x + ((c.x - a.x) * i) / steps, a.y + ((c.y - a.y) * i) / steps);
    await p.mouse.up();
    await p.waitForTimeout(350);
  };
  const setFilters = (obj) => p.evaluate(async (f) => {
    const { getEditorInstance } = await import('/js/editor/index.js');
    const ed = getEditorInstance();
    Object.assign(ed.one.filters, f);
    await ed.drawCanvas();
  }, obj);
  const layerBox = () => p.evaluate(async () => {
    const { getEditorInstance } = await import('/js/editor/index.js');
    const l = getEditorInstance().one;
    return { x: l.x, y: l.y, w: l.w, h: l.h };
  });
  const addShape = async () => {
    await p.click('.ed-tool[data-tool="shapes"]');
    await p.locator('.ed-panel .ed-grid .ed-item').first().click();
    await p.waitForTimeout(400);
  };
  const clearLayers = async () => {
    await p.evaluate(async () => {
      const { getEditorInstance } = await import('/js/editor/index.js');
      const ed = getEditorInstance();
      ed.selected = ed.page.layers.map((l) => l.id);
      ed.deleteSelected();
    });
    await p.waitForTimeout(400);
  };

  /* ---- دخول + محرر جديد ---- */
  await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', 'designer@meem.studio');
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.sidebar .nav-item', { timeout: 15000 });
  await p.goto(BASE + '/#/dashboard', { waitUntil: 'networkidle' });
  await p.locator('.desk-quick button', { hasText: 'تصميم جديد' }).click();
  await p.waitForSelector('.ed', { timeout: 10000 });
  await p.waitForSelector('.ed-canvas-holder canvas.main');
  await p.waitForTimeout(900);

  /* ---- 1) شكل + فلاتر UI جديدة ---- */
  await addShape();
  const box = await layerBox();
  const cxp = box.x + box.w / 2, cyp = box.y + box.h / 2;
  const baseCol = await px(p, cxp, cyp);
  ok('شكل أُضيف ولونه مش أبيض', !isWhite(baseCol));
  const labels = await p.textContent('.ed-panel[data-role=\"props\"] .ed-panel-body');
  ok('فلاتر جديدة في الخصائص: حدة/Dodge/Burn/عكس', ['حدة', 'Dodge', 'Burn', 'عكس الألوان'].every((x) => labels.includes(x)));

  /* ---- 2) Blur — حافة Shape تنتشر ---- */
  await setFilters({ blur: 14 });
  await p.waitForTimeout(400);
  const edgeOut = await px(p, box.x + box.w + 4, cyp); // بره الشكل بـ 4px
  ok('Blur — اللون انتشر بره الحافة', !isWhite(edgeOut));

  /* ---- 3) Sharpen — يشتغل من غير أخطاء ويحافظ على اللون ---- */
  await setFilters({ blur: 0, sharpen: 80 });
  await p.waitForTimeout(400);
  const afterSharp = await px(p, cxp, cyp);
  ok('Sharpen — اللون الداخلي ثابت تقريبًا', Math.abs(lum(afterSharp) - lum(baseCol)) < 30);

  /* ---- 4) Dodge — تفتيح ---- */
  await setFilters({ sharpen: 0, dodge: 80 });
  await p.waitForTimeout(400);
  const afterDodge = await px(p, cxp, cyp);
  ok('Dodge — المنطقة فتحت', lum(afterDodge) > lum(baseCol) + 15);

  /* ---- 5) Burn — تظليل ---- */
  await setFilters({ dodge: 0, burn: 80 });
  await p.waitForTimeout(400);
  const afterBurn = await px(p, cxp, cyp);
  ok('Burn — المنطقة قتمت', lum(afterBurn) < lum(baseCol) - 15);

  /* ---- 6) Invert ---- */
  await setFilters({ burn: 0, invert: 100 });
  await p.waitForTimeout(400);
  const afterInvert = await px(p, cxp, cyp);
  ok('Invert — الألوان اتعكست', Math.abs(afterInvert[0] - (255 - baseCol[0])) < 12 && Math.abs(afterInvert[2] - (255 - baseCol[2])) < 12);

  /* ---- 7) إعادة ضبط الفلاتر ---- */
  await p.locator('.ed-panel[data-role=\"props\"] .ed-panel-body .ed-mini', { hasText: 'إعادة ضبط الفلاتر' }).click();
  await p.waitForTimeout(400);
  const afterReset = await px(p, cxp, cyp);
  ok('إعادة الضبط — اللون الأصلي رجع', Math.abs(lum(afterReset) - lum(baseCol)) < 6);

  /* ---- 8) Blend — difference أبيض على أبيض = أسود ---- */
  await p.evaluate(async () => {
    const { getEditorInstance } = await import('/js/editor/index.js');
    const ed = getEditorInstance();
    ed.one.fill = '#ffffff';
    await ed.drawCanvas();
  });
  await p.waitForTimeout(300);
  const blendSel = p.locator('.ed-panel[data-role=\"props\"] .ed-panel-body select').last();
  const opts = await blendSel.locator('option').allTextContents();
  ok('قائمة الدمج — 16 وضع', opts.length === 16);
  ok('أوضاع الدمج بالعربي', opts[0].includes('عادي') && opts.some((o) => o.includes('فرق')));
  await blendSel.selectOption('difference');
  await p.waitForTimeout(400);
  const diffPx = await px(p, cxp, cyp);
  ok('difference — أبيض على أبيض بقى أسود', lum(diffPx) < 40);
  await blendSel.selectOption('source-over');
  await p.waitForTimeout(300);

  /* ---- 9) قناع من التحديد ---- */
  await clearLayers();
  await addShape();
  const b2 = await layerBox();
  const cy2 = b2.y + b2.h / 2;
  const col2 = await px(p, b2.x + b2.w / 2, cy2);
  await p.click('.ed-tool[data-tool="psel"]');
  await drag(0, 0, b2.x + b2.w / 2, 1080); // تحديد يسار الشكل
  // نرجع نحدد الطبقة نفسها عشان الخصائص تظهر
  await p.evaluate(async () => {
    const { getEditorInstance } = await import('/js/editor/index.js');
    const ed = getEditorInstance();
    ed.selected = [ed.page.layers[ed.page.layers.length - 1].id];
    ed.drawOverlay(); ed.renderProps();
  });
  await p.waitForTimeout(300);
  const maskBtn = p.locator('.ed-panel[data-role=\"props\"] .ed-panel-body .ed-mini', { hasText: 'قناع من التحديد' });
  ok('زر القناع مفعّل مع وجود تحديد', await maskBtn.isEnabled());
  await maskBtn.click();
  await p.waitForTimeout(600);
  const inSel = await px(p, b2.x + 10, cy2);           // داخل التحديد (يسار الشكل)
  const outSel = await px(p, b2.x + b2.w - 6, cy2);    // بره التحديد (يمين الشكل)
  ok('القناع — داخل التحديد لسه ملوّن', Math.abs(lum(inSel) - lum(col2)) < 25);
  ok('القناع — بره التحديد اختفى (أبيض)', isWhite(outSel));
  const hasMaskIcon = await p.evaluate(async () => {
    const { getEditorInstance } = await import('/js/editor/index.js');
    getEditorInstance().setTool('layers');
    return true;
  }).then(async () => (await p.textContent('.ed-panel-body')).includes('🎭'));
  ok('القناع — 🎭 في لوحة الطبقات', hasMaskIcon);

  /* ---- 10) إزالة القناع ---- */
  await p.evaluate(async () => {
    const { getEditorInstance } = await import('/js/editor/index.js');
    const ed = getEditorInstance();
    ed.selected = [ed.page.layers[ed.page.layers.length - 1].id];
    ed.renderProps();
  });
  await p.locator('.ed-panel[data-role=\"props\"] .ed-panel-body .ed-mini', { hasText: 'إزالة القناع' }).click();
  await p.waitForTimeout(600);
  ok('إزالة القناع — الشكل كامل رجع', !isWhite(await px(p, b2.x + b2.w - 6, cy2)));

  /* ---- 11) استيراد من رابط ---- */
  await clearLayers();
  await p.click('.ed-tool[data-tool="images"]');
  await p.fill('.ed-urlrow input', BASE + '/assets/stock/abstract.jpg');
  await p.locator('.ed-urlrow .ed-mini').click();
  await p.waitForTimeout(1500);
  const imgInfo = await p.evaluate(async () => {
    const { getEditorInstance } = await import('/js/editor/index.js');
    const ed = getEditorInstance();
    const l = ed.page.layers[ed.page.layers.length - 1];
    return l && l.type === 'image' ? { x: l.x, y: l.y, w: l.w, h: l.h } : null;
  });
  ok('استيراد من رابط — طبقة صورة اتضافت', !!imgInfo);
  if (imgInfo) {
    const ic = await px(p, imgInfo.x + imgInfo.w / 2, imgInfo.y + imgInfo.h / 2);
    ok('استيراد من رابط — الصورة مرسومة', !isWhite(ic));
  } else ok('استيراد من رابط — الصورة مرسومة', false);

  /* ---- 12) رفع متعدد ---- */
  const before = await p.evaluate(async () => { const { getEditorInstance } = await import('/js/editor/index.js'); return getEditorInstance().page.layers.length; });
  await p.locator('.ed-dropzone').click();
  await p.setInputFiles('input[type=file]', ['/tmp/tc/p5img.png', '/tmp/tc/p5img2.png']);
  await p.waitForTimeout(1500);
  const after = await p.evaluate(async () => { const { getEditorInstance } = await import('/js/editor/index.js'); return getEditorInstance().page.layers.length; });
  ok('رفع متعدد — صورتين اتضافوا (' + (after - before) + ')', after - before === 2);

  /* ---- 13) استعادة بعد الانهيار ---- */
  await clearLayers();
  await p.fill('.ed-title-input', DRAFT_TITLE);
  await p.click('.ed-tool[data-tool="brush"]');
  await drag(200, 250, 520, 250);
  await p.waitForTimeout(300);
  const crashedId = await p.evaluate(async () => {
    const { getEditorInstance } = await import('/js/editor/index.js');
    const ed = getEditorInstance();
    ed.saveDraft();
    const id = ed.designId; // null لو لسه جديد، أو id لو الحفظ التلقائي لحق
    ed.close(); // محاكاة انهيار/إغلاق مفاجئ
    return id;
  });
  await p.evaluate(async (id) => { const m = await import('/js/editor/index.js'); m.openEditor(id, {}); }, crashedId);
  await p.waitForSelector('.ed', { timeout: 10000 });
  await p.waitForSelector('.ed-recoverbar:not([hidden])', { timeout: 5000 });
  ok('شريط الاستعادة ظهر بعد الإغلاق المفاجئ', true);
  await p.locator('.ed-recoverbar .btn.primary', { hasText: 'استعادة' }).click();
  await p.waitForTimeout(1200);
  ok('الاستعادة — العنوان رجع', (await p.inputValue('.ed-title-input')) === DRAFT_TITLE);
  ok('الاستعادة — ضربة الفرشاة رجعت', isBlue(await px(p, 360, 250)));

  /* ---- 14) تجاهل المسودة ---- */
  await p.evaluate(async () => {
    const { getEditorInstance } = await import('/js/editor/index.js');
    const ed = getEditorInstance();
    ed.saveDraft();
    ed.close();
  });
  await p.evaluate(async (id) => { const m = await import('/js/editor/index.js'); m.openEditor(id, {}); }, crashedId);
  await p.waitForSelector('.ed', { timeout: 10000 });
  await p.waitForSelector('.ed-recoverbar:not([hidden])', { timeout: 5000 });
  await p.locator('.ed-recoverbar .btn.ghost', { hasText: 'تجاهل' }).click();
  await p.waitForTimeout(300);
  ok('تجاهل المسودة — الشريط اختفى', await p.locator('.ed-recoverbar:not([hidden])').count() === 0);
  if (crashedId) {
    const lg = await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'designer@meem.studio', password: '123456' }) })).json();
    const dl = await (await fetch(BASE + '/api/mutate', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + lg.token }, body: JSON.stringify({ op: 'delete', collection: 'designs', id: crashedId }) })).json();
    ok('تنظيف — حذف التصميم المحفوظ تلقائيًا', !!dl.ok);
  } else ok('تنظيف — حذف التصميم المحفوظ تلقائيًا', true);

  /* ---- 15) رجعية سريعة: الفرشاة والتراجع لسه شغالين ---- */
  await p.click('.ed-tool[data-tool="brush"]');
  await drag(700, 700, 900, 700);
  ok('رجعية — فرشاة بعد كل التغييرات', isBlue(await px(p, 800, 700)));
  await p.keyboard.press('Control+z');
  await p.waitForTimeout(500);
  ok('رجعية — Ctrl+Z شغال', isWhite(await px(p, 800, 700)));

  ok('بدون أخطاء console', errs.length === 0);
  if (errs.length) console.log('ERRORS:\n' + errs.slice(0, 8).join('\n'));

  await b.close();
  const pass = R.filter(Boolean).length;
  console.log(`\nV2-E2 Editor: ${pass}/${R.length}`);
  process.exit(pass === R.length ? 0 : 1);
})();
