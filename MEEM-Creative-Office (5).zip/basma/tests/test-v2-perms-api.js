/* MEEM V2-2 — اختبارات مصفوفة الصلاحيات (server-side)
 * كل دور ياخد 200 في نطاقه و403 بره نطاقه — على مستوى الـ API نفسه مش الواجهة.
 */
'use strict';
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };

async function api(path, token, body) {
  const res = await fetch(BASE + '/api' + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}
const login = (email) => api('/login', null, { email, password: '123456' }).then((r) => r.json.token);

(async () => {
  const admin = await login('admin@meem.studio');
  const designer = await login('designer@meem.studio');
  const content = await login('content@meem.studio');
  const voice = await login('voice@meem.studio');
  const dev = await login('dev@meem.studio');
  const cs = await login('cs@meem.studio');
  const client = await login('client@meem.studio');

  const mut = (t, collection, doc, op) => api('/mutate', t, { collection, doc, op, id: doc && doc.id });

  /* ---- 1) كل دور يكتب في نطاقه ---- */
  let r = await mut(designer, 'designs', { title: 'تصميم صلاحية V2' });
  const myDesign = r.json.doc && r.json.doc.id;
  ok('designer: يكتب designs (200)', r.status === 200 && !!myDesign);

  r = await mut(content, 'contents', { title: 'محتوى صلاحية V2', type: 'caption', body: 'x' });
  const myContent = r.json.doc && r.json.doc.id;
  ok('content: يكتب contents (200)', r.status === 200);

  r = await mut(voice, 'voices', { title: 'فويس صلاحية V2' });
  ok('voice: يكتب voices (200)', r.status === 200);
  const myVoice = r.json.doc && r.json.doc.id;

  r = await mut(dev, 'bugs', { title: 'باج صلاحية V2', severity: 'low', status: 'new', reporter: 'usr_dev' });
  const myBug = r.json.doc && r.json.doc.id;
  ok('dev: يكتب bugs (200)', r.status === 200);

  r = await mut(cs, 'requests', { title: 'طلب صلاحية V2', status: 'new' });
  const myReq = r.json.doc && r.json.doc.id;
  ok('cs: يكتب requests (200)', r.status === 200);

  /* ---- 2) بره النطاق = 403 ---- */
  r = await mut(designer, 'invoices', { title: 'هك فاتورة' });
  ok('designer ⛔ invoices (403)', r.status === 403);
  r = await mut(designer, 'settings', { id: 'automation', rules: [] });
  ok('designer ⛔ settings (403)', r.status === 403);
  r = await mut(content, 'designs', { title: 'هك تصميم' });
  ok('content ⛔ designs (403)', r.status === 403);
  r = await mut(voice, 'bugs', { title: 'هك باج' });
  ok('voice ⛔ bugs (403)', r.status === 403);
  r = await mut(dev, 'clients', { name: 'هك عميل' });
  ok('dev ⛔ clients (403)', r.status === 403);
  r = await mut(dev, 'invoices', { title: 'هك فاتورة 2' });
  ok('dev ⛔ invoices (403)', r.status === 403);
  r = await mut(cs, 'invoices', { title: 'هك فاتورة 3' });
  ok('cs ⛔ invoices (403)', r.status === 403);
  r = await mut(client, 'tasks', { title: 'هك مهمة' });
  ok('client ⛔ mutate خالص (403)', r.status === 403);

  /* ---- 3) activity/chats محمية ---- */
  r = await mut(designer, 'chats', { room: 'general', text: 'هك شات' });
  ok('designer ⛔ chats via mutate (403)', r.status === 403);
  r = await mut(admin, 'activity', { text: 'هك نشاط' });
  ok('حتى admin ⛔ activity (الكتابة مرفوضة 400/403)', r.status === 403 || r.status === 400);

  /* ---- 4) الحذف: ملكية أو أدمن ---- */
  r = await mut(content, 'designs', { id: myDesign }, 'delete');
  ok('content ⛔ حذف تصميم غيره (403)', r.status === 403);
  r = await api('/mutate', designer, { collection: 'designs', op: 'delete', id: myDesign });
  ok('designer يحذف تصميمه هو (200)', r.status === 200);
  // باج تاني بيعمله dev من غير حقول ملكية — السيرفر بيختم createdBy تلقائيًا
  r = await mut(dev, 'bugs', { title: 'باج تاني V2', severity: 'low', status: 'new' });
  const bug2 = r.json.doc && r.json.doc.id;
  ok('السيرفر بيختم createdBy على العناصر الجديدة', r.json.doc && r.json.doc.createdBy === 'usr_dev');
  r = await api('/mutate', dev, { collection: 'bugs', op: 'delete', id: bug2 });
  ok('dev يحذف باج عمله هو (200)', r.status === 200);
  // الأدمن يحذف أي حاجة
  r = await mut(admin, 'contents', { title: 'محتوى للحذف' });
  const admContent = r.json.doc.id;
  r = await api('/mutate', admin, { collection: 'contents', op: 'delete', id: admContent });
  ok('admin يحذف شغل غيره (200)', r.status === 200);

  /* ---- 5) timeentries: لنفسك فقط ---- */
  r = await mut(designer, 'timeentries', { taskId: 'task_x', minutes: 5, userId: 'usr_dev' });
  ok('designer ⛔ يسجل وقت باسم dev (403)', r.status === 403);
  r = await mut(designer, 'timeentries', { taskId: 'task_x', minutes: 5, userId: 'usr_design' });
  const myTime = r.json.doc && r.json.doc.id;
  ok('designer يسجل وقت لنفسه (200)', r.status === 200);

  /* ---- 6) state: الماليات والمفاتيح مخفية عن غير الإدارة ---- */
  await mut(admin, 'settings', { id: 'ai', key: 'sk-secret-123', model: 'gpt-4o-mini' });
  let st = await api('/state', designer);
  ok('designer: state من غير invoices', st.json.data.invoices === undefined);
  ok('designer: state من غير expenses/campaigns', st.json.data.expenses === undefined && st.json.data.campaigns === undefined);
  const aiDoc = (st.json.data.settings || []).find((s) => s.id === 'ai');
  ok('designer: مفتاح AI مش مكشوف في settings', !!aiDoc && !aiDoc.key && aiDoc.hasKey === true);
  st = await api('/state', admin);
  ok('admin: شايف invoices + المفتاح', Array.isArray(st.json.data.invoices) && (st.json.data.settings || []).some((s) => s.id === 'ai' && s.key));

  /* ---- 7) قرار الاعتماد: إدارة/cs فقط ---- */
  r = await mut(designer, 'designs', { title: 'تصميم للاعتماد V2', status: 'review' });
  const decDesign = r.json.doc.id;
  r = await api('/design/' + decDesign + '/decision', content, { decision: 'approve' });
  ok('content ⛔ قرار اعتماد (403)', r.status === 403);
  r = await api('/design/' + decDesign + '/decision', cs, { decision: 'approve' });
  ok('cs يعتمد تصميم (200)', r.status === 200);

  /* ---- 8) الأدمن فوق الكل ---- */
  r = await mut(admin, 'invoices', { title: 'فاتورة أدمن V2' });
  const admInv = r.json.doc && r.json.doc.id;
  ok('admin: يكتب invoices (200)', r.status === 200);

  /* ---- تنظيف ---- */
  for (const [col, id] of [['bugs', myBug], ['bugs', bug2], ['requests', myReq], ['contents', myContent], ['voices', myVoice], ['timeentries', myTime], ['designs', decDesign], ['invoices', admInv]]) {
    if (id) await api('/mutate', admin, { collection: col, op: 'delete', id });
  }
  await api('/mutate', admin, { collection: 'settings', op: 'delete', id: 'ai' });

  const pass = R.filter(Boolean).length;
  console.log(`\nRESULT: ${pass} passed, ${R.length - pass} failed`);
  process.exit(pass === R.length ? 0 : 1);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
