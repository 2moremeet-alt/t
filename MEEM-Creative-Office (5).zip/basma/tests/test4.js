/* MEEM Phase 1 — اختبار شامل: My Desk + Design Engine 2.0 */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';

const results = [];
const ok = (n, c) => { results.push([c ? 'PASS' : 'FAIL', n]); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const c = await b.newContext({ viewport: { width: 1600, height: 900 }, acceptDownloads: true });
  const p = await c.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  p.on('console', (m) => { if (m.type() === 'error') errs.push('console: ' + m.text()); });

  // 1) شاشة الدخول بهوية MEEM
  await p.goto(BASE, { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card', { timeout: 15000 });
  const title = await p.title();
  ok('العنوان MEE M | Creative Office', title.includes('MEE M'));

  // 2) دخول بحساب المصممة (ميم)
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.sidebar .nav-item', { timeout: 15000 });
  const userName = await p.textContent('.side-user, .topbar') || '';
  await p.waitForTimeout(600);
  await p.goto(BASE + '/#/dashboard', { waitUntil: 'networkidle' }); // V2-7: الهبوط بقى المكتب — My Desk من السايدبار

  // 3) My Desk
  const deskTiles = await p.locator('.desk-tile').count();
  ok('My Desk — 5 عدّادات', deskTiles === 5);
  const quick = await p.locator('.desk-quick button').count();
  ok('My Desk — إجراءات سريعة ≥ 3', quick >= 3);
  const deskName = await p.locator('h1').first().textContent();
  ok('الترحيب باسم ميم', /ميم/.test(deskName));
  await p.screenshot({ path: '/tmp/shots/meem-mydesk.png' });

  // 4) فتح المحرر من My Desk
  await p.locator('.desk-quick button', { hasText: 'تصميم جديد' }).click();
  await p.waitForSelector('.ed', { timeout: 10000 });
  await p.waitForTimeout(500);

  // 5) أدوات جديدة في الرايل: QR + السجل
  ok('رايل: أداة QR', await p.locator('.ed-tool[data-tool="qr"]').count() === 1);
  ok('رايل: أداة السجل', await p.locator('.ed-tool[data-tool="history"]').count() === 1);

  // 6) إضافة نص + تفعيل الانحناء
  await p.click('.ed-tool[data-tool="text"]');
  await p.locator('.ed-panel .ed-item').first().click(); // عنوان رئيسي
  await p.waitForTimeout(200);
  await p.locator('label.check:has-text("تفعيل الانحناء") input').check();
  await p.waitForTimeout(200);
  ok('نص منحني — ظهر شريط المقدار', await p.locator('label:text("مقدار الانحناء")').count() >= 1 || (await p.textContent('.ed-panel-body')).includes('مقدار الانحناء'));

  // 7) إضافة شكل ثم تحديد الكل وتجميعه
  await p.click('.ed-tool[data-tool="shapes"]');
  await p.locator('.ed-panel .ed-grid .ed-item').first().click();
  await p.waitForTimeout(200);
  await p.locator('.ed-stage').click({ position: { x: 5, y: 5 } }); // إلغاء التحديد
  await p.keyboard.press('Control+a');
  await p.waitForTimeout(150);
  await p.locator('.ed-panel-body >> nth=-1 >> button:has-text("تجميع")').first().click();
  await p.waitForTimeout(200);
  // التحقق: لوحة الطبقات تعرض 🔗
  await p.click('.ed-tool[data-tool="layers"]');
  const layersTxt = await p.textContent('.ed-panel-body');
  ok('التجميع — علامة 🔗 في الطبقات', layersTxt.includes('🔗'));

  // 8) المحاذاة الكاملة
  await p.keyboard.press('Control+a');
  await p.waitForTimeout(100);
  const alignBtns = await p.locator('button.ed-mini[title="محاذاة لليسار"]').count();
  const distBtns = await p.locator('button.ed-mini[title="توزيع أفقي"]').count();
  ok('أزرار محاذاة كاملة (left/cx/right/top/cy/bottom/dist)', alignBtns >= 1 && distBtns >= 1);
  await p.locator('button.ed-mini[title="توسيط أفقي"]').first().click();
  await p.waitForTimeout(150);

  // 9) QR: توليد وإضافة
  await p.click('.ed-tool[data-tool="qr"]');
  await p.locator('.ed-panel input[placeholder="https://example.com"]').fill('https://meem.studio');
  await p.locator('.ed-panel button:has-text("أضف للتصميم")').click();
  await p.waitForTimeout(400);
  await p.click('.ed-tool[data-tool="layers"]');
  const layersTxt2 = await p.textContent('.ed-panel-body');
  ok('QR — أُضيف كطبقة', layersTxt2.includes('QR Code'));

  // 10) الحفظ التلقائي: الانتظار ثم فحص المؤشر
  await p.waitForTimeout(4200);
  const ind = await p.textContent('.ed-saveind');
  ok('الحفظ التلقائي — مؤشر ✓ محفوظ', ind.includes('محفوظ'));

  // 11) التحقق من السيرفر: التصميم محفوظ وفيه groupId + QR + warp
  const tok = await p.evaluate(() => localStorage.getItem('basma_token'));
  const stateJ = await (await fetch(BASE + '/api/state', { headers: { Authorization: 'Bearer ' + tok } })).json();
  const designs = (stateJ.data && stateJ.data.designs) || stateJ.designs || [];
  const d = designs.filter((x) => (x.title || '').includes('بدون عنوان')).pop();
  ok('السيرفر — التصميم محفوظ', !!d);
  if (d) {
    // الطبقات الكاملة من endpoint التصميم نفسه (state خفيف بدون layers/pages)
    const fullJ = await (await fetch(BASE + '/api/design/' + d.id, { headers: { Authorization: 'Bearer ' + tok } })).json();
    const layers = (fullJ.design && fullJ.design.pages && fullJ.design.pages[0] && fullJ.design.pages[0].layers) || [];
    ok('السيرفر — 3 طبقات (نص+شكل+QR)', layers.length === 3);
    ok('السيرفر — groupId محفوظ (تجميع)', layers.some((l) => l.groupId));
    ok('السيرفر — warp محفوظ', layers.some((l) => l.warp && l.warp.on));
    ok('السيرفر — QR data URL محفوظ', layers.some((l) => (l.src || '').startsWith('data:image/png')));
  }

  // 12) لوحة السجل: خطوات + رجوع
  await p.click('.ed-tool[data-tool="history"]');
  const histItems = await p.locator('.ed-panel-body .ed-layer').count();
  ok('السجل — خطوات مسجلة (' + histItems + ')', histItems >= 4);
  const labels = await p.textContent('.ed-panel-body');
  ok('السجل — خطوات مسماة (تجميع/QR/منحني)', /تجميع/.test(labels) && /QR/.test(labels) && /منحني/.test(labels));
  await p.screenshot({ path: '/tmp/shots/meem-editor-phase1.png' });
  // رجوع لأول خطوة
  await p.locator('.ed-panel-body .ed-layer').last().click();
  await p.waitForTimeout(300);
  await p.click('.ed-tool[data-tool="layers"]');
  const afterJump = await p.textContent('.ed-panel-body');
  ok('السجل — الرجوع لأول خطوة أفرغ الكانفس', afterJump.includes('لا') || !(afterJump.includes('QR Code')));

  // 13) تصدير PNG
  await p.click('.ed-tool[data-tool="text"]');
  await p.locator('.ed-panel .ed-item').first().click();
  await p.waitForTimeout(300);
  const dl = p.waitForEvent('download', { timeout: 15000 });
  await p.locator('.ed-top button:has-text("تصدير")').click();
  await p.waitForSelector('.modal', { timeout: 5000 });
  await p.locator('.modal button.primary').click();
  const download = await dl;
  const fs = require('fs');
  const path = '/tmp/shots/meem-export.png';
  await download.saveAs(path);
  const sz = fs.statSync(path).size;
  ok('تصدير PNG (' + sz + ' بايت)', sz > 5000);

  // 14) الإيميل القديم يعمل كاسم مستعار
  const r = await fetch(BASE + '/api/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'designer@basma.studio', password: '123456' }),
  });
  const rj = await r.json();
  ok('الإيميل القديم designer@basma.studio → دخول ناجح', r.status === 200 && rj.ok);

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 5).join('\n'));

  console.log('\n=== النتيجة: ' + results.filter((r) => r[0] === 'PASS').length + '/' + results.length + ' ===');
  await b.close();
  process.exit(results.some((r) => r[0] === 'FAIL') ? 1 : 0);
})().catch((e) => { console.error('TEST CRASH:', e); process.exit(2); });
