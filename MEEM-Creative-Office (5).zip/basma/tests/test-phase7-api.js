/* MEEM — Phase 7 API: MEEM Chat (صلاحيات + عزل) */
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' ' + n); };

async function api(path, token, body) {
  const res = await fetch(BASE + '/api' + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}
const login = (email) => api('/login', null, { email, password: '123456' }).then((r) => r.json.token);

(async () => {
  const design = await login('designer@meem.studio');
  const dev = await login('dev@meem.studio');
  const client = await login('client@meem.studio'); // منى زكي — cli_zahra
  const client2 = await login('niletech@meem.studio'); // حسام — cli_nile

  /* ---- البذرة ---- */
  let st = await api('/state', design);
  ok('رسائل seeded (8)', (st.json.data.chats || []).length === 8);

  /* ---- الفريق ---- */
  let r = await api('/chat', design, { room: 'general', text: 'رسالة اختبار من المصممة' });
  ok('الفريق يبعت في general', r.status === 200 && !!r.json.doc.id);
  const msgTeam = r.json.doc.id;
  r = await api('/chat', dev, { room: 'design', text: 'x' });
  ok('الفريق يبعت في أي غرفة', r.status === 200);
  const msgDev = r.json.doc.id;

  /* ---- العميل ---- */
  r = await api('/chat', client, { room: 'general', text: 'محاولة' });
  ok('العميل مرفوض من غرفة الفريق (403)', r.status === 403);
  r = await api('/chat', client, { room: 'cli:cli_zahra', text: 'أهلاً فريق ميم!' });
  ok('العميل يبعت في غرفته', r.status === 200);
  const msgCli = r.json.doc.id;
  r = await api('/chat', client, { room: 'cli:cli_nile', text: 'محاولة' });
  ok('العميل مرفوض من غرفة عميل تاني (403)', r.status === 403);
  r = await api('/chat', client, { room: 'prj:prj_1', text: 'سؤال عن حملة رمضان' });
  ok('العميل يبعت في غرفة مشروعه', r.status === 200);
  const msgPrj = r.json.doc.id;
  r = await api('/chat', client, { room: 'prj:prj_5', text: 'محاولة' });
  ok('العميل مرفوض من غرفة مشروع مش مشروعه (403)', r.status === 403);
  r = await api('/chat', client2, { room: 'prj:prj_5', text: 'سؤال نايل تك' });
  ok('عميل نايل تك يبعت في غرفة مشروعه', r.status === 200);
  const msgPrj2 = r.json.doc.id;

  /* ---- رسالة فاضية ---- */
  r = await api('/chat', design, { room: 'general', text: '   ' });
  ok('رسالة فاضية مرفوضة (400)', r.status === 400);

  /* ---- عزل الحالة ---- */
  st = await api('/state', client);
  const rooms = new Set((st.json.data.chats || []).map((m) => m.room));
  const allowed = [...rooms].every((rm) => rm === 'cli:cli_zahra' || rm === 'prj:prj_1' || rm === 'prj:prj_6');
  ok('العميل: state فيها غرفته/غرف مشاريعه بس', allowed && rooms.size >= 2);
  st = await api('/state', design);
  ok('الفريق: بيشوف كل الرسايل', (st.json.data.chats || []).length >= 11);

  /* ---- تنظيف ---- */
  const admin = await login('admin@meem.studio');
  for (const id of [msgTeam, msgDev, msgCli, msgPrj, msgPrj2]) {
    await api('/mutate', admin, { collection: 'chats', op: 'delete', id });
  }
  st = await api('/state', admin);
  ok('التنظيف تم (رجعنا لـ 8)', (st.json.data.chats || []).length === 8);

  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
