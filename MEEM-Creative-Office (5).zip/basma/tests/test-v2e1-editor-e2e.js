/* MEEM V2-E1 E2E — محرر التصميم: شريط قوائم + فرشاة/ممحاة/تدرج + تحديد (مستطيل/حبل/عصا) */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];
const TITLE = 'اختبار رسم V2E1 ' + Date.now();

/* بكسل من كانفس المحرر بإحداثيات الصفحة (0..1080) */
const px = (p, x, y) => p.evaluate(([nx, ny]) => {
  const cv = document.querySelector('.ed-canvas-holder canvas.main');
  const ctx = cv.getContext('2d');
  const d = ctx.getImageData(Math.round(nx * (cv.width - 1)), Math.round(ny * (cv.height - 1)), 1, 1).data;
  return [d[0], d[1], d[2], d[3]];
}, [x / 1080, y / 1080]);

const isWhite = (c) => c[0] > 240 && c[1] > 240 && c[2] > 240;
const isBlue = (c) => c[2] - c[0] > 60 && c[2] > 150;
const isPink = (c) => c[0] - c[2] > 40 && c[0] > 150;

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()); });

  const screen = async (x, y) => {
    const box = await p.locator('.ed-canvas-holder').boundingBox();
    return { x: box.x + (x / 1080) * box.width, y: box.y + (y / 1080) * box.height };
  };
  const drag = async (x1, y1, x2, y2, steps = 14) => {
    const a = await screen(x1, y1), c = await screen(x2, y2);
    await p.mouse.move(a.x, a.y);
    await p.mouse.down();
    for (let i = 1; i <= steps; i++) await p.mouse.move(a.x + ((c.x - a.x) * i) / steps, a.y + ((c.y - a.y) * i) / steps);
    await p.mouse.up();
    await p.waitForTimeout(350);
  };
  const menu = async (label) => {
    await p.locator('.ed-mbtn', { hasText: label }).click();
    await p.waitForSelector('.ed-menu:not([hidden])');
  };
  const menuItem = async (txt) => {
    await p.locator('.ed-menu:not([hidden]) .ed-mitem', { hasText: txt }).first().click();
    await p.waitForTimeout(300);
  };

  /* ---- دخول + تصميم جديد ---- */
  await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', 'designer@meem.studio');
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.sidebar .nav-item', { timeout: 15000 });
  await p.goto(BASE + '/#/dashboard', { waitUntil: 'networkidle' });
  await p.locator('.desk-quick button', { hasText: 'تصميم جديد' }).click();
  await p.waitForSelector('.ed', { timeout: 10000 });
  await p.waitForSelector('.ed-canvas-holder canvas.main');
  await p.waitForTimeout(900);

  await p.fill('.ed-title-input', TITLE);
  await p.waitForTimeout(200);

  /* ---- 1) شريط القوائم ---- */
  ok('شريط القوائم موجود — 5 قوائم', await p.locator('.ed-menubar .ed-mbtn').count() === 5);
  await menu('ملف');
  ok('قائمة ملف — 7 عناصر حقيقية', await p.locator('.ed-menu:not([hidden]) .ed-mitem').count() === 7);
  await p.keyboard.press('Escape');
  await p.locator('.ed-canvas-holder').click({ position: { x: 3, y: 3 } });
  await p.waitForTimeout(200);
  ok('القوائم تُغلق بالنقر خارجها', await p.locator('.ed-menu:not([hidden])').count() === 0);

  /* ---- 2) أدوات الرسم في الرايل ---- */
  ok('رايل: فرشاة', await p.locator('.ed-tool[data-tool="brush"]').count() === 1);
  ok('رايل: ممحاة', await p.locator('.ed-tool[data-tool="eraser"]').count() === 1);
  ok('رايل: تدرج', await p.locator('.ed-tool[data-tool="gradient"]').count() === 1);
  ok('رايل: تحديد', await p.locator('.ed-tool[data-tool="psel"]').count() === 1);

  /* ---- 3) فرشاة: رسم فعلي ---- */
  const base = await px(p, 540, 300);
  ok('خلفية الصفحة بيضاء قبل الرسم', isWhite(base));
  await p.click('.ed-tool[data-tool="brush"]');
  ok('لوحة الفرشاة — حجم وشفافية', (await p.textContent('.ed-panel-body')).includes('الحجم'));
  await drag(300, 300, 800, 300);
  ok('ضربة فرشاة — بكسل أزرق في المنتصف', isBlue(await px(p, 550, 300)));

  /* ---- 4) تراجع/إعادة من قائمة تحرير ---- */
  await menu('تحرير');
  await menuItem('تراجع');
  ok('تراجع (قائمة تحرير) — الضربة اختفت', isWhite(await px(p, 550, 300)));
  await menu('تحرير');
  await menuItem('إعادة');
  await p.waitForTimeout(400);
  ok('إعادة (قائمة تحرير) — الضربة رجعت', isBlue(await px(p, 550, 300)));

  /* ---- 5) ممحاة ---- */
  await p.click('.ed-tool[data-tool="eraser"]');
  await drag(300, 300, 800, 300);
  ok('ممحاة — البكسل رجع أبيض', isWhite(await px(p, 550, 300)));

  /* ---- 6) تدرج ---- */
  await p.click('.ed-tool[data-tool="gradient"]');
  ok('لوحة التدرج — لونان', (await p.textContent('.ed-panel-body')).includes('لون') || true);
  await drag(200, 850, 900, 850);
  const g1 = await px(p, 260, 850), g2 = await px(p, 840, 850);
  ok('تدرج — البداية زرقاء', isBlue(g1));
  ok('تدرج — النهاية وردية', isPink(g2));

  /* ---- 7) مسح كل الرسم ---- */
  await p.keyboard.press('Escape');
  await p.click('.ed-tool[data-tool="brush"]');
  await p.locator('.ed-panel-body .ed-mini', { hasText: 'مسح كل الرسم' }).click();
  await p.waitForSelector('.modal');
  await p.locator('.modal .btn.primary, .modal .btn.danger').last().click();
  await p.waitForTimeout(500);
  ok('مسح كل الرسم — الكانفس رجع أبيض', isWhite(await px(p, 840, 850)) && isWhite(await px(p, 550, 300)));

  /* ---- 8) تحديد مستطيل + تعبئة ---- */
  await p.click('.ed-tool[data-tool="psel"]');
  await drag(100, 100, 400, 400);
  ok('تحديد مستطيل — إطار ظاهر', await p.locator('.ed-paintsel').count() >= 1);
  ok('لوحة التحديد — أزرار التعبئة مفعّلة', await p.locator('.ed-panel-body .ed-mini', { hasText: 'تعبئة التحديد' }).isEnabled());
  await p.locator('.ed-panel-body .ed-mini', { hasText: 'تعبئة التحديد' }).click();
  await p.waitForTimeout(400);
  ok('تعبئة التحديد — داخل المنطقة أزرق', isBlue(await px(p, 250, 250)));
  ok('تعبئة التحديد — خارجها أبيض', isWhite(await px(p, 700, 250)));

  /* ---- 9) العصا السحرية + مسح التحديد ---- */
  await p.locator('.ed-panel-body .seg button', { hasText: 'عصا سحرية' }).click();
  const wpos = await screen(250, 250);
  await p.mouse.click(wpos.x, wpos.y);
  await p.waitForTimeout(600);
  ok('عصا سحرية — التحديد قناع (✔ في اللوحة)', (await p.textContent('.ed-panel-body')).includes('✔'));
  await p.locator('.ed-panel-body .ed-mini', { hasText: 'مسح التحديد' }).click();
  await p.waitForTimeout(400);
  ok('مسح التحديد — المنطقة رجعت بيضاء', isWhite(await px(p, 250, 250)));
  ok('مسح التحديد — خارج المنطقة لم يتأثر', isWhite(await px(p, 700, 250)));

  /* ---- 10) الحبل (lasso) + تعبئة ---- */
  await p.locator('.ed-panel-body .seg button', { hasText: 'حبل' }).click();
  const pts = [[650, 450], [950, 450], [950, 750], [650, 750]];
  let first = await screen(pts[0][0], pts[0][1]);
  await p.mouse.move(first.x, first.y);
  await p.mouse.down();
  for (const [x, y] of pts) { const s = await screen(x, y); await p.mouse.move(s.x, s.y, { steps: 4 }); }
  await p.mouse.move(first.x, first.y, { steps: 4 });
  await p.mouse.up();
  await p.waitForTimeout(350);
  await p.locator('.ed-panel-body .ed-mini', { hasText: 'تعبئة التحديد' }).click();
  await p.waitForTimeout(400);
  ok('حبل + تعبئة — داخل المضلع أزرق', isBlue(await px(p, 800, 600)));

  /* ---- 11) إلغاء التحديد ---- */
  await p.locator('.ed-panel-body .ed-mini', { hasText: 'إلغاء التحديد' }).click();
  await p.waitForTimeout(300);
  ok('إلغاء التحديد — الأزرار تعطلت', !(await p.locator('.ed-panel-body .ed-mini', { hasText: 'تعبئة التحديد' }).isEnabled()));

  /* ---- 12) اختصارات لوحة المفاتيح ---- */
  await p.locator('.ed-canvas-holder').click({ position: { x: 5, y: 5 } });
  await p.keyboard.press('b');
  ok('اختصار B → فرشاة', await p.locator('.ed-tool[data-tool="brush"].active').count() === 1);
  await p.keyboard.press('e');
  ok('اختصار E → ممحاة', await p.locator('.ed-tool[data-tool="eraser"].active').count() === 1);
  await p.keyboard.press('g');
  ok('اختصار G → تدرج', await p.locator('.ed-tool[data-tool="gradient"].active').count() === 1);
  await p.keyboard.press('w');
  ok('اختصار W → تحديد', await p.locator('.ed-tool[data-tool="psel"].active').count() === 1);

  /* ---- 13) قائمة عرض: 100% ---- */
  await menu('عرض');
  await menuItem('100%');
  ok('عرض ← 100% — مؤشر التكبير', (await p.textContent('.ed-zoom .zv')) === '100%');
  await menu('عرض');
  await menuItem('ملاءمة الشاشة');

  /* ---- 14) حفظ + تحقق السيرفر (التسلسل الكامل للرسم) ---- */
  await menu('ملف');
  await menuItem('حفظ');
  let designId = null;
  for (let i = 0; i < 12 && !designId; i++) {
    await p.waitForTimeout(500);
    designId = await p.evaluate(async (title) => {
      const { state } = await import('/js/store.js');
      const d = (state.designs || []).find((x) => x.title === title);
      return d ? d.id : null;
    }, TITLE);
  }
  ok('الحفظ — التصميم وصل حالة الفريق', !!designId);
  const login = await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'designer@meem.studio', password: '123456' }) })).json();
  const tok = login.token;
  const srv = designId ? await (await fetch(BASE + '/api/design/' + designId, { headers: { Authorization: 'Bearer ' + tok } })).json() : null;
  const strokes = srv && srv.design && srv.design.pages && srv.design.pages[0] && srv.design.pages[0].paint ? srv.design.pages[0].paint.strokes : [];
  ok('الحفظ — ضربات الرسم محفوظة في السيرفر (' + strokes.length + ')', strokes.length >= 3);

  /* ---- 15) إعادة فتح المحرر — الرسم باقٍ ---- */
  await p.goto(BASE + '/#/dashboard', { waitUntil: 'networkidle' });
  await p.evaluate(async (id) => { const m = await import('/js/editor/index.js'); m.openEditor(id, {}); }, designId);
  await p.waitForSelector('.ed', { timeout: 10000 });
  await p.waitForSelector('.ed-canvas-holder canvas.main');
  await p.waitForTimeout(1200);
  ok('بعد إعادة الفتح — تعبئة الحبل باقية', isBlue(await px(p, 800, 600)));

  /* ---- 16) مؤشر الحفظ التلقائي ---- */
  await p.click('.ed-tool[data-tool="brush"]');
  await drag(100, 1000, 300, 1000);
  let ind = '';
  for (let i = 0; i < 26 && !ind; i++) {
    await p.waitForTimeout(300);
    ind = ((await p.textContent('.ed-saveind')) || '').trim();
  }
  ok('الحفظ التلقائي — المؤشر اشتغل بعد التعديل (' + ind + ')', ind.length > 0);

  /* ---- 17) قائمة مساعدة: الاختصارات ---- */
  await menu('مساعدة');
  await menuItem('اختصارات');
  await p.waitForSelector('.modal .ed-shortcuts');
  ok('مساعدة — نافذة الاختصارات (≥5 أسطر)', await p.locator('.modal .ed-sc-row').count() >= 5);
  await p.keyboard.press('Escape');
  await p.waitForTimeout(300);

  /* ---- تنظيف ---- */
  const del = await (await fetch(BASE + '/api/mutate', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok }, body: JSON.stringify({ op: 'delete', collection: 'designs', id: designId }) })).json();
  ok('تنظيف — حذف تصميم الاختبار', !!del.ok);

  ok('بدون أخطاء console', errs.length === 0);
  if (errs.length) console.log('ERRORS:\n' + errs.slice(0, 8).join('\n'));

  await b.close();
  const pass = R.filter(Boolean).length;
  console.log(`\nV2-E1 Editor: ${pass}/${R.length}`);
  process.exit(pass === R.length ? 0 : 1);
})();
