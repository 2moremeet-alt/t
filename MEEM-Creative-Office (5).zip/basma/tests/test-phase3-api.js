/* Phase 3 — اختبار الباك-إند: بورتال العميل + الأتمتة + الطلبات */
const B = 'http://localhost:3000';
let pass = 0, fail = 0;
const ok = (n, c, x = '') => { if (c) { pass++; console.log('  PASS', n); } else { fail++; console.log('  FAIL', n, x); } };
async function j(p, { m = 'GET', body, t } = {}) {
  const r = await fetch(B + p, { method: m, headers: Object.assign({ 'Content-Type': 'application/json' }, t ? { Authorization: 'Bearer ' + t } : {}), body: body ? JSON.stringify(body) : undefined });
  let json = null; try { json = await r.json(); } catch (e) {}
  return { s: r.status, json };
}
(async () => {
  const cl = await j('/api/login', { m: 'POST', body: { email: 'client@meem.studio', password: '123456' } });
  ok('دخول حساب العميل', cl.json?.ok && cl.json.user.role === 'client');
  const CT = cl.json.token;
  const adm = await j('/api/login', { m: 'POST', body: { email: 'admin@meem.studio', password: '123456' } });
  const AT = adm.json.token;
  const des = await j('/api/login', { m: 'POST', body: { email: 'designer@meem.studio', password: '123456' } });
  const DT = des.json.token;

  // state العميل مفلتر
  const st = await j('/api/state', { t: CT });
  ok('بورتال: مشاريع العميل فقط', st.json.data.projects.every((p) => p.clientId === 'cli_zahra') && st.json.data.projects.length >= 1);
  ok('بورتال: تصاميم العميل فقط', st.json.data.designs.every((d) => d.clientId === 'cli_zahra'));
  ok('بورتال: عميل واحد + مفيش طلبات', st.json.data.clients.length === 1 && st.json.data.requests.length === 0);

  // العميل ممنوع من mutate
  const mut = await j('/api/mutate', { m: 'POST', t: CT, body: { collection: 'tasks', doc: { title: 'هك' } } });
  ok('بورتال: mutate مرفوض 403', mut.s === 403);

  // تصميم العميل (الديمو)
  const myDesign = st.json.data.designs[0];
  ok('عند العميل تصميم واحد على الأقل', !!myDesign, JSON.stringify(st.json.data.designs.map(d => d.title)));

  // عزل التصميمات: تصميم عميل تاني → 404
  const all = await j('/api/state', { t: AT });
  const other = all.json.data.designs.find((d) => d.clientId && d.clientId !== 'cli_zahra');
  if (other) {
    const g = await j('/api/design/' + other.id, { t: CT });
    ok('بورتال: تصميم عميل آخر 404', g.s === 404);
  } else ok('بورتال: (لا تصميم لعميل آخر بعد — تُرك)', true);

  const dcount0 = (await j('/api/state', { t: AT })).json.data.deliveries.length;
  const tcount0 = (await j('/api/state', { t: AT })).json.data.tasks.length;

  // قرار العميل من البورتال (approve) على تصميم بحالة client/approved
  await j('/api/mutate', { m: 'POST', t: AT, body: { collection: 'designs', doc: { id: myDesign.id, status: 'client' } } });
  const dec = await j(`/api/design/${myDesign.id}/decision`, { m: 'POST', t: CT, body: { decision: 'approve', note: '' } });
  ok('بورتال: اعتماد العميل → client_approved', dec.json?.design?.status === 'client_approved');
  const st2 = await j('/api/state', { t: AT });
  ok('أتمتة: تسليم اتخلق تلقائيًا', st2.json.data.deliveries.length === dcount0 + 1);
  const newDlv = st2.json.data.deliveries.find((d) => d.auto);
  ok('أتمتة: التسليم فيه checklist (5 بنود)', newDlv && (newDlv.checklist || []).length === 5);
  ok('أتمتة: مهمة متابعة تسليم اتخلقت', st2.json.data.tasks.length >= tcount0 + 1 && st2.json.data.tasks.some((t) => t.title.includes('متابعة تسليم')));

  // طلب تعديل من العميل → مهمة تعديل
  const dec2 = await j(`/api/design/${myDesign.id}/decision`, { m: 'POST', t: CT, body: { decision: 'changes', note: 'غيّر اللون' } });
  ok('بورتال: طلب تعديل → changes', dec2.json?.design?.status === 'changes');
  const st3 = await j('/api/state', { t: AT });
  ok('أتمتة: مهمة تعديل للمصمم', st3.json.data.tasks.some((t) => t.title.includes('تعديلات العميل على')));

  // إيقاف قاعدة → مفيش تسليم جديد
  const settings = st3.json.data.settings.find((s) => s.id === 'automation');
  const rule = settings.rules.find((r) => r.action === 'create_delivery');
  rule.on = false;
  await j('/api/mutate', { m: 'POST', t: AT, body: { collection: 'settings', doc: settings } });
  const d1 = (await j('/api/state', { t: AT })).json.data.deliveries.length;
  await j('/api/mutate', { m: 'POST', t: AT, body: { collection: 'designs', doc: { id: myDesign.id, status: 'client' } } });
  await j(`/api/design/${myDesign.id}/decision`, { m: 'POST', t: CT, body: { decision: 'approve' } });
  const d2 = (await j('/api/state', { t: AT })).json.data.deliveries.length;
  ok('أتمتة: قاعدة موقوفة = مفيش تسليم', d2 === d1);
  // رجّع القاعدة شغالة
  rule.on = true;
  await j('/api/mutate', { m: 'POST', t: AT, body: { collection: 'settings', doc: settings } });

  // الطلبات: موجودة لـ cs + تحويل لمشروع يتم من الفرونت (هنا نتحقق من الـ collection)
  const cs = await j('/api/login', { m: 'POST', body: { email: 'cs@meem.studio', password: '123456' } });
  const stc = await j('/api/state', { t: cs.json.token });
  ok('الطلبات موجودة في state للموظفين', stc.json.data.requests.length >= 2);
  const rq = await j('/api/mutate', { m: 'POST', t: cs.json.token, body: { collection: 'requests', doc: { title: 'طلب تجريبي', clientId: 'cli_zahra', channel: 'whatsapp', status: 'new', priority: 'medium' } } });
  ok('إنشاء طلب', rq.json?.ok && !!rq.json.doc.id);

  console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
