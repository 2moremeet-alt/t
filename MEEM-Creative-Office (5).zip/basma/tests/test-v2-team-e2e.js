/* MEEM V2-4 E2E — إدارة الفريق من واجهة الأدمن */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  async function login(email) {
    const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errs.push(email + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(email + ': ' + m.text()); }); // الـ400 المتوقع من محاولة إنشاء مكرر مش خطأ حقيقي
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    await p.fill('input[type=email]', email);
    await p.click('.login-card .btn.primary');
    await p.waitForSelector('.sidebar .nav-item');
    return p;
  }

  const a = await login('admin@meem.studio');
  await a.goto(BASE + '/#/team', { waitUntil: 'networkidle' });
  await a.waitForSelector('.page-head .btn.primary');
  ok('زر «حساب جديد» في صفحة الفريق', (await a.locator('.page-head .btn.primary').innerText()).includes('حساب جديد'));

  /* إنشاء حساب من المودال */
  await a.click('.page-head .btn.primary');
  await a.waitForSelector('.modal');
  ok('مودال الحساب فتح', true);
  const inputs = a.locator('.modal .input');
  await inputs.nth(0).fill('موظف واجهة V24');
  await inputs.nth(1).fill('V24 UI');
  await inputs.nth(2).fill('v24ui@meem.studio');
  await inputs.nth(3).fill('مساعد');
  await a.locator('.modal button', { hasText: 'إنشاء الحساب' }).click();
  await a.waitForTimeout(1200);
  // idempotent: لو الحساب موجود من تشغيل سابق المودال هيفضل مفتوح (إيميل مكرر) — نقفله
  if (await a.locator('.modal button', { hasText: 'إلغاء' }).count()) {
    await a.locator('.modal button', { hasText: 'إلغاء' }).first().click();
    await a.waitForTimeout(300);
  }
  ok('الحساب الجديد ظهر في القائمة', (await a.locator('.card').filter({ hasText: 'v24ui@meem.studio' }).count()) >= 1);

  /* تعطيل → badge */
  const card = a.locator('.card').filter({ hasText: 'v24ui@meem.studio' }).first();
  await card.locator('button', { hasText: 'تعطيل' }).click();
  await a.waitForTimeout(1200);
  ok('badge معطّل ظهر', (await a.locator('.card').filter({ hasText: 'v24ui@meem.studio' }).filter({ hasText: 'معطّل' }).count()) >= 1);

  /* تفعيل تاني */
  await a.locator('.card').filter({ hasText: 'v24ui@meem.studio' }).first().locator('button', { hasText: 'تفعيل' }).click();
  await a.waitForTimeout(1200);
  ok('التفعيل اشتغل (مفيش badge معطّل)', (await a.locator('.card').filter({ hasText: 'v24ui@meem.studio' }).filter({ hasText: 'معطّل' }).count()) === 0);

  /* باسورد مودال بيفتح */
  await a.locator('.card').filter({ hasText: 'v24ui@meem.studio' }).first().locator('button', { hasText: 'باسورد' }).click();
  await a.waitForSelector('.modal');
  ok('مودال الباسورد فتح', (await a.locator('.modal input[type=password]').count()) === 1);
  await a.locator('.modal button', { hasText: 'إلغاء' }).click();

  /* designer ⛔ صفحة الفريق */
  const d = await login('designer@meem.studio');
  await d.goto(BASE + '/#/team', { waitUntil: 'networkidle' });
  await d.waitForTimeout(600);
  ok('designer ⛔ #/team → تحويل', !d.url().includes('#/team'));

  /* تنظيف: عطّل حساب الاختبار */
  const l = await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'admin@meem.studio', password: '123456' }) })).json();
  const st = await (await fetch(BASE + '/api/state', { headers: { Authorization: 'Bearer ' + l.token } })).json();
  const uu = st.data.users.find((x) => x.email === 'v24ui@meem.studio');
  if (uu) await fetch(BASE + '/api/user', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + l.token }, body: JSON.stringify({ id: uu.id, active: true }) }); // يفضل نشط عشان دورة تعطيل/تفعيل تفضل صالحة كل تشغيل

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
