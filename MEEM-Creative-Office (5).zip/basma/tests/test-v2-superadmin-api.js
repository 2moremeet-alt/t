/* MEEM V2-3 — Super Admin المخفي: الحساب · العزل · الأدوات · إدارة المستخدمين */
'use strict';
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };

async function api(path, token, body) {
  const res = await fetch(BASE + '/api' + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}
const login = (email, pass) => api('/login', null, { email, password: pass || '123456' }).then((r) => r.json.token);

(async () => {
  /* ---- 1) حساب المالك ---- */
  const owner = await login('owner@meem.studio');
  ok('owner@meem.studio يسجل دخول', !!owner);
  const ost = await api('/state', owner);
  const me = (ost.json.data.users || []).find((u) => u.email === 'owner@meem.studio');
  ok('دور المالك = superadmin', !!me && me.role === 'superadmin');
  ok('الباورد مش مكشوف في state', !!me && me.passwordHash === undefined);

  /* ---- 2) المالك مخفي عن الجميع ---- */
  for (const [who, email] of [['admin', 'admin@meem.studio'], ['designer', 'designer@meem.studio'], ['cs', 'cs@meem.studio'], ['client', 'client@meem.studio']]) {
    const t = await login(email);
    const st = await api('/state', t);
    const leaked = (st.json.data.users || []).some((u) => u.role === 'superadmin');
    ok(`المالك مخفي عن ${who}`, !leaked);
  }
  ok('المالك شايف نفسه', (ost.json.data.users || []).some((u) => u.email === 'owner@meem.studio'));

  /* ---- 3) قائمة المتصلين ---- */
  ok('state فيه online (array)', Array.isArray(ost.json.data.online));

  /* ---- 4) Tools: المالك فقط ---- */
  const admin = await login('admin@meem.studio');
  let r = await api('/mutate', admin, { collection: 'settings', op: 'upsert', doc: { id: 'tools', video: true, ai: true } });
  ok('admin ⛔ يعدل tools (403)', r.status === 403);
  r = await api('/mutate', owner, { collection: 'settings', op: 'upsert', doc: { id: 'tools', video: false, ai: true } });
  ok('owner يعدل tools (200)', r.status === 200);

  /* ---- 5) بوابة /api/ai ---- */
  const designer = await login('designer@meem.studio');
  r = await api('/ai', designer, { action: 'draft', type: 'caption' });
  ok('designer يستخدم AI وهو متاح (200 fallback)', r.status === 200 && r.json.fallback === true);
  await api('/mutate', owner, { collection: 'settings', op: 'upsert', doc: { id: 'tools', video: false, ai: false } });
  r = await api('/ai', designer, { action: 'draft', type: 'caption' });
  ok('designer ⛔ AI وهو مخفي (403)', r.status === 403);
  r = await api('/ai', owner, { action: 'draft', type: 'caption' });
  ok('owner يستخدم AI حتى وهو مخفي (200)', r.status === 200);

  /* ---- 6) إدارة المستخدمين /api/user ---- */
  r = await api('/user', designer, { name: 'هك', email: 'hack@meem.studio' });
  ok('designer ⛔ /api/user (403)', r.status === 403);
  /* V2-4: الأدمن بقى يدير الأدوار العادية (المميزة لسه للمالك — متغطية في test-v2-team-api) */
  r = await api('/user', admin, { name: 'موظف من الأدمن', email: 'v23admincreated@meem.studio', role: 'content' });
  ok('V2-4: admin ينشئ أدوار عادية (200/موجود)', r.status === 200 || r.status === 400);
  if (r.status === 200 && r.json.user) await api('/user', owner, { id: r.json.user.id, active: false });

  r = await api('/user', owner, { name: 'موظف اختبار V2', nameEn: 'V2 Tester', email: 'v2tester@meem.studio', role: 'editor', title: 'محرر' });
  let newId = r.json.user && r.json.user.id;
  if (r.status === 400 && !newId) {
    // idempotent: الحساب موجود من تشغيل سابق — أعد تفعيله وارجع الباسورد الافتراضي
    const st0 = await api('/state', owner);
    const ex = (st0.json.data.users || []).find((u) => u.email === 'v2tester@meem.studio');
    newId = ex && ex.id;
    r = await api('/user', owner, { id: newId, active: true, password: '123456', role: 'editor' });
  }
  ok('owner ينشئ/يعيد استخدام حساب الاختبار (200)', r.status === 200 && !!newId && r.json.user.role === 'editor');
  ok('الرد بدون passwordHash', r.json.user && r.json.user.passwordHash === undefined);

  r = await api('/user', owner, { name: 'موظف اختبار V2', email: 'v2tester@meem.studio' });
  ok('إيميل مكرر مرفوض (400)', r.status === 400);

  // الحساب الجديد يدخل بالباسورد الافتراضي
  const tt = await login('v2tester@meem.studio');
  ok('الحساب الجديد يسجل دخول (افتراضي 123456)', !!tt);

  // تغيير الباسورد
  r = await api('/user', owner, { id: newId, password: 'NewPass!234' });
  ok('owner يغير باسورد موظف (200)', r.status === 200);
  const tt2 = await login('v2tester@meem.studio', 'NewPass!234');
  ok('الدخول بالباسورد الجديد', !!tt2);
  const tt3 = await login('v2tester@meem.studio', '123456');
  ok('الباسورد القديم مرفوض', !tt3);

  // تعطيل الحساب
  r = await api('/user', owner, { id: newId, active: false });
  ok('owner يعطّل حساب (200)', r.status === 200 && r.json.user.active === false);
  const tt4 = await login('v2tester@meem.studio', 'NewPass!234');
  ok('المعطّل مايقدرش يدخل', !tt4);

  /* ---- 7) تنظيف: الحساب التجريبي يفضل معطّل (مفيش حذف مستخدمين — التعطيل هو الآلية) ---- */
  await api('/user', owner, { id: newId, active: false });

  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
