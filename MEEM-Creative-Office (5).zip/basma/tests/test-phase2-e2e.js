/* MEEM — Phase 2 E2E: دورة حياة التصميم كاملة */
const { chromium, devices } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = { d: [], a: [], c: [], m: [] };

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });

  /* ============ المصمم ============ */
  const dc = await b.newContext({ viewport: { width: 1600, height: 950 } });
  const d = await dc.newPage();
  d.on('pageerror', (e) => errs.d.push(e.message));
  d.on('console', (m) => { if (m.type() === 'error') errs.d.push(m.text()); });

  await d.goto(BASE, { waitUntil: 'networkidle' });
  await d.waitForSelector('.login-card', { timeout: 20000 });
  await d.click('.login-card .btn.primary');
  await d.waitForSelector('.sidebar .nav-item', { timeout: 20000 });
  ok('دخول المصمم', true);

  // تصميم جديد من الواجهة
  await d.goto(BASE + '/#/design', { waitUntil: 'networkidle' });
  await d.click('.page-head .btn.primary');
  await d.waitForSelector('#modal-root .modal, #modal-root [class*=modal]', { timeout: 8000 });
  await d.locator('#modal-root button', { hasText: 'بوست إنستجرام' }).first().click();
  await d.waitForSelector('.ed', { timeout: 10000 });
  await d.waitForTimeout(500);

  // أضف نصًا
  await d.click('.ed-tool[data-tool="text"]');
  await d.locator('.ed-panel[data-role="tools"] .ed-item').first().click();
  await d.waitForTimeout(300);

  // Brand Kit يظهر
  await d.click('.ed-tool[data-tool="brand"]');
  await d.waitForTimeout(250);
  const brandTxt = await d.textContent('.ed-panel[data-role="tools"]');
  ok('Brand Kit: لوحة الألوان والخطوط', brandTxt.includes('ألوان البراند') && brandTxt.includes('خطوط البراند') && (await d.locator('.ed-swatch').count()) >= 4);

  // احفظ ثم أرسل للمراجعة
  await d.click('.ed-top button:has-text("حفظ")');
  await d.waitForTimeout(900);
  const designId = await d.evaluate(async () => {
    const r = await fetch('/api/state', { headers: { Authorization: 'Bearer ' + localStorage.getItem('basma_token') } });
    const j = await r.json();
    const nd = j.data.designs.find((x) => (x.title || '').includes('بوست إنستجرام مربع'));
    return nd ? nd.id : j.data.designs[0].id;
  });
  ok('التصميم اتحفظ', !!designId);

  await d.click('.ed-top .btn.primary:has-text("للمراجعة")');
  await d.waitForSelector('.ed', { state: 'detached', timeout: 8000 });
  await d.waitForTimeout(700);

  // الجاليري: شارة في المراجعة
  await d.goto(BASE + '/#/design/gallery', { waitUntil: 'networkidle' });
  await d.waitForTimeout(600);
  ok('شارة «في المراجعة» في الجاليري', (await d.textContent('.cards-grid')).includes('في المراجعة'));
  ok('شارة V1 ظهرت', (await d.textContent('.cards-grid')).includes('V1'));

  /* ============ المراجع (admin) ============ */
  const ac = await b.newContext({ viewport: { width: 1600, height: 950 } });
  const a = await ac.newPage();
  a.on('pageerror', (e) => errs.a.push(e.message));
  a.on('console', (m) => { if (m.type() === 'error') errs.a.push(m.text()); });
  await a.goto(BASE, { waitUntil: 'networkidle' });
  await a.waitForSelector('.login-card');
  await a.fill('.login-card input[type="email"]', 'admin@meem.studio');
  await a.click('.login-card .btn.primary');
  await a.waitForSelector('.sidebar .nav-item');
  await a.goto(BASE + '/?r=' + Date.now() + '#/design/gallery', { waitUntil: 'networkidle' });
  await a.waitForTimeout(600);
  ok('زر «مراجعة» ظاهر للأدمن', await a.locator('.dcard .btn.primary:has-text("مراجعة")').isVisible());

  await a.click('.dcard:has-text("بوست إنستجرام مربع") .btn.primary:has-text("مراجعة")');
  await a.waitForSelector('.ed', { timeout: 10000 });
  await a.waitForTimeout(600);
  ok('وضع المراجعة: لوحة التعليقات مفتوحة', await a.locator('.ed-panel[data-role="tools"].open').isVisible() && (await a.textContent('.ed-panel-head')).includes('تعليقات المراجعة'));
  ok('شريط المراجعة فيه أزرار القرار', await a.locator('.ed-reviewbar .btn.danger').isVisible() && await a.locator('.ed-reviewbar .btn.ok').isVisible());

  // دبوس على الكانفس
  const box = await a.locator('.ed-canvas-holder').boundingBox();
  await a.mouse.click(box.x + box.width * 0.5, box.y + box.height * 0.4);
  await a.waitForSelector('#modal-root textarea', { timeout: 5000 });
  await a.fill('#modal-root textarea', 'العنوان محتاج يكبر شوية');
  await a.click('#modal-root button:has-text("ثبّت التعليق")');
  await a.waitForTimeout(800);
  ok('دبوس اتثبت على الكانفس', (await a.locator('.ed-pin').count()) >= 1);
  ok('التعليق في اللوحة', (await a.textContent('.ed-panel[data-role="tools"]')).includes('العنوان محتاج يكبر'));

  // طلب تعديل
  await a.click('.ed-reviewbar .btn.danger');
  await a.waitForSelector('#modal-root textarea');
  await a.fill('#modal-root textarea', 'كبّر العنوان وغيّر اللون');
  await a.click('#modal-root button:has-text("إرسال طلب التعديل")');
  await a.waitForTimeout(900);
  ok('الحالة بقت «تعديلات مطلوبة»', (await a.textContent('.ed-statuspill')).includes('تعديلات مطلوبة'));
  // أقفل محرر الأدمن
  await a.click('.ed-top .ed-icobtn[title="إغلاق"]');
  await a.waitForTimeout(600);
  const adminModal = await a.locator('#modal-root .btn:has-text("إغلاق بدون حفظ")');
  if (await adminModal.count()) await adminModal.click();
  await a.waitForTimeout(400);

  /* ============ المصمم: يشوف الملاحظات ويعيد الإرسال ============ */
  await d.goto(BASE + '/?r=' + Date.now() + '#/design/gallery', { waitUntil: 'networkidle' });
  await d.waitForTimeout(800);
  ok('المصمم يشوف «تعديلات مطلوبة»', (await d.textContent('.cards-grid')).includes('تعديلات مطلوبة'));
  ok('عداد التعليقات 💬 1', (await d.textContent('.cards-grid')).includes('💬 1'));

  await d.click('.dcard:has-text("بوست إنستجرام مربع")');
  await d.waitForSelector('.ed', { timeout: 10000 });
  await d.waitForTimeout(700);
  ok('شريط المراجعة يعرض ملاحظات المراجع', (await d.textContent('.ed-reviewbar')).includes('كبّر العنوان'));
  ok('الدبابيس ظاهرة عند المصمم', (await d.locator('.ed-pin').count()) >= 1);

  // يرد على التعليق ويحله
  await d.click('.ed-tool[data-tool="comments"]');
  await d.waitForTimeout(300);
  await d.locator('.ed-cmt button:has-text("رد")').first().click();
  await d.waitForTimeout(300);
  await d.locator('.ed-cmt input').first().fill('تمام هعدّله');
  await d.locator('.ed-cmt button:has-text("↩")').first().click();
  await d.waitForTimeout(900);
  // الزر ممكن يكون "تم ✓" أو "إعادة فتح" حسب الحالة
  const resolveBtn = d.locator('.ed-cmt button:has-text("تم ✓")').first();
  const reopenBtn = d.locator('.ed-cmt button:has-text("إعادة فتح")').first();
  if (await resolveBtn.count()) { await resolveBtn.click(); await d.waitForTimeout(700); }
  ok('الرد اتسجل والتعليق اتحل', (await d.textContent('.ed-cmt')).includes('تمام هعدّله') && await d.locator('.ed-cmt.resolved').count() === 1);

  // إعادة الإرسال
  await d.click('.ed-top .btn.primary:has-text("للمراجعة")');
  await d.waitForSelector('.ed', { state: 'detached', timeout: 8000 });

  /* ============ الأدمن: اعتماد ============ */
  await a.goto(BASE + '/?r=' + Date.now() + '#/design/gallery', { waitUntil: 'networkidle' });
  await a.waitForTimeout(800);
  await a.click('.dcard:has-text("بوست إنستجرام مربع") .btn.primary:has-text("مراجعة")');
  await a.waitForSelector('.ed', { timeout: 10000 });
  await a.waitForTimeout(600);
  await a.click('.ed-reviewbar .btn.ok');
  await a.waitForSelector('#modal-root textarea');
  await a.click('#modal-root button:has-text("اعتماد")');
  await a.waitForTimeout(1000);
  ok('الاعتماد: «معتمد داخليًا»', (await a.textContent('.ed-statuspill')).includes('معتمد داخليًا'));
  ok('زر «أرسله للعميل» ظهر', await a.locator('.ed-reviewbar button:has-text("أرسله للعميل")').isVisible());

  // النسخ
  await a.click('.ed-tool[data-tool="versions"]');
  await a.waitForTimeout(400);
  const verCount = await a.locator('.ed-ver').count();
  ok('النسخ V1..Vn (≥2): ' + verCount, verCount >= 2);
  await a.locator('.ed-ver button:has-text("قارن")').first().click();
  await a.waitForTimeout(900);
  ok('مقارنة نسخة: صورتان', (await a.locator('#modal-root img').count()) >= 2);
  await a.keyboard.press('Escape');
  await a.waitForTimeout(300);
  if (await a.locator('#modal-root .btn:has-text("إغلاق"), #modal-root [aria-label]').count()) {
    // لو مفيش إغلاق بـ Escape، اضغط أي زر إغلاق
  }

  // رابط العميل
  await a.click('.ed-reviewbar button:has-text("أرسله للعميل")');
  await a.waitForSelector('#modal-root button:has-text("أنشئ رابط الاعتماد")');
  await a.click('#modal-root button:has-text("أنشئ رابط الاعتماد")');
  await a.waitForTimeout(900);
  const shareUrl = await a.locator('#modal-root input[readonly]').inputValue();
  ok('رابط الاعتماد اتخلق', /\/approve\.html\?t=[a-f0-9]+/.test(shareUrl));
  // أقفل محرر الأدمن
  await a.keyboard.press('Escape');
  await a.waitForTimeout(300);
  await a.click('.ed-top .ed-icobtn[title="إغلاق"]');
  await a.waitForTimeout(500);
  const adminModal2 = await a.locator('#modal-root .btn:has-text("إغلاق بدون حفظ")');
  if (await adminModal2.count()) await adminModal2.click();
  await a.waitForTimeout(400);

  /* ============ العميل (عامة) ============ */
  const cc = await b.newContext({ viewport: { width: 900, height: 1000 } });
  const c = await cc.newPage();
  c.on('pageerror', (e) => errs.c.push(e.message));
  await c.goto(BASE + '/approve.html?t=badtoken123');
  await c.waitForTimeout(800);
  ok('رابط باطل → رسالة قفل', (await c.textContent('#main')).includes('غير صالح') || (await c.textContent('#main')).includes('ناقص'));

  await c.goto(shareUrl, { waitUntil: 'networkidle' });
  await c.waitForSelector('.preview canvas', { timeout: 15000 });
  ok('صفحة العميل: المعاينة رسمت (بعلامة مائية)', true);
  ok('صفحة العميل: العنوان ظاهر', (await c.textContent('h1')).length > 0);
  await c.fill('input[placeholder*="اسمك"]', 'أحمد من شركة النيل');
  await c.click('.btns .approve');
  await c.waitForSelector('.done', { timeout: 10000 });
  ok('العميل اعتمد → شاشة شكر', (await c.textContent('.done')).includes('شكرًا'));

  /* ============ الرجوع للتطبيق: الحالة النهائية ============ */
  await d.goto(BASE + '/?r=' + Date.now() + '#/design/gallery', { waitUntil: 'networkidle' });
  await d.waitForTimeout(900);
  ok('الحالة «اعتمده العميل»', (await d.textContent('.cards-grid')).includes('اعتمده العميل'));

  // تغيير المقاس
  await d.click('.dcard:has-text("بوست إنستجرام مربع")');
  await d.waitForSelector('.ed', { timeout: 10000 });
  await d.waitForTimeout(600);
  await d.click('.ed-top .ed-icobtn[title*="المقاس"]');
  await d.waitForSelector('#modal-root button:has-text("ستوري")');
  await d.click('#modal-root button:has-text("ستوري")');
  await d.waitForTimeout(700);
  const newSize = await d.evaluate(async (id) => {
    const r = await fetch('/api/design/' + id, { headers: { Authorization: 'Bearer ' + localStorage.getItem('basma_token') } });
    return (await r.json()).design;
  }, designId);
  await d.click('.ed-top button:has-text("حفظ")');
  await d.waitForTimeout(900);
  const after = await d.evaluate(async (id) => {
    const r = await fetch('/api/design/' + id, { headers: { Authorization: 'Bearer ' + localStorage.getItem('basma_token') } });
    const j = await r.json();
    return { w: j.design.w, h: j.design.h };
  }, designId);
  ok('تغيير المقاس → 1080×1920', after.w === 1080 && after.h === 1920);

  // قالب فريق
  await d.click('.ed-top .ed-icobtn[title*="قالب"]');
  await d.waitForSelector('#modal-root input');
  await d.fill('#modal-root input', 'قالب إعلانات النيل');
  await d.click('#modal-root button:has-text("حفظ القالب")');
  await d.waitForTimeout(800);
  await d.click('.ed-top .ed-icobtn[title="إغلاق"]');
  await d.waitForTimeout(400);
  const modalSave = await d.locator('#modal-root .btn:has-text("حفظ وإغلاق")');
  if (await modalSave.count()) await modalSave.click();
  await d.waitForTimeout(600);
  await d.goto(BASE + '/#/design/templates', { waitUntil: 'networkidle' });
  await d.waitForTimeout(700);
  ok('قالب الفريق في تبويب القوالب', (await d.textContent('.view')).includes('قوالب الفريق') && (await d.textContent('.view')).includes('قالب إعلانات النيل'));

  /* ============ موبايل: تعليق مثبّت ============ */
  const mc = await b.newContext({ ...devices['iPhone 12'] });
  const m = await mc.newPage();
  m.on('pageerror', (e) => errs.m.push(e.message));
  await m.goto(BASE, { waitUntil: 'networkidle' });
  await m.waitForSelector('.login-card', { timeout: 20000 });
  await m.click('.login-card .btn.primary');
  await m.waitForSelector('.sidebar .nav-item');
  await m.goto(BASE + '/#/design/gallery', { waitUntil: 'networkidle' });
  await m.waitForTimeout(800);
  await m.locator('.dcard').first().tap();
  await m.waitForSelector('.ed', { timeout: 10000 });
  await m.waitForTimeout(700);
  await m.tap('.ed-tool[data-tool="comments"]');
  await m.waitForTimeout(300);
  ok('موبايل: لوحة التعليقات فتحت', await m.locator('.ed-panel[data-role="tools"].open').isVisible());
  // أقفل اللوحة عشان الكانفس يبقى مكشوف (الأداة تظل فعّالة)
  await m.locator('.ed-panel[data-role="tools"] .ed-close').tap();
  await m.waitForTimeout(300);
  const mbox = await m.locator('.ed-canvas-holder').boundingBox();
  await m.tap('.ed-canvas-holder', { position: { x: mbox.width * 0.4, y: mbox.height * 0.6 } });
  await m.waitForSelector('#modal-root textarea', { timeout: 5000 });
  await m.fill('#modal-root textarea', 'تعديل من الموبايل');
  await m.tap('#modal-root button:has-text("ثبّت التعليق")');
  await m.waitForTimeout(900);
  ok('موبايل: دبوس جديد اتثبت', (await m.locator('.ed-pin').count()) >= 1);
  // افتح اللوحة تاني وشوف التعليق الجديد
  await m.tap('.ed-tool[data-tool="comments"]');
  await m.waitForTimeout(400);
  ok('موبايل: التعليق الجديد في اللوحة', (await m.textContent('.ed-panel[data-role="tools"]')).includes('تعديل من الموبايل'));
  await m.locator('.ed-panel[data-role="tools"] .ed-close').tap();
  await m.waitForTimeout(300);
  ok('موبايل: اللوحة اتقفلت', await m.locator('.ed-panel[data-role="tools"].open').count() === 0);

  /* ============ الأخطاء ============ */
  ok('ديسكتوب مصمم: صفر أخطاء (' + errs.d.length + ')', errs.d.length === 0);
  ok('أدمن: صفر أخطاء (' + errs.a.length + ')', errs.a.length === 0);
  ok('عميل: صفر أخطاء (' + errs.c.length + ')', errs.c.length === 0);
  ok('موبايل: صفر أخطاء (' + errs.m.length + ')', errs.m.length === 0);
  if (errs.d.length) console.log(errs.d.slice(0, 5));
  if (errs.a.length) console.log(errs.a.slice(0, 5));
  if (errs.m.length) console.log(errs.m.slice(0, 5));

  console.log('\n=== ' + R.filter(Boolean).length + '/' + R.length + ' ===');
  await b.close();
  process.exit(R.some((x) => !x) ? 1 : 0);
})().catch((e) => { console.error('CRASH', e); process.exit(2); });
