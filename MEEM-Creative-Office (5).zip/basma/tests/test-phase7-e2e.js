/* MEEM — Phase 7 E2E: Chat لحظي + اجتماع→مهام + شات عميل + AI المحرر */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const PNG = '/tmp/tc/p5img.png';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  /* V2-3: الفيديو/الـ AI مخفيين افتراضيًا — المالك يتيحهم للاختبار */
  const setTools = async (on) => {
    const l = await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'owner@meem.studio', password: '123456' }) })).json();
    await fetch(BASE + '/api/mutate', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + l.token }, body: JSON.stringify({ collection: 'settings', op: 'upsert', doc: { id: 'tools', video: on, ai: on } }) });
  };
  await setTools(true);
  const b = await chromium.launch({ args: ['--no-sandbox', '--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream'] });
  async function login(email) {
    const ctx = await b.newContext({ viewport: { width: 1600, height: 950 } });
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errs.push(email + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error') errs.push(email + ': ' + m.text()); });
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    await p.fill('input[type=email]', email);
    await p.click('.login-card .btn.primary');
    await p.waitForSelector('.sidebar .nav-item');
    return p;
  }

  /* ============ 1) شات لحظي بين متصفحين ============ */
  const d = await login('designer@meem.studio');
  const v = await login('dev@meem.studio');
  await d.goto(BASE + '/#/chat', { waitUntil: 'networkidle' });
  await v.goto(BASE + '/#/chat', { waitUntil: 'networkidle' });
  await d.waitForSelector('.chat-msgs');
  await v.waitForSelector('.chat-msgs');
  ok('غرف الفريق ظاهرة (≥4)', (await d.locator('.chat-room').count()) >= 4);
  ok('الرسائل seeded ظاهرة', (await d.locator('.chat-msg').count()) >= 3);

  const stamp = Date.now();
  await d.fill('.chat-input', 'رسالة لحظية ' + stamp);
  await d.click('.chat-compose .btn.primary');
  await v.waitForSelector(`.chat-msg:has-text("${stamp}")`, { timeout: 8000 });
  ok('الرسالة وصلت للمتصفح التاني لحظيًا ⚡', true);
  await d.waitForSelector(`.chat-msg.mine:has-text("${stamp}")`, { timeout: 8000 });
  ok('المرسل شاف رسالته (mine)', true);

  /* ============ 2) شات العميل (عزل) ============ */
  const c = await login('client@meem.studio');
  await c.goto(BASE + '/#/chat', { waitUntil: 'networkidle' });
  await c.waitForSelector('.chat-rooms');
  const clientRooms = await c.locator('.chat-room').count();
  // العزل الحقيقي: كل رسالة في state العميل داخل غرفه المسموحة (غرفته + غرف مشاريعه) — مهما زاد عدد مشاريعه
  const clTok = (await (await c.request.post(BASE + '/api/login', { data: { email: 'client@meem.studio', password: '123456' } })).json()).token;
  const clSt = (await (await c.request.get(BASE + '/api/state', { headers: { Authorization: 'Bearer ' + clTok } })).json()).data;
  const allowedRooms = new Set(['cli:cli_zahra', ...clSt.projects.map((pj) => 'prj:' + pj.id)]);
  const leaked = (clSt.chats || []).map((m) => m.room).filter((r) => !allowedRooms.has(r));
  ok('العميل: غرفه + غرف مشاريعه بس — صفر تسريب (' + clientRooms + ' غرف)', clientRooms >= 1 && leaked.length === 0);
  const cst = Date.now();
  await c.fill('.chat-input', 'سؤال العميل ' + cst);
  await c.click('.chat-compose .btn.primary');
  await c.waitForSelector(`.chat-msg.mine:has-text("${cst}")`, { timeout: 8000 });
  ok('العميل بعت في غرفته', true);

  /* ============ 3) اجتماع → مهام ============ */
  const a = await login('admin@meem.studio');
  await a.goto(BASE + '/#/meetings', { waitUntil: 'networkidle' });
  await a.waitForSelector('.meet-card');
  await a.click('.meet-card button:has-text("الملاحظات") >> nth=0');
  await a.waitForSelector('.modal textarea', { timeout: 5000 });
  await a.fill('.modal textarea', '- متابعة تسليم البروشر\n- مراجعة سكربت الفيديو');
  await a.click('.modal button:has-text("حوّل لمهام")');
  await a.waitForSelector('.modal:has-text("الملاحظات → مهام")', { timeout: 5000 });
  ok('مودال التحويل فتح بالسطرين', (await a.locator('.modal .check').count()) === 2);
  await a.selectOption('.modal select.select >> nth=0', 'prj_3');
  await a.click('.modal button:has-text("أنشئ المهام")');
  await a.waitForFunction(async () => {
    const r = await fetch('/api/state', { headers: { Authorization: 'Bearer ' + localStorage.getItem('basma_token') } });
    const st = await r.json();
    return st.data.tasks.filter((t) => (t.desc || '').includes('من اجتماع:')).length >= 2;
  }, null, { timeout: 8000 });
  ok('اتعملت مهمتين من الملاحظات ✓', true);
  // تنظيف المهام
  await a.evaluate(async () => {
    const T = localStorage.getItem('basma_token');
    const r = await fetch('/api/state', { headers: { Authorization: 'Bearer ' + T } });
    const st = await r.json();
    for (const t of st.data.tasks.filter((x) => (x.desc || '').includes('من اجتماع:'))) {
      await fetch('/api/mutate', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + T }, body: JSON.stringify({ collection: 'tasks', op: 'delete', id: t.id }) });
    }
  });

  /* ============ 4) AI في محرر التصميم ============ */
  await d.goto(BASE + '/#/design?r=' + Date.now(), { waitUntil: 'networkidle' });
  await d.click('.page-head .btn.primary');
  await d.locator('#modal-root button', { hasText: 'بوست إنستجرام' }).first().click();
  await d.waitForSelector('.ed', { timeout: 10000 });
  // ارفع صورة
  await d.click('.ed-tool[data-tool="upload"]');
  await d.waitForSelector('.ed-dropzone', { timeout: 5000 });
  await d.click('.ed-dropzone');
  await d.waitForSelector('body > input[type=file]', { state: 'attached', timeout: 5000 });
  await d.setInputFiles('body > input[type=file]', PNG);
  await d.waitForTimeout(1800);
  // اختارها (نص الكانفس)
  const box = await d.locator('.ed-canvas-holder').boundingBox();
  await d.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  await d.waitForTimeout(300);
  // لوحة AI
  await d.click('.ed-tool[data-tool="ai"]');
  await d.waitForSelector('.ed-panel button:has-text("تحسين")', { timeout: 5000 });
  ok('لوحة AI فتحت بأدوات الصورة', true);

  await d.click('.ed-panel button:has-text("تحسين")');
  await d.waitForSelector('.toast:has-text("تم ✓")', { timeout: 8000 });
  ok('✨ تحسين الصورة اشتغل (معالجة حقيقية)', true);
  await d.waitForTimeout(2500);

  await d.click('.ed-panel button:has-text("تكبير")');
  await d.waitForSelector('.toast:has-text("تم ✓")', { timeout: 8000 });
  ok('🔍 تكبير ×2 اشتغل', true);
  await d.waitForTimeout(2500);

  // مولد التصميم
  await d.fill('.ed-panel textarea[placeholder*="بوست عرض"]', 'بوست عرض تغيير زيت سيارات احترافي');
  await d.click('.ed-panel button:has-text("ولّد 3 Layouts")');
  await d.waitForSelector('.ed-panel button:has-text("طبّق")', { timeout: 5000 });
  ok('🤖 3 Layouts اتولدت', (await d.locator('.ed-panel button:has-text("طبّق")').count()) === 3);
  const layersBefore = await d.evaluate(() => document.querySelectorAll('.ed-layer-item, .ed-layers .ed-item').length);
  await d.click('.ed-panel button:has-text("طبّق") >> nth=0');
  await d.waitForSelector('.toast:has-text("اتطبق layout")', { timeout: 5000 });
  ok('الـ Layout اتطبق على الكانفس', true);

  // مولد الصور
  await d.fill('.ed-panel input[placeholder*="الخلفية"]', 'أزرق ودهبي مودرن');
  await d.click('.ed-panel button:has-text("ولّد وأضف للكانفس")');
  await d.waitForSelector('.toast:has-text("اتولدت")', { timeout: 10000 });
  ok('🎨 الخلفية اتولدت وانضافت للكانفس', true);

  /* ============ أخطاء؟ ============ */
  const realErrs = errs.filter((e) => !/favicon|DevTools|WebSocket/i.test(e));
  ok('مفيش أخطاء JS', realErrs.length === 0);
  if (realErrs.length) console.log(realErrs.join('\n'));

  await b.close();
  await setTools(false);
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
