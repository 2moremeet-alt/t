/* MEEM V2-10 E2E — كانبان المهام: أعمدة · سحب وإفلات · أسهم · مرفقات · فلاتر · صلاحيات */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const fs = require('fs');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  async function login(email) {
    const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errs.push(email + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(email + ': ' + m.text()); });
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    await p.fill('input[type=email]', email);
    await p.click('.login-card .btn.primary');
    await p.waitForSelector('.sidebar .nav-item');
    return p;
  }
  const loginApi = async (email) => (await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: '123456' }) })).json()).token;
  const stateOf = async (tok) => (await (await fetch(BASE + '/api/state', { headers: { Authorization: 'Bearer ' + tok } })).json()).data;

  /* ---- 1) اللوحة: 6 أعمدة + الكروت ---- */
  const d = await login('designer@meem.studio');
  await d.goto(BASE + '/#/tasks', { waitUntil: 'networkidle' });
  await d.waitForSelector('.kb-board');
  ok('6 أعمدة حالات', (await d.locator('.kb-col').count()) === 6);
  const totalCards = await d.locator('.kb-card').count();
  ok('الكروت معروضة (' + totalCards + ')', totalCards >= 10);
  ok('«المهام» في السايدبار', (await d.locator('.sidebar .nav-item', { hasText: 'المهام' }).count()) === 1);

  /* ---- 2) فلترة «مهامي» ---- */
  const mineBtn = d.locator('.page-head button', { hasText: 'مهامي' });
  await mineBtn.click();
  await d.waitForTimeout(400);
  const mineCards = await d.locator('.kb-card').count();
  ok('فلتر مهامي قلل الكروت (' + totalCards + '→' + mineCards + ')', mineCards < totalCards);
  await mineBtn.click();
  await d.waitForTimeout(400);

  /* ---- 3) تحريك بالسهم: new → progress (مع إرجاعها) ---- */
  const aTok = await loginApi('admin@meem.studio');
  const before = (await stateOf(aTok)).tasks.find((x) => x.status === 'new' && x.dept === 'design');
  ok('فيه مهمة تصميم new للاختبار', !!before);
  const card = d.locator('.kb-card', { hasText: before.title }).first();
  await card.locator('.kb-mv').last().click(); // ▶ تقدم
  await d.waitForTimeout(900);
  let now = (await stateOf(aTok)).tasks.find((x) => x.id === before.id);
  ok('السهم نقل المهمة new→progress (server-side)', now.status === 'progress');

  /* ---- 4) سحب وإفلات: progress → review ---- */
  const src = d.locator('.kb-card[data-task="' + before.id + '"]');
  const dst = d.locator('.kb-col').nth(2); // عمود «مراجعة»
  await src.dragTo(dst);
  await d.waitForTimeout(900);
  now = (await stateOf(aTok)).tasks.find((x) => x.id === before.id);
  ok('السحب نقل المهمة progress→review', now.status === 'review');

  /* ---- 5) مرفقات: رفع صورة على المهمة ---- */
  fs.writeFileSync('/tmp/tiny-att.png', Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c626001000000ffff03000006000557bfabd40000000049454e44ae426082', 'hex'));
  await d.locator('.kb-card[data-task="' + before.id + '"]').click();
  await d.waitForSelector('.modal');
  await d.locator('.modal button', { hasText: 'رفع ملف' }).click();
  await d.setInputFiles('input[type=file]', '/tmp/tiny-att.png');
  await d.waitForTimeout(1500);
  ok('المرفق ظهر في المودال', (await d.locator('.tf-file').count()) === 1);
  const fileUrl = await d.locator('.tf-file a').getAttribute('href');
  const up = await fetch(BASE + fileUrl);
  ok('رابط المرفق شغال (200)', up.status === 200);
  await d.keyboard.press('Escape');
  await d.waitForTimeout(500);
  now = (await stateOf(aTok)).tasks.find((x) => x.id === before.id);
  ok('المرفق محفوظ في المهمة (server-side)', (now.files || []).length === 1 && now.files[0].name === 'tiny-att.png');
  ok('📎 ظهر على الكارت', (await d.locator('.kb-card[data-task="' + before.id + '"] .kb-clip').count()) === 1);

  /* ---- 6) العميل ممنوع server-side من المهام ---- */
  const cTok = await loginApi('client@meem.studio');
  const deny = await fetch(BASE + '/api/mutate', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + cTok }, body: JSON.stringify({ collection: 'tasks', op: 'upsert', doc: { id: before.id, status: 'done' } }) });
  ok('العميل ما يقدرش يعدل المهام (403)', deny.status === 403);

  /* ---- 7) إرجاع الحالة الأصلية (نضافة) ---- */
  const tok2 = await loginApi('designer@meem.studio');
  await fetch(BASE + '/api/mutate', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok2 }, body: JSON.stringify({ collection: 'tasks', op: 'upsert', doc: { id: before.id, status: before.status, files: [] } }) });
  now = (await stateOf(aTok)).tasks.find((x) => x.id === before.id);
  ok('رجعنا المهمة لحالتها الأصلية', now.status === before.status && (now.files || []).length === 0);

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
