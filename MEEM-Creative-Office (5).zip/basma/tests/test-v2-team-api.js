/* MEEM V2-4 — الحسابات من الإدارة فقط: منع التسجيل الذاتي + صلاحيات الأدمن + الباسورد الذاتي */
'use strict';
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };

async function api(path, token, body) {
  const res = await fetch(BASE + '/api' + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { status: res.status, json: await res.json().catch(() => ({})) };
}
const login = (email, pass) => api('/login', null, { email, password: pass || '123456' }).then((r) => r.json.token);

(async () => {
  const admin = await login('admin@meem.studio');
  const designer = await login('designer@meem.studio');

  /* ---- 1) لا يوجد تسجيل ذاتي ---- */
  let r = await api('/signup', null, { email: 'hacker@x.com', password: '123456', name: 'هاكر' });
  ok('POST /api/signup مرفوض (401/404 — مفيش تسجيل ذاتي)', r.status === 404 || r.status === 401);
  r = await api('/register', null, { email: 'hacker@x.com', password: '123456', name: 'هاكر' });
  ok('POST /api/register مرفوض (401/404)', r.status === 404 || r.status === 401);
  r = await api('/mutate', designer, { collection: 'users', op: 'upsert', doc: { email: 'hacker@x.com', role: 'admin' } });
  ok('users مش collection قابلة للكتابة (400)', r.status === 400);

  /* ---- 2) الأدمن ينشئ ويدير حسابات الفريق ---- */
  r = await api('/user', admin, { name: 'مصمم اختبار V24', nameEn: 'V24 Designer', email: 'v24designer@meem.studio', role: 'designer', title: 'مصمم' });
  let nid = r.json.user && r.json.user.id;
  if (r.status === 400 && !nid) { // idempotent
    const st = await api('/state', admin);
    nid = (st.json.data.users || []).find((u) => u.email === 'v24designer@meem.studio').id;
    r = await api('/user', admin, { id: nid, active: true, password: '123456', role: 'designer' });
  }
  ok('admin ينشئ حساب designer (200)', r.status === 200 && !!nid);
  ok('الحساب الجديد يدخل (123456)', !!(await login('v24designer@meem.studio')));

  r = await api('/user', admin, { id: nid, active: false });
  ok('admin يعطّل (200)', r.status === 200);
  ok('المعطّل ما يدخلش', !(await login('v24designer@meem.studio')));
  await api('/user', admin, { id: nid, active: true });

  r = await api('/user', admin, { id: nid, password: 'V24Pass!11' });
  ok('admin يغيّر الباسورد (200)', r.status === 200);
  ok('دخول بالباسورد الجديد', !!(await login('v24designer@meem.studio', 'V24Pass!11')));

  /* ---- 3) حدود الأدمن: مفيش حسابات مميزة ---- */
  r = await api('/user', admin, { name: 'أدمن مزروع', email: 'fakeadmin@meem.studio', role: 'admin' });
  ok('admin ⛔ ينشئ admin (403)', r.status === 403);
  r = await api('/user', admin, { name: 'مالك مزروع', email: 'fakeowner@meem.studio', role: 'superadmin' });
  ok('admin ⛔ ينشئ superadmin (403)', r.status === 403);
  const st = await api('/state', admin);
  const adminRow = (st.json.data.users || []).find((u) => u.email === 'admin@meem.studio');
  r = await api('/user', admin, { id: adminRow.id, active: false });
  ok('admin ⛔ يعطّل حساب أدمن (403)', r.status === 403);
  const ownerSt = await api('/state', await login('owner@meem.studio'));
  const ownerRow = (ownerSt.json.data.users || []).find((u) => u.email === 'owner@meem.studio');
  r = await api('/user', admin, { id: ownerRow.id, password: 'hacked1' });
  ok('admin ⛔ يلمس حساب المالك (403)', r.status === 403);
  r = await api('/user', admin, { id: nid, role: 'admin' });
  ok('admin ⛔ يرقّي موظف لأدمن (403)', r.status === 403);
  r = await api('/user', designer, { name: 'x', email: 'x@meem.studio' });
  ok('designer ⛔ /api/user (403)', r.status === 403);

  /* ---- 4) الباسورد الذاتي (§32) ---- */
  r = await api('/password', designer, { current: 'غلط', next: 'NewSelf!1' });
  ok('باسورد حالي غلط → 403', r.status === 403);
  r = await api('/password', designer, { current: '123456', next: 'قصير' });
  ok('باسورد جديد قصير → 400', r.status === 400);
  r = await api('/password', designer, { current: '123456', next: 'TempSelf!1' });
  ok('تغيير الباسورد الذاتي (200)', r.status === 200);
  ok('دخول بالباسورد الذاتي الجديد', !!(await login('designer@meem.studio', 'TempSelf!1')));
  ok('القديم مرفوض', !(await login('designer@meem.studio', '123456')));
  // نرجعه
  const d2 = await login('designer@meem.studio', 'TempSelf!1');
  r = await api('/password', d2, { current: 'TempSelf!1', next: '123456' });
  ok('إرجاع باسورد الديمو (200)', r.status === 200 && !!(await login('designer@meem.studio')));

  /* ---- 5) تنظيف ---- */
  await api('/user', admin, { id: nid, active: false });

  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
