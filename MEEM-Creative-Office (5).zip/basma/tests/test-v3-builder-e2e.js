/* MEEM V3-3 E2E — بنّاء المكتب + طوابق + صالة العملاء */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

async function mk(ctx, email) {
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(email + ' pageerror: ' + e.message));
  p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(email + ': ' + m.text()); });
  await p.goto(BASE + '/?r=' + email + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', email);
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  if (email.startsWith('client@')) {
    await p.waitForSelector('.page-head', { timeout: 15000 });
    return p;
  }
  await p.waitForSelector('.office-map', { timeout: 15000 });
  await p.waitForTimeout(700);
  return p;
}

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const cAdm = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const cDes = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const cCli = await b.newContext({ viewport: { width: 1500, height: 950 } });

  const A = await mk(cAdm, 'admin@meem.studio');
  const D = await mk(cDes, 'designer@meem.studio');

  /* ---- 1) زر البنّاء للأدمن فقط ---- */
  ok('الأدمن شايف زر البنّاء 🛠️', (await A.locator('.of-build').count()) === 1);
  ok('المصمم مش شايف زر البنّاء', (await D.locator('.of-build').count()) === 0);

  /* ---- 2) فتح البنّاء + عناصر قابلة للسحب ---- */
  await A.locator('.of-build').click();
  await A.waitForTimeout(700);
  ok('شريط البنّاء ظاهر', (await A.locator('.of-bbar').count()) === 1);
  await A.locator('.of-bbar .of-hbtn', { hasText: '🗑️' }).click();
  await A.waitForTimeout(800);
  const bitems = await A.locator('.of-bitem').count();
  ok('عناصر أثاث قابلة للسحب (>20): ' + bitems, bitems > 20);

  /* ---- 3) سحب قطعة (counter الاستقبال) ---- */
  const before = await A.locator('.of-bitem[title="counter"]').evaluate((n) => n.style.left);
  const bb = await A.locator('.of-bitem[title="counter"]').boundingBox();
  await A.mouse.move(bb.x + bb.width / 2, bb.y + bb.height / 2);
  await A.mouse.down();
  await A.mouse.move(bb.x + bb.width / 2 + 60, bb.y + bb.height / 2 + 20, { steps: 5 });
  await A.mouse.up();
  await A.waitForTimeout(700);
  const after = await A.locator('.of-bitem[title="counter"]').evaluate((n) => n.style.left);
  ok('السحب حرّك الـ counter (' + before + '→' + after + ')', before !== after);

  /* ---- 4) تدوير ---- */
  await A.locator('.of-bitem[title="counter"] .of-bx.rr').click();
  await A.waitForTimeout(600);
  ok('التدوير سجل rotate(90 في الفن', (await A.evaluate(() => document.querySelector('svg.of-art').innerHTML.includes('rotate(90'))));

  /* ---- 5) إضافة وحذف قطعة ---- */
  const c1 = await A.locator('.of-bitem').count();
  await A.locator('.of-pal').selectOption('aqua');
  await A.waitForTimeout(600);
  const c2 = await A.locator('.of-bitem').count();
  ok('الإضافة من الباليتة زوّدت قطعة', c2 === c1 + 1);
  await A.locator('.of-bitem[title="aqua"]').last().locator('.of-bx').first().click();
  await A.waitForTimeout(600);
  ok('الحذف رجّع العدد', (await A.locator('.of-bitem').count()) === c1);

  /* ---- 6) سحب غرفة ---- */
  const rb = await A.locator('.office-room', { hasText: 'التسليمات' }).boundingBox();
  const rBefore = await A.locator('.office-room', { hasText: 'التسليمات' }).evaluate((n) => n.style.left);
  await A.mouse.move(rb.x + rb.width / 2, rb.y + rb.height / 2);
  await A.mouse.down();
  await A.mouse.move(rb.x + rb.width / 2 - 40, rb.y + rb.height / 2, { steps: 5 });
  await A.mouse.up();
  await A.waitForTimeout(700);
  const rAfter = await A.locator('.office-room', { hasText: 'التسليمات' }).evaluate((n) => n.style.left);
  ok('سحب الغرفة حرّكها', rBefore !== rAfter);

  /* ---- 7) قسم جديد ---- */
  await A.locator('.of-bbar .of-hbtn', { hasText: '🏷️' }).click();
  await A.fill('.of-newroom input', 'الجرافيك');
  await A.press('.of-newroom input', 'Enter');
  await A.waitForTimeout(700);
  ok('القسم الجديد ظهر', (await A.locator('.office-room', { hasText: 'الجرافيك' }).count()) === 1);

  /* ---- 8) حفظ →Persistence عند الأدمن والمصمم ---- */
  await A.locator('.of-bbar .of-hbtn', { hasText: '💾' }).click();
  await A.waitForTimeout(900);
  await A.reload({ waitUntil: 'load' });
  await A.waitForSelector('.office-map', { timeout: 15000 });
  await A.waitForTimeout(700);
  ok('بعد reload الأدمن: القسم الجديد لسه موجود', (await A.locator('.office-room', { hasText: 'الجرافيك' }).count()) === 1);
  await D.reload({ waitUntil: 'load' });
  await D.waitForSelector('.office-map', { timeout: 15000 });
  await D.waitForTimeout(700);
  ok('المصمم شايف نفس المكتب المحدّث (الجرافيك موجود)', (await D.locator('.office-room', { hasText: 'الجرافيك' }).count()) === 1);

  /* ---- 9) استرجاع الافتراضي ---- */
  await A.locator('.of-build').click();
  await A.waitForTimeout(600);
  await A.locator('.of-bbar .of-hbtn', { hasText: '🗑️' }).click();
  await A.waitForTimeout(900);
  await D.reload({ waitUntil: 'load' });
  await D.waitForSelector('.office-map', { timeout: 15000 });
  await D.waitForTimeout(700);
  ok('بعد Reset: الجرافيك اختفى عند المصمم', (await D.locator('.office-room', { hasText: 'الجرافيك' }).count()) === 0);

  /* ---- 10) عزل الأفاتارات بين الطوابق ---- */
  await A.locator('.of-flr').nth(1).click();
  await A.waitForTimeout(1500);
  await D.waitForTimeout(800);
  ok('الأدمن بالطابق ٢ مش شايف أفاتار المصمم (طابق ١)', (await A.locator('.of-av:not(.me)').count()) === 0);
  ok('المصمم مش شايف أفاتار الأدمن', (await D.locator('.of-av:not(.me)').count()) === 0);
  ok('الأدمن شايف الإدارة بالطابق ٢', (await A.locator('.office-room', { hasText: 'الإدارة' }).count()) === 1);

  /* ---- 11) صالة العملاء ---- */
  const C = await mk(cCli, 'client@meem.studio');
  ok('العميل هبط على البوابة', C.url().includes('#/portal'));
  ok('زر زيارة المكتب في البوابة', (await C.locator('button', { hasText: 'زور المكتب' }).count()) >= 1);
  await C.locator('button', { hasText: 'زور المكتب' }).first().click();
  await C.waitForTimeout(900);
  ok('العميل دخل المكتب', C.url().includes('#/office'));
  ok('لوحة صالة العملاء ظاهرة بمشاريعه', (await C.locator('.of-clpanel').count()) === 1 && (await C.locator('.of-clpanel .oc-m').count()) >= 1);
  ok('مدير الحساب معروض بلوحة العميل', (await C.locator('.of-clpanel .oc-am').count()) === 1);
  await C.locator('.of-flr').nth(1).click();
  await C.waitForTimeout(600);
  ok('العميل مقفول على الطابق ١', (await C.locator('.of-flr.on').first().textContent()).includes('١'));
  await C.locator('.office-room', { hasText: 'التصميم' }).click();
  await C.waitForTimeout(600);
  ok('غرف الفريق مقفولة على العميل', C.url().includes('#/office'));
  await C.locator('.of-clpanel button', { hasText: 'دعوة لاجتماع' }).click();
  await C.waitForTimeout(700);
  ok('زر دعوة لاجتماع ودّاه للاجتماعات', C.url().includes('#/meetings'));

  ok('صفر أخطاء console', errs.length === 0);
  if (errs.length) console.log('ERRORS:\n' + errs.slice(0, 8).join('\n'));

  await b.close();
  const pass = R.filter(Boolean).length;
  console.log(`\nV3-3 Builder/Floors/Lounge: ${pass}/${R.length}`);
  process.exit(pass === R.length ? 0 : 1);
})();
