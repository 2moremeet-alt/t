/* MEEM V2-9 E2E — الرسائل المباشرة + السايدبار + البروفايل (تغيير الباسورد) */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  async function login(email) {
    const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errs.push(email + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(email + ': ' + m.text()); });
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    await p.fill('input[type=email]', email);
    await p.click('.login-card .btn.primary');
    await p.waitForSelector('.sidebar .nav-item');
    return p;
  }
  const token = async (email) => (await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: '123456' }) })).json()).token;

  /* ---- 1) DM من المكتب: كليك على أفاتار الزميل ---- */
  const d = await login('designer@meem.studio');
  const c = await login('content@meem.studio');
  await d.waitForTimeout(1500);
  const avs = d.locator('.of-av.clickable');
  ok('أفاتار الزميل قابل للكليك في المكتب', (await avs.count()) >= 1);
  await avs.first().click();
  await d.waitForTimeout(800);
  ok('كليك الأفاتار فتح الشات', d.url().includes('#/chat'));
  ok('غرفة DM مفعلة', (await d.locator('.chat-room.active', { hasText: '💬' }).count()) === 1);

  /* ---- 2) إرسال رسالة — تصل لحظيًا للطرف التاني ---- */
  const uniq = 'بوست' + Date.now();
  await d.fill('.chat-input', 'أهلا يا أحمد، محتاجين ' + uniq + ' النهاردة 🎨');
  await d.click('.chat-compose .btn.primary');
  await d.waitForTimeout(800);
  ok('الرسالة ظهرت عندي', (await d.locator('.chat-msg.mine', { hasText: uniq }).count()) === 1);
  await c.goto(BASE + '/#/chat', { waitUntil: 'networkidle' });
  await c.waitForSelector('.chat-rooms');
  const dmRoom = c.locator('.chat-room', { hasText: 'ميم' });
  ok('الـ DM ظهر في قائمة الطرف التاني', (await dmRoom.count()) >= 1);
  await dmRoom.first().click();
  await c.waitForTimeout(500);
  ok('الرسالة وصلت الطرف التاني', (await c.locator('.chat-msg', { hasText: uniq }).count()) === 1);

  /* ---- 3) السايدبار فيه قسم رسائل مباشرة ---- */
  ok('DM في سايدبار المصمم', (await d.locator('.side-dms .dm-item').count()) >= 1);
  await d.locator('.side-dms .dm-item').first().click();
  await d.waitForTimeout(600);
  ok('كليك DM السايدبار فتح المحادثة', d.url().includes('#/chat'));

  /* ---- 4) خصوصية server-side: طرف تالت ما يشوفش الـ DM ---- */
  const vTok = await token('voice@meem.studio');
  const vState = await (await fetch(BASE + '/api/state', { headers: { Authorization: 'Bearer ' + vTok } })).json();
  const leaked = (vState.data.chats || []).filter((m) => String(m.room).startsWith('dm:'));
  ok('voice ما شايفش رسائل DM مش بتاعته (' + leaked.length + ')', leaked.length === 0);
  const dmRoomKey = 'dm:usr_content:usr_design';
  const deny = await fetch(BASE + '/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + vTok }, body: JSON.stringify({ room: dmRoomKey, text: 'تدخل' }) });
  ok('السيرفر رفض كتابة voice في DM غيره (403)', deny.status === 403);

  /* ---- 5) زر «رسالة مباشرة جديدة» ---- */
  await d.goto(BASE + '/#/chat', { waitUntil: 'networkidle' });
  await d.waitForSelector('.chat-new');
  await d.click('.chat-new');
  await d.waitForSelector('.dm-pick');
  const picks = await d.locator('.dm-pick').count();
  ok('مودال DM جديد فيه الزملاء (' + picks + ')', picks >= 4);
  await d.locator('.dm-pick', { hasText: 'نورهان' }).first().click();
  await d.waitForTimeout(500);
  ok('اختيار زميلة فتح DM جديد', (await d.locator('.chat-room.active', { hasText: 'نورهان' }).count()) === 1);

  /* ---- 6) البروفايل: تغيير كلمة المرور ---- */
  await d.locator('.user-chip').click();
  await d.waitForSelector('.modal');
  ok('مودال البروفايل فتح (معلومات + باسورد)', (await d.locator('.modal input[type=password]').count()) === 3);
  const ins = d.locator('.modal input[type=password]');
  await ins.nth(0).fill('غلط123');
  await ins.nth(1).fill('abc12345');
  await ins.nth(2).fill('abc12345');
  await d.locator('.modal button', { hasText: 'حفظ' }).click();
  await d.waitForTimeout(800);
  ok('الباسورد الغلط اترفض (المودال لسه مفتوح)', (await d.locator('.modal').count()) === 1);
  await ins.nth(0).fill('123456');
  await d.locator('.modal button', { hasText: 'حفظ' }).click();
  await d.waitForTimeout(900);
  ok('التغيير الصحيح نجح (المودال اتقفل)', (await d.locator('.modal').count()) === 0);
  const newLogin = await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'designer@meem.studio', password: 'abc12345' }) })).json();
  ok('اللوجين بالباسورد الجديد شغال', newLogin.ok === true);
  // نرجعها زي ما كانت عشان باقي الاختبارات
  const dTok2 = newLogin.token;
  const back = await fetch(BASE + '/api/password', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + dTok2 }, body: JSON.stringify({ current: 'abc12345', next: '123456' }) });
  ok('رجّعنا الباسورد الأصلي للاختبارات', (await back.json()).ok === true);

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
