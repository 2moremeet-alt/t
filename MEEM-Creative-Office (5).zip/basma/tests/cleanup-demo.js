/* تنظيف بيانات الاختبارات من db — يبقي البذرة + تصميم الديمو */
const BASE = 'http://localhost:3000';
async function api(path, token, body) {
  const res = await fetch(BASE + '/api' + path, {
    method: body ? 'POST' : 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  return res.json();
}
const SEED_TASK_TITLES = new Set([
  'سكربت فيديو 30 ثانية', '10 كابشنات إنستجرام', 'نصوص الصفحة الرئيسية',
  'تسجيل 30 ثانية — صحة', 'تعليق فيديو رمضان', 'بوست رئيسي — عرض الإفطار',
  'ستوري — عد تنازلي', 'كاروسيل 5 شرائح — خدمات نايل تك', 'غلاف فيسبوك + لينكدإن',
  'فلاير A5 — منتجع البحاري', 'منيو رمضان — A4 مطوي', 'كروت شخصية — فريق صحة',
  'تحديث شعار نايل تك', 'موشن 15 ثانية — بوست رمضان', 'تغليف هدايا المنتجع',
  'تسليم البروشر + اعتماد العميل', 'جدولة نشر شهر نايل تك',
  'صفحة الهبوط — UI', 'API نماذج التواصل', 'ربط الدومين و HTTPS',
]);
(async () => {
  const adm = await api('/login', null, { email: 'admin@meem.studio', password: '123456' });
  const T = adm.token;
  const st = await api('/state', T);
  const d = st.data;
  let n = 0;
  const del = async (col, id) => { await api('/mutate', T, { collection: col, op: 'delete', id }); n++; };

  for (const x of d.designs) if (x.id !== 'des_efb1ada037ce') await del('designs', x.id);
  // V2-10: مرفقات المهام التجريبية
  for (const x of d.tasks || []) if ((x.files || []).length) { await api('/mutate', T, { collection: 'tasks', op: 'upsert', doc: { id: x.id, files: [] } }); n++; }
  const SEED_CONTENT = ['10 كابشنات — حملة إفطار البحري', 'سكربت فيديو 30 ثانية — نايل تك', 'مقال SEO — أفضل 5 وجهات في الساحل'];
  for (const x of d.contents || []) if (!SEED_CONTENT.includes(x.title)) await del('contents', x.id);
  for (const x of d.voices || []) await del('voices', x.id);
  // إعادة تصميم الديمو لحالته الشرعية (اعتمده العميل) — عشان ترتيب الجاليري يفضل ثابت
  await api('/mutate', T, {
    collection: 'designs', op: 'upsert',
    doc: {
      id: 'des_efb1ada037ce',
      status: 'client_approved',
      review: null,
      comments: [],
      share: null,
      client: { name: 'زهرة عبدالله', decision: 'approve', note: 'التصميم عجبنا جدًا — شكرًا!', at: new Date().toISOString() },
    },
  });
  for (const x of d.projects) if (!/^prj_\d+$/.test(x.id)) await del('projects', x.id);
  for (const x of d.requests) if (!['req_1', 'req_2'].includes(x.id)) await del('requests', x.id);
  for (const x of d.deliveries) if (!/^dlv_\d+$/.test(x.id)) await del('deliveries', x.id);
  for (const x of d.tasks) if (!SEED_TASK_TITLES.has(x.title)) await del('tasks', x.id);

  // Phase 5: فيديوهات/باجات/لقطات الاختبار
  for (const x of d.videos || []) await del('videos', x.id);
  const SEED_BUGS = ['صفحة الهبوط بتكسر على موبايل iOS', 'فورم التواصل مش بيبعت إيميل', 'بطء تحميل صور المعرض'];
  for (const x of d.bugs || []) if (!SEED_BUGS.includes(x.title)) await del('bugs', x.id);
  for (const x of d.shoots || []) {
    const shots = (x.shots || []).filter((sh) => !(sh.desc || '').includes('E2E'));
    if (shots.length !== (x.shots || []).length || (x.photos || []).length) {
      await api('/mutate', T, { collection: 'shoots', op: 'upsert', doc: { id: x.id, shots, photos: [] } });
      n++;
    }
  }

  // Phase 6: بيانات اختبارات المالية/الوقت/التسويق/المعرفة
  const SEED_NUMS = ['INV-2026-001', 'INV-2026-002', 'INV-2026-003', 'INV-2026-004'];
  for (const x of d.invoices || []) if (!SEED_NUMS.includes(x.num)) await del('invoices', x.id);
  const keptInv = new Set(SEED_NUMS);
  for (const x of d.payments || []) {
    const inv = (d.invoices || []).find((v) => v.id === x.invoiceId);
    if (!inv || !keptInv.has(inv.num)) await del('payments', x.id);
  }
  for (const x of d.expenses || []) if (/E2E|DEBUG/.test(x.title)) await del('expenses', x.id);
  for (const x of d.timeentries || []) if (x.note === 'تايمر' || x.taskTitle === 'اختبار' || (x.start || '').endsWith('T09:00:00.000Z')) await del('timeentries', x.id);
  for (const x of d.campaigns || []) {
    if (/اختبار/.test(x.title)) { await del('campaigns', x.id); continue; }
    if (x.title === 'إعلانات العيد — فيسبوك' && +x.revenue !== 38000) { await api('/mutate', T, { collection: 'campaigns', op: 'upsert', doc: { id: x.id, revenue: 38000 } }); n++; }
  }
  for (const x of d.prompts || []) if (/اختبار/.test(x.title)) await del('prompts', x.id);
  for (const x of d.articles || []) if (/اختبار/.test(x.title)) await del('articles', x.id);

  // Phase 7: رسائل الشات التجريبية + أصول الاختبار
  /* V2-9: رسائل DM مش بتظهر في state admin (خصوصية) — نعددها من الملف مباشرة */
  const fs = require('fs'); const path = require('path');
  const fileChats = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'data', 'db.json'), 'utf8')).chats || [];
  for (const x of fileChats) if (/رسالة لحظية|سؤال العميل|رسالة اختبار|محاولة|أهلاً فريق ميم|سؤال عن حملة|سؤال نايل تك/.test(x.text) || /^dm:/.test(x.room || '')) await del('chats', x.id);
  for (const x of d.assets || []) if (x.name === 'p5img.png') await del('assets', x.id);

  // V2-5: جلسات التصوير المزرعة → لقطاتها الأصلية فقط وغير متعلمة
  for (const x of d.shoots || []) {
    if (/منيو|نايل تك/.test(x.title || '')) {
      const shots = (x.shots || []).filter((sh) => /^sh_\d+$/.test(sh.id)).map((sh) => Object.assign({}, sh, { done: false }));
      await api('/mutate', T, { collection: 'shoots', op: 'upsert', doc: { id: x.id, shots, photos: [] } });
    }
  }

  // V2-3: إرجاع الأدوات للإخفاء الافتراضي (كتابة tools للمالك فقط)
  const ol = await api('/login', null, { email: 'owner@meem.studio', password: '123456' });
  await api('/mutate', ol.token, { collection: 'settings', op: 'upsert', doc: { id: 'tools', video: false, ai: false } });

  const st2 = await api('/state', T);
  console.log(`حُذف ${n} عنصر | designs=${st2.data.designs.length} projects=${st2.data.projects.length} requests=${st2.data.requests.length} deliveries=${st2.data.deliveries.length} tasks=${st2.data.tasks.length}`);
})();
