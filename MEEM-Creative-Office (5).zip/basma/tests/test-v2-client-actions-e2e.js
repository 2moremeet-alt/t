/* MEEM V2-12 E2E — صفحة العميل التفاعلية: معاينة مائية · اعتماد بتأكيد · طلب تعديل بمرفقات · تسجيل */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const fs = require('fs');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const loginApi = async (email) => (await (await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: '123456' }) })).json()).token;
  const aTok = await loginApi('admin@meem.studio');
  const jpost = async (path, body) => (await fetch(BASE + '/api' + path, { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + aTok }, body: JSON.stringify(body) })).json();

  /* ---- تجهيز: تصميم بحالة client على prj_1 + لينك ---- */
  const testDesign = { id: 'des_v12test', projectId: 'prj_1', clientId: 'cli_1', title: 'بوستر اختبار V12', status: 'client', type: 'سوشيال', url: '' };
  await jpost('/mutate', { collection: 'designs', op: 'upsert', doc: testDesign });
  const link = await jpost('/client-link', { projectId: 'prj_1', regenerate: true });
  const token = link.token;

  /* ---- 1) البوابة: أزرار الاعتماد/التعديل ظاهرة ---- */
  const ctx = await b.newContext({ viewport: { width: 1200, height: 900 } });
  const g = await ctx.newPage();
  g.on('pageerror', (e) => errs.push(e.message));
  g.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()); });
  await g.goto(BASE + '/client/project/' + token, { waitUntil: 'networkidle' });
  await g.waitForSelector('.tp-card');
  const card = g.locator('.tp-card', { hasText: 'بوستر اختبار V12' });
  ok('كارت التصميم ظاهر بأزراره', (await card.locator('button', { hasText: 'اعتماد' }).count()) === 1 && (await card.locator('button', { hasText: 'تعديل' }).count()) === 1);
  ok('علامة مائية على المصغرة', (await card.locator('.tp-wm-mini').count()) === 1);

  /* ---- 2) المعاينة: lightbox بعلامة مائية ---- */
  await card.locator('button', { hasText: 'معاينة' }).click();
  await g.waitForSelector('.tp-preview');
  ok('المعاينة فيها 9 علامات مائية', (await g.locator('.tp-wm-layer .tp-wm').count()) === 9);
  await g.keyboard.press('Escape');
  await g.waitForTimeout(400);

  /* ---- 3) طلب تعديل: ملاحظات إجبارية + مرفق ---- */
  await card.locator('button', { hasText: 'تعديل' }).click();
  await g.waitForSelector('.modal');
  await g.locator('.modal button', { hasText: 'إرسال الطلب' }).click();
  await g.waitForTimeout(500);
  ok('ملاحظات فاضية → الطلب اترفض (المودال مفتوح)', (await g.locator('.modal').count()) === 1);
  fs.writeFileSync('/tmp/rev-ref.png', Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c626001000000ffff03000006000557bfabd40000000049454e44ae426082', 'hex'));
  await g.locator('.modal button', { hasText: 'إرفاق' }).click();
  await g.setInputFiles('.modal input[type=file]', '/tmp/rev-ref.png');
  await g.waitForTimeout(1200);
  ok('المرفق اترفع واتعرض', (await g.locator('.modal', { hasText: 'rev-ref.png' }).count()) === 1);
  await g.locator('.modal textarea').fill('اللوجو يصغر شوية والخلفية أغمق');
  await g.locator('.modal button', { hasText: 'إرسال الطلب' }).click();
  await g.waitForTimeout(1200);
  let st = await (await (await fetch(BASE + '/api/state', { headers: { Authorization: 'Bearer ' + aTok } })).json()).data;
  let d12 = st.designs.find((x) => x.id === 'des_v12test');
  ok('الحالة بقت changes server-side', d12.status === 'changes');
  ok('الملاحظات محفوظة', d12.client && d12.client.note.includes('أغمق'));
  ok('المرفق محفوظ (url بتاع uploads)', (d12.client.files || []).length === 1 && d12.client.files[0].url.startsWith('/uploads/'));
  const upRes = await fetch(BASE + d12.client.files[0].url);
  ok('رابط المرفق شغال (200)', upRes.status === 200);
  ok('اتسجل في النشاط', st.activity.some((a) => (a.text || '').includes('طلب تعديل على')));

  /* ---- 4) الاعتماد: بتأكيد ---- */
  await jpost('/mutate', { collection: 'designs', op: 'upsert', doc: Object.assign({}, testDesign, { status: 'client', client: null }) });
  await g.goto(BASE + '/client/project/' + token, { waitUntil: 'networkidle' });
  await g.waitForSelector('.tp-card');
  const card2 = g.locator('.tp-card', { hasText: 'بوستر اختبار V12' });
  await card2.locator('button', { hasText: 'اعتماد' }).click();
  await g.waitForSelector('.modal', { hasText: 'اعتماد نهائي' });
  ok('مودال التأكيد ظهر قبل الاعتماد', true);
  await g.locator('.modal button', { hasText: 'أيوة، اعتماد' }).click();
  await g.waitForTimeout(1200);
  st = await (await (await fetch(BASE + '/api/state', { headers: { Authorization: 'Bearer ' + aTok } })).json()).data;
  d12 = st.designs.find((x) => x.id === 'des_v12test');
  ok('الحالة بقت client_approved', d12.status === 'client_approved');
  ok('الاعتماد اتسجل في النشاط', st.activity.some((a) => (a.text || '').includes('اعتمد')));

  /* ---- 5) أمان: توكن غلط ما يقررش ---- */
  const bad = await fetch(BASE + '/api/tportal/' + 'e'.repeat(48) + '/decision', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ designId: 'des_v12test', decision: 'approve' }) });
  ok('توكن غلط = 404 على القرار', bad.status === 404);
  await jpost('/mutate', { collection: 'designs', op: 'upsert', doc: { id: 'des_v12other', projectId: 'prj_5', clientId: 'cli_nile', title: 'تصميم مشروع تاني', status: 'client', type: 'سوشيال', url: '' } });
  const cross = await fetch(BASE + '/api/tportal/' + token + '/decision', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ designId: 'des_v12other', decision: 'approve' }) });
  ok('تصميم من مشروع تاني مرفوض (404)', cross.status === 404);
  await jpost('/mutate', { collection: 'designs', op: 'delete', id: 'des_v12other' });

  /* ---- تنظيف ---- */
  await jpost('/mutate', { collection: 'designs', op: 'delete', id: 'des_v12test' });

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
