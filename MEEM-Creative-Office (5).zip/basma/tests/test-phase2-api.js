/* Phase 2 — اختبار دورة حياة التصميم على مستوى API */
const B = 'http://localhost:3000';
let pass = 0, fail = 0;
const ok = (name, cond, extra = '') => {
  if (cond) { pass++; console.log('  PASS', name); }
  else { fail++; console.log('  FAIL', name, extra); }
};

async function j(path, { method = 'GET', body, token } = {}) {
  const res = await fetch(B + path, {
    method,
    headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  let json = null; try { json = await res.json(); } catch (e) {}
  return { status: res.status, json };
}

(async () => {
  // دخول
  const des = await j('/api/login', { method: 'POST', body: { email: 'designer@meem.studio', password: '123456' } });
  const adm = await j('/api/login', { method: 'POST', body: { email: 'admin@meem.studio', password: '123456' } });
  ok('login designer+admin', des.json?.ok && adm.json?.ok);
  const dT = des.json.token, aT = adm.json.token;

  // تصميم جديد
  const page = { w: 1080, h: 1080, bg: { type: 'color', color: '#7c5cff' }, layers: [{ id: 'ly1', type: 'text', text: 'مرحبا', x: 100, y: 100, w: 400, h: 100, fontSize: 64 }] };
  const created = await j('/api/mutate', { method: 'POST', token: dT, body: { collection: 'designs', doc: { title: 'تصميم اختبار Phase2', w: 1080, h: 1080, pages: [page], layers: page.layers, thumb: '', status: 'progress', owner: des.json.user.id } } });
  const id = created.json?.doc?.id;
  ok('create design', !!id, JSON.stringify(created.json));
  ok('state payload stripped (no pages/layers)', created.json.doc.pages === undefined && created.json.doc.layers === undefined && created.json.doc.layerCount === 1);

  // submit
  const sub = await j(`/api/design/${id}/submit`, { method: 'POST', token: dT, body: { note: 'جاهز للمراجعة' } });
  ok('submit → status review', sub.json?.design?.status === 'review');
  ok('submit → version V1', sub.json?.version?.v === 1);

  // تعليق مثبّت
  const cm = await j(`/api/design/${id}/comment`, { method: 'POST', token: aT, body: { x: 0.42, y: 0.3, text: 'كبّر العنوان شوية' } });
  ok('pin comment', cm.json?.comments?.length === 1 && cm.json.comments[0].text === 'كبّر العنوان شوية');
  const pinId = cm.json.comments[0].id;

  // رد + resolve
  const rp = await j(`/api/design/${id}/comment`, { method: 'POST', token: dT, body: { id: pinId, op: 'reply', text: 'تمام هكبّره' } });
  ok('comment reply', rp.json?.comments?.[0]?.replies?.length === 1);
  const rs = await j(`/api/design/${id}/comment`, { method: 'POST', token: dT, body: { id: pinId, op: 'resolve' } });
  ok('comment resolve', rs.json?.comments?.[0]?.resolved === true);

  // قرار: طلب تعديل (بدون ملاحظات → 400)
  const bad = await j(`/api/design/${id}/decision`, { method: 'POST', token: aT, body: { decision: 'changes' } });
  ok('decision changes requires note (400)', bad.status === 400);
  const chg = await j(`/api/design/${id}/decision`, { method: 'POST', token: aT, body: { decision: 'changes', note: 'اللون غامق' } });
  ok('decision changes → status changes', chg.json?.design?.status === 'changes');

  // إعادة إرسال → V2 ثم اعتماد → V3
  const sub2 = await j(`/api/design/${id}/submit`, { method: 'POST', token: dT, body: {} });
  ok('resubmit → V2 + review', sub2.json?.version?.v === 2 && sub2.json?.design?.status === 'review');
  const ap = await j(`/api/design/${id}/decision`, { method: 'POST', token: aT, body: { decision: 'approve' } });
  ok('approve → status approved + V3', ap.json?.design?.status === 'approved' && ap.json?.version?.v === 3);

  // رابط العميل
  const sh = await j(`/api/design/${id}/share`, { method: 'POST', token: dT, body: {} });
  const token = sh.json?.token;
  ok('share token', !!token && sh.json.ok);
  ok('share → status client', (await j(`/api/design/${id}`, { token: dT })).json.design.status === 'client');
  const pub = await j(`/api/share/${token}`);
  ok('public share GET (no auth)', pub.status === 200 && pub.json?.watermark === true && Array.isArray(pub.json?.pages) && pub.json.pages[0].layers.length === 1);
  const pubBad = await j(`/api/share/wrongtoken`);
  ok('bad share token → 404', pubBad.status === 404);
  const clBad = await j(`/api/share/${token}/decision`, { method: 'POST', body: { name: 'عميل', decision: 'changes' } });
  ok('client changes requires note (400)', clBad.status === 400);
  const cl = await j(`/api/share/${token}/decision`, { method: 'POST', body: { name: 'أحمد', decision: 'approve', note: '' } });
  ok('client approve → client_approved', cl.json?.status === 'client_approved');

  // نسخ: عدد + استعادة
  const full = await j(`/api/design/${id}`, { token: dT });
  ok('versions saved (3)', (full.json.design.versions || []).length === 3);
  const v1 = full.json.design.versions[0];
  // عدّل الصفحة الحالية ثم استعد V1
  await j('/api/mutate', { method: 'POST', token: dT, body: { collection: 'designs', doc: { id, pages: [{ w: 1080, h: 1080, bg: { type: 'color', color: '#000' }, layers: [] }], layers: [] } } });
  const rest = await j(`/api/design/${id}/restore`, { method: 'POST', token: dT, body: { vid: v1.id } });
  ok('restore V1 → layers back', rest.json?.design?.pages?.[0]?.layers?.length === 1 && rest.json.design.pages[0].layers[0].text === 'مرحبا');

  // قالب فريق + إعدادات brand kit عبر mutate
  const tpl = await j('/api/mutate', { method: 'POST', token: dT, body: { collection: 'templates', doc: { name: 'قالب اختبار', cat: 'فريق MEEM', custom: true, pages: [page] } } });
  ok('save team template', !!tpl.json?.doc?.id);
  const st = await j('/api/state', { token: dT });
  ok('state includes templates+settings', Array.isArray(st.json?.data?.templates) && st.json.data.templates.length >= 1 && Array.isArray(st.json?.data?.settings));

  // revoke share
  const rv = await j(`/api/design/${id}/share`, { method: 'POST', token: dT, body: { off: true } });
  ok('revoke share', rv.json?.revoked === true);
  ok('revoked link → 404', (await j(`/api/share/${token}`)).status === 404);

  // تنظيف
  await j('/api/mutate', { method: 'POST', token: dT, body: { op: 'delete', collection: 'designs', id } });
  await j('/api/mutate', { method: 'POST', token: dT, body: { op: 'delete', collection: 'templates', id: tpl.json.doc.id } });

  console.log(`\nRESULT: ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
