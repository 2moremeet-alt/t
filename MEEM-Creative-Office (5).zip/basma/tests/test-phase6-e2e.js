/* MEEM — Phase 6 E2E: Finance + Time + Reports + Marketing + KB + GitHub */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 1600, height: 950 } });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(e.message));
  p.on('console', (m) => { if (m.type() === 'error') errs.push(m.text()); });
  await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', 'admin@meem.studio');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.sidebar .nav-item');

  /* ============ 1) المالية ============ */
  await p.goto(BASE + '/#/finance', { waitUntil: 'networkidle' });
  await p.waitForSelector('.kpis .kpi', { timeout: 8000 });
  ok('KPIs المالية (5)', (await p.locator('.kpis .kpi').count()) === 5);
  ok('الفواتير seeded', (await p.locator('.view .card:has-text("INV-2026")').count()) >= 4);

  // فاتورة جديدة
  await p.click('.page-head .btn.primary');
  await p.waitForSelector('.modal:has-text("فاتورة جديدة")', { timeout: 5000 });
  await p.fill('.modal input[value^="INV-"]', 'INV-E2E-1');
  await p.fill('.modal .grid2 input.input >> nth=1', 'فاتورة E2E');
  await p.click('.modal button:has-text("بند")');
  await p.waitForSelector('.fin-item');
  await p.fill('.fin-item input[placeholder="وصف البند"]', 'بند تجريبي');
  await p.fill('.fin-item input[type=number] >> nth=0', '3');
  await p.fill('.fin-item input[type=number] >> nth=1', '1000');
  ok('الإجمالي الحي (3×1000+14% = 3,420)', (await p.textContent('.fin-total')).includes('3,420'));
  await p.click('.modal button:has-text("حفظ")');
  await p.waitForSelector('.view .card:has-text("INV-E2E-1")', { timeout: 8000 });
  ok('الفاتورة ظهرت في اللستة', true);

  // دفعة كاملة → مدفوعة
  await p.click('.view .card:has-text("INV-E2E-1") button:has-text("دفعة")');
  await p.waitForSelector('.modal:has-text("تسجيل دفعة")', { timeout: 5000 });
  await p.click('.modal button:has-text("سجل الدفعة")');
  await p.waitForSelector('.view .card:has-text("INV-E2E-1") .badge:has-text("مدفوعة")', { timeout: 8000 });
  ok('دفعة كاملة → الحالة «مدفوعة»', true);

  // مصروف
  await p.click('.tabs button:has-text("المصروفات")');
  const expBefore = await p.locator('.fin-table .fin-tr').count();
  await p.click('button:has-text("مصروف جديد")');
  await p.waitForSelector('.modal:has-text("مصروف جديد")', { timeout: 5000 });
  await p.fill('.modal .field input.input >> nth=0', 'مصروف E2E');
  await p.fill('.modal input[type=number]', '250');
  await p.click('.modal button:has-text("حفظ")');
  await p.waitForFunction((n) => document.querySelectorAll('.fin-table .fin-tr').length > n, expBefore, { timeout: 8000 });
  ok('مصروف اتسجل في الجدول', true);

  /* ============ 2) تتبع الوقت ============ */
  await p.goto(BASE + '/#/time?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.tt-timer', { timeout: 8000 });
  const tRowsBefore = await p.locator('.fin-table .fin-tr').count();
  await p.click('.tt-timer .btn.ok');
  await p.waitForTimeout(1600);
  const clockTxt = await p.textContent('.tt-clock');
  ok('التايمر بيعدّ', clockTxt !== '00:00:00');
  await p.click('.tt-timer .btn.danger');
  await p.waitForFunction((n) => document.querySelectorAll('.fin-table .fin-tr').length > n, tRowsBefore, { timeout: 8000 });
  ok('التايمر اتحفظ كإدخال', true);

  const rowsBefore = await p.locator('.fin-table .fin-tr').count();
  await p.click('.page-head .btn:has-text("إدخال يدوي")');
  await p.waitForSelector('.modal:has-text("إدخال ساعات")', { timeout: 5000 });
  await p.fill('.modal input[type=number]', '90');
  await p.click('.modal button:has-text("حفظ")');
  await p.waitForFunction((n) => document.querySelectorAll('.fin-table .fin-tr').length > n, rowsBefore, { timeout: 8000 });
  ok('إدخال يدوي 90د اتضاف', true);

  /* ============ 3) التقارير ============ */
  await p.goto(BASE + '/#/reports?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.kpis .kpi', { timeout: 8000 });
  ok('KPIs التقرير (6)', (await p.locator('.kpis .kpi').count()) === 6);
  const collected = await p.locator('.kpis .kpi >> nth=4').innerText();
  ok('التحصيل > 0 (بذرة الشهر)', !/\b0 ج\.م/.test(collected));
  ok('جدول أداء الفريق', (await p.locator('.rep-grid .fin-tr').count()) > 1);
  ok('رسوم SVG (2)', (await p.locator('.rep-chart').count()) === 2);
  await p.fill('input[type=month]', '2026-08');
  await p.dispatchEvent('input[type=month]', 'change');
  await p.waitForTimeout(500);
  const collectedAug = await p.locator('.kpis .kpi >> nth=4').innerText();
  ok('تغيير الشهر بيحدّث الأرقام', collectedAug !== collected);

  /* ============ 4) التسويق ============ */
  await p.goto(BASE + '/#/marketing?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.view .dcard', { timeout: 8000 });
  ok('حملات seeded (3)', (await p.locator('.view .dcard').count()) === 3);
  ok('ROI ظاهر على الكارت', await p.locator('.view .dcard .badge:has-text("ROI")').first().isVisible());
  const roiBefore = await p.locator('.kpis .kpi >> nth=5').innerText();
  await p.click('.view .dcard >> nth=0');
  await p.waitForSelector('.modal:has-text("إعلانات العيد")', { timeout: 5000 });
  const revInp = p.locator('.modal input[type=number] >> nth=4');
  await revInp.fill(String((+(await revInp.inputValue()) || 0) + 5000));
  await p.click('.modal button:has-text("حفظ")');
  await p.waitForTimeout(800);
  const roiAfter = await p.locator('.kpis .kpi >> nth=5').innerText();
  ok('تعديل الإيراد غيّر الـ ROI', roiAfter !== roiBefore);

  /* ============ 5) المعرفة ============ */
  await p.goto(BASE + '/#/kb?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.kb-card', { timeout: 8000 });
  const nPrompts = await p.locator('.kb-card').count();
  ok('برومبتات seeded (' + nPrompts + ')', nPrompts >= 6);
  await p.fill('.view input[placeholder*="دور في البرومبتات"]', 'كابشن');
  await p.waitForTimeout(400);
  const filtered = await p.locator('.kb-card').count();
  ok('البحث بيفلتر (' + filtered + ')', filtered >= 1 && filtered < nPrompts);
  await p.fill('.view input[placeholder*="دور في البرومبتات"]', '');
  await p.click('.tabs button:has-text("قاعدة المعرفة")');
  await p.waitForSelector('.view .card:has-text("دليل براند")', { timeout: 5000 });
  await p.click('.view .card:has-text("دليل براند")');
  await p.waitForSelector('.modal:has-text("دليل براند")', { timeout: 5000 });
  ok('المقال فتح في القارئ', (await p.locator('.modal textarea').inputValue()).includes('0E7490'));
  await p.click('.modal button:has-text("إغلاق")');

  /* ============ 6) GitHub ============ */
  await p.goto(BASE + '/#/projects/prj_5?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('a[href*="github"]', { timeout: 8000 });
  ok('رابط GitHub في صفحة المشروع', true);

  /* ============ أخطاء؟ ============ */
  const realErrs = errs.filter((e) => !/favicon|DevTools/i.test(e));
  ok('مفيش أخطاء JS', realErrs.length === 0);
  if (realErrs.length) console.log(realErrs.join('\n'));

  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.error('FATAL', e); process.exit(1); });
