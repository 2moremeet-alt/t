/* MEEM V2-E3 E2E — الهوية الختامية MEE M: أسود/أبيض/فضي/أزرق كهربائي + الكلمة العلامة */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push('pageerror: ' + e.message));
  p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()); });

  const vars = () => p.evaluate(() => {
    const cs = getComputedStyle(document.documentElement);
    return {
      brand: cs.getPropertyValue('--brand').trim(),
      bg: cs.getPropertyValue('--bg').trim(),
      text: cs.getPropertyValue('--text').trim(),
      text2: cs.getPropertyValue('--text-2').trim(),
      accent: cs.getPropertyValue('--accent').trim(),
    };
  });

  /* ---- 1) صفحة الدخول ---- */
  await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  ok('العنوان فيه MEE M', (await p.title()).includes('MEE M'));
  ok('لوجو الدخول حرف M', (await p.textContent('.login-logo')).trim() === 'M');
  const fav = await p.evaluate(() => document.querySelector('link[rel=icon]').href);
  ok('الـ favicon أزرق كهربائي', decodeURIComponent(fav).includes('0066ff'));
  let v = await vars();
  ok('--brand أزرق كهربائي (0,102,255)', v.brand === '#0066ff');
  ok('--bg أسود عميق', v.bg === '#08090d');
  ok('--text أبيض', v.text === '#eef1f6');
  ok('--text-2 فضي', v.text2 === '#a8b0c0');
  ok('--accent سماوي كهربائي', v.accent === '#22d3ee');
  const loginBg = await p.evaluate(() => getComputedStyle(document.querySelector('.login-wrap')).backgroundImage);
  ok('خلفية الدخول بلا بنفسجي', !loginBg.includes('124, 92, 255') && loginBg.includes('0, 102, 255'));
  const btnBg = await p.evaluate(() => getComputedStyle(document.querySelector('.login-card .btn.primary')).backgroundImage);
  ok('الزر الأساسي بتدرج أزرق كهربائي', btnBg.includes('0, 102, 255'));

  /* ---- 2) السايدبار والتوب بار ---- */
  await p.fill('input[type=email]', 'designer@meem.studio');
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.sidebar .nav-item', { timeout: 15000 });
  ok('لوجو السايدبار حرف M', (await p.textContent('.side-logo')).trim() === 'M');
  const sideTitle = await p.textContent('.side-title');
  ok('اسم البراند MEE M | Creative Office', sideTitle.includes('MEE M') && sideTitle.includes('Creative Office'));
  ok('document.title فيه MEE M', (await p.title()).includes('MEE M'));
  const sideBg = await p.evaluate(() => getComputedStyle(document.querySelector('.sidebar')).backgroundColor);
  ok('السايدبار خلفية داكنة جديدة', sideBg === 'rgb(12, 14, 20)' || sideBg === 'rgb(18, 20, 28)' || sideBg.startsWith('rgb(1'));

  /* ---- 3) MEE M Chat ---- */
  await p.goto(BASE + '/#/chat', { waitUntil: 'networkidle' });
  await p.waitForTimeout(900);
  const chatH1 = await p.textContent('h1');
  ok('هيدر الشات MEE M Chat', chatH1.includes('MEE M Chat'));
  ok('عنوان تبويب الشات MEE M', (await p.title()).includes('MEE M'));

  /* ---- 4) المحرر بالهوية الجديدة ---- */
  await p.goto(BASE + '/#/dashboard', { waitUntil: 'networkidle' });
  await p.locator('.desk-quick button', { hasText: 'تصميم جديد' }).click();
  await p.waitForSelector('.ed', { timeout: 10000 });
  await p.waitForTimeout(700);
  const menuBg = await p.evaluate(() => getComputedStyle(document.querySelector('.ed-menubar')).backgroundColor);
  ok('شريط قوائم المحرر أسود', menuBg === 'rgb(11, 14, 20)' || menuBg === 'rgb(8, 9, 13)' || menuBg.startsWith('rgb(1'));
  ok('أدوات الرسم لسه موجودة (رجعية)', await p.locator('.ed-tool[data-tool="brush"]').count() === 1);
  await p.evaluate(async () => { const { getEditorInstance } = await import('/js/editor/index.js'); getEditorInstance().close(); });

  /* ---- 5) تبديل اللغة — البراند لاتيني في اللغتين ---- */
  await p.goto(BASE + '/#/dashboard', { waitUntil: 'networkidle' });
  await p.locator('.topbar button[data-act="lang"]').click();
  await p.waitForTimeout(700);
  const sideTitleEn = await p.textContent('.side-title');
  ok('بالإنجليزي — البراند MEE M', sideTitleEn.includes('MEE M'));
  await p.locator('.topbar button[data-act="lang"]').click();
  await p.waitForTimeout(500);

  /* ---- 6) مفيش بنفسجي قديم في الـ tokens ---- */
  v = await vars();
  ok('مفيش بنفسجي في --brand', !v.brand.toLowerCase().includes('7c5cff'));

  ok('بدون أخطاء console', errs.length === 0);
  if (errs.length) console.log('ERRORS:\n' + errs.slice(0, 8).join('\n'));

  await b.close();
  const pass = R.filter(Boolean).length;
  console.log(`\nV2-E3 Identity: ${pass}/${R.length}`);
  process.exit(pass === R.length ? 0 : 1);
})();
