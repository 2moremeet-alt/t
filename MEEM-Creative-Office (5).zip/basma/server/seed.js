'use strict';
/**
 * بيانات تجريبية للمنصة — تُنفَّذ مرة واحدة لو قاعدة البيانات فاضية
 * node server/seed.js
 */
const store = require('./store');

const P = {
  new: 'new',
  progress: 'progress',
  review: 'review',
  client: 'client',
  revision: 'revision',
  delivered: 'delivered',
  done: 'done',
};

function days(n) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

function seed() {
  store.load();
  const db = store.db;
  if (db.users.length) return false;

  /* ------------------------------ الفريق ------------------------------ */
  const users = [
    { id: 'usr_admin', name: 'ميم عبدالله', nameEn: 'Meem Abdullah', email: 'admin@meem.studio', password: '123456', role: 'admin', title: 'المدير العام', titleEn: 'General Manager', phone: '+20 100 000 0001', avatarColor: '#f59e0b', initials: 'م' },
    { id: 'usr_design', name: 'ميم', nameEn: 'Meem', email: 'designer@meem.studio', password: '123456', role: 'designer', title: 'مصممة جرافيك أولى', titleEn: 'Senior Graphic Designer', phone: '+20 100 000 0002', avatarColor: '#7c5cff', initials: 'م' },
    { id: 'usr_design2', name: 'كريم فؤاد', nameEn: 'Karim Fouad', email: 'karim@meem.studio', password: '123456', role: 'designer', title: 'مصمم سوشيال ميديا', titleEn: 'Social Media Designer', phone: '+20 100 000 0008', avatarColor: '#06b6d4', initials: 'ك' },
    { id: 'usr_content', name: 'أحمد الشريف', nameEn: 'Ahmed Elsharif', email: 'content@meem.studio', password: '123456', role: 'content', title: 'كاتب محتوى إعلاني', titleEn: 'Copywriter', phone: '+20 100 000 0003', avatarColor: '#10b981', initials: 'أ' },
    { id: 'usr_voice', name: 'ليلى مراد', nameEn: 'Laila Morad', email: 'voice@meem.studio', password: '123456', role: 'voice', title: 'معلّقة صوتية', titleEn: 'Voice Over Artist', phone: '+20 100 000 0004', avatarColor: '#ec4899', initials: 'ل' },
    { id: 'usr_cs', name: 'نورهان سعيد', nameEn: 'Nourhan Saeed', email: 'cs@meem.studio', password: '123456', role: 'cs', title: 'مسؤولة خدمة العملاء والتسليمات', titleEn: 'Client Success & Delivery', phone: '+20 100 000 0005', avatarColor: '#ef4444', initials: 'ن' },
    { id: 'usr_dev', name: 'يوسف طارق', nameEn: 'Youssef Tarek', email: 'dev@meem.studio', password: '123456', role: 'dev', title: 'مطوّر Full-Stack', titleEn: 'Full-Stack Developer', phone: '+20 100 000 0006', avatarColor: '#3b82f6', initials: 'ي' },
  ];
  users.forEach((u) => store.createUser(u));

  /* ------------------------------ العملاء ------------------------------ */
  const clients = [
    { id: 'cli_zahra', name: 'مطاعم زهرة اللوتس', nameEn: 'Zahra Lotus Restaurants', contact: 'أ/ منى زكي', phone: '+20 111 222 3344', email: 'mona@zahralotus.eg', city: 'القاهرة', type: 'مطاعم', notes: 'يفضّلون التسليم مساءً، ومراجعة واحدة مجانية.' },
    { id: 'cli_nile', name: 'نايل تك للحلول الرقمية', nameEn: 'NileTech Digital', contact: 'م/ حسام', phone: '+20 122 333 4455', email: 'hossam@niletech.eg', city: 'الجيزة', type: 'تكنولوجيا', notes: 'عقد سنوي — 12 تصميم سوشيال شهريًا.' },
    { id: 'cli_bahary', name: 'منتجع البحاري', nameEn: 'Bahary Resort', contact: 'أ/ رانيا', phone: '+20 100 555 6677', email: 'ranya@bahary.eg', city: 'الساحل الشمالي', type: 'سياحة', notes: 'موسم صيف — مطبوعات + سوشيال.' },
    { id: 'cli_sahha', name: 'صيدليات صحة', nameEn: 'Seha Pharmacies', contact: 'د/ عمرو', phone: '+20 155 777 8899', email: 'amr@seha.eg', city: 'دمنهور', type: 'صحة', notes: 'يلتزمون بالهوية البصرية بدقة.' },
  ];
  clients.forEach((c) => store.upsert('clients', c));

  /* ------------------------------ المشاريع ------------------------------ */
  const projects = [
    { id: 'prj_1', clientId: 'cli_zahra', title: 'حملة رمضان — زهرة اللوتس', titleEn: 'Ramadan Campaign', dept: 'design', status: P.progress, priority: 'high', due: days(4), owner: 'usr_design', budget: 18000, tags: ['سوشيال', 'مطبوعات'] },
    { id: 'prj_2', clientId: 'cli_nile', title: 'حزمة سوشيال شهرية — نايل تك', titleEn: 'Monthly Social Pack', dept: 'design', status: P.review, priority: 'medium', due: days(2), owner: 'usr_design2', budget: 9000, tags: ['سوشيال'] },
    { id: 'prj_3', clientId: 'cli_bahary', title: 'بروشور موسم الصيف', titleEn: 'Summer Brochure', dept: 'design', status: P.client, priority: 'high', due: days(1), owner: 'usr_design', budget: 12000, tags: ['مطبوعات'] },
    { id: 'prj_4', clientId: 'cli_sahha', title: 'إعلان إذاعي — صيدليات صحة', titleEn: 'Radio Spot', dept: 'voice', status: P.progress, priority: 'medium', due: days(6), owner: 'usr_voice', budget: 6000, tags: ['فويس أوفر'] },
    { id: 'prj_5', clientId: 'cli_nile', title: 'موقع نايل تك — النسخة الجديدة', titleEn: 'Website Revamp', dept: 'dev', status: P.progress, priority: 'high', due: days(12), owner: 'usr_dev', budget: 45000, tags: ['برمجة'] },
    { id: 'prj_6', clientId: 'cli_zahra', title: 'محتوى منيو رمضان', titleEn: 'Ramadan Menu Copy', dept: 'content', status: P.progress, priority: 'medium', due: days(3), owner: 'usr_content', budget: 4500, tags: ['محتوى'] },
  ];
  projects.forEach((p) => store.upsert('projects', p));

  /* ------------------------------ المهام ------------------------------ */
  const tasks = [
    // محتوى
    { projectId: 'prj_6', dept: 'content', type: 'سكربت إعلان', title: 'سكربت فيديو 30 ثانية', desc: 'سكربت باللهجة المصرية، تركيز على وجبات الإفطار العائلي.', assignee: 'usr_content', status: P.progress, priority: 'high', due: days(3), words: 120, lang: 'ar' },
    { projectId: 'prj_1', dept: 'content', type: 'كابشن', title: '10 كابشنات إنستجرام', desc: 'كابشنات + هاشتاجات لحملة رمضان.', assignee: 'usr_content', status: P.review, priority: 'medium', due: days(2), words: 600, lang: 'ar' },
    { projectId: 'prj_5', dept: 'content', type: 'محتوى موقع', title: 'نصوص الصفحة الرئيسية', desc: 'Hero + 3 خدمات + قسم عن الشركة، عربي/إنجليزي.', assignee: 'usr_content', status: P.new, priority: 'medium', due: days(7), words: 450, lang: 'ar_en' },
    // فويس أوفر
    { projectId: 'prj_4', dept: 'voice', type: 'إعلان إذاعي', title: 'تسجيل 30 ثانية — صحة', desc: 'صوت نسائي دافئ، سرعة متوسطة، ماستر -14 LUFS.', assignee: 'usr_voice', status: P.progress, priority: 'high', due: days(6), durationSec: 30, lang: 'ar', takes: 2 },
    { projectId: 'prj_1', dept: 'voice', type: 'فيديو', title: 'تعليق فيديو رمضان', desc: 'تعليق على فيديو 45 ثانية، يحتاج نسختين (سريعة/هادئة).', assignee: 'usr_voice', status: P.new, priority: 'medium', due: days(5), durationSec: 45, lang: 'ar', takes: 0 },
    // تصميم — سوشيال
    { projectId: 'prj_1', dept: 'design', type: 'سوشيال', sub: 'post_1x1', title: 'بوست رئيسي — عرض الإفطار', desc: '1080×1080، بألوان الهوية، مع مساحة للنص العربي.', assignee: 'usr_design', status: P.progress, priority: 'high', due: days(3), sizes: ['1080x1080'] },
    { projectId: 'prj_1', dept: 'design', sub: 'story_9x16', dept_: 'design', type: 'سوشيال', title: 'ستوري — عد تنازلي', desc: '1080×1920، 3 إطارات للعد التنازلي.', assignee: 'usr_design', status: P.new, priority: 'medium', due: days(4), sizes: ['1080x1920'] },
    { projectId: 'prj_2', dept: 'design', type: 'سوشيال', sub: 'post_4x5', title: 'كاروسيل 5 شرائح — خدمات نايل تك', desc: '1080×1350، شريحة غلاف + 3 خدمات + CTA.', assignee: 'usr_design2', status: P.review, priority: 'high', due: days(2), sizes: ['1080x1350'] },
    { projectId: 'prj_2', dept: 'design', type: 'سوشيال', sub: 'cover_fb', title: 'غلاف فيسبوك + لينكدإن', desc: '820×312 و 1584×396 بنفس المفهوم.', assignee: 'usr_design2', status: P.progress, priority: 'low', due: days(5), sizes: ['820x312', '1584x396'] },
    // تصميم — مطبوعات
    { projectId: 'prj_3', dept: 'design', type: 'مطبوعات', sub: 'flyer_a5', title: 'فلاير A5 — منتجع البحاري', desc: 'A5 بوجهين، 300dpi، CMYK، مع 3mm bleed.', assignee: 'usr_design', status: P.client, priority: 'high', due: days(1), sizes: ['1748x2480'] },
    { projectId: 'prj_1', dept: 'design', type: 'مطبوعات', sub: 'menu', title: 'منيو رمضان — A4 مطوي', desc: 'منيو 4 صفحات مطوي، خط عربي واضح.', assignee: 'usr_design', status: P.progress, priority: 'high', due: days(4), sizes: ['2480x3508'] },
    { projectId: 'prj_4', dept: 'design', type: 'مطبوعات', sub: 'card', title: 'كروت شخصية — فريق صحة', desc: '90×50mm، وجهين، ورق كوتشي 350.', assignee: 'usr_design2', status: P.new, priority: 'low', due: days(9), sizes: ['1063x591'] },
    // تصميم — براندينج / موشن / تغليف
    { projectId: 'prj_2', dept: 'design', type: 'براندينج', sub: 'logo', title: 'تحديث شعار نايل تك', desc: '3 مقترحات + نسخة مونوكروم + دليل استخدام مصغّر.', assignee: 'usr_design', status: P.revision, priority: 'high', due: days(0), sizes: [] },
    { projectId: 'prj_1', dept: 'design', type: 'موشن', sub: 'motion', title: 'موشن 15 ثانية — بوست رمضان', desc: 'تحريك البوست الرئيسي مع مؤثرات ظهور النص.', assignee: 'usr_design2', status: P.new, priority: 'medium', due: days(6), sizes: ['1080x1080'] },
    { projectId: 'prj_3', dept: 'design', type: 'تغليف', sub: 'packaging', title: 'تغليف هدايا المنتجع', desc: 'ديلاكس + كيس، مع موك أب للعرض.', assignee: 'usr_design', status: P.new, priority: 'low', due: days(14), sizes: [] },
    // تسليمات
    { projectId: 'prj_3', dept: 'delivery', type: 'تسليم', title: 'تسليم البروشر + اعتماد العميل', desc: 'إرسال PDF للطباعة + JPG للعرض، وانتظار الاعتماد النهائي.', assignee: 'usr_cs', status: P.client, priority: 'high', due: days(1) },
    { projectId: 'prj_2', dept: 'delivery', type: 'متابعة', title: 'جدولة نشر شهر نايل تك', desc: 'رفع 12 تصميم على أداة الجدولة وتأكيد المواعيد.', assignee: 'usr_cs', status: P.new, priority: 'medium', due: days(3) },
    // برمجة
    { projectId: 'prj_5', dept: 'dev', type: 'واجهة', title: 'صفحة الهبوط — UI', desc: 'تحويل تصميم Figma لـ HTML/CSS متجاوب RTL.', assignee: 'usr_dev', status: P.progress, priority: 'high', due: days(5), points: 8 },
    { projectId: 'prj_5', dept: 'dev', type: 'باك-إند', title: 'API نماذج التواصل', desc: 'Endpoint لتخزين الطلبات + إرسال إيميل تلقائي.', assignee: 'usr_dev', status: P.new, priority: 'medium', due: days(8), points: 5 },
    { projectId: 'prj_5', dept: 'dev', type: 'نشر', title: 'ربط الدومين و HTTPS', desc: 'نقل الموقع للدومين الجديد + شهادة SSL.', assignee: 'usr_dev', status: P.new, priority: 'low', due: days(11), points: 3 },
  ];
  tasks.forEach((t, i) => {
    t.comments = i % 4 === 0
      ? [{ id: store.uid('cmt'), userId: 'usr_admin', text: 'خلينا نخلّص دي الأول، العميل مستني.', textEn: 'Let’s prioritise this one, the client is waiting.', at: new Date(Date.now() - 3600e3 * 5).toISOString() }]
      : [];
    t.files = [];
    store.upsert('tasks', t);
  });

  /* ------------------------------ التسليمات ------------------------------ */
  const deliveries = [
    { id: 'dlv_1', projectId: 'prj_3', clientId: 'cli_bahary', title: 'بروشور موسم الصيف', channel: 'email', status: 'waiting_client', items: ['brochure-summer-v2.pdf', 'brochure-summer-preview.jpg'], clientFeedback: '', revisions: 1, signoff: null, deliveredAt: new Date(Date.now() - 3600e3 * 20).toISOString() },
    { id: 'dlv_2', projectId: 'prj_2', clientId: 'cli_nile', title: 'حزمة سوشيال — الأسبوع 1', channel: 'drive', status: 'revision', items: ['post-1.png', 'post-2.png', 'carousel.pdf'], clientFeedback: 'اللوجو أكبر شوية، واللون الأزرق أغمق.', revisions: 1, signoff: null, deliveredAt: new Date(Date.now() - 3600e3 * 50).toISOString() },
    { id: 'dlv_3', projectId: 'prj_1', clientId: 'cli_zahra', title: 'بوستات رمضان — الدفعة الأولى', channel: 'whatsapp', status: 'approved', items: ['ramadan-post-1.png'], clientFeedback: 'تمام جدًا، شكراً!', revisions: 0, signoff: { by: 'أ/ منى زكي', at: new Date(Date.now() - 3600e3 * 8).toISOString() }, deliveredAt: new Date(Date.now() - 3600e3 * 30).toISOString() },
  ];
  deliveries.forEach((d) => store.upsert('deliveries', d));

  /* ------------------------------ الاجتماعات ------------------------------ */
  const meetings = [
    { id: 'mt_1', title: 'اجتماع الصباح اليومي', titleEn: 'Daily Standup', room: 'standup', host: 'usr_admin', scheduledAt: new Date(Date.now() + 3600e3).toISOString(), durationMin: 15, attendees: users.map((u) => u.id), notes: 'آخر تحديثات + المعطّلات.' },
    { id: 'mt_2', title: 'مراجعة تصاميم نايل تك', titleEn: 'NileTech Design Review', room: 'review-niletech', host: 'usr_design2', scheduledAt: new Date(Date.now() + 3600e3 * 5).toISOString(), durationMin: 45, attendees: ['usr_design2', 'usr_design', 'usr_cs', 'usr_admin'], notes: 'عرض الكاروسيل وملاحظات العميل.' },
    { id: 'mt_3', title: 'جلسة العميل — منتجع البحاري', titleEn: 'Client Session — Bahary', room: 'client-bahary', host: 'usr_cs', scheduledAt: new Date(Date.now() + 3600e3 * 26).toISOString(), durationMin: 60, attendees: ['usr_cs', 'usr_design', 'usr_admin'], notes: 'اعتماد البروشر النهائي.' },
  ];
  meetings.forEach((m) => store.upsert('meetings', m));

  store.log('usr_admin', 'تم تهيئة مساحة العمل', 'Workspace initialised');
  store.forceSave();
  return true;
}

/* ================= Phase 3 — ترحيل + حسابات عملاء + أتمتة ================= */
function phase3migrate() {
  const db = store.db;
  let changed = false;

  // 1) Brand Kit + Brand Voice لكل عميل
  (db.clients || []).forEach((c) => {
    if (!c.brandKit) {
      c.brandKit = {
        colors: ['#7c5cff', '#0d1017', '#ffffff', '#f59e0b'],
        fonts: ['Cairo', 'Tajawal'],
        logo: '',
      };
      changed = true;
    }
    if (!c.brandVoice) {
      c.brandVoice = {
        tone: 'ودود ومحترف',
        keywords: 'جودة، ثقة، عرض خاص',
        donts: 'بدون مبالغات أو وعود غير قابلة للتحقيق',
        sample: 'استمتع بتجربة تليق بك — عرضنا الجديد وصل.',
      };
      changed = true;
    }
  });

  // 2) حسابات دخول للعملاء (Client Portal)
  const clientAccounts = [
    { id: 'usr_client_zahra', name: 'منى زكي (زهرة اللوتس)', nameEn: 'Mona Zaki', email: 'client@meem.studio', password: '123456', role: 'client', clientId: 'cli_zahra', title: 'حساب العميل — زهرة اللوتس', avatarColor: '#f472b6', initials: 'م' },
    { id: 'usr_client_nile', name: 'حسام (نايل تك)', nameEn: 'Hossam', email: 'niletech@meem.studio', password: '123456', role: 'client', clientId: 'cli_nile', title: 'حساب العميل — نايل تك', avatarColor: '#38bdf8', initials: 'ح' },
  ];
  clientAccounts.forEach((u) => {
    const existing = db.users.find((x) => x.email === u.email);
    if (!existing) { store.createUser(u); changed = true; }
    else if (!existing.clientId) { existing.clientId = u.clientId; changed = true; }
  });

  // 3) قواعد الأتمتة الافتراضية
  if (!(db.settings || []).find((s) => s.id === 'automation')) {
    db.settings = db.settings || [];
    db.settings.push({
      id: 'automation',
      rules: [
        { id: 'rule_dlv', trigger: 'client_approved', action: 'create_delivery', on: true, label: 'العميل اعتمد → إنشاء تسليم جاهز' },
        { id: 'rule_task', trigger: 'client_approved', action: 'create_task_delivery', on: true, label: 'العميل اعتمد → مهمة متابعة لخدمة العملاء' },
        { id: 'rule_rev', trigger: 'client_changes', action: 'create_task_revision', on: true, label: 'العميل طلب تعديل → مهمة تعديل للمصمم' },
        { id: 'rule_log', trigger: 'design_submitted', action: 'log', on: true, label: 'إرسال تصميم للمراجعة → تسجيل في النشاط' },
      ],
    });
    changed = true;
  }

  // 4) ربط التصاميم اليتيمة بمشروع وعميل (عشان البورتال يشتغل)
  (db.designs || []).forEach((d) => {
    if (!d.clientId) {
      const prj = d.projectId ? (db.projects || []).find((p) => p.id === d.projectId) : null;
      if (prj) { d.clientId = prj.clientId; changed = true; }
      else if (!d.projectId) { d.projectId = 'prj_1'; d.clientId = 'cli_zahra'; changed = true; }
    }
  });

  // 5) طلبات تجريبية
  if (!(db.requests || []).length) {
    db.requests = [
      { id: 'req_1', title: 'بوستات عيد الميلاد السنوي', clientId: 'cli_zahra', channel: 'whatsapp', notes: '6 بوستات + ستوري، نفس روح حملة رمضان.', priority: 'high', status: 'new', assignee: '', createdAt: new Date().toISOString() },
      { id: 'req_2', title: 'لاندينج صفحة لمنتج جديد', clientId: 'cli_nile', channel: 'email', notes: 'صفحة واحدة بالعربي والإنجليزي.', priority: 'medium', status: 'assigned', assignee: 'usr_dev', createdAt: new Date(Date.now() - 86400000).toISOString() },
    ];
    changed = true;
  }

  if (changed) store.forceSave();
  return changed;
}

/* ------------------------------ Phase 4: Content + Voice ------------------------------ */
function phase4seed() {
  const db = store.db;
  let changed = false;

  // إعدادات الـ AI (من غير مفتاح = المولد المحلي + شارة Pro)
  if (!db.settings.find((s) => s.id === 'ai')) {
    store.upsert('settings', {
      id: 'ai', provider: 'openai', key: '', model: 'gpt-4o-mini',
      baseUrl: 'https://api.openai.com/v1',
    });
    changed = true;
  }

  // محتوى ديمو
  if (!(db.contents || []).length) {
    db.contents = [];
    const now = Date.now();
    const C = (o) => { store.upsert('contents', Object.assign({
      comments: [], versions: [], status: 'draft', lang: 'ar', owner: 'usr_content',
      createdAt: new Date(now - 86400e3).toISOString(),
    }, o)); };
    C({
      title: '10 كابشنات — حملة إفطار البحري', type: 'caption', projectId: 'prj_1', clientId: 'cli_bahary',
      status: 'approved', words: 180,
      body: '🌙 الفطار له طعم تاني لما العيلة بتجتمع عليه.\n\nمن قلب مطبخنا لبيتكم — وجبات إفطار متكاملة بتوصلكم سخنة قبل الأذان.\n\n✅ مكونات طازة كل يوم\n✅ توصيل مجاني للطلبات فوق 500 ج.م\n✅ خصم 15% على أول طلب\n\nاطلبوا دلوقتي واستمتعوا بتجربة تليق بلمة العيلة ❤️\n\n#إفطار_البحري #لمة_العيلة #رمضان_يجمعنا',
      review: { submittedAt: new Date(now - 90000e3).toISOString(), submittedBy: 'usr_content', submittedByName: ' سلمى', decision: 'approve', decidedByName: 'مدير', decidedAt: new Date(now - 80000e3).toISOString(), note: '' },
    });
    C({
      title: 'سكربت فيديو 30 ثانية — نايل تك', type: 'script30', projectId: 'prj_2', clientId: 'cli_nile',
      status: 'review', words: 95,
      body: '[المشهد 1 — 0:00-0:05]\nصوت هادي وواثق: «في عالم بيتحرك بسرعة… انت محتاج شريك يفهم التقنية.»\n\n[المشهد 2 — 0:05-0:18]\nلقطات سريعة للفريق وهو بيشتغل: «نايل تك — بنحول الأفكار لحلول رقمية متكاملة: مواقع، تطبيقات، وأنظمة إدارة.»\n\n[المشهد 3 — 0:18-0:26]\nشاشة الموبايل بتعرض المنتج: «جودة… ثقة… والتزام بالمواعيد.»\n\n[المشهد 4 — 0:26-0:30]\nاللوجو + CTA: «نايل تك — التكنولوجيا بأسلوب يفرق. تواصلوا معانا النهاردة.»',
      review: { submittedAt: new Date(now - 3600e3 * 3).toISOString(), submittedBy: 'usr_content', submittedByName: 'سلمى', note: 'جاهز للتسجيل' },
    });
    C({
      title: 'مقال SEO — أفضل 5 وجهات في الساحل', type: 'article', projectId: 'prj_3', clientId: 'cli_sahha',
      status: 'draft', words: 60,
      body: 'الساحل الشمالي مش بس بحر — ده تجربة كاملة. في المقال ده هنوديك في جولة على 5 وجهات لازم تزورها السنة دي…',
    });
    changed = true;
  }

  if (!db.voices) db.voices = [];

  if (changed) store.forceSave();
  return changed;
}

/* ------------------------------ Phase 5: Photography + Bugs ------------------------------ */
function phase5seed() {
  const db = store.db;
  let changed = false;

  if (!(db.shoots || []).length) {
    db.shoots = [];
    const now = Date.now();
    store.upsert('shoots', {
      title: 'جلسة تصوير منيو — مطعم البحري',
      clientId: 'cli_bahary', projectId: 'prj_1', photographer: 'usr_design',
      date: new Date(now + 86400e3 * 4).toISOString().slice(0, 10),
      location: 'فرع المعمورة', status: 'planned', photos: [], notes: 'إضاءة طبيعية وقت العصر، تركيز على الأطباق الرئيسية.',
      shots: [
        { id: 'sh_1', desc: 'طبق السمك المشوي الرئيسي', type: 'منتج', framing: 'Close-up', priority: 'high', done: false },
        { id: 'sh_2', desc: 'سفرة إفطار كاملة من فوق', type: 'أجواء', framing: 'Flat-lay', priority: 'high', done: false },
        { id: 'sh_3', desc: 'الشيف بيحضّر الطبق', type: 'كواليس', framing: 'Medium', priority: 'medium', done: false },
        { id: 'sh_4', desc: 'واجهة المطعم بالليل', type: 'مكاني', framing: 'Wide', priority: 'low', done: false },
      ],
      createdAt: new Date(now - 86400e3).toISOString(),
    });
    store.upsert('shoots', {
      title: 'تصوير فريق نايل تك',
      clientId: 'cli_nile', projectId: 'prj_2', photographer: 'usr_design2',
      date: new Date(now + 86400e3 * 9).toISOString().slice(0, 10),
      location: 'مكتب سموحة', status: 'planned', photos: [], notes: 'بورتريهات فردية + صورة جماعية.',
      shots: [
        { id: 'sh_5', desc: 'بورتريهات فردية (8 أفراد)', type: 'بورتريه', framing: 'Half-body', priority: 'high', done: false },
        { id: 'sh_6', desc: 'صورة جماعية قدام اللوجو', type: 'فريق', framing: 'Wide', priority: 'high', done: false },
      ],
      createdAt: new Date(now - 86400e3).toISOString(),
    });
    changed = true;
  }

  if (!(db.bugs || []).length) {
    db.bugs = [];
    const now = Date.now();
    const B = (o) => store.upsert('bugs', Object.assign({ comments: [], status: 'new', severity: 'medium', createdAt: new Date(now - 86400e3).toISOString() }, o));
    B({ title: 'صفحة الهبوط بتكسر على موبايل iOS', desc: 'القايمة بتختفي بعد السكرول لتحت على Safari.', severity: 'high', status: 'inprogress', reporter: 'usr_cs', assignee: 'usr_dev', projectId: 'prj_5' });
    B({ title: 'فورم التواصل مش بيبعت إيميل', desc: 'الرسالة بتتحفظ في الداتا بيز بس الإيميل مش بيوصل.', severity: 'critical', status: 'new', reporter: 'usr_content', assignee: 'usr_dev', projectId: 'prj_5' });
    B({ title: 'بطء تحميل صور المعرض', desc: 'الصور الأصلية بتتحمل بدل المصغرات.', severity: 'medium', status: 'testing', reporter: 'usr_dev', assignee: 'usr_dev', projectId: 'prj_5' });
    changed = true;
  }

  if (!db.videos) db.videos = [];

  if (changed) store.forceSave();
  return changed;
}


/* ---------------- Phase 6: Business + Management ---------------- */
function phase6seed() {
  const db = store.db;
  let changed = false;
  if (!(db.invoices || []).length) {
    db.invoices = []; db.payments = [];
    const now = Date.now();
    const iso = (off) => new Date(now + off * 86400e3).toISOString();
    const day = (off) => new Date(now + off * 86400e3).toISOString().slice(0, 10);
    const total = (inv) => {
      const sub = (inv.items || []).reduce((x, i) => x + (+i.qty || 0) * (+i.price || 0), 0);
      return Math.round(sub * (1 + (+inv.tax || 0) / 100) - (+inv.discount || 0));
    };
    const I = (o) => store.upsert('invoices', Object.assign({ items: [], tax: 14, discount: 0, notes: '', status: 'draft', createdAt: iso(0) }, o));

    const inv1 = I({
      num: 'INV-2026-001', clientId: 'cli_zahra', projectId: 'prj_1', title: 'الدفعة 1 — حملة رمضان', status: 'paid',
      issuedAt: day(-25), due: day(-10),
      items: [{ desc: 'هوية بصرية للحملة', qty: 1, price: 6000 }, { desc: 'بوست إنستجرام', qty: 10, price: 350 }, { desc: 'سكربت فيديو', qty: 2, price: 1200 }],
      notes: 'شكرًا لثقتكم 🌙',
    });
    store.upsert('payments', { invoiceId: inv1.id, amount: total(inv1), method: 'تحويل بنكي', at: iso(-12), by: 'usr_admin' });

    const inv2 = I({
      num: 'INV-2026-002', clientId: 'cli_nile', projectId: 'prj_5', title: 'موقع نايل تك — الدفعة الأولى', status: 'sent',
      issuedAt: day(-12), due: day(18),
      items: [{ desc: 'تصميم UI — صفحة الهبوط', qty: 1, price: 15000 }, { desc: 'تطوير Frontend', qty: 1, price: 10000 }],
    });
    store.upsert('payments', { invoiceId: inv2.id, amount: 10000, method: 'فودافون كاش', at: iso(-6), by: 'usr_admin' });

    I({
      num: 'INV-2026-003', clientId: 'cli_bahary', projectId: 'prj_3', title: 'بروشور موسم الصيف', status: 'sent',
      issuedAt: day(-40), due: day(-10),
      items: [{ desc: 'بروشور A4 مطوي — تصميم وطباعة', qty: 1, price: 9500 }],
    });

    I({
      num: 'INV-2026-004', clientId: 'cli_sahha', projectId: 'prj_4', title: 'إعلان إذاعي — صحة', status: 'draft',
      issuedAt: day(0), due: day(20),
      items: [{ desc: 'تعليق صوتي 30 ثانية', qty: 2, price: 1500 }, { desc: 'مكساج وماسترنج', qty: 1, price: 800 }],
    });
    changed = true;
  }

  if (!(db.expenses || []).length) {
    db.expenses = [];
    const now = Date.now();
    const iso = (off) => new Date(now + off * 86400e3).toISOString();
    const E = (o) => store.upsert('expenses', Object.assign({ category: 'أخرى', projectId: '', at: iso(0), by: 'usr_admin' }, o));
    E({ title: 'رواتب الفريق — سبتمبر', category: 'رواتب', amount: 22000, at: iso(-5) });
    E({ title: 'اشتراكات Adobe + Figma', category: 'أدوات', amount: 1200, at: iso(-8) });
    E({ title: 'حملة إعلانات — نايل تك', category: 'إعلانات', amount: 3500, at: iso(-3), projectId: 'prj_2' });
    E({ title: 'مايك تسجيل جديد', category: 'أجهزة', amount: 8500, at: iso(-15) });
    E({ title: 'مطوّر Freelance — API', category: 'أوتسورس', amount: 4000, at: iso(-6), projectId: 'prj_5' });
    changed = true;
  }

  if (!(db.timeentries || []).length) {
    db.timeentries = [];
    const now = Date.now();
    const T = (title) => (db.tasks || []).find((t) => t.title === title);
    const E = (title, userId, offDays, mins) => {
      const t = T(title);
      const start = new Date(now - offDays * 86400e3).toISOString();
      const end = new Date(now - offDays * 86400e3 + mins * 60000).toISOString();
      store.upsert('timeentries', { taskId: t ? t.id : '', taskTitle: title, projectId: t ? t.projectId : '', userId, start, end, mins, note: '' });
    };
    E('سكربت فيديو 30 ثانية', 'usr_content', 0.2, 95);
    E('10 كابشنات إنستجرام', 'usr_content', 1, 140);
    E('بوست رئيسي — عرض الإفطار', 'usr_design', 0.4, 120);
    E('غلاف فيسبوك + لينكدإن', 'usr_design2', 1.5, 75);
    E('صفحة الهبوط — UI', 'usr_design', 2, 180);
    E('API نماذج التواصل', 'usr_dev', 0.6, 150);
    E('ربط الدومين و HTTPS', 'usr_dev', 2.4, 60);
    E('تسجيل 30 ثانية — صحة', 'usr_voice', 1.2, 90);
    E('تعليق فيديو رمضان', 'usr_voice', 3, 110);
    E('تسليم البروشر + اعتماد العميل', 'usr_cs', 0.8, 45);
    changed = true;
  }

  if (!(db.campaigns || []).length) {
    db.campaigns = [];
    const now = Date.now();
    const day = (off) => new Date(now + off * 86400e3).toISOString().slice(0, 10);
    const C = (o) => store.upsert('campaigns', Object.assign({ status: 'active', notes: '', createdAt: new Date().toISOString() }, o));
    C({ title: 'إعلانات العيد — فيسبوك', channel: 'facebook', clientId: 'cli_zahra', budget: 8000, spent: 5200, leads: 64, conversions: 11, revenue: 38000, start: day(-20) });
    C({ title: 'نايل تك — جوجل سيرش', channel: 'google', clientId: 'cli_nile', budget: 12000, spent: 7800, leads: 38, conversions: 6, revenue: 21000, start: day(-14) });
    C({ title: 'صيف المنتجع — إنستجرام', channel: 'instagram', clientId: 'cli_bahary', budget: 5000, spent: 5000, leads: 92, conversions: 19, revenue: 46000, start: day(-45), status: 'done' });
    changed = true;
  }

  if (!(db.prompts || []).length) {
    db.prompts = [];
    const P = (o) => store.upsert('prompts', Object.assign({ tags: [], createdAt: new Date().toISOString() }, o));
    P({ title: 'كابشن إنستجرام — {{العميل}}', category: 'محتوى', body: 'اكتب كابشن إنستجرام بالعامية المصرية عن {{المنتج}} لـ {{العميل}}. النبرة ودودة، مع CTA واضح و3 هاشتاجات.' });
    P({ title: 'سكربت فيديو 30 ثانية', category: 'محتوى', body: 'اكتب سكربت فيديو 30 ثانية عن {{المنتج}}: هوك في أول 3 ثواني، 3 نقاط بيع، وخاتمة بدعوة للتفاعل. اللهجة: {{اللهجة}}.' });
    P({ title: 'بريف تصميم صفحة هبوط', category: 'تصميم', body: 'صمم صفحة هبوط لـ {{العميل}} — الهدف: {{الهدف}}. الألوان من البراند كيت، وموبايل فيرست، وCTA واحد واضح.' });
    P({ title: 'صوت إعلاني هادئ', category: 'صوت', body: 'سجّل تعليقًا صوتيًا لمدة {{المدة}} ثانية بنبرة {{النبرة}}، سرعة متوسطة، مع ترك فراغ نصف ثانية بين الجمل.' });
    P({ title: 'ستوري بورد ريل', category: 'فيديو', body: 'اعمل ستوري بورد لريل {{المدة}} ثانية عن {{المنتج}}: 6 لقطات، لكل لقطة وصف بصري + نص overlay + مدة.' });
    P({ title: 'حملة إعلانية — فيسبوك', category: 'تسويق', body: 'اقتراح 3 زوايا إعلانية لـ {{المنتج}} على فيسبوك: لكل زاوية هوك + نص إعلان + استهداف مقترح.' });
    changed = true;
  }

  if (!(db.articles || []).length) {
    db.articles = [];
    const A = (o) => store.upsert('articles', Object.assign({ tags: [], createdAt: new Date().toISOString(), author: 'usr_admin' }, o));
    A({ title: 'دليل براند — منتجع البحاري', category: 'براند', body: 'الألوان: أزرق بحري #0E7490 ورملي #E7D8B9. الخط: Cairo للعناوين. النبرة: راقية ودودة. ممنوع: الصور المزدحمة والموسيقى الصاخبة.' });
    A({ title: 'معايير تسليم الملفات', category: 'سير العمل', body: 'كل تسليم يشمل: ملف مفتوح (PSD/AI) + PDF مطبعة (CMYK, 3mm bleed) + نسخ ويب (JPG/PNG, sRGB). التسمية: project_item_vN.' });
    A({ title: 'Onboarding عميل جديد', category: 'سير العمل', body: '1) عقد + دفعة مقدمة 30% · 2) استبيان براند · 3) جلسة Kickoff (Meet) · 4) خطة أسبوعين · 5) إضافة العميل للبوابة.' });
    A({ title: 'نبرة المحتوى — صيدليات صحة', category: 'براند', body: 'نبرة طبية مبسطة، ممنوع الوعود العلاجية القاطعة، كل ادعاء طبي بمصدر. الكلمات المفضلة: صحتك، بأمان، استشر.' });
    changed = true;
  }

  // GitHub links على مشاريع الديف
  const prj5 = (db.projects || []).find((p) => p.id === 'prj_5');
  if (prj5 && !prj5.repo) { store.upsert('projects', { id: 'prj_5', repo: 'https://github.com/meem-studio/niletech-web' }); changed = true; }
  const prj2 = (db.projects || []).find((p) => p.id === 'prj_2');
  if (prj2 && !prj2.repo) { store.upsert('projects', { id: 'prj_2', repo: 'https://github.com/meem-studio/niletech-social' }); changed = true; }

  if (changed) store.forceSave();
  return changed;
}


/* ---------------- Phase 7: Collaboration + AI ---------------- */
function phase7seed() {
  const db = store.db;
  let changed = false;
  if (!(db.chats || []).length) {
    db.chats = [];
    const now = Date.now();
    const M = (room, by, byName, text, offMin) => store.upsert('chats', { room, by, byName, text, at: new Date(now - offMin * 60000).toISOString() });
    M('general', 'usr_admin', 'ميم عبدالله', 'صباح الخير يا فريق 🌟 أسبوع التسليمات — يلا نركز', 95);
    M('general', 'usr_content', 'أحمد الشريف', 'صباحو! السكربتات جاهزة للمراجعة ✍️', 90);
    M('general', 'usr_design', 'ميم', 'هبدأ تصاميم حملة زهرة النهارده 🎨', 85);
    M('design', 'usr_design2', 'كريم فؤاد', 'رفعت مسودة البروشر — محتاج عين ميم عليها', 60);
    M('design', 'usr_design', 'ميم', 'شفتها — حطيت التعديلات في التعليقات 📍', 55);
    M('dev', 'usr_dev', 'يوسف طارق', 'صفحة الهبوط اتربطت بالـ API — فاضل الـ HTTPS 🔧', 40);
    M('prj:prj_5', 'usr_cs', 'نورهان سعيد', 'عميل نايل تك سأل عن موعد التسليم المبدئي', 30);
    M('cli:cli_nile', 'usr_cs', 'نورهان سعيد', 'أهلاً أستاذ حسام! التسليم المبدئي يوم 27 إن شاء الله 🤝', 20);
    changed = true;
  }
  if (changed) store.forceSave();
  return changed;
}

if (require.main === module) {
  const created = seed();
  const m = phase3migrate();
  const m4 = phase4seed();
  const m5 = phase5seed();
  const m6 = phase6seed();
  const m7 = phase7seed();
  console.log(created ? '[seed] demo data created' : '[seed] db already has users, skipped');
  console.log(m ? '[seed] phase3 migrated' : '[seed] phase3 already present');
  console.log(m4 ? '[seed] phase4 seeded (ai settings + content library)' : '[seed] phase4 already present');
  console.log(m5 ? '[seed] phase5 seeded (shoots + bugs)' : '[seed] phase5 already present');
  console.log(m6 ? '[seed] phase6 seeded (finance + time + marketing + kb)' : '[seed] phase6 already present');
  console.log(m7 ? '[seed] phase7 seeded (chat rooms)' : '[seed] phase7 already present');
}

/* V2-3: حساب المالك المخفي (superadmin) + إعدادات الأدوات (فيديو/AI مخفيين عن الفريق) */
function v2seed() {
  const db = store.db;
  let changed = false;
  if (!db.users.find((u) => u.role === 'superadmin')) {
    // createUser بيعمل push بنفسه — بلا unshift إضافي
    store.createUser({
      id: 'usr_owner', name: 'المالك', nameEn: 'Owner', email: 'owner@meem.studio',
      password: '123456', role: 'superadmin', title: 'صاحب الصلاحية العليا', titleEn: 'Super Admin',
      phone: '', avatarColor: '#2f7bff', initials: 'O',
    });
    changed = true;
  }
  /* حماية: لو اتزرع مكرر في نسخة قديمة — إزالة التكرار */
  const seenOwner = new Set();
  const before = db.users.length;
  db.users = db.users.filter((u) => {
    if (u.role !== 'superadmin') return true;
    if (seenOwner.has(u.id)) return false;
    seenOwner.add(u.id);
    return true;
  });
  if (db.users.length !== before) changed = true;
  /* V2-6: فرق المشاريع (members بأدوار) */
  const ROLE_BY_DEPT = { design: 'design', content: 'content', voice: 'voice', dev: 'dev' };
  for (const prj of (db.projects || [])) {
    if (!prj.members) {
      const lead = prj.owner || 'usr_admin';
      const mem = [{ userId: lead, role: ROLE_BY_DEPT[prj.dept] || 'design' }];
      if (prj.dept === 'dev') mem.push({ userId: 'usr_design', role: 'design' });
      else mem.push({ userId: 'usr_content', role: 'content' });
      mem.push({ userId: 'usr_cs', role: 'cs' });
      prj.members = mem;
      changed = true;
    }
  }
  db.settings = db.settings || [];
  if (!db.settings.find((s) => s.id === 'tools')) {
    db.settings.push({ id: 'tools', video: false, ai: false, label: 'أدوات تجريبية — الفيديو والـ AI مخفيين عن الفريق' });
    changed = true;
  }
  if (changed) store.forceSave();
  return changed;
}

module.exports = { seed, phase3migrate, phase4seed, phase5seed, phase6seed, phase7seed, v2seed };
