'use strict';
/**
 * MEEM | Creative Office — طبقة التخزين (JSON on disk, zero dependencies)
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

function sha256(s) {
  return crypto.createHash('sha256').update(String(s)).digest('hex');
}
function uid(prefix) {
  return (prefix || 'id') + '_' + crypto.randomBytes(6).toString('hex');
}
function nowISO() {
  return new Date().toISOString();
}

function emptyDB() {
  return {
    meta: { name: 'MEEM | Creative Office', version: 1, createdAt: nowISO() },
    users: [],
    clients: [],
    projects: [],
    tasks: [],
    designs: [],
    deliveries: [],
    meetings: [],
    assets: [],
    invoices: [],
    templates: [],
    settings: [],
    requests: [],
    contents: [],
    voices: [],
    videos: [],
    shoots: [],
    bugs: [],
    activity: [],
    tokens: {},
  };
}

let db = emptyDB();

function load() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf8');
      const parsed = JSON.parse(raw);
      db = Object.assign(emptyDB(), parsed);
      return true;
    }
  } catch (e) {
    console.error('[store] failed to read db, starting fresh:', e.message);
  }
  return false;
}

let writeTimer = null;
function save() {
  if (writeTimer) return;
  writeTimer = setTimeout(() => {
    writeTimer = null;
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      const tmp = DB_FILE + '.tmp';
      fs.writeFileSync(tmp, JSON.stringify(db, null, 2), 'utf8');
      fs.renameSync(tmp, DB_FILE);
    } catch (e) {
      console.error('[store] save failed:', e.message);
    }
  }, 60);
}

function forceSave() {
  if (writeTimer) { clearTimeout(writeTimer); writeTimer = null; }
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
  } catch (e) {
    console.error('[store] forceSave failed:', e.message);
  }
}

/* ------------------------------- users ------------------------------- */

function createUser(u) {
  const user = {
    id: u.id || uid('usr'),
    name: u.name,
    nameEn: u.nameEn || u.name,
    email: String(u.email || '').toLowerCase(),
    passwordHash: u.passwordHash || sha256(u.password || '123456'),
    role: u.role || 'designer',
    title: u.title || '',
    titleEn: u.titleEn || '',
    phone: u.phone || '',
    avatarColor: u.avatarColor || '#7c5cff',
    initials: u.initials || (u.name || '?').slice(0, 1),
    active: u.active !== false,
    clientId: u.clientId || null,
    createdAt: nowISO(),
  };
  db.users.push(user);
  return user;
}

function publicUser(u) {
  if (!u) return null;
  const { passwordHash, ...rest } = u;
  return rest;
}

function findByEmail(email) {
  const e = String(email || '').toLowerCase().trim();
  return db.users.find((u) => u.email === e) || null;
}

function findById(id) {
  return db.users.find((u) => u.id === id) || null;
}

/* ------------------------------- tokens ------------------------------- */

function createToken(userId) {
  const token = crypto.randomBytes(24).toString('hex');
  db.tokens[token] = { userId, createdAt: nowISO() };
  save();
  return token;
}

function tokenUser(token) {
  const t = db.tokens[token];
  if (!t) return null;
  return findById(t.userId);
}

/* ------------------------------- generic ------------------------------- */

const COLLECTIONS = ['clients', 'projects', 'tasks', 'designs', 'deliveries', 'meetings', 'assets', 'invoices', 'templates', 'settings', 'requests', 'contents', 'voices', 'videos', 'shoots', 'bugs', 'payments', 'expenses', 'timeentries', 'campaigns', 'prompts', 'articles', 'chats'];

function list(name) {
  return db[name] || [];
}

function upsert(name, doc) {
  if (!COLLECTIONS.includes(name)) throw new Error('unknown collection: ' + name);
  const arr = db[name];
  if (!doc.id) doc.id = uid(name.slice(0, 3));
  doc.updatedAt = nowISO();
  const i = arr.findIndex((d) => d.id === doc.id);
  if (i >= 0) {
    arr[i] = Object.assign({}, arr[i], doc);
    return arr[i];
  }
  doc.createdAt = doc.createdAt || nowISO();
  arr.push(doc);
  return doc;
}

function remove(name, id) {
  if (!COLLECTIONS.includes(name)) throw new Error('unknown collection: ' + name);
  const arr = db[name];
  const i = arr.findIndex((d) => d.id === id);
  if (i < 0) return false;
  arr.splice(i, 1);
  return true;
}

function log(userId, text, textEn, meta) {
  db.activity.unshift({
    id: uid('act'),
    userId: userId || null,
    text: text || '',
    textEn: textEn || '',
    meta: meta || {},
    at: nowISO(),
  });
  if (db.activity.length > 400) db.activity.length = 400;
}

module.exports = {
  sha256, uid, nowISO,
  load, save, forceSave,
  get db() { return db; },
  reset(next) { db = next; },
  createUser, publicUser, findByEmail, findById,
  createToken, tokenUser,
  COLLECTIONS, list, upsert, remove, log,
};
