# 🏢 MEEM Creative Office — Product Blueprint v1.0

> **الغرض من هذه الوثيقة:** خريطة كاملة للنظام قبل كتابة أي سطر كود جديد —
> كل صفحة، كل Role، كل أداة داخل كل قسم، كل زر في محرر التصميم، الـ Workflow بين الأقسام،
> وقاعدة البيانات التي تربط العميل → المشروع → المهمة → التصميم → النسخ → المراجعة → التسليم.
> أي ميزة تُبنى بعد ذلك يجب أن تكون لها خانة هنا أولًا.

---

## 1. الرؤية

**MEEM Creative Office** ليس موقعًا — هو **مكتب إبداعي افتراضي كامل**:

- كل شخص يدخل بحسابه فيجد **مكتبه هو** (My Desk) وأدواته حسب دوره.
- كل قسم = **برنامج كامل داخل المكتب**، وليس صفحة عرض.
- كل عمل له **دورة حياة**: طلب → مشروع → إنتاج → مراجعة داخلية → مراجعة عميل → تسليم → أرشفة.
- كل خطوة لها **سجل، تاريخ، مسؤول، نسخة، ملفات، تعليقات**.

```
CLIENT → CUSTOMER SERVICE → REQUEST → PROJECT
   → CONTENT → CONTENT APPROVAL
   → DESIGN / VOICE / VIDEO / DEV
   → INTERNAL REVIEW → CLIENT REVIEW
   → APPROVE ⇄ REVISION
   → DELIVERY → COMPLETED → ARCHIVE
```

---

## 2. قرار العلامة التجارية

| | قبل | بعد |
|---|---|---|
| الاسم | بصمة \| Basma Studio | **MEEM \| Creative Office** |
| الهوية | Dark Navy + Purple→Cyan | نفس الاتجاه البصري (تأكيد عند التنفيذ) |
| النطاق التجريبي | `@basma.studio` | `@meem.studio` (تحويل الحسابات تلقائيًا) |

**التنفيذ:** إعادة التسمية = ملفات الهوية + نصوص الواجهة + أسماء الحسابات، بدون تغيير المنطق.

---

## 3. الوضع الحالي — ما تم بناؤه فعلاً (نقطة البداية)

موجود وشغال حاليًا (كود فعلي، مُختبَر):

| الوحدة | الحالة |
|---|---|
| تسجيل دخول / صلاحيات 7 أدوار | ✅ يعمل |
| Dashboard + Tasks + Activity | ✅ يعمل |
| **محرر Canvas حقيقي** (~3000 سطر): قوالب، نصوص (font family/size/weight/letter-spacing/line-height/align)، fill/gradient/stroke/shadow، صور + brightness/contrast/saturation/blur/opacity/radius، خلفيات، ملصقات، طبقات، تصدير PNG/JPG/PDF | ✅ يعمل — **يُطوَّر ولا يُعاد** |
| إرسال للمراجعة → تعديلات → تسليم (Kanban) | ✅ يعمل |
| اجتماعات WebRTC حقيقية (فيديو/صوت/شاشة/شات/رفع يد) | ✅ يعمل |
| عملاء (CRM بسيط) + ملفات + i18n عربي/إنجليزي | ✅ يعمل |

**المبدأ:** البناء فوق هذا الأساس، لا إعادة بناء. المحرر الحالي هو نواة الـ Design Engine.

---

## 4. الأدوار والصلاحيات (10 أدوار)

| Role | يرى | يعمل |
|---|---|---|
| 👑 **Admin / Owner (MIM)** | كل شيء | كل شيء + الفريق + التقارير + المالية + الأتمتة |
| 📋 **Project Manager** | كل المشاريع والمهام والمراجعات | إنشاء مشاريع، إسناد، اعتماد داخلي |
| 🎨 **Designer** | مشاريعه + Design Studio | تصميم، نسخ، إرسال للمراجعة |
| ✍️ **Content Writer** | مشاريعه + Content Studio | كتابة + AI + سكربتات |
| 🎙️ **Voice Artist** | مهامه الصوتية + Voice Studio | تسجيل وتحرير صوتي |
| 🎬 **Video Editor** | مهامه + Video Studio | مونتاج وموشن |
| 💻 **Developer** | مشاريعه + Dev Hub | برمجة + Bugs + Deployment |
| 👩‍💼 **Customer Service** | العملاء + الطلبات + التسليمات | طلبات، متابعات، بوابة العميل، تسليم |
| 🧾 **Accountant** | المالية فقط | فواتير، مدفوعات، مصروفات |
| 👨‍💼 **Client** | أعماله فقط (Client Portal) | مراجعة، اعتماد، طلب تعديل، تحميل |

**مصفوفة الصلاحيات تُدار بمصفوفة `permissions[role][action]` واحدة في السيرفر** — أي زر في الواجهة يقابله فحص صلاحية عند الـ API.

---

## 5. الهيكل العام — القائمة الجانبية (IA)

```
🏠 Dashboard (My Desk)
📋 WORK          → Projects · Tasks · Calendar · My Workspace
👥 CLIENTS       → CRM · Requests · Client Portal · Client Messages
🎨 CREATIVE      → Content Studio · Design Studio · Voice Studio ·
                   Video Studio · Photography · Brand Kits · Templates · Assets
💻 DEVELOPMENT   → Dev Hub · Bugs · Git · Testing · Deployments
📦 DELIVERY      → Review · Client Approval · Deliveries · Archive
🤝 COLLABORATION → MEEM Chat · MEEM Meet · Files · Notes
📣 MARKETING     → Campaigns · Ads · Analytics
💰 BUSINESS      → Finance · Quotes · Invoices
🧠 RESOURCES     → AI Tools · Prompt Library · Knowledge Base
📊 MANAGEMENT    → Team · Reports · Activity Log
⚙️ Settings
```

القائمة تُفلتر حسب الـ Role (المصمم لا يرى BUSINESS وهكذا — يرى مجموعته + ما يخصه).

---

## 6. 🖥️ My Desk — مكتب المستخدم

أول شاشة لكل مستخدم. ليست لوحة إدارة — **مكتب شخصي**.

```
MY DESK — MIM
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎨 My Designs          4
🔍 Reviews             2
✏️ Revisions           1
📦 Deliveries          2
🎥 Meetings            1
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚡ Quick Actions
+ New Design · + New Task · + Upload File · + Start Meeting · + Open Project
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 مشاريعي (بطاقات بنسبة إنجاز):  خان سوسن 72% · جسور الود 40% · Mind Bloom 15%
```

- **Today Panel**: مهام اليوم، Deadlines قريبة، اجتماعات قادمة.
- **My Projects**: كروت المشاريع المسندة لي + نسبة الإنجاز (محسوبة من المهام).
- كل رقم في العدادات = فلتر مباشر (ضغطة → قائمة المهام المفلترة).
- لكل Role نفس الهيكل بعدّادات تخصه (الـ CS يرى طلبات مفتوحة بدل تصاميم).

---

## 7. 📋 المشاريع — العمود الفقري

### بطاقة المشروع (Fields)
`اسم · العميل · مدير المشروع · تاريخ البداية · Deadline · الأولوية (High/Med/Low) · الحالة · الفريق (أعضاء بأدوارهم) · الميزانية · الملاحظات`

### داخل المشروع (Tabs)
`Overview · Content · Design · Voice · Video · Programming · Review · Delivery · Files · Meetings · Chat · Activity`

### حالات المشروع
`Draft → Active → In Review → Client Review → Delivery → Completed → Archived`

- نسبة الإنجاز = متوسط إنجاز المهام المرتبطة.
- كل Tab يعرض مهام القسم + ملفاته + اجتماعاته المربوطة.
- إنشاء مهمة من أي Tab يرث المشروع + القسم + العميل تلقائيًا.

---

## 8. 👥 CRM — ملف العميل

```
Client Profile
├── معلومات العميل (الاسم · الشركة · النوع · الحالة)
├── 📞 بيانات التواصل (هواتف · إيميلات · العنوان)
├── 🌐 حسابات السوشيال (روابط + إحصاء)
├── 🎨 Brand Kit (شعارات · ألوان · خطوط · أنماط · صور)
├── ✍️ Brand Voice (لغة · لهجة · Tone · Emoji · كلمات مفضلة/ممنوعة)
├── 📋 المشاريع   ├── 📦 التسليمات   ├── 💬 المحادثات
├── 📁 الملفات    ├── 🧾 الفواتير    └── 📝 الملاحظات (Timeline)
```

**Brand Voice** يُستخدم تلقائيًا في Content Studio وفي توليد الـ AI (يُحقن كـ system prompt).

---

## 9. 📨 طلبات العملاء (Requests)

نموذج New Request (يملؤه الـ CS):
`العميل · نوع الطلب (محتوى/تصميم/فيديو/Voice Over/برمجة/تعديل/أخرى) · الوصف · Reference (رفع ملفات) · Deadline · Priority`

### دورة الطلب
`New → Assigned (→ مشروع جديد أو مهمة داخل مشروع قائم) → In Progress → Review → Done`

- زر **Assign Task** يحول الطلب لمهمة (أو مشروع كامل لو متعدد الأقسام) مع إشعار المسؤول.
- **Automation:** نوع الطلب يحدد القسم المُسند إليه افتراضيًا.

---

## 10. ✍️ Content Studio

### أنواع المحتوى
`Post · Caption · Carousel · Story · Reel Script · Video Script · Advertisement · Blog · Website Copy · Product Description · Email · SEO`

### أدوات الكاتب (AI Toolbar)
`✨ Generate · 🔄 Rewrite · ✂️ Shorten · 📈 Improve · 🎯 Hook · 📢 CTA · 💡 Ideas · 🔍 SEO · 🌍 Translate · 🗣️ Change Dialect`

- كل نوع محتوى له قالب هيكل (مثلاً Carousel = شرائح، Reel = ثوانٍ ومشاهد).
- كل نص مرتبط بمهمة ومشروع وعميل → يمر بنفس دورة المراجعة.
- **حالات:** `Draft → Sent for Review → Approved / Changes Requested`.

---

## 11. 🎨 DESIGN STUDIO — الـ Design Engine (أهم وحدة)

> **التعريف للمطور:** Design Engine بمحرر Canvas حقيقي، يدعم إنشاء Canvas بمقاسات جاهزة أو مخصصة،
> Text/Fonts/Weights/Spacing/Colors/Effects، Images، Shapes، Icons، Stickers، Backgrounds، Layers،
> Multi-select، Grouping، Alignment، Guides، Crop، Rotate، Filters، AI Image Generation،
> Background Removal، Image Enhancement، Templates، Brand Kits، QR Codes، Undo/Redo، Autosave،
> Version History، Resize، Export، Editable Projects، ثم Submit for Review.

### 11.1 شاشة «+ إنشاء تصميم»
اختيار المصدر: **Blank · Template · AI Design · Duplicate Existing**
ثم الفئة:

| الفئة | المحتويات |
|---|---|
| 📱 Social Media | IG: Post/Story/Carousel/Reel Cover/Highlight · FB: Post/Cover/Ad · TikTok: Cover/Ad · X: Post/Header · LinkedIn: Post/Banner · YouTube: Thumbnail/Channel Art · WhatsApp: Status/Catalog |
| 🖨️ Print | A4 · A5 · A6 · Flyer · Poster · Brochure · Menu · Business Card · Letterhead · Certificate · Invitation · Roll-up · Banner · Sticker · Label · Packaging · Booklet · Magazine |
| 🏷️ Branding | Logo · Logo Variations · Business Card · Letterhead · Envelope · Brand Guidelines · Social Media Kit · Company Profile |
| 📢 Advertising | Facebook Ads · Instagram Ads · Google Ads · Display · Product Ads · Offer Ads · Campaign Creatives |
| 📊 Infographics & Presentations | Infographic · Presentation · Pitch Deck · Company Profile · Report · Data Visualization |
| 🎁 Invitations & Events | Wedding · Birthday · Baby Shower · Corporate Event · Conference · Festival · Holiday · Certificate |
| 📐 Custom | Width × Height + Unit (PX / CM / MM / IN) + DPI |

### 11.2 هيكل المحرر (Design OS)

```
┌────────────────────────────────────────────────────────────┐
│ ← Projects   Design #102   [Undo][Redo]   [Save ✓] [Export]│
├──────────┬────────────────────────────────┬────────────────┤
│ Panels   │            CANVAS              │   Properties   │
│ Templates│   (zoom · pan · grid · snap)   │   (سياقية:     │
│ Elements │                                │   تتغير حسب    │
│ Text     │                                │   العنصر       │
│ Images   │                                │   المحدد)      │
│ Uploads  │                                │                │
│ AI       │                                │                │
│ Brand    │                                │                │
│ Background│                               │                │
│ Stickers │                                │                │
│ QR       │                                │                │
│ Layers   │                                │                │
└──────────┴────────────────────────────────┴────────────────┘
```

### 11.3 🔤 أداة النص — المواصفة الكاملة

| مجموعة | الخيارات |
|---|---|
| Font | Font Family (مكتبة خطوط + **Upload Custom Font** + Recent + Favorites ⭐) |
| Size | 8 · 10 · 12 · 16 · 24 · 32 · 48 · 64 · 96 · **Custom (رقم حر)** |
| Weight | Thin · Light · Regular · Medium · Semi Bold · Bold · Extra Bold · Black |
| Alignment | Left · Center · Right · Justify |
| Spacing | Letter Spacing · Line Height · Paragraph Spacing |
| Transform | Uppercase · Lowercase · Capitalize · **Curved Text / Warp** (منحنى على مسار) |

### 11.4 🎨 لون النص
`Solid · Gradient (خطي/دائري + نقاط تحكم) · Pattern · Image Fill`
+ Color Picker (HEX · RGB · HSL) + Opacity + **حفظ في Brand Colors** بضغطة.

### 11.5 ✨ Text Effects
`Shadow · Glow · Stroke/Outline · Background · Gradient · Pattern · Blur · Opacity · 3D · Curved/Warp`
(كل تأثير = لوحة خصائص: لون، إزاحة، سماكة، انتشار، زاوية).

### 11.6 🖼️ أدوات الصور

| Transform | Adjust | Filters |
|---|---|---|
| Move · Scale · Rotate · Flip H · Flip V · Crop · Crop Shapes (دائرة/قلب/نجمة…) | Brightness · Contrast · Saturation · Temperature · Tint · Exposure · Highlights · Shadows · Sharpness · Blur · Opacity | مكتبة فلاتر جاهزة + Preset مخصص |

### 11.7 🤖 AI Photo Tools
`Remove Background · Replace Background · AI Enhance · Upscale · Remove Object · Remove Blur · Retouch · Restore Old Photo · Colorize · Face Enhance`

> **ملاحظة تقنية صادقة:** التنفيذ الفعلي لهذه الأدوات يحتاج ربط API خدمة AI خارجية
> (مثل remove.bg / Clipdrop / Stability). الواجهة + pipeline + أزرار «Add to Canvas» تُبنى كلها؛
> جودة النتيجة تعتمد على الخدمة المختارة (قرار مفتوح — قسم 20).
> بدون مفتاح API تعمل الأدوات ببدائل محلية بسيطة (قص محيط، تحسين تباين) ويُعلَّم الزر «Pro».

### 11.8 🤖 AI Design & Image Generator
- **Generate Design:** يصف المصمم المطلوب (مثلاً: «بوست عرض تغيير زيت سيارات، احترافي، أزرق وأسود، مساحة للمنتج والسعر») → النظام يقترح **3 Layouts** على الـ Canvas.
- **AI Image Generator:** Prompt · Style · Aspect Ratio · Number of Images → Generate → **Add to Canvas**.
- **AI Background:** Generate Background · Replace Background · Expand Image · Extend Canvas.

### 11.9 🧩 Elements & Backgrounds & QR
- **Elements:** Shapes · Icons · Illustrations · Stickers · Emojis · Arrows · Frames · Lines · Badges · Decorations (مكتبة SVG داخلية + رفع).
- **Backgrounds:** Solid · Gradient · Texture · Pattern · Image · AI Generated.
- **QR Generator:** URL · WhatsApp · Phone · Text · Email → Generate → يضاف كعنصر قابل للتحرير.

### 11.10 🧱 Layers (الطبقات)
```
👁 🔒 Headline        — لكل Layer: Hide · Lock · Duplicate · Rename ·
👁 🔒 Product Image      Delete · Group · Ungroup · Bring Forward ·
👁 🔒 Price              Send Backward
👁 🔒 CTA Button
👁 🔒 Background
```
- **Multi-select** (Ctrl/Shift + سحب框) → تحريك/تعديل/محاذاة عدة طبقات معًا.
- **Grouping:** تجميع عناصر ككتلة واحدة (تحريك، تكرار، تصدير).
- Drag & Drop لإعادة الترتيب.

### 11.11 📐 Alignment & Guides
`Align Left · Center · Right · Top · Middle · Bottom · Distribute H · Distribute V`
\+ **Grid · Guides (أسحب من المسطرة) · Snap to edges/centers · Margins · Safe Area** (منطقة أمان لكل مقاس).

### 11.12 ↩️ History
`Undo · Redo (اختصارات Ctrl+Z / Ctrl+Y) + لوحة History قابلة للنقر:`
```
1. Added Text        — كل خطوة مسماة ومحفوظة، يمكن القفز لأي خطوة.
2. Changed Color     — History محفوظ مع المشروع (قابل للعرض بعد إعادة الفتح).
3. Moved Image
```

### 11.13 💾 Auto Save
- حفظ تلقائي كل تغيير (debounced ~2s) + مؤشر `Saving… → ✓ Saved`.
- إغلاق الصفحة آمن تمامًا — المشروع قابل للاستكمال بعد شهر (**Editable Project** وليس صورة).

### 11.14 📐 Resize
`Instagram Post/Story · Facebook · TikTok · WhatsApp · LinkedIn · YouTube · X · A4 · A5 · Custom`
+ **Duplicate & Resize:** يُنشئ نسخة بالمقاس الجديد — **الأصل لا يتغير**.

### 11.15 📤 Export
| الصيغ | الإعدادات |
|---|---|
| PNG · JPG · WEBP · PDF · PDF Print · SVG | Quality · Resolution (1x/2x/3x) · DPI · Transparent Background · Bleed · Crop Marks |

### 11.16 📦 Editable Design Project (البنية المحفوظة)
```
Design Project
├── Canvas (المقاس · الخلفية · DPI)
├── Layers (شجرة كاملة)
├── Text (خطوط · خصائص · مؤثرات)
├── Images (الأصول + تعديلاتها — non-destructive)
├── Fonts (المضمنة والمرفوعة)
├── Colors (المستخدمة + Brand Colors)
└── History (خطوات)
```

### 11.17 ⭐ Templates & Brand Kit & Team Templates
- **Templates:** مكتبة مصنفة حسب الفئة + البحث + معاينة.
- **Brand Kit:** اختيار العميل (مثلاً Khan Sawsan) → تظهر مباشرة: Logo · Colors · Fonts · Patterns · Photos · Icons — بدون بحث.
- **Save as MEEM Template:** حفظ تصميمي كقالب متاح لكل الفريق (بموافقة Admin).

### 11.18 🔍 دورة التصميم بعد الانتهاء
```
Submit for Review → Waiting Review
   ↓ (المراجع يرى: Design · Version · Designer · Project · Deadline)
✅ Approve  →  Client Review
✏️ Request Changes → يعود للمصمم مع التعليقات المثبتة
```

### 11.19 📍 التعليقات على التصميم (Pinned Comments)
- المراجع يضغط أي نقطة على التصميم → 📍 + نص («صغر اللوجو» / «لون السعر أوضح»).
- كل تعليق **مربوط بإحداثياته** على الـ Canvas + حالته (Open / Resolved) + ردود.
- المصمم يرى كل التعليقات كأيقونات على التصميم وينقر للقفز للمكان.

### 11.20 🔄 Version Control
`V1 → V2 → V3 → V4 → Approved` — كل نسخة محفوظة كاملة (قابلة للفتح والمقارنة جنبًا إلى جنب). لا مزيد من `final-final-2-new.png` 😂

---

## 12. 🎙️ Voice Studio

**Voice Task:** `Project · Video/Script · Duration · Language · Dialect · Voice · Tone`

**Recording Room (متصفح — MediaRecorder API):**
`🎙️ Record · ▶ Play · ⏸ Pause · ⏹ Stop · ⏱️ Timeline`

**Audio Editor:**
`✂️ Cut/Trim · 🔇 Noise Reduction · 🔊 Volume/Normalize · 🎚️ Equalizer (Bands) · Fade In/Out · Speed`

**ثم:** `Send for Review` → نفس دورة المراجعة (نسخ V1/V2 + تعليقات).

> التنفيذ: تسجيل + قص + Volume + Fade وEQ بسيط = ممكن بالكامل في المتصفح (Web Audio API).
> Noise Reduction حقيقية = مكتبة RNNoise-wasm (مفتوحة المصدر) — تُضاف في مرحلة الصوت.

---

## 13. 🎬 Video Studio

**الأنواع:** `Reel · TikTok · Shorts · YouTube · Ads · Motion · Intro · Outro · Thumbnail`

**المحرر (Timeline-based):**
`Video Track · Audio Track · Voice Over Track · Text Track · Stickers/Overlays`
\+ `Transitions · Captions (تلقائية يدوية) · Speed · Trim · Export (MP4)`

> التنفيذ: مونتاج كامل في المتصفح ثقيل؛ المرحلة الأولى = Timeline + Trim + نصوص + تصدير
> عبر WebCodecs/ffmpeg.wasm للأعمال الخفيفة (Reels/Ads قصيرة)، والأعمال الثقيلة تُصدَّر كمواصفة
> تسليم (Delivery Spec) للمونتير على جهازه. (قرار مفتوح — قسم 20).

---

## 14. 📸 Photography (قسم إضافي)

```
Photography
├── Types: Product · Food · Personal Branding · Events · Commercial
├── Shot List (قطة/ملاحظات/تمت؟)
├── Schedule (تاريخ الجلسة + الفريق)
├── Raw Files (رفع) → Selected Photos → Retouching (مهام مرتبطة بالـ Design Studio)
└── Final Delivery
```

---

## 15. 💻 Development Hub

**الأنواع:** `Websites · Landing Pages · Dashboards · E-commerce · Apps · APIs · Maintenance`

**داخل كل مشروع برمجة:** `UI/UX · Frontend · Backend · Database · API · Testing · Bug Fixes · Deployment · Documentation`

**🐛 Bug Tracker:** `Bug (عنوان · وصف · Screenshot · Priority · Assigned Developer · Status)`
الحالات: `Open → In Progress → Testing → Fixed → Closed`

**🔗 Git (مستقبلي):** ربط Repository · Branches · Commits · Pull Requests · Issues · Deployments
(المرحلة الأولى: حقول روابط خارجية فقط — تكامل GitHub API لاحقًا).

---

## 16. 📦 Delivery Center + Client Portal

### Delivery Board (أعمدة)
`🟡 Waiting Client → 🔵 Revision → 🟢 Approved → 📦 Ready to Deliver → ✅ Delivered`

### Pre-Delivery Checklist (لا تسليم بدونها)
`☑ Content correct · ☑ Logo correct · ☑ Colors correct · ☑ Dimensions correct · ☑ Spelling checked · ☑ Contact info checked · ☑ High quality · ☑ Client approved` → زر **READY FOR DELIVERY**

### 👨‍💼 Client Portal (حساب Client)
- يرى حملاته فقط: `Campaign → 10 Designs → 01 ✅ · 02 ⏳ · 03 ✏️ · 04 ✅`
- لكل تصميم: معاينة + **✅ Approve** أو **✏️ Request Revision** (مع تعليق).
- تحميل الملفات المعتمدة + سجل محادثاته مع الـ CS.

---

## 17. 🤝 Collaboration

- **MEEM Chat:** غرف `General · Design Team · Content Team · Development` + Project Chats + Client Chats. (WebSocket موجود بالفعل — يُبنى فوقه).
- **MEEM Meet:** الغرفة الحالية (كاميرا/ميك/شاشة/شات/رفع يد) + **ربط الاجتماع بالمشروع** + بعد الاجتماع: **Meeting Notes → زر Convert Notes → Tasks** (كل سطر bullet يتحول مهمة مُسندة).
- **Calendar:** Deadlines · Meetings · Reviews · Deliveries · Tasks (عرض شهري/أسبوعي).
- **File Manager:** لكل مشروع شجرة: `Content · Designs · Voice · Video · Source Files · Client Files · Deliveries`.

---

## 18. 📣 Marketing · 💰 Finance · 📊 Reports · 🧠 Resources

| القسم | المحتوى |
|---|---|
| **Marketing** | Campaigns · Ads · Target Audience · Platforms · Campaign Assets · Performance (مرتبط بالمحتوى والتصميم) |
| **Finance** | Clients · Packages · Invoices · Payments · Expenses · **Project Profit** (إيراد − وقت الفريق × التكلفة) |
| **Time Tracker** | تسجيل وقت لكل مهمة («تصميم إعلان — 1:42 ساعة») → يغذي التقارير والـ Profit |
| **Reports** | Projects Completed/Late · Designs · Revisions · Client Approvals · Team Performance · Average Delivery Time |
| **Prompt Library** | Design/Image/Content/Video/Voice/Marketing Prompts + ⭐ Favorite · 📋 Copy · ✏️ Edit (يُحقن في أدوات الـ AI) |
| **Knowledge Base** | MEEM Guidelines · How We Work · File Naming · Design/Content/Delivery Rules · Programming Standards |
| **Activity Log** | مين عدّل؟ مين حذف؟ مين وافق؟ مين أرسل للعميل؟ مين طلب تعديل؟ (كل حدث = سطر: who/what/when/where) |

---

## 19. 🤖 Automation (النظام يشتغل بدل الفريق)

قواعد `Trigger → Actions` (قابلة للتفعيل/التعطيل من Admin):

| Trigger | Actions |
|---|---|
| CONTENT APPROVED | Create Design Task → Assign Designer → Notify |
| DESIGN APPROVED (داخليًا) | Send to Customer Service → Client Review |
| CLIENT APPROVED | Create Delivery → Notify CS |
| CLIENT REQUESTED REVISION | Create Revision Task → Assign Designer → Notify |
| DEADLINE −24h | Notify المسؤول + PM |
| TASK 3 أيام بدون حركة | Notify PM |

---

## 20. 🗄️ قاعدة البيانات (النموذج)

```
users ─┬─ roles/permissions
       ├─ time_entries → tasks
clients ─┬─ brand_kits (logos/colors/fonts/patterns)
         ├─ brand_voice (lang/dialect/tone/emoji/keywords)
         ├─ requests → tasks/projects
         └─ invoices/payments
projects ─┬─ tasks (قسم/حالة/مسؤول/deadline/version)
          ├─ designs ─┬─ design_versions (V1..Vn — كاملة قابلة للفتح)
          │           ├─ pinned_comments (x/y/status/replies)
          │           └─ reviews (reviewer/verdict/notes)
          ├─ content_items (type/status/approvals)
          ├─ voice_tasks (audio files/versions/reviews)
          ├─ video_tasks · dev_tasks · bugs
          ├─ meetings ─── meeting_notes → tasks
          ├─ files (مجلدات مصنفة)
          └─ deliveries (checklist/status/client_feedback)
templates (فئات + team templates)
prompt_library · knowledge_articles
activity_log (كل حدث)
automation_rules
```

**مبادئ:** كل كيان له `id, createdAt, createdBy` · كل حالة تغيير تُسجل في `activity_log` ·
النسخ (versions) **غير مدمرة** — الأصل لا يُكتب فوقه أبدًا.

**الترحيل:** الـ store الحالي (JSON) يُوسَّع بنفس البنية — لا كسر للبيانات الموجودة.

---

## 21. خارطة الطريق (Roadmap)

> **المبدأ:** كل مرحلة تُسلَّم كاملة ومُختبَرة قبل التالية — لا أجزاء معلقة.

| المرحلة | المحتوى | معيار القبول |
|---|---|---|
| **Phase 0 — Blueprint** | هذه الوثيقة + اعتمادك عليها | ✅ موافقة MIM |
| **Phase 1 — MEEM + My Desk + Design Engine 2.0** | إعادة التسمية MEEM · My Desk لكل role · ترقية المحرر: Multi-select + Grouping · Alignment/Distribute كامل · Guides/Grid/Snap · History panel · Autosave indicator · Warp/Curved text · Gradient/Pattern fill للنص · Image Fill · Crop Shapes · QR Generator · Weight/Spacing كاملين · Custom fonts upload | ميم تصمم بوست كامل من الصفر بكل الأدوات وتحفظ وتعيد الفتح وتكمل |
| **Phase 2 — دورة حياة التصميم** ✅ **تم التسليم** | Submit for Review · Pinned Comments على الـ Canvas · Version Control (V1..Vn + مقارنة + استعادة) · Approve/Request Changes · اعتماد العميل برابط سري (علامة مائية) · Save as Team Template · Brand Kit داخل المحرر · Resize + Duplicate&Resize · Export settings (DPI/WEBP/PDF Print) — *SVG/Bleed مؤجَّلة لمحرك المتجهات* | تصميم يمر: إنشاء → مراجعة بتعليقات مثبّتة → نسخة جديدة → اعتماد ✅ |
| **Phase 3 — المشاريع والعملاء** ✅ **تم التسليم** | Projects module كامل (6 تبويبات: نظرة عامة/مهام/تصاميم/ملفات/تسليمات/نشاط) · CRM (Brand Kit: ألوان+خطوط+لوجو · Brand Voice: نبرة/كلمات/ممنوعات/مثال) · Requests + Assign + تحويل لمشروع بمهمة تلقائية · Calendar (مهام+مشاريع+اجتماعات) · Files مربوطة بالمشاريع · Activity Log موسع (100 حدث + فلاتر) · Client Portal كامل (حسابات عملاء بدور `client`: اعتماد/طلب تعديل/تحميل PNG/مشاريعي — وصلاحيات معزولة على السيرفر) · Delivery Checklist (بوابة «إرسال للعميل») · Automation rules (trigger→action على السيرفر + بث `refresh-state` لحظي) | السلسلة كاملة اشتغلت: طلب → مشروع → مهمة → تصميم → اعتماد عميل من البورتال → تسليم أوتوماتيك بـ checklist ✅ (145/145 اختبار) |
| **Phase 4 — Content + Voice** ✅ **تم التسليم** | **Content Studio**: مكتبة محتوى بأنواع (كابشن/سكربت 30-60ث/مقال/إعلان/إيميل/SEO) + محرر كامل بإحصاءات حية + **AI Toolbar** (توليد مسودة/تحسين/تقصير/تظبيط للصوت/هاشتاجات/عناوين) بـ Pipeline كامل: مفتاح API في الإعدادات → بروكسي سيرفر، ومن غير مفتاح → **مولّد محلي** ذكي + شارة Pro · **Brand Voice** مرتبط بالعميل يُحقن في التوليد · دورة مراجعة كاملة (مسودة→مراجعة→اعتماد/تعديلات + تعليقات + نسخ) · **Voice Studio**: تسجيل ميكروفون حقيقي + رفع ملفات + موجة صوتية (Waveform) + تشغيل + **قص (Trim) + Volume + Fade In/Out + EQ (Bass/Treble)** بمعالجة OfflineAudioContext → WAV · ربط التسجيل بسكربت معتمد (Teleprompter) · نفس دورة المراجعة · endpoints عامة `/api/doc/:col/:id/{submit\|decision\|comment}` + `/api/ai` | كاتب ينتج سكربت معتمد → فويس يسجل ويرسل → اعتماد — كلها شغالة ومتصلة بالمشاريع والعملاء ✅ (182/182 اختبار) |
| **Phase 5 — Video + Photography + Dev** ✅ **تم التسليم** | **Video Studio**: رفع فيديوهات/صور/صوت (سيرفر ملفات `/api/upload` مش قاعدة بيانات) · **Timeline خفيف**: ترتيب كليبات + Trim لكل كليب + نص Overlay لكل كليب + تراك صوت خلفي · **Preview حي على Canvas** بمحرك تتابعي + Playhead · **تصدير WebM حقيقي** (captureStream + AudioContext) يترفع ويترفق بالمشروع · دورة مراجعة كاملة · **Photography**: جلسات تصوير (Shoots) بـ Shot List (وصف/نوع/تأطير/أولوية ✓) + رفع لقطات الجلسة (معرض) + حالات · **Dev Hub**: تبويبان — بورد المهام + **Bug Tracker** كامل (severity/new→inprogress→testing→fixed→closed + تعليقات + إسناد) | مونتير يرفع كليبات ويرتبهم ويقص ويصدّر فيديو WebM حقيقي · مصور يخلص Shot List · مطور يقفل Bug — كل قسم برنامج مستقل ✅ |
| **Phase 6 — Business + Management** ✅ **تم التسليم** | **Finance** (`#/finance`): فواتير كاملة (بنود/ضريبة/خصم · draft→sent→paid + overdue تلقائي) + تسجيل دفعات جزئية + مصروفات (رواتب/أدوات/إعلانات) + KPIs (محصل/مستحق/متأخر/صافي ربح) · **Time Tracker** (`#/time`): تايمر حي لكل مهمة (start/stop) + إدخال يدوي + مجاميع ساعات لكل عضو/مشروع · **Reports** (`#/reports`): تقرير شهر كامل — مشاريع وتسلمات، مهام متأخرة، أداء الفريق (مهام + ساعات + التزام بالمواعيد)، ربحية (إصدار/تحصيل/مصروفات/هامش) + رسوم SVG · **Marketing** (`#/marketing`): حملات (قناة/ميزانية/مصروف/عملاء محتملون/تحويلات/إيراد) + ROI · **Knowledge** (`#/kb`): مكتبة برومبت (فئات/متغيرات/نسخ) + قاعدة معرفة (مقالات بفئات وبحث) · **GitHub links**: حقل repo في المشاريع يظهر كرابط في الكارت | الإدارة تشوف تقرير شهر كامل: مشاريع، تأخير، أداء فريق، ربحية ✅ |
| **Phase 7 — Collaboration + AI + اللمسة الأخيرة** ✅ **تم التسليم** | **MEEM Chat** (`#/chat`): غرف فريق (General/Design/Content/Development) + شات لكل مشروع + شات لكل عميل — رسائل لحظية عبر الـ WebSocket الموجود، عزل كامل: العميل يشوف غرفته وغرف مشاريعه بس · **Meetings → Tasks**: ملاحظات الاجتماع (نقاط) + زر «حوّل لمهام» يحوّل كل سطر لمهمة مُسندة لمشروع · **AI في محرر التصميم**: لوحة AI — أدوات صور (Remove BG · Enhance · Upscale · Colorize · Retouch) على أي layer صورة + **مولد تصميم** (وصف → 3 Layouts على الكانفس ببراند العميل) + **مولد صور/خلفيات** (Prompt → إضافة للكانفس) — Pipeline كامل: مفتاح API → السيرفر بروكسي، ومن غير مفتاح → بدائل محلية حقيقية (معالجة Canvas) + شارة Pro · رجريشن نهائية كاملة | الفريق يتشات لحظي · اجتماع يتحول مهام بضغطة · المصمم يولّد تصميم وخلفية بالـ AI ويضيفهم للكانفس ✅ (277/277 اختبار) |

**ملاحظة AI:** الأدوات المولِّدة (تصميم/صور/صوت) تُبنى واجهتها وpipeline كاملين في مرحلتها،
وتُوصَّل بمفتاح API عند توفره (قرار 20.2).

---

## 22. قرارات مفتوحة (تحتاج كلمة منك)

1. **الاسم النهائي:** MEEM Creative Office — مؤكد؟ (وهل الشعار «ميم» أم «MEEM»؟)
2. **خدمات الـ AI الخارجية:** هل يوجد (أو سيتوفر) مفتاح API لخدمة صور/توليد (OpenAI / Stability / remove.bg / Clipdrop)؟ بدونها نبني الواجهات + بدائل محلية.
3. **حساب العميل (Client Portal):** يدخل بنفس النظام (حساب client) أم نكتفي في المرحلة الأولى بصفحة اعتماد برابط سري لكل حملة؟
4. **اللغة:** نبقي الثنائية عربي/إنجليزي في كل الأقسام الجديدة؟ (الموجود حاليًا ثنائي)
5. **ترتيب المراحل:** الترتيب أعلاه يبدأ بالـ Design Engine — موافق؟ ولا تقديم شيء؟

---

## 23. 🏢 MEE M 2.0 — Virtual Creative Office (المواصفات النهائية الجديدة)

> المصدر: «المواصفات النهائية لتعديل وتطوير المشروع الحالي» (69 بند + 16 مرحلة).
> القاعدة الحاكمة: **تطوير على الأساس الحالي — مش إعادة بناء**. أي وظيفة موجودة وشغالة تُستخدم كما هي.

### قرارات مُعتمدة من المالكة (ملزمة)
1. **الفيديو (WebRTC) والـ AI الموجودين**: يبقوا في الكود لكن **مخفيين عن واجهة الفريق** — المدير العام فقط يشوفهم من لوحة التحكم. البنية تفضل جاهزة للتفعيل مستقبلًا.
2. **الهوية الجديدة (MEE M — أسود/أبيض/فضي/أزرق كهربائي، Futuristic)**: **تدريجيًا** — كل صفحة جديدة تطلع بالهوية الجديدة، والصفحات القديمة تُعدَّل في مرحلة ختامية.
3. **الـ Super Admin**: حساب مخفي جديد `owner@meem.studio` (أعلى صلاحية، مش ظاهر في قائمة الفريق) + `admin@meem.studio` يفضل مديرًا عامًا ظاهرًا.
4. **العملاء**: **الاتنين مع بعض** — رابط توكن آمن لكل مشروع `/client/project/<TOKEN>` (بدون تسجيل دخول) + حسابات العملاء الحالية تفضل شغالة.

### خريطة الموجود ↔ المطلوب (لا يُعاد بناء الموجود)
| بند المواصفات | الحالة الحالية |
|---|---|
| لا يوجد Sign Up عام | ✅ موجود أصلًا (صفر endpoints تسجيل ذاتي) |
| عربي/إنجليزي + RTL/LTR | ✅ i18n كامل (`t()`) — يُمد للأجزاء الجديدة |
| Chat نصي (فريق/مشروع/عميل) | ✅ Phase 7 — **الجديد: Direct Messages** |
| نظام مهام كامل + New Task | ✅ موجود — **الجديد: حالات Review/Revision/Delivered + Attachments** |
| Watermark + اعتماد برابط سري | ✅ Phase 2 — **الجديد: توكن دائم لكل مشروع + صفحة عميل موحدة** |
| بورتال عميل (بحساب) | ✅ موجود — **الجديد: دخول بالتوكن بدون حساب** |
| محرر تصميم (Layers/History/Autosave/Versions/Brand Kit/Export) | ✅ موجود — **الجديد: ترقيات Priority 1-3 (أدوات تحديد/رسم/فلاتر/Blend/Masks/Crash Recovery)** |
| طلبات مشاريع (Requests) | ✅ موجود — **الجديد: نموذج عام بدون login + أسئلة ديناميكية لكل خدمة** |
| أدوار وصلاحيات server-side | ✅ جزئي (client معزول + canChat) — **الجديد: مصفوفة صلاحيات كاملة لكل دور** |
| Virtual Office 2D + Presence | ❌ جديد تمامًا |
| Super Admin Dashboard منفصل | ❌ جديد (admin dashboard موجود جزئيًا في الأقسام) |
| Project Team (مشروع متعدد الأعضاء) | ❌ جديد |
| Responsive Mobile/Touch للمكتب | ❌ جديد |

### مراحل التنفيذ (V2) — بنفس ترتيب المواصفات
| المرحلة | المحتوى | الحالة |
|---|---|---|
| **V2-1** فحص شامل + إصلاح أي أزرار/وظائف معطلة + Baseline اختبارات (277) | ✅ |
| **V2-2** Roles & Permissions server-side: `server/perms.js` (مصفوفة كتابة/حذف/قراءة لكل دور) + ختم createdBy + إخفاء الماليات ومفاتيح API من state + قرار الاعتماد للإدارة/CS + فلترة Navigation/Routes (29 اختبار جديد — 306/306) | ✅ |
| **V2-3** Super Admin: حساب `owner@meem.studio` مخفي (دور `superadmin`) + **OWNER CONTROL** بهوية MEE M الجديدة (9 تبويبات: Overview/Team/Projects/Tasks/Clients/Files/Requests/Tools/Settings) + `/api/user` (إنشاء/تعديل/باسورد/تفعيل — للمالك فقط) + منع دخول المعطّلين + presence (المتصلون الآن) + **إخفاء الفيديو/AI عن الفريق** بـ Tools toggles (لحظي) — 37 اختبار جديد، 343/343 | ✅ |
| **V2-4** الحسابات من الإدارة فقط: `/api/user` موسع للأدمن (أدوار عادية فقط — المميزة للمالك · منع الترقية) + `/api/password` ذاتي بالباسورد الحالي (§32) + منع دخول المعطّلين + شاشة الفريق بإدارة كاملة (إنشاء/تعديل/تفعيل/باسورد) + التسجيل الذاتي مرفوض ومُختبَر (49 اختبار جديد — 372/372) | ✅ |
| **V2-5** Workspace لكل تخصص: Navigation + Routes بأدوار (designer: تصميم/تصوير · content: محتوى · voice: صوت · dev: برمجة · cs: عملاء/طلبات) مع بقاء بيانات المشاريع المشتركة للتعاون (§5/§6) + حراس تحويل + 14 اختبار (386/386) | ✅ |
| **V2-6** Project Team: `members` بأدوار في كل مشروع (مزروع للديمو) + قسم «فريق المشروع» بصفحة المشروع (أفاتار + دور + **نقطة اتصال لحظية** عبر presence) + إضافة/إزالة أعضاء (إدارة/CS) + بلوك «التعديلات والاعتمادات» + الكروت بتعرض أفاتارات الفريق — 11 اختبار (397/397) | ✅ |
| **V2-7** Virtual Office 2D: `#/office` — **الهبوط الرئيسي للفريق** — خريطة بهوية MEE M (9 غرف: استقبال/تصميم/محتوى/فويس/برمجة/CS/تسليمات/استراحة/إدارة🔒) + غرفتك مميزة + المتصلون في كل قسم لحظيًا + نقرة = دخول القسم (بصلاحيات V2-5) + موبايل عمودي باللمس — 16 اختبار (413/413) | ✅ |
| **V2-8** Avatars + حركة: بث المواقع لحظيًا عبر WS (`pos/posinit/status/posleave`) · WASD/الأسهم + tap-to-move · أفاتار كل زميل بيتحرك عندك live · حالات 🟢متاح/🔴مشغول/🟡اجتماع (حلقة ملونة) · ممرات حقيقية بين الغرف · موقعك محفوظ — 10 اختبارات (423/423) | ✅ |
| **V2-9** سايدبار + DMs + بروفايل: غرف `dm:id1:id2` بخصوصية **server-side** (canChat + فلترة state) · كليك على أفاتار زميل في المكتب = محادثة · زر «رسالة مباشرة جديدة» · قسم DMs في السايدبار بنقاط اتصال · بروفايل الموظف (user-chip) = بيانات + تغيير كلمة المرور (`/api/password`) — 18 اختبار (441/441) | ✅ |
| **V2-10** Tasks Kanban `#/tasks`: 6 أعمدة (جديدة/شغل مستمر/مراجعة/عند العميل/تعديلات/تم) · **سحب وإفلات** + أسهم ◀▶ للموبايل · فلاتر (مهامي/قسم/مشروع) · **مرفقات المهام** (رفع/معاينة صور/حذف/رابط) · 📎 على الكارت · client مرفوض server-side — 14 اختبار (455/455) | ✅ |
| **V2-11** بوابة العميل بالتوكن: `/client/project/TOKEN` **بدون تسجيل** (SPA fallback موجود) · `GET /api/tportal/:token` عام (project+designs مرئية+deliveries+tasks — من غير layers) · `POST /api/client-link` (admin/cs) يولد/يجدد توكن 48-hex · زر «🔗 لينك العميل» بصفحة المشروع + نسخ + توليد جديد (القديم يموت) · توكن غلط = 404 + صفحة خطأ · حسابات العملاء القديمة شغالة — 13 اختبار (468/468) | ✅ |
| **V2-12** صفحة العميل التفاعلية: معاينة **بعلامة مائية** (9 علامات + مصغرة) · **اعتماد** بمودال تأكيد + تسجيل في النشاط · **طلب تعديل** بملاحظات إجبارية + **مرفقات** (`POST /api/tportal/:token/upload` — 10MB، صور/PDF/ZIP فقط) · القرار مقيد بمشروع التوكن (تصميم خارجي 404) · أتمتة الاعتماد (تسليم/متابعة) تشتغل · **إصلاح جوهري: confirmDialog كان بيرجع إلغاء دايمًا** (close بينادي onClose قبل resolve) — 16 اختبار (484/484) | ✅ |
| **V2-13** صفحة «اطلب مشروع» العامة `/request`: 5 خدمات (تصميم/محتوى/فويس/موقع/سوشيال) · **فورم ديناميكي لكل خدمة** (services.js) + حقول مشتركة · تحقق client+server (إيميل/خانات) · `POST /api/requests/new` عام · الطلب يوصل CS ببيانات الاتصال والفورم · التحويل لمشروع **ينشئ/يطابق عميل بالإيميل** — 17 اختبار (501/501) | ✅ |
| **V2-14** i18n كامل AR/EN: شاشات V2 كلها bilingual (كانبان أعمدة/فلاتر · DMs · بروفايل · بوابة العميل · اطلب مشروع + labelEn لكل حقل) · مفاتيح ترجمة لأسماء السايدبار · **زر لغة في الصفحات العامة** + langchange re-render · RTL/LTR فوري ومحفوظ — 15 اختبار (516/516) | ✅ |
| **V2-15** Responsive + joystick: **joystick لمس** في المكتب (يظهر تلقائيًا على الأجهزة اللمسية، knob بيرجع مكانه) · درج السايدبار · الكانبان تمرير أفقي · مودالات 88vh · التوببار على الصغير (بحث يختفي/عنوان يتقص) · تابلت نظيف — **إصلاح: زر منيو الموبايل كان مخفي دايمًا** (قاعدة display:none بعد الميديا كويري) — 13 اختبار (529/529) | ✅ |
| **V2-16** الاختبار الشامل النهائي: 3 جولات متتالية (API 221 → E2E 310 → API بعد E2E 128) + pubcheck عام — **529/529** · تقرير الجاهزية `docs/V2-16-Final-Test-Report.md` | ✅ |
| **V2-E1** المحرر Priority 1: شريط قوائم علوي كامل (ملف/تحرير/عرض/طبقات/مساعدة — كله wired) + نظام رسم Vector كامل (فرشاة/ممحاة/تدرج — strokes محفوظة في المستند فتركب على undo/redo والحفظ والتصدير) + أدوات تحديد بكسل (مستطيل/حبل/عصا سحرية flood-fill بأقنعة) + تعبئة/مسح التحديد + اختصارات B/E/G/W — **38/38 E2e جديد** · الإصلاحات: clip-leak في scratch canvas + قوائم hidden — الرجعة الكاملة 788 فحص أخضر | ✅ |
| **V2-E2** المحرر Priority 2: فلاتر بكسلية جديدة (Sharpen convolution + Dodge/Burn luminance-aware + Invert) عبر مسار offscreen في drawLayer + أقنعة طبقات من التحديد (مستطيل/حبل/عصا — مع 🎭 في لوحة الطبقات) + أوضاع دمج بأسماء عربية (16 وضعًا كانوا موجودين محركًا) + استيراد صور من رابط + رفع متعدد الملفات + Crash Recovery (مسودة localStorage كل 15ث + beforeunload + شريط استعادة/تجاهل) — **27/27 E2E جديد** · الرجعة الكاملة 594 فحص أخضر | ✅ |
| **V2-E3** الهوية الختامية MEE M: نظام Tokens جديد بالكامل (أسود #08090d / أبيض #eef1f6 / فضي #a8b0c0 / أزرق كهربائي #0066ff + تدرج #0066ff→#7dd8ff) · إزالة البنفسجي القديم من 3 ملفات CSS + UI JS · الكلمة العلامة MEE M (لوجو M في الدخول والسايدبار · favicon · titles · MEE M Chat) بنفس الشكل في اللغتين — **21/21 E2E جديد** · الرجعة الكاملة 615 فحص أخضر — **بهذا اكتمل برنامج V2.0 بالكامل (V2-1..V2-16 + E1 + E2 + E3)** | ✅ |
| **V3-1** مكتب بيكسلي (Gather-look): عالم 2400×1700px بأرضيات مبلّطة (بلاط/سجاد/خشب/خرسانة/عشب) + جدران وأبواب بفتحات 90px + 61 قطعة أثاث SVG (مكاتب/كراسي/كنب/نباتات/أحواض/آلات قهوة/ثلاجات/بوردات/TV/رفوف/طاولات بينج بونج/طابعات) + شجر خارجي — أفاتار sprite (رأس حقيقي + جسم SVG) بحركة مشي bob واتجاه وجهين + لوحة اسم Gather (نقطة حالة + الاسم/«أنت») — كاميرا: افتراضي Fit (كل المكتب) + تكبير/تصغير (HUD/عجلة/قرص) ومتابعة عند التكبير — **17/17 E2E جديد (`test-v3-office-art-e2e.js`)** · الرجعية الكاملة خضراء (411 فحص E2E) — تحليل الفجوات: `docs/V3-Gather-Parity-Analysis.md` | ✅ |
| **V3-2** Proximity behavior: proximity engine (300px world) with a 'People near you' bar that opens a text DM + 12 interactive objects (department computers → each's board, break-room TV → works gallery, admin whiteboard role-restricted, coffee machine → break that automatically switches status to busy, asset cabinet, ping-pong/fridge/plants → emotes) + spatial speech bubbles that appear above the avatar and vanish with distance + badges 🎧 busy / ✍️ typing from DM / 🔒 private + 2 private meeting booths with an internal text channel isolated from outsiders + instant emote bar (👋👍🎉❤️) — **new 18/18 E2E (`test-v3-proximity-e2e.js`)** and full regression green | ✅ |
| **V3-3** المكتب القابل للبناء: Office Builder للأدمن/المالك (سحب أفات/غرف، تدوير ٩°، إضافة/حذف قطع، قسم جديد، حفظ في settings يعمّم على الكل + Reset) + طابقان بمبدّل (١: استقبال/تصميم/محتوى/صالة عملاء/استراحة/تسليمات + البوكسات — ٢: برمجة/فويس/خدمة عملاء/اجتماعات/إدارة) بعزل أفاتارات وقرب لكل طابق + Client Lounge: العميل يدخل المكتب من زر بالبوابة (رابط التوكن) بلوحة مشاريعه + مدير حسابه بزر 💬 + زر دعوة لاجتماع، ومقفول على الطابق ١ وغرف الفريق — **25/25 E2E جديد (`test-v3-builder-e2e.js`)** والرجعية كاملة خضراء · (توصيل القرب بالـ WebRTC المخفي ما زال مكبوتًا بقرار ساري) | ✅ |
| **V4-0** إصلاح العلل المُبلَّغة: «مهمة جديدة» كانت تنهار عند الفتح (appendChild على كائن) → مودال كامل يعمل من كل المداخل والمهام تُحفظ فعلًا · تحصين إضافة أعضاء المشاريع (state حديث + منع تكرار) · التحقق الكامل من دورة حياة الحساب (إنشاء/تعديل/باسورد/تعطيل≠حذف/تفعيل/منع دخول المعطّل) — **24/24 E2E جديد (`test-v4-fixes-e2e.js`)** · خطة المقر 3D (55 بندًا) في `docs/V4-Headquarters-Plan.md` | ✅ |
| **V4-1** المقر ثلاثي الأبعاد: three.js r149 vendor محلي (lazy) · المكتب 3D واجهة افتراضية fullscreen لكل الأدوار + تبديل محفوظ 2D⇄3D · غرف من التخطيط الحي للبنّاء (تحديث لحظي عند الحفظ) بجدران متصادمة وفتحات أبواب وأثاث متصادم وبوكسات · لافتات أقسام عربية/إنجليزية بـ LOD · أفاتار بفيزياء تصادم + كاميرا شخص ثالث (سحب/wheel) · WASD/أسهم + جويستيك لمس شفاف يظهر أثناء اللمس فقط (لا أزرار حركة سفلية) · برومبت دخول الأقسام بنفس صلاحيات 2D + نقر لافتة/أفاتار · طوابق ١/٢ بموضع محفوظ + مزامنة أفاتارات لحظية بنفس بروتوكول pos — **19/19 E2E جديد (`test-v4-3d-e2e.js`)** وسويتات 2D محوّلة صراحة | ✅ |
| **V4-2** الهوية والأفاتار: راوت `POST /api/look` (نفس الحساب فقط، حقول معقّمة) · محرر مظهر بالبروفايل بمعاينة SVG (نوع/6 بشرات/6 تسريحات/8 ألوان شعر/4 أطقم+ألوان/4 إكسسوارات) محفوظة server-side · الأفاتار 3D يتجسد بالهندسات ويتحدث لحظيًا (refresh-state) + سبرايت 2D ملوّن · صورة بروفايل مرفوعة بكل الأماكن بتحديث live · Onboarding موظف جديد (ترحيب+مظهر) بعلم `onboarded` + هجرة للحسابات القديمة — **17/17 E2E جديد (`test-v4-avatar-e2e.js`)** | ✅ |
| **V4-3** نظام مهام كامل: حالات To Do/Progress/Review/Completed/**Blocked** (عمود + كارت أحمر) · منفذون متعددون `assignees[]` مع توافق `assignee` القديم · خطوات فرعية بنسبة إنجاز · سجل عمل يدوي (ساعات+ملاحظة) مقابل ساعات تقديرية · مرفقات من مودال الإنشاء · اعتماد/طلب تعديلات في Review مع خط زمني للحدث · «مهامي» تحسب كل المنفذين · مهام قديمة تفتح بdefaults آمنة — **15/15 E2E (`test-v4-tasks-e2e.js`) + 7/7 API (`test-v4-tasks-api.js`)** | ✅ |
| **V4-4** المشاريع والعملاء: طلب مشروع من البوابة `POST /api/portal/request` (عملاء فقط) · قسم «طلباتي» بحالاته + سبب الرفض · رفض الإدارة بسبب يصل العميل · مدير ملفات المشروع (رفع/تحميل/تسمية/حذف/بحث/رافع+حجم) بتحديث في المكان + تبويب محفوظ · لافتة «المشاريع» 3D بنقر raycast حقيقي · تصفية server-side لطلبات العميل — **14/14 E2E (`test-v4-projects-e2e.js`) + 10/10 API (`test-v4-projects-api.js`)** | ✅ |
| **V4-5** التواصل: شات متقدم — تحميل أقدم (`GET /api/chat-history` before/limit + state أحدث 100) · unread badges · typing لحظي (`ctyping`) · ✓✓ مقروءة (`cread`) · رد/تعديل/حذف (server-side صاحبها أو أدمن) · ملفات بمعاينة · إيموجي · بحث فوري · **مركز إشعارات** (جرس+badge+لوحة: رسائل وتغيّرات حالة مهامك) · **كارت قرب 3D** بنقر raycast (اسم/دور/حالة + دردشة/بروفايل/**دعوة = اجتماع حقيقي + DM**) — **26/26 E2E (`test-v4-chat-e2e.js`) + 12/12 API (`test-v4-chat-api.js`)** | ✅ |
| **V4-6** مركز تحكم المالك: هوية الموقع في DB (اسم/وصف/لون/نصوص دخول/ثيم 3D — راوت عام `GET /api/brand` + تطبيق لحظي) · **مصفوفة صلاحيات 6×16 تُفرض server-side** (FORBIDDEN_GRANTS: settings/activity/users/chats — مقاومة IDOR) · سجل النشاط غير قابل للكتابة (خارج COLLECTIONS) · **Ctrl+K مركز أوامر** (صفحات/مشاريع/مهام/فريق) · ثيمات المكتب 3D (default/neon/warm/dark) — **11/11 E2E (`test-v4-owner-e2e.js`) + 11/11 API (`test-v4-owner-api.js`)** | ✅ |
| **V4-7** الأداء والاستجابة: Pooling مركزي لكل هندسات/خامات 3D (`__of3d.pool()`) · عدّاد FPS + جودة تكيفية (pixelRatio↓ عند <28fps) · Responsive مُثبت 4 مقاسات × الصفحات = صفر overflow · لمس (جوئيستيك أثناء اللمس فقط)/ماوس/كيبورد · `/api/state`=48ms — **15/15 E2E (`test-v4-perf-e2e.js`)** | ✅ |

**خارج النسخة الحالية (البنية جاهزة فقط):** Video/Camera/Screen Sharing · AI Assistant — يُفعَّلوا مستقبلًا بكلمة واحدة من لوحة المدير.

---

*MEEM Product Blueprint v2.0 — أي تعديل على المنتج يبدأ بتعديل هذه الوثيقة أولًا.*
