'use strict';
/* MEEM — مصفوفة الصلاحيات (V2-2)
 * المصدر الوحيد للحقيقة في "مين يعمل إيه" — يُفرض server-side على /api/mutate والـ endpoints الحساسة.
 * الأدوار: superadmin (مخفي، أعلى صلاحية) · admin (مدير عام) · designer · content · voice · dev · cs · editor · client
 */

const ROLES = ['superadmin', 'admin', 'designer', 'content', 'voice', 'dev', 'cs', 'editor', 'client'];

/* صلاحيات الكتابة (create/update) لكل collection حسب الدور.
 * delete = نفس النطاق + ملكية العنصر (أو admin/superadmin). */
const WRITE = {
  designer: ['designs', 'shoots', 'videos', 'assets', 'tasks', 'meetings', 'templates', 'timeentries'],
  content:  ['contents', 'prompts', 'articles', 'assets', 'tasks', 'meetings', 'timeentries'],
  voice:    ['voices', 'assets', 'tasks', 'meetings', 'timeentries'],
  dev:      ['bugs', 'videos', 'assets', 'tasks', 'meetings', 'timeentries'],
  cs:       ['clients', 'requests', 'projects', 'tasks', 'deliveries', 'assets', 'meetings', 'timeentries'],
  editor:   ['contents', 'voices', 'videos', 'assets', 'tasks', 'meetings', 'timeentries'],
};
/* admin/superadmin: كل حاجة (ماعدا activity — يسجله السيرفر فقط). client: ولا حاجة.
 * chats لغير الإدارة: ممنوع mutate — الشات من /api/chat فقط. */

const ADMIN_ONLY = ['invoices', 'payments', 'expenses', 'campaigns', 'settings'];

/* collections لا تُقرأ إلا للإدارة (تُخفى من /api/state للأدوار التانية) */
const READ_ADMIN_ONLY = ['invoices', 'payments', 'expenses', 'campaigns'];

/* حق قرار الاعتماد/طلب التعديل (design/doc lifecycle) */
const DECISION_ROLES = ['superadmin', 'admin', 'cs'];

function isSuper(user) { return user && user.role === 'superadmin'; }
function isAdmin(user) { return user && (user.role === 'admin' || user.role === 'superadmin'); }

/* V4-6: مصفوفة صلاحيات قابلة للتخصيص من الإعدادات — تُفرض server-side */
const FORBIDDEN_GRANTS = ['settings', 'activity', 'users', 'chats']; /* مينفعش تُمنح من المصفوفة أبدًا */
let dbRef = null;
function attach(db) { dbRef = db; }
function matrixFor(role) {
  const doc = dbRef && (dbRef.settings || []).find((x) => x.id === 'perms');
  const m = doc && doc.matrix && doc.matrix[role];
  return (m && typeof m === 'object') ? m : null;
}

/* هل الدور يملك كتابة على الـ collection؟ */
function canWrite(user, collection) {
  if (!user) return false;
  if (user.role === 'client') return false;
  if (isAdmin(user)) return collection !== 'activity';
  const m = matrixFor(user.role);
  if (m) {
    if (FORBIDDEN_GRANTS.includes(collection)) return false;
    if (typeof m[collection] === 'boolean') return m[collection];
  }
  return (WRITE[user.role] || []).includes(collection);
}

/* هل يملك حذف عنصر محدد؟ (نطاق كتابة + ملكية أو أدمن) */
const OWNER_FIELDS = ['by', 'owner', 'createdBy', 'reporter', 'userId'];
function canDelete(user, collection, doc) {
  if (!canWrite(user, collection)) return false;
  if (isAdmin(user)) return true;
  if (!doc) return false;
  if (collection === 'timeentries') return doc.userId === user.id || doc.createdBy === user.id;
  return OWNER_FIELDS.some((f) => doc[f] === user.id);
}

/* timeentries: الموظف يسجل لنفسه فقط */
function canWriteTimeentry(user, doc) {
  if (isAdmin(user)) return true;
  const mine = !doc.userId || doc.userId === user.id;
  return mine && !doc.id ? true : mine; // تعديل entry موجود بيتحقق منه canDelete/الملكية
}

/* V2-4: إدارة الحسابات — المالك + المدير العام (بقواعد تصعيد في server.js) */
function canManageUsers(user) { return user && (user.role === 'superadmin' || user.role === 'admin'); }

/* قرار اعتماد؟ */
function canDecide(user) { return user && DECISION_ROLES.includes(user.role); }

/* تصفية الـ state حسب الدور (دفاع إضافي بعد إخفاء الواجهات) */
function filterState(user, data) {
  if (!user || user.role === 'client') return data; // العملاء لهم تصفية أقوى موجودة في server.js
  if (isAdmin(user)) return data;
  for (const col of READ_ADMIN_ONLY) delete data[col];
  // إخفاء مفاتيح API الحساسة من الإعدادات
  if (Array.isArray(data.settings)) {
    data.settings = data.settings.map((s) => {
      if (s && (s.id === 'ai' || s.apiKey || s.key)) {
        const { key, apiKey, ...rest } = s;
        return Object.assign({}, rest, { hasKey: !!(key || apiKey) });
      }
      return s;
    });
  }
  return data;
}

module.exports = { ROLES, WRITE, attach, FORBIDDEN_GRANTS, ADMIN_ONLY, READ_ADMIN_ONLY, DECISION_ROLES, isSuper, isAdmin, canWrite, canDelete, canWriteTimeentry, canManageUsers, canDecide, filterState };
