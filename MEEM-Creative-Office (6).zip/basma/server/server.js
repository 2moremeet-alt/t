'use strict';
/**
 * MEEM | Creative Office
 * سيرفر بدون أي مكتبات خارجية: HTTP static + REST API + WebSocket (signaling للاجتماعات + بث التحديثات)
 *   node server/server.js
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const store = require('./store');
const perms = require('./perms');
const { seed, phase3migrate, phase4seed, phase5seed, phase6seed, phase7seed, v2seed } = require('./seed');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const UPLOAD_DIR = path.join(__dirname, '..', 'data', 'uploads');
try { fs.mkdirSync(UPLOAD_DIR, { recursive: true }); } catch (e) {}

/* ============================ WebSocket من الصفر ============================ */

const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
/** @type {Set<WSClient>} */
const clients = new Set();
/* V2-3: ids المستخدمين المتصلين حاليًا (للداشبورد والمكتب الافتراضي) */
const onlineIds = () => [...new Set([...clients].map((c) => c.userId).filter(Boolean))];

class WSClient {
  constructor(socket, req) {
    this.socket = socket;
    this.alive = true;
    this.buf = Buffer.alloc(0);
    this.userId = null;
    this.room = null;
    this.name = null;
    const u = new URL(req.url, 'http://localhost');
    this.token = u.searchParams.get('token') || '';
    this.clientId = u.searchParams.get('cid') || crypto.randomBytes(4).toString('hex');
    socket.setNoDelay(true);
  }

  send(obj) {
    if (!this.alive) return;
    try {
      const payload = Buffer.from(JSON.stringify(obj), 'utf8');
      this.socket.write(encodeFrame(payload, 0x1));
    } catch (e) { /* ignore */ }
  }

  close(code, reason) {
    try {
      const body = Buffer.from([(code >> 8) & 0xff, code & 0xff], 'binary');
      const r = Buffer.from(reason || '', 'utf8');
      this.socket.write(encodeFrame(Buffer.concat([body, r]), 0x8));
    } catch (e) { /* ignore */ }
    this.socket.end();
  }
}

function encodeFrame(payload, opcode) {
  const len = payload.length;
  let header;
  if (len < 126) {
    header = Buffer.alloc(2);
    header[1] = len;
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[1] = 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  header[0] = 0x80 | opcode;
  return Buffer.concat([header, payload]);
}

function decodeFrames(client) {
  const out = [];
  let buf = client.buf;
  while (true) {
    if (buf.length < 2) break;
    const b0 = buf[0], b1 = buf[1];
    const fin = (b0 & 0x80) !== 0;
    const opcode = b0 & 0x0f;
    const masked = (b1 & 0x80) !== 0;
    let len = b1 & 0x7f;
    let off = 2;
    if (len === 126) {
      if (buf.length < off + 2) break;
      len = buf.readUInt16BE(off); off += 2;
    } else if (len === 127) {
      if (buf.length < off + 8) break;
      len = Number(buf.readBigUInt64BE(off)); off += 8;
    }
    let mask = null;
    if (masked) {
      if (buf.length < off + 4) break;
      mask = buf.subarray(off, off + 4); off += 4;
    }
    if (buf.length < off + len) break;
    let payload = buf.subarray(off, off + len);
    if (mask) {
      const p = Buffer.allocUnsafe(len);
      for (let i = 0; i < len; i++) p[i] = payload[i] ^ mask[i & 3];
      payload = p;
    }
    buf = buf.subarray(off + len);
    out.push({ fin, opcode, payload });
  }
  client.buf = buf;
  return out;
}

function canChat(user, room) {
  if (!user || !room) return false;
  /* V2-9: الرسائل المباشرة dm:id1:id2 — للطرفين فقط (خصوصية server-side) */
  if (room.startsWith('dm:')) {
    const ids = room.split(':').slice(1);
    return user.role !== 'client' && ids.length === 2 && ids.includes(user.id);
  }
  if (user.role !== 'client') return true;
  if (room === 'cli:' + user.clientId) return true;
  if (room.startsWith('prj:')) {
    const prj = (store.db.projects || []).find((p) => p.id === room.slice(4));
    return !!prj && prj.clientId === user.clientId;
  }
  return false;
}

function broadcast(obj, filter) {
  const msg = typeof obj === 'string' ? obj : JSON.stringify(obj);
  for (const c of clients) {
    if (!c.alive) continue;
    if (filter && !filter(c)) continue;
    try { c.socket.write(encodeFrame(Buffer.from(msg, 'utf8'), 0x1)); } catch (e) { /* ignore */ }
  }
}

function toRoom(room, obj, except) {
  for (const c of clients) {
    if (c.room !== room || !c.alive) continue;
    if (except && c.clientId === except) continue;
    c.send(obj);
  }
}

function roomRoster(room) {
  const seen = new Map();
  for (const c of clients) {
    if (c.room !== room || !c.alive) continue;
    seen.set(c.clientId, {
      clientId: c.clientId,
      userId: c.userId,
      name: c.name,
      role: c.role || '',
      color: c.color || '#7c5cff',
    });
  }
  return [...seen.values()];
}

/* ============================ HTTP helpers ============================ */

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.mp3': 'audio/mpeg',
  '.wav': 'audio/wav',
  '.ogg': 'audio/ogg',
  '.pdf': 'application/pdf',
  '.mp4': 'video/mp4',
  '.webm': 'video/webm',
  '.mov': 'video/quicktime',
  '.m4a': 'audio/mp4',
  '.weba': 'audio/webm',
  '.map': 'application/json; charset=utf-8',
};

function sendJSON(res, code, obj) {
  const body = Buffer.from(JSON.stringify(obj), 'utf8');
  res.writeHead(code, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const max = limit || 24 * 1024 * 1024; // 24MB (صور/أصوات base64)
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > max) {
        reject(new Error('payload too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function readBodyRaw(req, limit) {
  return new Promise((resolve, reject) => {
    const max = limit || 40 * 1024 * 1024;
    const chunks = [];
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > max) {
        reject(new Error('payload too large'));
        req.destroy();
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function tokenOf(req) {
  const h = req.headers['authorization'] || '';
  if (h.startsWith('Bearer ')) return h.slice(7).trim();
  try {
    const cookies = {};
    (req.headers.cookie || '').split(';').forEach((p) => {
      const i = p.indexOf('=');
      if (i > 0) cookies[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
    });
    return cookies.basma_token || '';
  } catch (e) { return ''; }
}

function authUser(req) {
  const t = tokenOf(req);
  if (!t) return null;
  return store.tokenUser(t);
}

function serveStatic(req, res, urlPath) {
  let p = decodeURIComponent(urlPath.split('?')[0]);
  if (p === '/' || p === '') p = '/index.html';
  const full = path.normalize(path.join(PUBLIC_DIR, p));
  if (!full.startsWith(PUBLIC_DIR)) {
    res.writeHead(403).end('forbidden');
    return;
  }
  fs.stat(full, (err, st) => {
    if (err || !st.isFile()) {
      // SPA fallback
      const fallback = path.join(PUBLIC_DIR, 'index.html');
      fs.readFile(fallback, (e2, data) => {
        if (e2) { res.writeHead(404).end('not found'); return; }
        res.writeHead(200, { 'Content-Type': MIME['.html'] });
        res.end(data);
      });
      return;
    }
    const ext = path.extname(full).toLowerCase();
    const type = MIME[ext] || 'application/octet-stream';
    const stream = fs.createReadStream(full);
    res.writeHead(200, {
      'Content-Type': type,
      'Content-Length': st.size,
      'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=300',
    });
    stream.pipe(res);
  });
}

/* ============================ REST API ============================ */

async function handleAPI(req, res, url) {
  const route = url.pathname.replace(/^\/api\/?/, '');
  const parts = route.split('/').filter(Boolean);
  const method = req.method.toUpperCase();

  /* ---- auth ---- */
  if (parts[0] === 'login' && method === 'POST') {
    const body = JSON.parse((await readBody(req, 64 * 1024)) || '{}');
    // قبول الإيميلات القديمة (@basma.studio) كاسم مستعار بعد إعادة التسمية إلى MEEM
    const emailNorm = String(body.email || '').trim().toLowerCase().replace(/@basma\.studio$/, '@meem.studio');
    const user = store.findByEmail(emailNorm);
    if (user && user.active === false) {
      return sendJSON(res, 403, { ok: false, error: 'الحساب معطّل — راجع الإدارة', errorEn: 'Account disabled' });
    }
    if (!user || user.passwordHash !== store.sha256(body.password || '')) {
      return sendJSON(res, 401, { ok: false, error: 'بيانات الدخول غير صحيحة', errorEn: 'Invalid email or password' });
    }
    const token = store.createToken(user.id);
    res.setHeader('Set-Cookie', `basma_token=${token}; Path=/; Max-Age=2592000; SameSite=Lax`);
    store.log(user.id, `${user.name} سجّل الدخول`, `${user.nameEn} signed in`);
    store.save();
    return sendJSON(res, 200, { ok: true, token, user: store.publicUser(user) });
  }

  if (parts[0] === 'logout' && method === 'POST') {
    const t = tokenOf(req);
    if (t) delete store.db.tokens[t];
    store.save();
    res.setHeader('Set-Cookie', 'basma_token=; Path=/; Max-Age=0; SameSite=Lax');
    return sendJSON(res, 200, { ok: true });
  }

  if (parts[0] === 'me') {
    const u = authUser(req);
    if (!u) return sendJSON(res, 401, { ok: false, error: 'غير مسجّل الدخول', errorEn: 'Not authenticated' });
    return sendJSON(res, 200, { ok: true, user: store.publicUser(u) });
  }

  /* ---- روابط اعتماد العميل (عامة بدون تسجيل دخول) ---- */
  if (parts[0] === 'share' && parts[1]) {
    const d = (store.db.designs || []).find((x) => x.share && x.share.token === parts[1] && !x.share.revoked);
    if (!d) return sendJSON(res, 404, { ok: false, error: 'الرابط غير صالح أو تم إيقافه', errorEn: 'Invalid or revoked link' });
    if (method === 'GET') {
      return sendJSON(res, 200, {
        ok: true,
        title: d.title,
        status: d.status,
        watermark: true,
        office: 'MEEM Creative Office',
        client: d.client || null,
        pages: d.pages || [],
        updatedAt: d.updatedAt,
      });
    }
    if (method === 'POST') {
      let body;
      try { body = JSON.parse((await readBody(req, 64 * 1024)) || '{}'); }
      catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح', errorEn: 'Invalid JSON' }); }
      const name = String(body.name || '').trim().slice(0, 60) || 'العميل';
      const decision = body.decision === 'changes' ? 'changes' : 'approve';
      const note = String(body.note || '').slice(0, 600);
      if (decision === 'changes' && !note) {
        return sendJSON(res, 400, { ok: false, error: 'اكتب ملاحظاتك عشان نعرف نعدّل إيه', errorEn: 'Please add your notes' });
      }
      d.client = { name, decision, note, at: store.nowISO(), via: 'link' };
      d.status = decision === 'approve' ? 'client_approved' : 'changes';
      store.log(null, `${name} (${decision === 'approve' ? 'اعتمد' : 'طلب تعديل على'}) تصميم «${d.title}»`,
        `${name} ${decision === 'approve' ? 'approved' : 'requested changes on'} "${d.title}"`, { designId: d.id });
      store.save();
      broadcast({ type: 'sync', collection: 'designs', op: 'upsert', doc: stripDesignPayload(d) });
      runAutomation(decision === 'approve' ? 'client_approved' : 'client_changes', { design: d, user: null });
      return sendJSON(res, 200, { ok: true, decision, status: d.status });
    }
  }

  /* ---- V2-11: بوابة العميل بالتوكن — عام بدون تسجيل ---- */
  if (parts[0] === 'tportal' && parts[1] && method === 'GET') {
    const token = String(parts[1]).slice(0, 64);
    const prj = (store.db.projects || []).find((x) => x.clientToken && x.clientToken === token);
    if (!prj) return sendJSON(res, 404, { ok: false, error: 'اللينك غير صالح أو منتهي', errorEn: 'Invalid or expired link' });
    const client = (store.db.clients || []).find((c) => c.id === prj.clientId);
    const designs = (store.db.designs || []).filter((d) => d.projectId === prj.id && ['client', 'client_approved', 'client_changes', 'approved', 'delivered'].includes(d.status)).map(stripDesignPayload);
    const deliveries = (store.db.deliveries || []).filter((x) => x.projectId === prj.id);
    const tasks = (store.db.tasks || []).filter((x) => x.projectId === prj.id).map((x) => ({ id: x.id, title: x.title, type: x.type, status: x.status, due: x.due }));
    return sendJSON(res, 200, {
      ok: true,
      data: {
        project: { id: prj.id, title: prj.title, titleEn: prj.titleEn, type: prj.type, status: prj.status, due: prj.due },
        clientName: client ? client.name : '',
        clientNameEn: client ? client.nameEn : '',
        designs, deliveries, tasks,
      },
    });
  }

  /* V2-12: رفع مرفقات طلب التعديل — عام لكن مقيد بالتوكن والحجم والنوع */
  if (parts[0] === 'tportal' && parts[1] && parts[2] === 'upload' && method === 'POST') {
    const prj = (store.db.projects || []).find((x) => x.clientToken && x.clientToken === String(parts[1]).slice(0, 64));
    if (!prj) return sendJSON(res, 404, { ok: false, error: 'اللينك غير صالح', errorEn: 'Invalid link' });
    const raw = await readBodyRaw(req, 10 * 1024 * 1024);
    if (!raw || !raw.length) return sendJSON(res, 400, { ok: false, error: 'ملف فاضي' });
    const nameParam = String(url.searchParams.get('name') || 'file.bin');
    const ext = (path.extname(nameParam).toLowerCase().match(/^\.(png|jpe?g|webp|gif|pdf|zip|docx?)$/) || [null])[0];
    if (!ext) return sendJSON(res, 400, { ok: false, error: 'نوع الملف مرفوض (صور/PDF/ZIP فقط)', errorEn: 'File type not allowed' });
    const id = 'upl_' + crypto.randomBytes(6).toString('hex');
    fs.mkdirSync(UPLOAD_DIR, { recursive: true });
    fs.writeFileSync(path.join(UPLOAD_DIR, id + ext), raw);
    return sendJSON(res, 200, { ok: true, id, url: '/uploads/' + id + ext, size: raw.length });
  }

  /* V2-12: قرار العميل (اعتماد/طلب تعديل) من البوابة الآمنة */
  if (parts[0] === 'tportal' && parts[1] && parts[2] === 'decision' && method === 'POST') {
    const prj = (store.db.projects || []).find((x) => x.clientToken && x.clientToken === String(parts[1]).slice(0, 64));
    if (!prj) return sendJSON(res, 404, { ok: false, error: 'اللينك غير صالح', errorEn: 'Invalid link' });
    let body;
    try { body = JSON.parse((await readBody(req, 64 * 1024)) || '{}'); } catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح' }); }
    const d = (store.db.designs || []).find((x) => x.id === body.designId && x.projectId === prj.id);
    if (!d) return sendJSON(res, 404, { ok: false, error: 'التصميم مش تابع للمشروع ده' });
    const decision = body.decision === 'changes' ? 'changes' : 'approve';
    const note = String(body.note || '').slice(0, 600);
    if (decision === 'changes' && !note) {
      return sendJSON(res, 400, { ok: false, error: 'اكتب ملاحظاتك عشان نعرف نعدّل إيه', errorEn: 'Please add your notes' });
    }
    const files = Array.isArray(body.files) ? body.files.slice(0, 8).filter((f) => f && typeof f.url === 'string' && f.url.startsWith('/uploads/')).map((f) => ({ name: String(f.name || 'ملف').slice(0, 80), url: f.url })) : [];
    const client = (store.db.clients || []).find((c) => c.id === prj.clientId);
    const cname = client ? client.name : 'العميل';
    d.client = { name: cname, decision, note, files, at: store.nowISO(), via: 'portal-token' };
    d.status = decision === 'approve' ? 'client_approved' : 'changes';
    store.log(null, `${cname} ${decision === 'approve' ? 'اعتمد' : 'طلب تعديل على'} تصميم «${d.title}»${files.length ? ` (+${files.length} مرفق)` : ''}`,
      `${cname} ${decision === 'approve' ? 'approved' : 'requested changes on'} "${d.title}"`, { designId: d.id });
    store.save();
    broadcast({ type: 'sync', collection: 'designs', op: 'upsert', doc: stripDesignPayload(d) });
    runAutomation(decision === 'approve' ? 'client_approved' : 'client_changes', { design: d, user: null });
    return sendJSON(res, 200, { ok: true, decision, status: d.status });
  }

  /* ---- V2-13: طلب مشروع من الموقع العام (بدون تسجيل) ---- */
  if (parts[0] === 'requests' && parts[1] === 'new' && method === 'POST') {
    let body;
    try { body = JSON.parse((await readBody(req, 32 * 1024)) || '{}'); } catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح' }); }
    const service = String(body.service || '').slice(0, 24);
    const form = (body.form && typeof body.form === 'object') ? body.form : {};
    const clean = {};
    for (const [k, v] of Object.entries(form)) clean[String(k).slice(0, 40)] = String(v == null ? '' : v).slice(0, 2000);
    if (!clean.name || !clean.email || !clean.phone || !clean.details || !service) {
      return sendJSON(res, 400, { ok: false, error: 'كمل الخانات المطلوبة (الاسم/الإيميل/الموبايل/التفاصيل/الخدمة)', errorEn: 'Missing required fields' });
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(clean.email)) {
      return sendJSON(res, 400, { ok: false, error: 'الإيميل مش صح', errorEn: 'Invalid email' });
    }
    const SVC_AR = { design: 'تصميم جرافيك', content: 'كتابة محتوى', voice: 'فويس أوفر', dev: 'موقع/تطبيق', social: 'إدارة سوشيال ميديا' };
    if (!SVC_AR[service]) return sendJSON(res, 400, { ok: false, error: 'خدمة مش معروفة' });
    const doc = {
      id: 'req_' + crypto.randomBytes(6).toString('hex'),
      title: SVC_AR[service] + ' — ' + (clean.company || clean.name),
      service, form: clean, clientId: null,
      contact: { name: clean.name, email: clean.email, phone: clean.phone, company: clean.company || '' },
      channel: 'web', notes: clean.details, priority: 'medium', status: 'new', assignee: '',
      createdAt: new Date().toISOString(),
    };
    store.db.requests = store.db.requests || [];
    store.db.requests.unshift(doc);
    store.log(null, `طلب جديد من الموقع: ${doc.title}`, 'New public request: ' + doc.title);
    store.save();
    broadcast({ type: 'sync', collection: 'requests', op: 'upsert', doc });
    broadcast({ type: 'refresh-state' });
    return sendJSON(res, 200, { ok: true, id: doc.id });
  }

  /* ---- V4-6: الهوية العامة (بدون تسجيل — لصفحة الدخول) ---- */
  if (parts[0] === 'brand' && method === 'GET') {
    const b = (store.db.settings || []).find((x) => x.id === 'brand') || {};
    return sendJSON(res, 200, { ok: true, brand: { siteName: b.siteName || 'MEE M', tagline: b.tagline || '', primary: b.primary || '#3d8bff', loginTitle: b.loginTitle || '', loginSub: b.loginSub || '' } });
  }

  /* ---- من هنا لازم يكون مسجّل ---- */
  const user = authUser(req);
  if (!user) return sendJSON(res, 401, { ok: false, error: 'الجلسة منتهية، سجّل الدخول من جديد', errorEn: 'Session expired' });

  /* V2-11: توليد/جلب لينك العميل للمشروع (إدارة/CS) */
  if (parts[0] === 'client-link' && method === 'POST') {
    if (!['admin', 'superadmin', 'cs'].includes(user.role)) {
      return sendJSON(res, 403, { ok: false, error: 'للإدارة وخدمة العملاء فقط', errorEn: 'Admin/CS only' });
    }
    let body;
    try { body = JSON.parse((await readBody(req, 16 * 1024)) || '{}'); } catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح' }); }
    const prj = (store.db.projects || []).find((x) => x.id === body.projectId);
    if (!prj) return sendJSON(res, 404, { ok: false, error: 'المشروع مش موجود' });
    if (!prj.clientToken || body.regenerate) {
      prj.clientToken = crypto.randomBytes(24).toString('hex');
      store.log(user.id, `أنشأ لينك عميل لمشروع ${prj.title}`, 'Generated client link for ' + prj.title);
      store.save();
      broadcast({ type: 'sync', collection: 'projects', op: 'upsert', doc: prj });
    }
    return sendJSON(res, 200, { ok: true, token: prj.clientToken, url: '/client/project/' + prj.clientToken });
  }

  /* ---- V4-4: طلب مشروع جديد من بوابة العميل (حساب عميل مسجّل) ---- */
  if (parts[0] === 'portal' && parts[1] === 'request' && method === 'POST') {
    if (user.role !== 'client') return sendJSON(res, 403, { ok: false, error: 'بوابة الطلبات لحسابات العملاء', errorEn: 'Client accounts only' });
    let body;
    try { body = JSON.parse((await readBody(req, 32 * 1024)) || '{}'); } catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح' }); }
    const SVC_AR = { design: 'تصميم جرافيك', content: 'كتابة محتوى', voice: 'فويس أوفر', dev: 'موقع/تطبيق', social: 'إدارة سوشيال ميديا' };
    const service = String(body.service || '').slice(0, 24);
    if (!SVC_AR[service]) return sendJSON(res, 400, { ok: false, error: 'خدمة مش معروفة', errorEn: 'Unknown service' });
    const details = String(body.details || '').trim().slice(0, 2000);
    if (!details) return sendJSON(res, 400, { ok: false, error: 'اكتب تفاصيل الطلب', errorEn: 'Details required' });
    const cl = (store.db.clients || []).find((c) => c.id === user.clientId) || {};
    const doc = {
      id: 'req_' + crypto.randomBytes(6).toString('hex'),
      title: SVC_AR[service] + ' — ' + (cl.name || user.name || ''),
      service, form: { name: user.name || '', email: user.email || '', phone: String(body.phone || cl.phone || '').slice(0, 40), details },
      clientId: user.clientId || null,
      contact: { name: user.name || '', email: user.email || '', phone: String(body.phone || cl.phone || ''), company: cl.name || '' },
      channel: 'portal', notes: details, priority: ['low', 'medium', 'high'].includes(body.priority) ? body.priority : 'medium',
      status: 'new', assignee: '',
      createdAt: new Date().toISOString(),
    };
    store.db.requests = store.db.requests || [];
    store.db.requests.unshift(doc);
    store.log(user.id, `طلب جديد من البوابة: ${doc.title}`, 'New portal request: ' + doc.title);
    store.save();
    broadcast({ type: 'sync', collection: 'requests', op: 'upsert', doc });
    broadcast({ type: 'refresh-state' });
    return sendJSON(res, 200, { ok: true, id: doc.id });
  }

  if (parts[0] === 'state' && method === 'GET') {
    const data = {
        users: store.db.users.map(store.publicUser),
        clients: store.db.clients,
        projects: store.db.projects,
        tasks: store.db.tasks,
        designs: (store.db.designs || []).map(stripDesignPayload),
        deliveries: store.db.deliveries,
        meetings: store.db.meetings,
        assets: (store.db.assets || []).map((a) => ({ id: a.id, name: a.name, type: a.type, tags: a.tags, size: a.size, createdAt: a.createdAt })),
        invoices: store.db.invoices,
        templates: store.db.templates || [],
        settings: store.db.settings || [],
        requests: store.db.requests || [],
        contents: store.db.contents || [],
        videos: store.db.videos || [],
        shoots: store.db.shoots || [],
        bugs: store.db.bugs || [],
        payments: store.db.payments || [],
        expenses: store.db.expenses || [],
        timeentries: store.db.timeentries || [],
        campaigns: store.db.campaigns || [],
        prompts: store.db.prompts || [],
        articles: store.db.articles || [],
        chats: (store.db.chats || []).filter((m) => !String(m.room).startsWith('dm:') || canChat(user, m.room)).slice(-100), /* V4-5: أحدث 100 — الأقدم عبر chat-history */
        voices: (store.db.voices || []).map(stripVoicePayload),
        activity: (store.db.activity || []).slice(0, 60),
    };

    /* V2-2: تصفية حسب الدور (إخفاء الماليات والمفاتيح عن غير الإدارة) */
    if (user.role !== 'client') perms.filterState(user, data);
    /* V2-3: المالك المخفي عن الجميع + قائمة المتصلين */
    if (user.role !== 'superadmin') data.users = (data.users || []).filter((u) => u.role !== 'superadmin');
    data.online = onlineIds();

    /* بوابة العميل: يشوف شغله هو بس */
    if (user.role === 'client') {
      const cid = user.clientId;
      const myPrj = (data.projects || []).filter((p) => p.clientId === cid).map((p) => p.id);
      data.projects = (data.projects || []).filter((p) => p.clientId === cid);
      data.tasks = (data.tasks || []).filter((t) => myPrj.includes(t.projectId));
      data.designs = (data.designs || []).filter((d) => d.clientId === cid);
      data.deliveries = (data.deliveries || []).filter((d) => d.clientId === cid);
      data.clients = (data.clients || []).filter((c) => c.id === cid);
      /* V4-4: العميل يشوف طلباته هو فقط (حقول محدودة) */
      data.requests = (data.requests || [])
        .filter((r) => (r.clientId && r.clientId === cid) || (r.contact && user.email && r.contact.email === user.email))
        .map((r) => ({ id: r.id, title: r.title, service: r.service, status: r.status, priority: r.priority, rejectReason: r.rejectReason || '', projectId: r.projectId || '', createdAt: r.createdAt }));
      data.invoices = [];
      data.templates = [];
      data.contents = [];
      data.voices = [];
      data.videos = (data.videos || []).filter((v) => myPrj.includes(v.projectId));
      data.shoots = [];
      data.bugs = [];
      data.payments = [];
      data.expenses = [];
      data.timeentries = [];
      data.campaigns = [];
      data.prompts = [];
      data.articles = [];
      data.chats = (data.chats || []).filter((m) => canChat(user, m.room));
      data.users = (data.users || []).filter((u) => u.id === user.id || u.role !== 'client');
    }

    return sendJSON(res, 200, { ok: true, user: store.publicUser(user), data });
  }

  /* ---- V2-4 (§32): تغيير كلمة المرور الذاتية — بالباسورد الحالي ---- */
  if (parts[0] === 'password' && method === 'POST') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); }
    catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح', errorEn: 'Invalid JSON' }); }
    if (user.passwordHash !== store.sha256(String(body.current || ''))) {
      return sendJSON(res, 403, { ok: false, error: 'كلمة المرور الحالية غلط', errorEn: 'Current password is incorrect' });
    }
    if (String(body.next || '').length < 6) {
      return sendJSON(res, 400, { ok: false, error: 'كلمة المرور الجديدة قصيرة (6+)', errorEn: 'New password too short (6+)' });
    }
    user.passwordHash = store.sha256(String(body.next));
    store.log(user.id, 'غيّر كلمة مروره', 'Changed own password');
    store.save();
    return sendJSON(res, 200, { ok: true });
  }

  /* ---- V2-3: إدارة المستخدمين — المالك المخفي فقط (V2-4 هتوسعها للأدمن) ---- */
  if (parts[0] === 'user' && method === 'POST') {
    if (!perms.canManageUsers(user)) return sendJSON(res, 403, { ok: false, error: 'إدارة الحسابات للإدارة فقط', errorEn: 'User management: management only' });
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); }
    catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح', errorEn: 'Invalid JSON' }); }
    const ALLOWED = ['name', 'nameEn', 'email', 'title', 'titleEn', 'phone', 'avatarColor', 'initials', 'role', 'active'];
    let target;
    if (body.id) {
      target = store.findById(body.id);
      if (!target) return sendJSON(res, 404, { ok: false, error: 'الحساب غير موجود', errorEn: 'User not found' });
      /* V2-4: الأدمن ما يلمسش الحسابات المميزة (admin/superadmin) ولا يرقّي نفسه */
      if (!perms.isSuper(user) && (target.role === 'superadmin' || target.role === 'admin')) {
        return sendJSON(res, 403, { ok: false, error: 'الحسابات الإدارية للمالك فقط', errorEn: 'Privileged accounts: owner only' });
      }
      if (!perms.isSuper(user) && (body.role === 'superadmin' || body.role === 'admin')) {
        return sendJSON(res, 403, { ok: false, error: 'الترقية لأدوار إدارية للمالك فقط', errorEn: 'Role escalation: owner only' });
      }
      for (const f of ALLOWED) if (body[f] !== undefined) target[f] = body[f];
      if (body.email) target.email = String(body.email).toLowerCase();
      if (body.password) target.passwordHash = store.sha256(String(body.password));
    } else {
      if (!body.email || !body.name) return sendJSON(res, 400, { ok: false, error: 'الاسم والإيميل مطلوبين', errorEn: 'Name and email required' });
      /* V2-4: الأدمن ما ينشئش حسابات مميزة */
      if (!perms.isSuper(user) && (body.role === 'superadmin' || body.role === 'admin')) {
        return sendJSON(res, 403, { ok: false, error: 'إنشاء الحسابات الإدارية للمالك فقط', errorEn: 'Creating privileged accounts: owner only' });
      }
      const email = String(body.email).toLowerCase();
      if (store.findByEmail(email)) return sendJSON(res, 400, { ok: false, error: 'الإيميل مستخدم بالفعل', errorEn: 'Email already in use' });
      target = store.createUser({
        name: body.name, nameEn: body.nameEn, email, password: body.password || '123456',
        role: body.role === 'superadmin' ? 'superadmin' : (perms.ROLES.includes(body.role) ? body.role : 'designer'),
        title: body.title || '', titleEn: body.titleEn || '', phone: body.phone || '',
        avatarColor: body.avatarColor, initials: body.initials, active: body.active !== false, clientId: body.clientId || null,
      });
    }
    store.log(user.id, `إدارة حساب: ${target.name}`, `Managed user account: ${target.name}`);
    store.save();
    broadcast({ type: 'refresh-state' });
    return sendJSON(res, 200, { ok: true, user: store.publicUser(target) });
  }

  /* ---- V4-2: مظهر الأفاتار + صورة البروفايل + Onboarding — لنفس الحساب فقط ---- */
  if (parts[0] === 'look' && method === 'POST') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); }
    catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح', errorEn: 'Invalid JSON' }); }
    const u = user;
    const hex = (v) => typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v);
    const str = (v, n) => String(v).slice(0, n);
    if (body.avatar && typeof body.avatar === 'object') {
      const A = body.avatar, clean = Object.assign({}, u.avatar || {});
      if (A.gender === 'm' || A.gender === 'f') clean.gender = A.gender;
      if (hex(A.skin)) clean.skin = A.skin;
      if (A.hair) clean.hair = str(A.hair, 12);
      if (hex(A.hairColor)) clean.hairColor = A.hairColor;
      if (A.outfit) clean.outfit = str(A.outfit, 12);
      if (hex(A.outfitColor)) clean.outfitColor = A.outfitColor;
      if (A.accessory) clean.accessory = str(A.accessory, 12);
      u.avatar = clean;
    }
    if (typeof body.photo === 'string' && (body.photo === '' || body.photo.startsWith('/uploads/'))) u.photo = body.photo;
    if (body.onboarded === true) u.onboarded = true;
    store.log(u.id, `حدّث مظهره في المكتب`, `Updated office look`);
    store.save();
    broadcast({ type: 'refresh-state' });
    return sendJSON(res, 200, { ok: true, user: store.publicUser(u) });
  }

  // تعديل عام: { collection, doc } | { collection, id }
  if (parts[0] === 'mutate' && method === 'POST') {
    let body;
    try { body = JSON.parse((await readBody(req)) || '{}'); }
    catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح', errorEn: 'Invalid JSON' }); }
    const { op = 'upsert', collection, doc, id } = body;
    if (!store.COLLECTIONS.includes(collection)) {
      return sendJSON(res, 400, { ok: false, error: 'collection غير معروفة', errorEn: 'Unknown collection' });
    }
    if (user.role === 'client') {
      return sendJSON(res, 403, { ok: false, error: 'حساب العميل للاطلاع والاعتماد فقط', errorEn: 'Client accounts are read/approve only' });
    }
    /* ---- V2-2: مصفوفة الصلاحيات تُفرض server-side ---- */
    if (!perms.canWrite(user, collection)) {
      return sendJSON(res, 403, { ok: false, error: 'مفيش صلاحية للتعديل على ' + collection, errorEn: 'Permission denied: ' + collection });
    }
    /* V2-3: مفاتيح الأدوات (فيديو/AI) للمالك المخفي فقط */
    if (collection === 'settings' && ((doc && doc.id === 'tools') || (op === 'delete' && id === 'tools')) && !perms.isSuper(user)) {
      return sendJSON(res, 403, { ok: false, error: 'إعدادات الأدوات للمالك فقط', errorEn: 'Tools settings: owner only' });
    }
    if (collection === 'timeentries' && !perms.isAdmin(user)) {
      const target = doc && doc.id ? (store.db.timeentries || []).find((x) => x.id === doc.id) : null;
      const ownerMismatch = (doc && doc.userId && doc.userId !== user.id) ||
        (target && target.userId !== user.id && target.createdBy !== user.id);
      if (ownerMismatch) {
        return sendJSON(res, 403, { ok: false, error: 'تسجيل الوقت يكون لنفسك فقط', errorEn: 'You can only log your own time' });
      }
    }
    if (op === 'delete') {
      const existing = (store.db[collection] || []).find((x) => x.id === id);
      if (!perms.canDelete(user, collection, existing)) {
        return sendJSON(res, 403, { ok: false, error: 'مفيش صلاحية لحذف العنصر ده', errorEn: 'Delete permission denied' });
      }
      const removed = store.remove(collection, id);
      store.log(user.id, `حذف عنصر من ${collection}`, `Deleted from ${collection}`);
      store.save();
      broadcast({ type: 'sync', collection, op: 'delete', id });
      return sendJSON(res, 200, { ok: true, removed });
    }
    if (op === 'bulk') {
      const saved = (doc || []).map((d) => store.upsert(collection, d));
      store.save();
      const bulkOut = collection === 'designs' ? saved.map(stripDesignPayload) : collection === 'voices' ? saved.map(stripVoicePayload) : saved;
      broadcast({ type: 'sync', collection, op: 'bulk', docs: bulkOut });
      return sendJSON(res, 200, { ok: true, docs: bulkOut });
    }
    /* V2-2: ختم المُنشئ على العناصر الجديدة (أساس تتبع الملكية للحذف) */
    const payload = doc || {};
    if (!payload.id && !payload.createdBy && !payload.owner && !payload.by) payload.createdBy = user.id;
    const saved = store.upsert(collection, payload);
    // تصميم مربوط بمشروع → يرث العميل تلقائيًا (يظهر في بورتال العميل)
    if (collection === 'designs' && saved.projectId && !saved.clientId) {
      const prj = (store.db.projects || []).find((p) => p.id === saved.projectId);
      if (prj) saved.clientId = prj.clientId;
    }
    store.log(user.id, describeOp(collection, doc, user), describeOpEn(collection, doc, user));
    store.save();
    const out = collection === 'designs' ? stripDesignPayload(saved) : collection === 'voices' ? stripVoicePayload(saved) : saved;
    broadcast({ type: 'sync', collection, op: 'upsert', doc: out });
    return sendJSON(res, 200, { ok: true, doc: out });
  }

  // تصميم كامل (بالطبقات) — منفصل عشان حجمه كبير
  if (parts[0] === 'design' && method === 'GET' && parts[1]) {
    const d = (store.db.designs || []).find((x) => x.id === parts[1]);
    if (!d) return sendJSON(res, 404, { ok: false, error: 'التصميم غير موجود', errorEn: 'Design not found' });
    if (user.role === 'client' && d.clientId !== user.clientId) {
      return sendJSON(res, 404, { ok: false, error: 'التصميم غير موجود', errorEn: 'Design not found' });
    }
    return sendJSON(res, 200, { ok: true, design: d });
  }

  /* ---- Phase 2: دورة حياة التصميم (مراجعة/تعليقات/نسخ/اعتماد/مشاركة) ---- */
  if (parts[0] === 'design' && method === 'POST' && parts[1] && parts[2]) {
    const d = (store.db.designs || []).find((x) => x.id === parts[1]);
    if (!d) return sendJSON(res, 404, { ok: false, error: 'التصميم غير موجود', errorEn: 'Design not found' });
    let body;
    try { body = JSON.parse((await readBody(req, 4 * 1024 * 1024)) || '{}'); }
    catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح', errorEn: 'Invalid JSON' }); }
    const action = parts[2];

    if (action === 'submit') {
      d.status = 'review';
      d.review = { submittedAt: store.nowISO(), submittedBy: user.id, submittedByName: user.name, note: String(body.note || '').slice(0, 300) };
      if (d.client && d.client.decision === 'changes') d.review.resubmit = true;
      const v = snapshotVersion(d, user, 'إرسال للمراجعة');
      store.log(user.id, `أرسل «${d.title}» للمراجعة (نسخة V${v.v})`, `Submitted "${d.title}" for review (V${v.v})`, { designId: d.id });
      store.save();
      broadcast({ type: 'sync', collection: 'designs', op: 'upsert', doc: stripDesignPayload(d) });
      runAutomation('design_submitted', { design: d, user });
      return sendJSON(res, 200, { ok: true, design: stripDesignPayload(d), version: { id: v.id, v: v.v } });
    }

    if (action === 'decision') {
      const decision = body.decision === 'approve' ? 'approve' : 'changes';
      const note = String(body.note || '').slice(0, 600);
      if (decision === 'changes' && !note) {
        return sendJSON(res, 400, { ok: false, error: 'اكتب ملاحظات التعديل', errorEn: 'Please add change notes' });
      }
      /* قرار من بورتال العميل */
      if (user.role === 'client') {
        if (d.clientId !== user.clientId) return sendJSON(res, 404, { ok: false, error: 'التصميم غير موجود', errorEn: 'Design not found' });
        d.client = { name: user.name, decision, note, at: store.nowISO(), via: 'portal' };
        d.status = decision === 'approve' ? 'client_approved' : 'changes';
        store.log(user.id, `${user.name} ${decision === 'approve' ? 'اعتمد' : 'طلب تعديل على'} «${d.title}» من البورتال`,
          `${user.name} ${decision === 'approve' ? 'approved' : 'requested changes on'} "${d.title}" via portal`, { designId: d.id });
        store.save();
        broadcast({ type: 'sync', collection: 'designs', op: 'upsert', doc: stripDesignPayload(d) });
        runAutomation(decision === 'approve' ? 'client_approved' : 'client_changes', { design: d, user });
        return sendJSON(res, 200, { ok: true, design: stripDesignPayload(d) });
      }
      /* V2-2: قرار الاعتماد الداخلي للإدارة وخدمة العملاء فقط */
      if (!perms.canDecide(user)) {
        return sendJSON(res, 403, { ok: false, error: 'الاعتماد للإدارة وخدمة العملاء فقط', errorEn: 'Approval is restricted to management/CS' });
      }
      d.status = decision === 'approve' ? 'approved' : 'changes';
      d.review = Object.assign({}, d.review, { decision, decidedBy: user.id, decidedByName: user.name, note, decidedAt: store.nowISO() });
      let version = null;
      if (decision === 'approve') version = snapshotVersion(d, user, 'اعتماد داخلي');
      store.log(user.id, `${decision === 'approve' ? 'اعتمد' : 'طلب تعديل على'} «${d.title}»${note ? ': ' + note : ''}`,
        `${decision === 'approve' ? 'Approved' : 'Requested changes on'} "${d.title}"`, { designId: d.id });
      store.save();
      broadcast({ type: 'sync', collection: 'designs', op: 'upsert', doc: stripDesignPayload(d) });
      if (decision === 'approve') runAutomation('internal_approved', { design: d, user });
      return sendJSON(res, 200, { ok: true, design: stripDesignPayload(d), version: version ? { id: version.id, v: version.v } : null });
    }

    if (action === 'comment') {
      d.comments = d.comments || [];
      if (body.id) {
        const c = d.comments.find((x) => x.id === body.id);
        if (!c) return sendJSON(res, 404, { ok: false, error: 'التعليق غير موجود', errorEn: 'Comment not found' });
        if (body.op === 'resolve') c.resolved = true;
        else if (body.op === 'reopen') c.resolved = false;
        else if (body.op === 'reply') {
          c.replies = c.replies || [];
          c.replies.push({ text: String(body.text || '').slice(0, 600), by: user.id, byName: user.name, at: store.nowISO() });
        } else if (body.op === 'delete' && (c.by === user.id || user.role === 'admin')) {
          d.comments = d.comments.filter((x) => x.id !== body.id);
        }
      } else {
        const text = String(body.text || '').trim().slice(0, 600);
        if (!text) return sendJSON(res, 400, { ok: false, error: 'اكتب تعليقًا', errorEn: 'Empty comment' });
        d.comments.push({
          id: store.uid('pin'),
          x: Math.max(0, Math.min(1, Number(body.x) || 0)),
          y: Math.max(0, Math.min(1, Number(body.y) || 0)),
          text, by: user.id, byName: user.name, at: store.nowISO(), resolved: false, replies: [],
        });
      }
      store.save();
      broadcast({ type: 'sync', collection: 'designs', op: 'upsert', doc: stripDesignPayload(d) });
      return sendJSON(res, 200, { ok: true, comments: d.comments });
    }

    if (action === 'version') {
      const v = snapshotVersion(d, user, String(body.note || '').slice(0, 200) || 'نسخة يدوية');
      store.log(user.id, `حفظ نسخة V${v.v} من «${d.title}»`, `Saved version V${v.v} of "${d.title}"`, { designId: d.id });
      store.save();
      broadcast({ type: 'sync', collection: 'designs', op: 'upsert', doc: stripDesignPayload(d) });
      return sendJSON(res, 200, { ok: true, version: { id: v.id, v: v.v } });
    }

    if (action === 'restore') {
      const v = (d.versions || []).find((x) => x.id === body.vid);
      if (!v) return sendJSON(res, 404, { ok: false, error: 'النسخة غير موجودة', errorEn: 'Version not found' });
      d.pages = JSON.parse(JSON.stringify(v.pages || []));
      if (d.pages && d.pages[0]) {
        d.layers = d.pages[0].layers || [];
        d.w = d.pages[0].w; d.h = d.pages[0].h;
      }
      store.log(user.id, `استعاد نسخة V${v.v} في «${d.title}»`, `Restored V${v.v} in "${d.title}"`, { designId: d.id });
      store.save();
      broadcast({ type: 'sync', collection: 'designs', op: 'upsert', doc: stripDesignPayload(d) });
      return sendJSON(res, 200, { ok: true, design: d });
    }

    if (action === 'share') {
      if (body.off) {
        if (d.share) d.share.revoked = true;
        store.log(user.id, `أوقف رابط اعتماد «${d.title}»`, `Revoked client link for "${d.title}"`, { designId: d.id });
        store.save();
        broadcast({ type: 'sync', collection: 'designs', op: 'upsert', doc: stripDesignPayload(d) });
        return sendJSON(res, 200, { ok: true, revoked: true });
      }
      if (!d.share || d.share.revoked) {
        d.share = { token: crypto.randomBytes(10).toString('hex'), at: store.nowISO(), by: user.id, revoked: false };
      }
      if (d.status !== 'client_approved') d.status = 'client';
      store.log(user.id, `أنشأ رابط اعتماد للعميل «${d.title}»`, `Created client approval link for "${d.title}"`, { designId: d.id });
      store.save();
      broadcast({ type: 'sync', collection: 'designs', op: 'upsert', doc: stripDesignPayload(d) });
      return sendJSON(res, 200, { ok: true, token: d.share.token });
    }

    return sendJSON(res, 400, { ok: false, error: 'إجراء غير معروف', errorEn: 'Unknown action' });
  }

  /* ---- Phase 4: دورة مراجعة عامة (محتوى / صوت) ---- */
  if (parts[0] === 'doc' && ['contents', 'voices', 'videos'].includes(parts[1])) {
    const col = parts[1];
    const colName = col === 'contents' ? 'محتوى' : 'تسجيل';
    const d = (store.db[col] || []).find((x) => x.id === parts[2]);
    if (!d) return sendJSON(res, 404, { ok: false, error: 'غير موجود', errorEn: 'Not found' });
    if (method === 'GET') return sendJSON(res, 200, { ok: true, doc: d });
    if (method === 'POST' && parts[3]) {
      let body;
      try { body = JSON.parse((await readBody(req, 4 * 1024 * 1024)) || '{}'); }
      catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح', errorEn: 'Invalid JSON' }); }
      const action = parts[3];
      const strip = col === 'voices' ? stripVoicePayload : (x) => x;
      const flush = () => { store.save(); broadcast({ type: 'sync', collection: col, op: 'upsert', doc: strip(d) }); };

      if (action === 'submit') {
        d.status = 'review';
        d.review = { submittedAt: store.nowISO(), submittedBy: user.id, submittedByName: user.name, note: String(body.note || '').slice(0, 300) };
        let version = null;
        if (col === 'contents') {
          d.versions = d.versions || [];
          const v = { id: store.uid('ver'), v: d.versions.length + 1, body: d.body || '', at: store.nowISO(), by: user.id, byName: user.name, note: 'إرسال للمراجعة' };
          d.versions.push(v);
          if (d.versions.length > 25) d.versions.shift();
          version = { id: v.id, v: v.v };
        }
        store.log(user.id, `أرسل ${colName} «${d.title}» للمراجعة`, `Submitted ${col === 'contents' ? 'content' : 'voice take'} "${d.title}" for review`);
        flush();
        runAutomation(col + '_submitted', { design: d, user });
        return sendJSON(res, 200, { ok: true, doc: strip(d), version });
      }

      if (action === 'decision') {
        const decision = body.decision === 'approve' ? 'approve' : 'changes';
        const note = String(body.note || '').slice(0, 600);
        if (decision === 'changes' && !note) return sendJSON(res, 400, { ok: false, error: 'اكتب ملاحظات التعديل', errorEn: 'Please add change notes' });
        /* V2-2: قرار الاعتماد للإدارة وخدمة العملاء فقط */
        if (!perms.canDecide(user)) {
          return sendJSON(res, 403, { ok: false, error: 'الاعتماد للإدارة وخدمة العملاء فقط', errorEn: 'Approval is restricted to management/CS' });
        }
        if (d.owner === user.id && user.role !== 'admin') {
          return sendJSON(res, 403, { ok: false, error: 'ماينفعش تقيّم شغلك بنفسك', errorEn: 'You cannot review your own work' });
        }
        d.status = decision === 'approve' ? 'approved' : 'changes';
        d.review = Object.assign({}, d.review, { decision, decidedBy: user.id, decidedByName: user.name, note, decidedAt: store.nowISO() });
        store.log(user.id, `${decision === 'approve' ? 'اعتمد' : 'طلب تعديل على'} ${colName} «${d.title}»${note ? ': ' + note : ''}`,
          `${decision === 'approve' ? 'Approved' : 'Requested changes on'} "${d.title}"`);
        flush();
        if (decision === 'approve') runAutomation(col + '_approved', { design: d, user });
        return sendJSON(res, 200, { ok: true, doc: strip(d) });
      }

      if (action === 'comment') {
        d.comments = d.comments || [];
        if (body.id) {
          const c = d.comments.find((x) => x.id === body.id);
          if (!c) return sendJSON(res, 404, { ok: false, error: 'التعليق غير موجود', errorEn: 'Comment not found' });
          if (body.op === 'resolve') c.resolved = true;
          else if (body.op === 'reopen') c.resolved = false;
          else if (body.op === 'reply') {
            c.replies = c.replies || [];
            c.replies.push({ text: String(body.text || '').slice(0, 600), by: user.id, byName: user.name, at: store.nowISO() });
          } else if (body.op === 'delete' && (c.by === user.id || user.role === 'admin')) {
            d.comments = d.comments.filter((x) => x.id !== body.id);
          }
        } else {
          const text = String(body.text || '').trim().slice(0, 600);
          if (!text) return sendJSON(res, 400, { ok: false, error: 'اكتب تعليقًا', errorEn: 'Empty comment' });
          d.comments.push({ id: store.uid('cmt'), text, by: user.id, byName: user.name, at: store.nowISO(), resolved: false, replies: [] });
        }
        flush();
        return sendJSON(res, 200, { ok: true, comments: d.comments });
      }

      return sendJSON(res, 400, { ok: false, error: 'إجراء غير معروف', errorEn: 'Unknown action' });
    }
  }

  /* ---- Phase 7: MEEM Chat ---- */
  if (parts[0] === 'chat' && method === 'POST') {
    let body;
    try { body = JSON.parse((await readBody(req, 64 * 1024)) || '{}'); }
    catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح' }); }
    const room = String(body.room || '').slice(0, 60);
    if (!canChat(user, room)) return sendJSON(res, 403, { ok: false, error: 'مش مصرح لك بالغرفة دي', errorEn: 'Room access denied' });
    store.db.chats = store.db.chats || [];

    /* V4-5: حذف رسالة (صاحبها أو الأدمن) */
    if (body.deleteId) {
      const doc = store.db.chats.find((m) => m.id === String(body.deleteId));
      if (!doc || doc.room !== room) return sendJSON(res, 404, { ok: false, error: 'الرسالة مش موجودة' });
      if (doc.by !== user.id && !perms.isAdmin(user)) return sendJSON(res, 403, { ok: false, error: 'تحذف رسائلك بس', errorEn: 'Delete your own messages only' });
      store.db.chats = store.db.chats.filter((m) => m.id !== doc.id);
      store.save();
      broadcast({ type: 'chat-del', id: doc.id, room }, (c) => {
        const u = c.userId ? (store.db.users || []).find((x) => x.id === c.userId) : null;
        return u ? canChat(u, room) : false;
      });
      return sendJSON(res, 200, { ok: true, deleted: doc.id });
    }

    /* V4-5: تعديل رسالة (صاحبها فقط) */
    if (body.editId) {
      const doc = store.db.chats.find((m) => m.id === String(body.editId));
      if (!doc || doc.room !== room) return sendJSON(res, 404, { ok: false, error: 'الرسالة مش موجودة' });
      if (doc.by !== user.id) return sendJSON(res, 403, { ok: false, error: 'تعدّل رسائلك بس', errorEn: 'Edit your own messages only' });
      const text = String(body.text || '').trim().slice(0, 2000);
      if (!text) return sendJSON(res, 400, { ok: false, error: 'رسالة فاضية' });
      doc.text = text;
      doc.edited = true;
      store.save();
      broadcast({ type: 'chat-edit', doc }, (c) => {
        const u = c.userId ? (store.db.users || []).find((x) => x.id === c.userId) : null;
        return u ? canChat(u, room) : false;
      });
      return sendJSON(res, 200, { ok: true, doc });
    }

    const text = String(body.text || '').trim().slice(0, 2000);
    const file = (body.file && typeof body.file === 'object' && body.file.url) ? { name: String(body.file.name || 'ملف').slice(0, 120), url: String(body.file.url).slice(0, 300) } : null;
    if (!text && !file) return sendJSON(res, 400, { ok: false, error: 'رسالة فاضية', errorEn: 'Empty message' });
    const reply = (body.reply && typeof body.reply === 'object' && body.reply.id) ? { id: String(body.reply.id).slice(0, 30), name: String(body.reply.name || '').slice(0, 60), snippet: String(body.reply.snippet || '').slice(0, 140) } : null;
    const doc = { id: 'msg_' + crypto.randomBytes(6).toString('hex'), room, by: user.id, byName: user.name, color: user.avatarColor || '', text, at: new Date().toISOString() };
    if (file) doc.file = file;
    if (reply) doc.reply = reply;
    store.db.chats.push(doc);
    if (store.db.chats.length > 2000) store.db.chats = store.db.chats.slice(-2000);
    store.log(user.id, `رسالة في ${room}`, `Chat message in ${room}`);
    store.save();
    broadcast({ type: 'chat', doc }, (c) => {
      const u = c.userId ? (store.db.users || []).find((x) => x.id === c.userId) : null;
      return u ? canChat(u, room) : false;
    });
    return sendJSON(res, 200, { ok: true, doc });
  }

  /* ---- V4-5: تاريخ غرفة (ترقيم صفحات) ---- */
  if (parts[0] === 'chat-history' && method === 'GET') {
    const room = String(url.searchParams.get('room') || '').slice(0, 60);
    if (!canChat(user, room)) return sendJSON(res, 403, { ok: false, error: 'مش مصرح لك بالغرفة دي', errorEn: 'Room access denied' });
    const before = String(url.searchParams.get('before') || '');
    const limit = Math.min(100, Math.max(1, parseInt(url.searchParams.get('limit') || '50', 10) || 50));
    let msgs = (store.db.chats || []).filter((m) => m.room === room);
    if (before) msgs = msgs.filter((m) => (m.at || '') < before);
    msgs = msgs.slice(-limit);
    return sendJSON(res, 200, { ok: true, msgs });
  }

  /* ---- Phase 5: رفع ملفات ميديا (فيديو/صور/صوت) — تُحفظ كملفات مش في db.json ---- */
  if (parts[0] === 'upload' && method === 'POST') {
    const raw = await readBodyRaw(req, 40 * 1024 * 1024);
    if (!raw || !raw.length) return sendJSON(res, 400, { ok: false, error: 'ملف فاضي', errorEn: 'Empty file' });
    const nameParam = String(url.searchParams.get('name') || 'media.bin');
    const ext = (path.extname(nameParam).toLowerCase().match(/^\.[a-z0-9]{2,5}$/) || ['.bin'])[0];
    const id = 'upl_' + crypto.randomBytes(6).toString('hex');
    fs.writeFileSync(path.join(UPLOAD_DIR, id + ext), raw);
    store.log(user.id, `رفع ملف ميديا (${(raw.length / 1048576).toFixed(1)}MB)`, `Uploaded media file (${(raw.length / 1048576).toFixed(1)}MB)`);
    store.save();
    return sendJSON(res, 200, { ok: true, id, url: '/uploads/' + id + ext, size: raw.length });
  }

  /* ---- Phase 4: AI pipeline (بروكسي + fallback محلي على العميل) ---- */
  if (parts[0] === 'ai' && method === 'POST') {
    /* V2-3: لو الأدوات مخفية — الـ AI للمالك فقط */
    const toolsDoc = (store.db.settings || []).find((x) => x.id === 'tools');
    if (toolsDoc && toolsDoc.ai === false && !perms.isSuper(user)) {
      return sendJSON(res, 403, { ok: false, error: 'أدوات الـ AI موقوفة حاليًا', errorEn: 'AI tools are currently disabled' });
    }
    let body;
    try { body = JSON.parse((await readBody(req, 256 * 1024)) || '{}'); }
    catch (e) { return sendJSON(res, 400, { ok: false, error: 'JSON غير صالح', errorEn: 'Invalid JSON' }); }
    const cfg = (store.db.settings || []).find((s) => s.id === 'ai') || {};
    if (!cfg.key) return sendJSON(res, 200, { ok: true, fallback: true });
    const sys = 'انت كاتب محتوى محترف في وكالة إبداعية مصرية. التزم بصوت البراند المعطى، واكتب بالعامية المصرية الراقية إلا لو طُلب غير ذلك. رد بالنص المطلوب فقط بدون مقدمات.';
    const usr = JSON.stringify({ action: body.action || 'draft', type: body.type || '', lang: body.lang || 'ar', brandVoice: body.voice || null, currentText: String(body.text || '').slice(0, 8000), instruction: String(body.instruction || '').slice(0, 500) });
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 25000);
      const r = await fetch((cfg.baseUrl || 'https://api.openai.com/v1').replace(/\/$/, '') + '/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + cfg.key },
        body: JSON.stringify({ model: cfg.model || 'gpt-4o-mini', messages: [{ role: 'system', content: sys }, { role: 'user', content: usr }], temperature: 0.8 }),
        signal: ctrl.signal,
      });
      clearTimeout(t);
      const j = await r.json();
      const text = j.choices && j.choices[0] && j.choices[0].message && j.choices[0].message.content;
      if (!text) return sendJSON(res, 200, { ok: true, fallback: true, providerError: String(j.error && j.error.message || 'no content').slice(0, 200) });
      return sendJSON(res, 200, { ok: true, text });
    } catch (e) {
      return sendJSON(res, 200, { ok: true, fallback: true, providerError: String(e.message).slice(0, 200) });
    }
  }

  if (parts[0] === 'asset' && method === 'GET' && parts[1]) {
    const a = (store.db.assets || []).find((x) => x.id === parts[1]);
    if (!a) return sendJSON(res, 404, { ok: false, error: 'غير موجود', errorEn: 'Not found' });
    return sendJSON(res, 200, { ok: true, asset: a });
  }

  if (parts[0] === 'activity' && method === 'GET') {
    return sendJSON(res, 200, { ok: true, activity: (store.db.activity || []).slice(0, 100) });
  }

  if (parts[0] === 'ping') return sendJSON(res, 200, { ok: true, at: new Date().toISOString() });

  return sendJSON(res, 404, { ok: false, error: 'المسار غير موجود', errorEn: 'Not found' });
}

function stripDesignPayload(d) {
  const { layers, pages, versions, ...rest } = d;
  rest.layerCount = (d.layers || []).length;
  rest.pageCount = (d.pages || []).length;
  if (versions) rest.versionCount = versions.length;
  return rest;
}

/* الصوت تقيل — القوائم تاخد metadata للتسجيلات من غير dataURL */
function stripVoicePayload(v) {
  const rest = Object.assign({}, v);
  rest.takes = (v.takes || []).map((t) => ({ id: t.id, dur: t.dur || 0, at: t.at, name: t.name || '', processed: !!t.processed, hasData: !!t.data }));
  return rest;
}

/* ================= الأتمتة: trigger → action ================= */
function runAutomation(trigger, ctx) {
  const cfg = (store.db.settings || []).find((s) => s.id === 'automation');
  if (!cfg || !cfg.rules) return;
  const fired = [];
  cfg.rules.filter((r) => r.on && r.trigger === trigger).forEach((r) => {
    const d = ctx.design || {};
    if (r.action === 'create_delivery') {
      store.upsert('deliveries', {
        title: 'تسليم: ' + (d.title || 'تصميم'),
        projectId: d.projectId || '',
        clientId: d.clientId || '',
        channel: 'email',
        status: 'draft',
        items: [],
        checklist: [
          { label: 'اعتماد العميل النهائي', done: true },
          { label: 'تصدير المقاسات النهائية (PNG/PDF)', done: false },
          { label: 'مطابقة الهوية البصرية (Brand Kit)', done: false },
          { label: 'مراجعة إملائية نهائية', done: false },
          { label: 'تسمية الملفات بشكل واضح', done: false },
        ],
        clientFeedback: '',
        revisions: 0,
        signoff: { by: (d.client && d.client.name) || 'العميل', at: store.nowISO() },
        deliveredAt: null,
        auto: true,
      });
    } else if (r.action === 'create_task_delivery') {
      store.upsert('tasks', {
        dept: 'delivery', type: 'متابعة', title: 'متابعة تسليم: ' + (d.title || ''),
        desc: 'أُنشئت تلقائيًا بعد اعتماد العميل.', assignee: 'usr_cs', status: 'new',
        priority: 'high', due: store.nowISO().slice(0, 10), projectId: d.projectId || '', comments: [], files: [],
      });
    } else if (r.action === 'create_task_revision') {
      store.upsert('tasks', {
        dept: 'design', type: 'تعديل', title: 'تعديلات العميل على: ' + (d.title || ''),
        desc: (d.client && d.client.note) || 'راجع ملاحظات العميل.', assignee: d.owner || 'usr_design',
        status: 'revision', priority: 'high', due: store.nowISO().slice(0, 10), projectId: d.projectId || '', comments: [], files: [],
      });
    }
    fired.push(r);
  });
  if (fired.length) {
    fired.forEach((r) => store.log(null, '🤖 أتمتة نفّذت: ' + r.label, 'Automation ran: ' + r.label, { designId: d0id(ctx) }));
    store.save();
    broadcast({ type: 'refresh-state' });
  }
}
function d0id(ctx) { return ctx && ctx.design ? ctx.design.id : null; }

/* لقطة نسخة (V1..Vn) — تخزن الصفحات كاملة + صورة مصغرة */
function snapshotVersion(d, user, note) {
  d.versions = d.versions || [];
  const v = {
    id: store.uid('ver'),
    v: d.versions.length + 1,
    note: note || '',
    at: store.nowISO(),
    by: user.id,
    byName: user.name,
    thumb: d.thumb || '',
    pages: JSON.parse(JSON.stringify(d.pages || [])),
  };
  d.versions.push(v);
  if (d.versions.length > 25) d.versions.shift(); // سقف الأمان للحجم
  return v;
}


function describeOp(collection, doc, user) {
  const names = { tasks: 'مهمة', projects: 'مشروع', clients: 'عميل', designs: 'تصميم', deliveries: 'تسليم', meetings: 'اجتماع', assets: 'أصل', invoices: 'فاتورة', templates: 'قالب', settings: 'إعدادات' };
  return `حدّث ${names[collection] || collection}: ${doc.title || doc.name || doc.id || ''}`;
}
function describeOpEn(collection, doc, user) {
  const names = { tasks: 'task', projects: 'project', clients: 'client', designs: 'design', deliveries: 'delivery', meetings: 'meeting', assets: 'asset', invoices: 'invoice', templates: 'template', settings: 'settings' };
  return `Updated ${names[collection] || collection}: ${doc.titleEn || doc.title || doc.name || doc.id || ''}`;
}

/* ============================ server ============================ */

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  res.setHeader('X-Content-Type-Options', 'nosniff');

  if (url.pathname === '/healthz') return sendJSON(res, 200, { ok: true, service: 'meem-studio' });

  if (url.pathname.startsWith('/api/')) {
    try {
      return await handleAPI(req, res, url);
    } catch (e) {
      console.error('[api]', e);
      return sendJSON(res, 500, { ok: false, error: e.message, errorEn: 'Server error' });
    }
  }

  if (url.pathname === '/ws') return; // handled in upgrade

  if (url.pathname.startsWith('/uploads/')) {
    const fname = path.basename(url.pathname);
    if (!/^[a-zA-Z0-9_.-]+$/.test(fname)) { res.writeHead(403).end('forbidden'); return; }
    const full = path.join(UPLOAD_DIR, fname);
    fs.stat(full, (err, st) => {
      if (err || !st.isFile()) { res.writeHead(404).end('not found'); return; }
      const type = MIME[path.extname(full).toLowerCase()] || 'application/octet-stream';
      res.writeHead(200, { 'Content-Type': type, 'Content-Length': st.size, 'Cache-Control': 'public, max-age=31536000' });
      fs.createReadStream(full).pipe(res);
    });
    return;
  }

  return serveStatic(req, res, url.pathname);
});

server.on('upgrade', (req, socket) => {
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname !== '/ws') { socket.destroy(); return; }
  const key = req.headers['sec-websocket-key'];
  if (!key || String(req.headers.upgrade).toLowerCase() !== 'websocket') { socket.destroy(); return; }

  const accept = crypto.createHash('sha1').update(key + WS_GUID).digest('base64');
  socket.write(
    'HTTP/1.1 101 Switching Protocols\r\n' +
    'Upgrade: websocket\r\n' +
    'Connection: Upgrade\r\n' +
    `Sec-WebSocket-Accept: ${accept}\r\n\r\n`
  );

  const client = new WSClient(socket, req);
  const user = client.token ? store.tokenUser(client.token) : null;
  if (user) {
    client.userId = user.id;
    client.name = user.name;
    client.role = user.role;
    client.color = user.avatarColor;
  }
  clients.add(client);
  broadcast({ type: 'presence', count: clients.size, users: onlineIds() });
  if (user) client.send({
    type: 'posinit',
    users: [...clients].filter((c) => c.pos && c.userId && c !== client)
      .map((c) => ({ userId: c.userId, name: c.name, color: c.color, ...c.pos })),
  });

  socket.on('data', (chunk) => {
    client.buf = Buffer.concat([client.buf, chunk]);
    let frames;
    try { frames = decodeFrames(client); } catch (e) { socket.destroy(); return; }
    for (const f of frames) {
      if (f.opcode === 0x8) { client.alive = false; socket.end(); cleanup(); return; }
      if (f.opcode === 0x9) { try { socket.write(encodeFrame(f.payload, 0xA)); } catch (e) {} continue; }
      if (f.opcode === 0xA) continue;
      if (f.opcode !== 0x1 && f.opcode !== 0x2) continue;
      let msg;
      try { msg = JSON.parse(f.payload.toString('utf8')); } catch (e) { continue; }
      handleWS(client, msg);
    }
  });

  socket.on('error', cleanup);
  socket.on('close', cleanup);

  function cleanup() {
    if (!client.alive && !clients.has(client)) return;
    client.alive = false;
    clients.delete(client);
    if (client.room) {
      toRoom(client.room, { type: 'peer-left', clientId: client.clientId, name: client.name });
      client.room = null;
    }
    broadcast({ type: 'presence', count: clients.size, users: onlineIds() });
    if (client.userId) broadcast({ type: 'posleave', userId: client.userId });
  }
});

function handleWS(client, msg) {
  switch (msg.type) {
    case 'hello': {
      client.name = msg.name || client.name || 'ضيف';
      client.role = msg.role || client.role || '';
      client.color = msg.color || client.color || '#7c5cff';
      client.send({ type: 'hello-ack', clientId: client.clientId, count: clients.size });
      break;
    }
    case 'join-room': {
      const room = String(msg.room || '').slice(0, 64);
      if (client.room && client.room !== room) {
        toRoom(client.room, { type: 'peer-left', clientId: client.clientId, name: client.name });
      }
      client.room = room;
      const roster = roomRoster(room).filter((p) => p.clientId !== client.clientId);
      client.send({ type: 'room-joined', room, peers: roster, clientId: client.clientId });
      toRoom(room, {
        type: 'peer-joined',
        clientId: client.clientId,
        userId: client.userId,
        name: client.name,
        role: client.role,
        color: client.color,
      }, client.clientId);
      break;
    }
    case 'leave-room': {
      if (client.room) {
        toRoom(client.room, { type: 'peer-left', clientId: client.clientId, name: client.name });
        client.room = null;
      }
      client.send({ type: 'room-left' });
      break;
    }
    // signaling
    case 'offer':
    case 'answer':
    case 'ice':
    case 'chat':
    case 'hand-raise':
    case 'state': {
      if (!client.room) return;
      const payload = Object.assign({}, msg, { from: client.clientId, fromName: client.name });
      if (msg.to) {
        for (const c of clients) {
          if (c.clientId === msg.to && c.room === client.room) { c.send(payload); break; }
        }
      } else {
        toRoom(client.room, payload, client.clientId);
      }
      break;
    }
    case 'roster': {
      if (client.room) client.send({ type: 'room-roster', peers: roomRoster(client.room) });
      break;
    }
    case 'ping': {
      client.send({ type: 'pong', t: Date.now() });
      break;
    }
    /* V2-8 — حركة الأفاتارات في المكتب الافتراضي */
    case 'pos': {
      if (!client.userId) return;
      client.pos = {
        x: Math.max(0, Math.min(100, Number(msg.x) || 0)),
        y: Math.max(0, Math.min(100, Number(msg.y) || 0)),
        status: String(msg.status || client.status || 'available').slice(0, 16),
        room: String(msg.room || '').slice(0, 24),
        floor: Math.min(2, Math.max(1, Number(msg.floor) || 1)),
      };
      broadcast({ type: 'pos', userId: client.userId, name: client.name, color: client.color, ...client.pos }, (c) => c !== client);
      break;
    }
    /* V3-2 — فقاعات/إيموتات/typing في المكتب الافتراضي (فلترة القرب على العميل) */
    case 'obubble': {
      if (!client.userId) return;
      broadcast({
        type: 'obubble', userId: client.userId, name: client.name,
        text: String(msg.text || '').slice(0, 140),
        room: String(msg.room || '').slice(0, 24),
      }, (c) => c !== client);
      break;
    }
    case 'oemote': {
      if (!client.userId) return;
      broadcast({
        type: 'oemote', userId: client.userId, name: client.name,
        emote: String(msg.emote || '').slice(0, 8),
        room: String(msg.room || '').slice(0, 24),
      }, (c) => c !== client);
      break;
    }
    case 'otyping': {
      if (!client.userId) return;
      for (const c of clients) {
        if (c.userId && c.userId === String(msg.to || '')) { c.send({ type: 'otyping', from: client.userId, name: client.name }); break; }
      }
      break;
    }
    /* V4-5: typing + مقروءة داخل غرف الشات */
    case 'ctyping': {
      if (!client.userId) return;
      const room = String(msg.room || '').slice(0, 60);
      const u0 = (store.db.users || []).find((x) => x.id === client.userId);
      if (!u0 || !canChat(u0, room)) return;
      for (const c of clients) {
        if (c === client || !c.userId) continue;
        const u = (store.db.users || []).find((x) => x.id === c.userId);
        if (u && canChat(u, room)) c.send({ type: 'ctyping', room, userId: client.userId, name: client.name });
      }
      break;
    }
    case 'cread': {
      if (!client.userId) return;
      const room = String(msg.room || '').slice(0, 60);
      const u0 = (store.db.users || []).find((x) => x.id === client.userId);
      if (!u0 || !canChat(u0, room)) return;
      for (const c of clients) {
        if (c === client || !c.userId) continue;
        const u = (store.db.users || []).find((x) => x.id === c.userId);
        if (u && canChat(u, room)) c.send({ type: 'cread', room, userId: client.userId, at: new Date().toISOString() });
      }
      break;
    }
    case 'posreq': {
      client.send({
        type: 'posinit',
        users: [...clients].filter((c) => c.pos && c.userId && c !== client)
          .map((c) => ({ userId: c.userId, name: c.name, color: c.color, ...c.pos })),
      });
      break;
    }
    case 'status': {
      if (!client.userId) return;
      client.status = String(msg.status || 'available').slice(0, 16);
      broadcast({ type: 'status', userId: client.userId, status: client.status }, (c) => c !== client);
      break;
    }
    default:
      break;
  }
}

// keep-alive
setInterval(() => {
  for (const c of clients) {
    if (!c.alive) { clients.delete(c); continue; }
    try { c.socket.write(encodeFrame(Buffer.alloc(0), 0x9)); } catch (e) { clients.delete(c); }
  }
}, 25000).unref();

/* ============================ boot ============================ */

const loaded = store.load();
const created = seed();
const migrated = phase3migrate();
const migrated4 = phase4seed();
const migrated5 = phase5seed();
if (!loaded) console.log('[boot] new database created at data/db.json');
if (created) console.log('[boot] demo data seeded');
if (migrated) console.log('[boot] phase3 migrated (client accounts + brand kits + automation)');
if (migrated4) console.log('[boot] phase4 seeded (content library + ai settings)');
if (migrated5) console.log('[boot] phase5 seeded (shoots + bug tracker)');
const migrated6 = phase6seed();
if (migrated6) console.log('[boot] phase6 seeded (finance + time + marketing + kb)');
const migrated7 = phase7seed();
if (migrated7) console.log('[boot] phase7 seeded (chat rooms)');
const migratedV2 = v2seed();
if (migratedV2) console.log('[boot] V2 seeded (owner account + tools settings)');

/* V4-2: مظهر افتراضي + علم Onboarding للحسابات الموجودة */
let migratedV42 = false;
(store.db.users || []).forEach((u) => {
  if (!u.avatar || typeof u.avatar !== 'object') {
    u.avatar = { gender: 'm', skin: '#ffd9b3', hair: 'short', hairColor: '#1b1b1b', outfit: 'tshirt', outfitColor: u.avatarColor || '#3d8bff', accessory: 'none' };
    migratedV42 = true;
  }
  if (u.onboarded === undefined) { u.onboarded = true; migratedV42 = true; }
});
if (migratedV42) { store.save(); console.log('[boot] v4-2 migrated (avatar looks + onboarded flags)'); }

/* V4-6: إعدادات الهوية + مصفوفة الصلاحيات القابلة للتخصيص */
let migratedV46 = false;
if (!(store.db.settings || []).find((x) => x.id === 'brand')) {
  store.upsert('settings', {
    id: 'brand', siteName: 'MEE M — Creative Office', tagline: 'استوديو الإنتاج الإبداعي',
    primary: '#0066ff', loginTitle: 'أهلًا بعودتك 👋', loginSub: 'ادخل لمكتب ميم الإبداعي',
    officeTheme: 'default',
  });
  migratedV46 = true;
}
if (!(store.db.settings || []).find((x) => x.id === 'perms')) {
  store.upsert('settings', { id: 'perms', matrix: {} });
  migratedV46 = true;
}
if (migratedV46) { store.save(); console.log('[boot] v4-6 migrated (brand settings + perms matrix)'); }
perms.attach(store.db); /* V4-6 */

server.listen(PORT, HOST, () => {
  console.log('');
  console.log('  MEEM | Creative Office');
  console.log(`  ➜  http://localhost:${PORT}`);
  console.log(`  ➜  bound on ${HOST}:${PORT}`);
  console.log('  demo login: designer@meem.studio / 123456');
  console.log('');
});

process.on('SIGINT', () => { store.forceSave(); process.exit(0); });
process.on('SIGTERM', () => { store.forceSave(); process.exit(0); });
