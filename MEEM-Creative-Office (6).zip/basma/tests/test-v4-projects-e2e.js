/* MEEM V4-4 E2E — دورة كاملة: طلب من البوابة → إسناد → مشروع → مدير ملفات → رفض بسبب → لافتة 3D */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const fs = require('fs');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];
const GL = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];

async function mk(ctx, email) {
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(email + ' PE: ' + e.message.slice(0, 140)));
  await p.goto(BASE + '/?r=' + email + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', email);
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.page-head, .office-map, .of3d-canvas', { timeout: 25000 });
  await p.waitForTimeout(700);
  return p;
}

(async () => {
  const b = await chromium.launch({ args: GL });
  const c1 = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const C = await mk(c1, 'client@meem.studio');
  const c2 = await b.newContext({ viewport: { width: 1500, height: 950 } }); /* سياق منفصل — localStorage مش مشترك */
  const A = await mk(c2, 'admin@meem.studio');
  const MARK = 'ماركر V44 ' + Date.now();
  const MARK2 = 'ماركر رفض V44 ' + Date.now();

  /* ---- 1) العميل يطلب مشروع من البوابة ---- */
  await C.goto(BASE + '/#/portal'); await C.waitForTimeout(1000);
  ok('زر «اطلب مشروع جديد» في البوابة', (await C.locator('button', { hasText: 'اطلب مشروع جديد' }).count()) === 1);
  await C.locator('button', { hasText: 'اطلب مشروع جديد' }).click();
  await C.waitForSelector('.modal-backdrop');
  const m1 = C.locator('.modal-backdrop');
  await m1.locator('select').first().selectOption('design');
  await m1.locator('textarea').fill('محتاج بوستات حملة جديدة — ' + MARK);
  await m1.locator('input').first().fill('01000000000');
  await m1.locator('button', { hasText: 'إرسال الطلب' }).click();
  await C.waitForTimeout(1400);
  ok('الطلب اتسجل وظهر في «طلباتي»', (await C.locator('text=قيد الاستلام').count()) >= 1);

  /* ---- 2) الأدمن يشوف الطلب من بوابة العميل ---- */
  await A.goto(BASE + '/#/requests'); await A.waitForTimeout(1100);
  const card = A.locator('.card', { hasText: MARK });
  ok('الطلب وصل الإدارة بbadge بوابة العميل', (await card.count()) === 1 && (await card.innerText()).includes('بوابة العميل'));

  /* ---- 3) إسناد ثم تحويل لمشروع ---- */
  await card.locator('button', { hasText: 'إسناد' }).click();
  await A.waitForSelector('.modal-backdrop');
  await A.locator('.modal-backdrop button', { hasText: 'إسناد' }).last().click();
  await A.waitForTimeout(900);
  const card2 = A.locator('.card', { hasText: MARK });
  ok('الحالة بقت «تم الإسناد»', (await card2.innerText()).includes('تم الإسناد'));
  await card2.locator('button', { hasText: 'تحويل لمشروع' }).click();
  await A.waitForTimeout(1500);
  ok('اتحوّل لمشروع وفتحنا صفحته', A.url().includes('#/projects/') && (await A.locator('.page-head, .tabs').count()) >= 1);

  /* ---- 4) مدير ملفات المشروع: رفع/تسمية/بحث/حذف ---- */
  await A.locator('.tabs button', { hasText: 'الملفات' }).click();
  await A.waitForTimeout(700);
  fs.writeFileSync('/tmp/v44-file.txt', 'ملف اختبار V4-4');
  await A.locator('input[type=file]').setInputFiles('/tmp/v44-file.txt');
  await A.waitForTimeout(1300);
  ok('الملف اترفع وظهر في المدير', (await A.locator('.card', { hasText: 'v44-file.txt' }).count()) >= 1);
  /* إعادة تسمية */
  await A.locator('.card', { hasText: 'v44-file.txt' }).locator('button[title="إعادة تسمية"]').click();
  await A.waitForSelector('.modal-backdrop');
  await A.locator('.modal-backdrop input').fill('ملف-الحملة.txt');
  await A.locator('.modal-backdrop button', { hasText: 'حفظ' }).last().click();
  await A.waitForTimeout(1200);
  ok('إعادة التسمية اشتغلت', (await A.locator('.card', { hasText: 'ملف-الحملة.txt' }).count()) >= 1);
  /* بحث */
  await A.locator('input[placeholder*="ابحث في ملفات المشروع"]').fill('zzzz-no-match');
  await A.waitForTimeout(400);
  ok('البحث بيفلتر', (await A.locator('.empty', { hasText: 'مفيش نتائج للبحث' }).count()) >= 1);
  await A.locator('input[placeholder*="ابحث في ملفات المشروع"]').fill('');
  await A.waitForTimeout(300);
  /* حذف */
  await A.locator('.card', { hasText: 'ملف-الحملة.txt' }).locator('button[title="حذف"]').click();
  await A.waitForSelector('.modal-backdrop');
  await A.locator('.modal-backdrop button', { hasText: 'تأكيد' }).click();
  await A.waitForTimeout(1200);
  ok('الحذف اشتغل', (await A.locator('.card', { hasText: 'ملف-الحملة.txt' }).count()) === 0);

  /* ---- 5) دورة الرفض: طلب تاني → رفض بسبب → العميل يشوف السبب ---- */
  await C.goto(BASE + '/#/portal'); await C.waitForTimeout(900);
  await C.locator('button', { hasText: 'اطلب مشروع جديد' }).click();
  await C.waitForSelector('.modal-backdrop');
  const m2 = C.locator('.modal-backdrop');
  await m2.locator('select').first().selectOption('voice');
  await m2.locator('textarea').fill('طلب للاختبار — ' + MARK2);
  await m2.locator('button', { hasText: 'إرسال الطلب' }).click();
  await C.waitForTimeout(1200);
  await A.goto(BASE + '/#/requests'); await A.waitForTimeout(1100);
  const card3 = A.locator('.card', { hasText: MARK2 });
  await card3.locator('button', { hasText: 'رفض' }).click();
  await A.waitForSelector('.modal-backdrop');
  await A.locator('.modal-backdrop textarea').fill('الميزانية مش مناسبة حاليًا');
  await A.locator('.modal-backdrop button', { hasText: 'تأكيد الرفض' }).click();
  await A.waitForTimeout(1000);
  ok('الإدارة رفضت الطلب بسبب', (await A.locator('.card', { hasText: MARK2 }).innerText()).includes('مرفوض'));
  await C.goto(BASE + '/#/portal'); await C.waitForTimeout(1100);
  const cTxt = await C.locator('body').innerText();
  ok('العميل شايف «مرفوض» + سبب الرفض', cTxt.includes('مرفوض') && cTxt.includes('الميزانية مش مناسبة حاليًا'));

  /* ---- 6) لافتة المشاريع 3D: نقر حقيقي يفتح الوحدة ---- */
  await A.goto(BASE + '/#/office');
  await A.waitForFunction(() => window.__of3d && window.__of3d.ready, null, { timeout: 40000 });
  await A.waitForTimeout(1200);
  await A.evaluate(() => {
    const pt = window.__of3d.signPos();
    const cv = window.__of3d.canvas();
    for (const type of ['pointerdown', 'pointerup']) {
      cv.dispatchEvent(new PointerEvent(type, { clientX: pt.x, clientY: pt.y, pointerType: 'mouse', bubbles: true }));
    }
  });
  await A.waitForTimeout(800);
  ok('نقرة لافتة «المشاريع» فتحت وحدة المشاريع', A.url().includes('#/projects'));

  /* ---- 7) تنظيف: حذف الطلبين والمشروع ---- */
  await A.evaluate(async ([mk1, mk2]) => {
    const tk = localStorage.getItem('basma_token');
    const H = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tk };
    const st = await (await fetch('/api/state', { headers: H })).json();
    const reqs = (st.data.requests || []).filter((r) => (r.notes || '').includes(mk1) || (r.notes || '').includes(mk2));
    for (const r of reqs) {
      if (r.projectId) await fetch('/api/mutate', { method: 'POST', headers: H, body: JSON.stringify({ op: 'delete', collection: 'projects', id: r.projectId }) });
      await fetch('/api/mutate', { method: 'POST', headers: H, body: JSON.stringify({ op: 'delete', collection: 'requests', id: r.id }) });
    }
    const tks = (st.data.tasks || []).filter((t) => t.title.includes(mk1) || (st.data.projects || []).some((pp) => pp.fromRequest && pp.title.includes(mk1) && t.projectId === pp.id));
    for (const t of tks) await fetch('/api/mutate', { method: 'POST', headers: H, body: JSON.stringify({ op: 'delete', collection: 'tasks', id: t.id }) });
  }, [MARK, MARK2]);
  await A.waitForTimeout(800);
  await A.goto(BASE + '/#/requests'); await A.waitForTimeout(900);
  ok('تنظيف الطلبات', !(await A.locator('body').innerText()).includes(MARK));

  ok('مفيش pageerrors', errs.length === 0);
  if (errs.length) console.log('ERRS:', errs.slice(0, 6));

  const pass = R.filter(Boolean).length;
  console.log('\nV4-4 projects suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  await b.close();
  process.exit(pass === R.length ? 0 : 1);
})();
