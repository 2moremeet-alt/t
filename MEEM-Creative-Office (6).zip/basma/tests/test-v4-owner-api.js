/* MEEM V4-6 API — الهوية العامة + مصفوفة صلاحيات تُفرض backend + سجل غير قابل للتعديل */
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };

async function j(path, { method = 'GET', token, body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null; try { data = await res.json(); } catch (e) {}
  return { status: res.status, data };
}

(async () => {
  const aT = (await j('/api/login', { method: 'POST', body: { email: 'admin@meem.studio', password: '123456' } })).data.token;
  const dT = (await j('/api/login', { method: 'POST', body: { email: 'designer@meem.studio', password: '123456' } })).data.token;
  const cT = (await j('/api/login', { method: 'POST', body: { email: 'client@meem.studio', password: '123456' } })).data.token;
  ok('تسجيل الدخول', !!(aT && dT && cT));

  /* ---- 1) الهوية العامة بدون تسجيل ---- */
  const pub = await j('/api/brand');
  ok('GET /api/brand عام وفيه siteName/primary', pub.status === 200 && pub.data.ok && !!pub.data.brand.siteName && !!pub.data.brand.primary);

  /* ---- 2) الأدمن يغيّر الهوية ---- */
  const st0 = await j('/api/state', { token: aT });
  const brandOld = (st0.data.data.settings || []).find((x) => x.id === 'brand') || {};
  const upd = await j('/api/mutate', { method: 'POST', token: aT, body: { collection: 'settings', doc: Object.assign({}, brandOld, { siteName: 'MEE M TEST', primary: '#ff0000' }) } });
  const pub2 = await j('/api/brand');
  ok('تغيير الهوية وصل الراوت العام', upd.status === 200 && pub2.data.brand.siteName === 'MEE M TEST' && pub2.data.brand.primary === '#ff0000');
  await j('/api/mutate', { method: 'POST', token: aT, body: { collection: 'settings', doc: brandOld } }); /* إرجاع */

  /* ---- 3) المصفوفة الافتراضية: المصمم يكتب مهام ---- */
  const t1 = await j('/api/mutate', { method: 'POST', token: dT, body: { collection: 'tasks', doc: { title: 'V46 فحص', dept: 'design', type: 'x', status: 'new' } } });
  const tid = t1.data && t1.data.doc && t1.data.doc.id;
  ok('المصمم يكتب مهام (افتراضي)', t1.status === 200);

  /* ---- 4) قفل tasks للمصمم من المصفوفة → 403 فوري ---- */
  await j('/api/mutate', { method: 'POST', token: aT, body: { collection: 'settings', doc: { id: 'perms', matrix: { designer: { tasks: false, designs: true } } } } });
  const t2 = await j('/api/mutate', { method: 'POST', token: dT, body: { collection: 'tasks', doc: { title: 'V46 ممنوع', dept: 'design', type: 'x', status: 'new' } } });
  const t3 = await j('/api/mutate', { method: 'POST', token: dT, body: { collection: 'designs', doc: { title: 'V46 تصميم', w: 100, h: 100, pages: [], layers: [], status: 'draft', owner: 'usr_design' } } });
  ok('المصفوفة بتُفرض server-side (tasks=403, designs=200)', t2.status === 403 && t3.status === 200);

  /* ---- 5) المصفوفة مش بتمنح الممنوعات (IDOR) ---- */
  await j('/api/mutate', { method: 'POST', token: aT, body: { collection: 'settings', doc: { id: 'perms', matrix: { designer: { settings: true, activity: true, users: true, chats: true, invoices: true } } } } });
  const h1 = await j('/api/mutate', { method: 'POST', token: dT, body: { collection: 'settings', doc: { id: 'tools', ai: true } } });
  const h2 = await j('/api/mutate', { method: 'POST', token: dT, body: { collection: 'activity', doc: { text: 'hack' } } });
  const h3 = await j('/api/mutate', { method: 'POST', token: dT, body: { collection: 'invoices', doc: { number: 'X', clientId: 'c', total: 1 } } });
  ok('settings/activity ممنوعة دائمًا حتى لو المصفوفة منحتها', h1.status === 403 && h2.status >= 400);
  ok('لكن المنح المشروع شغال (invoices=200)', h3.status === 200);
  if (h3.data && h3.data.doc) await j('/api/mutate', { method: 'POST', token: aT, body: { op: 'delete', collection: 'invoices', id: h3.data.doc.id } });

  /* ---- 6) العميل خارج اللعبة دائمًا ---- */
  const c1 = await j('/api/mutate', { method: 'POST', token: cT, body: { collection: 'tasks', doc: { title: 'x' } } });
  ok('العميل 403 دائمًا', c1.status === 403);

  /* ---- 7) سجل النشاط غير قابل للتعديل حتى للأدمن ---- */
  const act = await j('/api/mutate', { method: 'POST', token: aT, body: { collection: 'activity', doc: { text: 'تلاعب' } } });
  ok('الأدمن مش قادر يكتب في السجل (مرفوض)', act.status >= 400);

  /* ---- 8) إرجاع المصفوفة → الصلاحيات ترجع ---- */
  await j('/api/mutate', { method: 'POST', token: aT, body: { collection: 'settings', doc: { id: 'perms', matrix: {} } } });
  const t4 = await j('/api/mutate', { method: 'POST', token: dT, body: { collection: 'tasks', doc: { title: 'V46 رجع', dept: 'design', type: 'x', status: 'new' } } });
  ok('بعد التصفير المصمم يكتب مهام تاني', t4.status === 200);

  /* ---- 9) تنظيف ---- */
  for (const id of [tid, t4.data.doc && t4.data.doc.id, t3.data.doc && t3.data.doc.id].filter(Boolean)) {
    const col = id === (t3.data.doc && t3.data.doc.id) ? 'designs' : 'tasks';
    await j('/api/mutate', { method: 'POST', token: aT, body: { op: 'delete', collection: col, id } });
  }
  ok('تنظيف', true);

  const pass = R.filter(Boolean).length;
  console.log('\nV4-6 API suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  process.exit(pass === R.length ? 0 : 1);
})();
