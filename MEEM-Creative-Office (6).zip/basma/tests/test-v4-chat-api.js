/* MEEM V4-5 API — شات: إرسال/تاريخ/تعديل/حذف/ملفات/ردود + صلاحيات الغرف */
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };

async function j(path, { method = 'GET', token, body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null; try { data = await res.json(); } catch (e) {}
  return { status: res.status, data };
}

(async () => {
  const a = await j('/api/login', { method: 'POST', body: { email: 'admin@meem.studio', password: '123456' } });
  const d = await j('/api/login', { method: 'POST', body: { email: 'designer@meem.studio', password: '123456' } });
  const c = await j('/api/login', { method: 'POST', body: { email: 'client@meem.studio', password: '123456' } });
  const aT = a.data.token, dT = d.data.token, cT = c.data.token;
  ok('تسجيل الدخول', !!(aT && dT && cT));
  const dm = 'dm:' + [a.data.user.id, d.data.user.id].sort().join(':');
  const MK = 'V45API ' + Date.now();

  /* ---- 1) إرسال رسالة + ملف + رد ---- */
  const s1 = await j('/api/chat', { method: 'POST', token: aT, body: { room: dm, text: MK + ' الأولى' } });
  ok('إرسال رسالة DM', s1.status === 200 && s1.data.ok && s1.data.doc.room === dm);
  const s2 = await j('/api/chat', { method: 'POST', token: aT, body: { room: dm, text: '', file: { name: 'بريف.pdf', url: '/uploads/x.pdf' }, reply: { id: s1.data.doc.id, name: a.data.user.name, snippet: MK } } });
  ok('رسالة بملف ورد', s2.status === 200 && s2.data.doc.file && s2.data.doc.file.name === 'بريف.pdf' && s2.data.doc.reply && s2.data.doc.reply.id === s1.data.doc.id);
  const s3 = await j('/api/chat', { method: 'POST', token: aT, body: { room: dm, text: '' } });
  ok('رسالة فاضية بدون ملف → 400', s3.status === 400);

  /* ---- 2) التاريخ + الترقيم ---- */
  const h1 = await j('/api/chat-history?room=' + encodeURIComponent(dm) + '&limit=10', { token: dT });
  ok('التاريخ رجّع الرسائل', h1.status === 200 && (h1.data.msgs || []).some((m) => m.text === MK + ' الأولى'));
  const newest = (h1.data.msgs || [])[h1.data.msgs.length - 1];
  const h2 = await j('/api/chat-history?room=' + encodeURIComponent(dm) + '&before=' + encodeURIComponent(newest.at) + '&limit=10', { token: dT });
  ok('before بيستثني الأحدث', h2.status === 200 && !(h2.data.msgs || []).some((m) => m.id === newest.id));

  /* ---- 3) تعديل: صاحبها فقط ---- */
  const e1 = await j('/api/chat', { method: 'POST', token: dT, body: { room: dm, editId: s1.data.doc.id, text: MK + ' معدّلة' } });
  ok('تعديل رسالة الغير → 403', e1.status === 403);
  const e2 = await j('/api/chat', { method: 'POST', token: aT, body: { room: dm, editId: s1.data.doc.id, text: MK + ' معدّلة' } });
  const h3 = await j('/api/chat-history?room=' + encodeURIComponent(dm) + '&limit=20', { token: aT });
  const edited = (h3.data.msgs || []).find((m) => m.id === s1.data.doc.id);
  ok('تعديل رسالة النفس ✓ + علامة edited', e2.status === 200 && edited && edited.text === MK + ' معدّلة' && edited.edited === true);

  /* ---- 4) حذف: صاحبها أو أدمن ---- */
  const del1 = await j('/api/chat', { method: 'POST', token: dT, body: { room: dm, deleteId: s1.data.doc.id } });
  ok('حذف رسالة الغير (مش أدمن) → 403', del1.status === 403);
  const del2 = await j('/api/chat', { method: 'POST', token: aT, body: { room: dm, deleteId: s2.data.doc.id } });
  const h4 = await j('/api/chat-history?room=' + encodeURIComponent(dm) + '&limit=20', { token: aT });
  ok('الأدمن حذف رسالة ✓', del2.status === 200 && !(h4.data.msgs || []).some((m) => m.id === s2.data.doc.id));

  /* ---- 5) صلاحيات الغرف: العميل بره DM ---- */
  const x1 = await j('/api/chat', { method: 'POST', token: cT, body: { room: dm, text: 'hack' } });
  const x2 = await j('/api/chat-history?room=' + encodeURIComponent(dm), { token: cT });
  ok('العميل في DM موظفين → 403 (إرسال + تاريخ)', x1.status === 403 && x2.status === 403);

  /* ---- 6) تنظيف ---- */
  await j('/api/chat', { method: 'POST', token: aT, body: { room: dm, deleteId: s1.data.doc.id } });
  const h5 = await j('/api/chat-history?room=' + encodeURIComponent(dm) + '&limit=50', { token: aT });
  ok('تنظيف الرسائل', !(h5.data.msgs || []).some((m) => (m.text || '').includes(MK)));

  const pass = R.filter(Boolean).length;
  console.log('\nV4-5 API suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  process.exit(pass === R.length ? 0 : 1);
})();
