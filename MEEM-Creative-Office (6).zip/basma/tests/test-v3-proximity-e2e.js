/* MEEM V3-2 E2E — القرب والتفاعل: فقاعات، إيموتات، بوكسات خاصة، كائنات، typing */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const FORCE2D = (b) => { const orig = b.newContext.bind(b); b.newContext = async (opts) => { const ctx = await orig(opts); try { ctx.addInitScript(() => { try { localStorage.setItem('meem_view3d', '0'); } catch (e) {} }); } catch (e) {} return ctx; }; return b; };
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

async function login(b, email) {
  const p = await b.newPage();
  p.on('pageerror', (e) => errs.push(email + ' pageerror: ' + e.message));
  p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(email + ': ' + m.text()); });
  await p.goto(BASE + '/?r=' + Date.now() + Math.random(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', email);
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.office-map', { timeout: 15000 });
  await p.waitForTimeout(800);
  return p;
}
const clickWorld = async (p, x, y) => {
  const mb = await p.locator('.office-map').boundingBox();
  await p.mouse.click(mb.x + (x / 100) * mb.width, mb.y + (y / 100) * mb.height);
};

(async () => {
  const b = FORCE2D(await chromium.launch({ args: ['--no-sandbox'] }));
  const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const ctx2 = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const A = await ctx.newPage();
  A.on('pageerror', (e) => errs.push('A pageerror: ' + e.message));
  A.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push('A: ' + m.text()); });
  await A.goto(BASE + '/?r=1a', { waitUntil: 'networkidle' });
  await A.waitForSelector('.login-card');
  await A.fill('input[type=email]', 'designer@meem.studio');
  await A.fill('input[type=password]', '123456');
  await A.click('.login-card .btn.primary');
  await A.waitForSelector('.office-map', { timeout: 15000 });
  await A.waitForTimeout(800);
  const B = await ctx2.newPage();
  B.on('pageerror', (e) => errs.push('B pageerror: ' + e.message));
  B.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push('B: ' + m.text()); });
  await B.goto(BASE + '/?r=1b', { waitUntil: 'networkidle' });
  await B.waitForSelector('.login-card');
  await B.fill('input[type=email]', 'content@meem.studio');
  await B.fill('input[type=password]', '123456');
  await B.click('.login-card .btn.primary');
  await B.waitForSelector('.office-map', { timeout: 15000 });
  await B.waitForTimeout(800);

  /* ---- 1) التقارب: الاتنين يمشوا لنفس النقطة ---- */
  await clickWorld(A, 50, 53);
  await clickWorld(B, 50, 53);
  await A.waitForTimeout(3000);
  await B.waitForTimeout(1200);
  ok('شريط «قريبين منك» ظهر للمصمم وفيه المحتوى', (await A.locator('.of-near-b').count()) === 1 && (await A.textContent('.of-near-b')).includes('أحمد'));

  /* ---- 2) فقاعة قريبة توصل ---- */
  await A.fill('.of-say', 'ياهلا يا صديقي');
  await A.press('.of-say', 'Enter');
  await B.waitForTimeout(900);
  ok('فقاعة المصمم ظهرت عنده', (await A.locator('.of-bubble').count()) >= 1);
  ok('الفقاعة وصلت للمحتوى القريب (نصها صح)', (await B.locator('.of-bubble').count()) === 1 && (await B.textContent('.of-bubble')).includes('ياهلا'));

  /* ---- 3) كائن تفاعلي: ماكينة القهوة → بريك + 🎧 ---- */
  await A.locator('.of-hot#hs-coffee, .of-hot[title="بريك قهوة"]').first().click();
  await A.waitForTimeout(400);
  ok('القهوة قلبت الحالة مشغول (chip on)', (await A.locator('.of-status-chip.on').textContent()).includes('مشغول'));
  ok('فقاعة ☕ وصلت للقريب', (await B.locator('.of-bubble').count()) >= 1);
  await B.waitForTimeout(900);
  ok('المحتوى شايف 🎧 فوق المصمم المشغول', (await B.locator('.of-badge').allTextContents()).some((t) => t.includes('🎧')));

  /* ---- 4) البعد بيخفي الفقاعات والإيموتات ---- */
  await clickWorld(B, 90, 56);
  await B.waitForTimeout(3200);
  await A.fill('.of-say', 'رسالة بعيدة');
  await A.press('.of-say', 'Enter');
  await A.locator('.of-emo').first().click();
  await B.waitForTimeout(1000);
  ok('البعيد مش شايف الفقاعة', (await B.locator('.of-bubble').count()) === 0);
  ok('البعيد مش شايف الإيموت', (await B.locator('.of-emote').count()) === 0);

  /* ---- 5) بوكس خاص: اللي بره معزول ---- */
  await clickWorld(B, 47, 53);
  await B.waitForTimeout(3000);
  await A.waitForTimeout(900);
  ok('المصمم شايف 🔒 على المحتوى جوّه البوكس', (await A.locator('.of-badge').allTextContents()).some((t) => t.includes('🔒')));
  await B.fill('.of-say', 'كلام سرّي جوّه البوكس');
  await B.press('.of-say', 'Enter');
  await A.waitForTimeout(1000);
  ok('اللي بره البوكس مش شايف كلامه', (await A.locator('.of-bubble').count()) === 0);

  /* ---- 6) دخول المصمم نفس البوكس → قناة خاصة + الفقاعات تشتغل ---- */
  await clickWorld(A, 47, 55);
  await A.waitForTimeout(2600);
  ok('قناة البوكس ظاهرة للمصمم', await A.locator('.of-chan:not([hidden])').count() === 1);
  ok('القناة فيها الاتنين', (await A.locator('.of-chan .oc-m').count()) === 2);
  await B.fill('.of-say', 'اتفضلت جوّه؟');
  await B.press('.of-say', 'Enter');
  await A.waitForTimeout(1000);
  ok('فقاعة البوكس وصلت للمصمم جوّه', (await A.locator('.of-bubble').allTextContents()).some((t) => t.includes('جوّه')));

  /* ---- 7) 💬 من شريط القرب يفتح DM + typing indicator ✍️ ---- */
  await B.locator('.of-near-b').first().click();
  await B.waitForTimeout(900);
  ok('زر القرب فتح الشات للمحتوى', B.url().includes('#/chat'));
  await B.fill('.chat-input', 'بكتبلك دلوقتي');
  await A.waitForTimeout(2200);
  ok('المصمم شايف ✍️ typing فوق المحتوى', (await A.locator('.of-badge').allTextContents()).some((t) => t.includes('✍️')));

  /* ---- 8) كائنات: مقفول لغير الإدارة + راوت ---- */
  await B.goto(BASE + '/#/office', { waitUntil: 'networkidle' });
  await B.waitForSelector('.office-map');
  await clickWorld(A, 33, 55);
  await A.waitForTimeout(2400);
  await A.locator('.of-flr').nth(1).click();
  await A.waitForTimeout(600);
  await A.locator('.of-hot[title="إعلانات الإدارة"]').click();
  await A.waitForTimeout(700);
  ok('السبورة مقفولة على المصمم (فضل في المكتب)', A.url().includes('#/office'));
  await A.locator('.of-flr').nth(0).click();
  await A.waitForTimeout(600);
  await A.locator('.of-hot[title="لوحة مشاريع التصميم"]').click();
  await A.waitForTimeout(800);
  ok('كمبيوتر التصميم فتح لوحة المشاريع', A.url().includes('#/design'));

  ok('صفر أخطاء console عند الطرفين', errs.length === 0);
  if (errs.length) console.log('ERRORS:\n' + errs.slice(0, 10).join('\n'));

  await b.close();
  const pass = R.filter(Boolean).length;
  console.log(`\nV3-2 Proximity: ${pass}/${R.length}`);
  process.exit(pass === R.length ? 0 : 1);
})();
