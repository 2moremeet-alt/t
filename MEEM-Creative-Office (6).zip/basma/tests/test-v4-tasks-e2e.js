/* MEEM V4-3 E2E — نظام المهام الكامل: حقول، منفذون متعددون، خطوات، سجل عمل، اعتماد، Blocked، توافق قديم */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];
const GL = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];

async function mk(ctx, email) {
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(email + ' PE: ' + e.message.slice(0, 140)));
  await p.goto(BASE + '/?r=' + email + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', email);
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.office-map, .of3d-canvas, .page-head', { timeout: 70000 });
  await p.waitForTimeout(600);
  return p;
}

(async () => {
  const b = await chromium.launch({ args: GL });
  const c1 = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const A = await mk(c1, 'admin@meem.studio');
  const TITLE = 'مهمة V4-3 الشاملة ' + Date.now();

  /* ---- 1) مودال المهمة فيه الحقول الجديدة ---- */
  await A.goto(BASE + '/#/dashboard'); await A.waitForTimeout(900);
  await A.locator('button', { hasText: 'مهمة جديدة' }).first().click();
  await A.waitForSelector('.modal-backdrop');
  await A.waitForTimeout(500);
  const modal = A.locator('.modal-backdrop');
  ok('تاريخ بدء + ساعات تقديرية', (await modal.locator('input[type=date]').count()) >= 2 && (await modal.locator('input[type=number]').count()) >= 1);
  let cbCount = 0;
  for (let i = 0; i < 10 && cbCount < 5; i++) { cbCount = await modal.locator('.col input[type=checkbox]').count(); if (cbCount < 5) await A.waitForTimeout(400); }
  ok('قائمة منفذين متعددة (checkboxes)', cbCount >= 5);
  ok('محرر خطوات فرعية + إرفاق', (await modal.locator('button', { hasText: 'خطوة' }).count()) >= 1 && (await modal.locator('button', { hasText: 'إرفاق' }).count()) >= 1);

  /* ---- 2) إنشاء مهمة كاملة ---- */
  await modal.locator('input').first().fill(TITLE);
  /* منفذان: أول checkbox (أدمن) + التاني (مصمم) */
  await modal.locator('label', { hasText: 'ميم عبدالله' }).locator('input').check();
  await modal.locator('label', { hasText: /^ميم\s*$/ }).locator('input').check();
  /* خطوتان فرعيتان */
  const subIn = modal.locator('input[placeholder*="خطوة"]');
  await subIn.fill('تجميع المراجع');
  await modal.locator('button', { hasText: 'خطوة' }).click();
  await subIn.fill('تنفيذ النسخة الأولى');
  await modal.locator('button', { hasText: 'خطوة' }).click();
  /* ساعات + تواريخ */
  await modal.locator('input[type=number]').first().fill('4');
  await modal.locator('input[type=date]').first().fill('2026-09-20');
  await modal.locator('input[type=date]').nth(1).fill('2026-09-25');
  await modal.locator('button', { hasText: 'حفظ' }).last().click();
  await A.waitForTimeout(1200);

  /* ---- 3) الكانبان بيعرض المؤشرات ---- */
  await A.goto(BASE + '/#/tasks'); await A.waitForTimeout(1000);
  const card = A.locator('.kb-card', { hasText: TITLE });
  ok('الكارت فيه ☑0/2 و⏱4 و👥2', (await card.innerText()).includes('0/2') && (await card.innerText()).includes('4س') && (await card.innerText()).includes('2'));

  /* ---- 4) التفاصيل: خطوات + سجل عمل ---- */
  await card.click();
  await A.waitForSelector('.modal-backdrop');
  const det = A.locator('.modal-backdrop');
  const subChecks = det.locator('.grid2 .col input[type=checkbox]');
  await subChecks.first().check();
  await A.waitForTimeout(900);
  ok('الخطوة اتعلّمت واتحفظت (1/2)', (await det.innerText()).includes('1/2'));
  await det.locator('input[type=number]').first().fill('2');
  await det.locator('input[placeholder*="اشتغلت"]').fill('تجميع المراجع من العميل');
  await det.locator('button', { hasText: 'سجّل وقت' }).click();
  await A.waitForTimeout(900);
  ok('سجل العمل: فعلي 2س / تقديري 4س', (await det.innerText()).includes('2س / التقديري 4س'));

  /* ---- 5) مراجعة → اعتماد ---- */
  await det.locator('select').first().selectOption('review');
  await A.waitForTimeout(1000);
  ok('أزرار الاعتماد ظهرت في المراجعة', (await det.locator('button', { hasText: 'اعتماد' }).count()) >= 1);
  await det.locator('button', { hasText: 'اعتماد' }).click();
  await A.waitForTimeout(1000);
  await A.goto(BASE + '/#/tasks'); await A.waitForTimeout(900);
  const doneCol = A.locator('.kb-col', { hasText: 'تم ✓' });
  ok('المهمة المعتمدة في عمود تم ✓', (await doneCol.innerText()).includes(TITLE));

  /* ---- 6) الخط الزمني فيه أحداث ---- */
  await A.locator('.kb-card', { hasText: TITLE }).click();
  await A.waitForSelector('.modal-backdrop');
  const tl = await A.locator('.modal-backdrop').innerText();
  ok('الخط الزمني فيه إنشاء + تسجيل وقت + اعتماد', tl.includes('ساعة عمل') && tl.includes('اعتمد المهمة'));
  await A.keyboard.press('Escape');

  /* ---- 7) حالة Blocked ---- */
  await A.locator('.kb-card', { hasText: TITLE }).click();
  await A.waitForSelector('.modal-backdrop');
  await A.locator('.modal-backdrop select').first().selectOption('blocked');
  await A.waitForTimeout(1000);
  await A.keyboard.press('Escape');
  await A.waitForTimeout(500);
  ok('الكارت اتعلّم blocked', (await A.locator('.kb-card.blocked', { hasText: TITLE }).count()) === 1);
  ok('عمود متوقفة موجود في الكانبان', (await A.locator('.kb-col-head', { hasText: 'متوقفة' }).count()) === 1);

  /* ---- 8) المنفذ التاني شايف المهمة عنده ---- */
  const c2 = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const D = await mk(c2, 'designer@meem.studio');
  await D.goto(BASE + '/#/tasks'); await D.waitForTimeout(900);
  await D.locator('button, label', { hasText: 'مهامي' }).first().click().catch(() => {});
  await D.waitForTimeout(700);
  const dTxt = await D.evaluate(() => document.body.innerText);
  ok('المصمم (منفذ تاني) شايف المهمة', dTxt.includes(TITLE));
  await D.close();

  /* ---- 9) توافق قديم: مهمة قديمة بحقول ناقصة تفتح وتتعدل ---- */
  await A.locator('.kb-card').first().click();
  await A.waitForSelector('.modal-backdrop');
  ok('مهمة قديمة تفتح من غير انهيار', (await A.locator('.modal-backdrop').count()) === 1);
  await A.keyboard.press('Escape');

  /* ---- 10) تنظيف ---- */
  await A.evaluate(async (title) => {
    const tk = localStorage.getItem('basma_token');
    const H = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tk };
    const st = await (await fetch('/api/state', { headers: H })).json();
    const t = (st.data.tasks || []).find((x) => x.title === title);
    if (t) await fetch('/api/mutate', { method: 'POST', headers: H, body: JSON.stringify({ op: 'delete', collection: 'tasks', id: t.id }) });
  }, TITLE);
  await A.waitForTimeout(700);
  ok('تنظيف المهمة', !(await A.evaluate((t2) => document.body.innerText.includes(t2), TITLE)));

  ok('مفيش pageerrors', errs.length === 0);
  if (errs.length) console.log('ERRS:', errs.slice(0, 6));

  const pass = R.filter(Boolean).length;
  console.log('\nV4-3 tasks suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  await b.close();
  process.exit(pass === R.length ? 0 : 1);
})();
