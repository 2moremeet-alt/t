/* MEEM V4-3 API — حقول المهام الجديدة تُحفظ وتُقرأ + حالة blocked + صلاحيات mutate */
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };

async function j(path, { method = 'GET', token, body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null; try { data = await res.json(); } catch (e) {}
  return { status: res.status, data };
}

(async () => {
  const aT = (await j('/api/login', { method: 'POST', body: { email: 'admin@meem.studio', password: '123456' } })).data.token;
  const dT = (await j('/api/login', { method: 'POST', body: { email: 'designer@meem.studio', password: '123456' } })).data.token;
  const cT = (await j('/api/login', { method: 'POST', body: { email: 'client@meem.studio', password: '123456' } })).data.token;
  ok('تسجيل الدخول (أدمن/مصمم/عميل)', !!(aT && dT && cT));
  const dUser = (await j('/api/me', { token: dT })).data.user;

  /* ---- 1) إنشاء مهمة بكل حقول V4-3 ---- */
  const id = 'tk_v43_' + Date.now();
  const doc = {
    id, dept: 'design', type: 'بوستر', title: 'مهمة API V4-3', desc: '', assignee: dUser.id,
    assignees: [dUser.id], status: 'blocked', priority: 'high',
    start: '2026-09-18', due: '2026-09-30', est: 6, words: 0, lang: 'ar',
    subtasks: [{ id: 's1', text: 'بحث', done: false }, { id: 's2', text: 'سكتشات', done: false }],
    log: [], history: [{ at: new Date().toISOString(), userId: 'u_admin', text: 'أنشأ المهمة' }],
    comments: [], files: [],
  };
  const up = await j('/api/mutate', { method: 'POST', token: aT, body: { collection: 'tasks', doc } });
  ok('إنشاء مهمة blocked بحقول V4-3', up.status === 200 && up.data.ok);

  /* ---- 2) الحقول رجعت سليمة في /api/state ---- */
  const st = await j('/api/state', { token: aT });
  const t1 = (st.data.data.tasks || []).find((x) => x.id === id);
  ok('الحقول محفوظة: est/start/subtasks/history/assignees',
    !!t1 && t1.status === 'blocked' && t1.est === 6 && t1.start === '2026-09-18' && t1.subtasks.length === 2 && t1.history.length === 1 && t1.assignees.length === 1);

  /* ---- 3) المنفذ يسجل وقت عمل ---- */
  t1.log.push({ id: 'l1', userId: dUser.id, hours: 2.5, note: 'سكتشات أولية', at: new Date().toISOString() });
  t1.subtasks[0].done = true;
  const up2 = await j('/api/mutate', { method: 'POST', token: dT, body: { collection: 'tasks', doc: t1 } });
  const st2 = await j('/api/state', { token: dT });
  const t2 = (st2.data.data.tasks || []).find((x) => x.id === id);
  ok('سجل العمل والخطوة اتحفظوا من حساب المنفذ', up2.status === 200 && t2 && t2.log.length === 1 && t2.log[0].hours === 2.5 && t2.subtasks[0].done === true);

  /* ---- 4) العميل مرفوض من تعديل المهام ---- */
  const up3 = await j('/api/mutate', { method: 'POST', token: cT, body: { collection: 'tasks', doc: Object.assign({}, t2, { status: 'done' }) } });
  ok('العميل مش قادر يعدل مهام (403)', up3.status === 403);

  /* ---- 5) اعتماد: review → done مع سجل تاريخ ---- */
  t2.status = 'review';
  await j('/api/mutate', { method: 'POST', token: aT, body: { collection: 'tasks', doc: t2 } });
  t2.status = 'done';
  t2.history.push({ at: new Date().toISOString(), userId: 'u_admin', text: 'اعتمد المهمة ✅' });
  await j('/api/mutate', { method: 'POST', token: aT, body: { collection: 'tasks', doc: t2 } });
  const st3 = await j('/api/state', { token: aT });
  const t3 = (st3.data.data.tasks || []).find((x) => x.id === id);
  ok('دورة review→done والخط الزمني محفوظ', t3.status === 'done' && t3.history.length === 2);

  /* ---- 6) تنظيف ---- */
  const del = await j('/api/mutate', { method: 'POST', token: aT, body: { op: 'delete', collection: 'tasks', id } });
  const st4 = await j('/api/state', { token: aT });
  ok('تنظيف المهمة', del.status === 200 && !(st4.data.data.tasks || []).some((x) => x.id === id));

  const pass = R.filter(Boolean).length;
  console.log('\nV4-3 API suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  process.exit(pass === R.length ? 0 : 1);
})();
