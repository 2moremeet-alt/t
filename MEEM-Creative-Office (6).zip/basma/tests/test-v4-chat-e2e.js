/* MEEM V4-5 E2E — شات متقدم + مركز إشعارات + كارت قرب 3D */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const fs = require('fs');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];
const GL = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];
const MK = 'V45E2E ' + Date.now();

async function j(path, { method = 'GET', token, body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null; try { data = await res.json(); } catch (e) {}
  return { status: res.status, data };
}

async function mk(ctx, email) {
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(email + ' PE: ' + e.message.slice(0, 140)));
  await p.goto(BASE + '/?r=' + email + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', email);
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.page-head, .office-map, .of3d-canvas', { timeout: 25000 });
  await p.waitForTimeout(800);
  return p;
}

(async () => {
  const aTok = (await j('/api/login', { method: 'POST', body: { email: 'admin@meem.studio', password: '123456' } })).data;
  const dTok = (await j('/api/login', { method: 'POST', body: { email: 'designer@meem.studio', password: '123456' } })).data;
  const aT = aTok.token, dT = dTok.token;
  const dm = 'dm:' + [aTok.user.id, dTok.user.id].sort().join(':');

  /* بذر 55 رسالة قديمة في العام (لاختبار تحميل الأقدم) */
  const seeded = [];
  await j('/api/chat', { method: 'POST', token: aT, body: { room: 'general', text: 'OLDEST-MARKER-' + MK } });
  for (let i = 1; i <= 120; i++) {
    const r = await j('/api/chat', { method: 'POST', token: aT, body: { room: 'general', text: 'OLD-' + i + ' ' + MK } });
    seeded.push(r.data.doc.id);
  }

  const b = await chromium.launch({ args: GL });
  const A = await mk(await b.newContext({ viewport: { width: 1500, height: 950 } }), 'admin@meem.studio');
  const D = await mk(await b.newContext({ viewport: { width: 1500, height: 950 } }), 'designer@meem.studio');

  /* ---- 1) تحميل الأقدم ---- */
  await A.goto(BASE + '/#/chat'); await A.waitForTimeout(1300);
  await A.locator('.chat-room', { hasText: 'العام' }).first().click();
  await A.waitForTimeout(700);
  ok('زر «تحميل رسائل أقدم» موجود', (await A.locator('button', { hasText: 'تحميل رسائل أقدم' }).count()) >= 1);
  ok('أقدم رسالة مش ظاهرة قبل التحميل', !(await A.locator('.chat-msgs').innerText()).includes('OLDEST-MARKER'));
  await A.locator('button', { hasText: 'تحميل رسائل أقدم' }).click();
  await A.waitForTimeout(1200);
  ok('بعد التحميل: أقدم رسالة ظهرت', (await A.locator('.chat-msgs').innerText()).includes('OLDEST-MARKER'));

  /* ---- 2) DM جديد من الأدمن ---- */
  await A.locator('.chat-new').click();
  await A.waitForSelector('.modal-backdrop');
  await A.locator('.dm-pick', { hasText: 'ميم' }).first().click();
  await A.waitForTimeout(900);
  await A.locator('.chat-input').fill(MK + ' MSG1');
  await A.locator('.chat-input').press('Enter');
  await A.waitForTimeout(1000);
  ok('الرسالة اتبعتت في DM', (await A.locator('.chat-msgs').innerText()).includes(MK + ' MSG1'));

  /* ---- 3) إشعار + unread عند المصمم ---- */
  await D.waitForTimeout(1200);
  const badge = await D.locator('.bell-badge').innerText().catch(() => '');
  ok('جرس الإشعارات زاد عند المصمم', badge && parseInt(badge, 10) >= 1);
  await D.goto(BASE + '/#/chat'); await D.waitForTimeout(1200);
  const dmRoom = D.locator('.chat-room', { hasText: 'ميم عبدالله' }).first();
  ok('شارة غير مقروء على غرفة الـ DM', (await dmRoom.locator('.room-badge').count()) >= 1);
  await dmRoom.click();
  await D.waitForTimeout(900);
  ok('الرسالة ظاهرة عند المصمم', (await D.locator('.chat-msgs').innerText()).includes(MK + ' MSG1'));
  ok('الشارة اختفت بعد الفتح', (await D.locator('.chat-room', { hasText: 'ميم عبدالله' }).first().locator('.room-badge').count()) === 0);

  /* ---- 4) رد ---- */
  const msg1 = D.locator('.chat-msg', { hasText: MK + ' MSG1' }).first();
  await msg1.hover();
  await msg1.locator('button[title="رد"]').click();
  await D.waitForTimeout(500);
  ok('شريط الرد ظهر', (await D.locator('.chat-reply-bar').count()) === 1);
  await D.locator('.chat-input').fill(MK + ' REPLY');
  await D.locator('.chat-input').press('Enter');
  await D.waitForTimeout(1000);
  const aTxt = await A.locator('.chat-msgs').innerText();
  ok('الرد + الاقتباس وصلوا الأدمن', aTxt.includes(MK + ' REPLY') && aTxt.includes('↩'));

  /* ---- 5) تعديل ---- */
  const myMsg = A.locator('.chat-msg.mine', { hasText: MK + ' MSG1' }).first();
  await myMsg.hover();
  await myMsg.locator('button[title="تعديل"]').click();
  await A.waitForSelector('.modal-backdrop');
  await A.locator('.modal-backdrop input').fill(MK + ' EDITED');
  await A.locator('.modal-backdrop button', { hasText: 'حفظ' }).click();
  await A.waitForTimeout(1000);
  ok('التعديل اشتغل + علامة عُدّلت', (await A.locator('.chat-msgs').innerText()).includes(MK + ' EDITED') && (await A.locator('.chat-msgs').innerText()).includes('عُدّلت'));
  await D.waitForTimeout(800);
  ok('التعديل وصل المصمم لحظيًا', (await D.locator('.chat-msgs').innerText()).includes(MK + ' EDITED'));

  /* ---- 6) حذف ---- */
  const replyMsg = D.locator('.chat-msg.mine', { hasText: MK + ' REPLY' }).first();
  await replyMsg.hover();
  await replyMsg.locator('button[title="حذف"]').click();
  await D.waitForSelector('.modal-backdrop');
  await D.locator('.modal-backdrop button', { hasText: 'تأكيد' }).click();
  await D.waitForTimeout(1000);
  ok('الحذف عند المصمم', !(await D.locator('.chat-msgs').innerText()).includes(MK + ' REPLY'));
  await A.waitForTimeout(600);
  ok('الحذف وصل الأدمن لحظيًا', !(await A.locator('.chat-msgs').innerText()).includes(MK + ' REPLY'));

  /* ---- 7) typing ---- */
  await D.locator('.chat-input').fill('بكتب حاجة');
  await A.waitForTimeout(1600);
  ok('مؤشر «بيكتب…» ظهر عند الأدمن', (await A.locator('.chat-typing').innerText()).includes('بيكتب'));
  await D.locator('.chat-input').fill('');

  /* ---- 8) إيموجي ---- */
  for (let i = 0; i < 5; i++) {
    await A.locator('button[title="إيموجي"]').click();
    await A.waitForTimeout(350);
    if (await A.locator('.chat-emoji-pop').isVisible()) break;
  }
  await A.locator('.chat-emoji-pop button', { hasText: '🔥' }).click();
  ok('الإيموجي دخل الإدخال', (await A.locator('.chat-input').inputValue()).includes('🔥'));
  await A.locator('.chat-input').fill('');

  /* ---- 9) ملف ---- */
  fs.writeFileSync('/tmp/v45.png', Buffer.from('89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000d49444154789c626001000000ffff03000006000557bfabd40000000049454e44ae426082', 'hex'));
  await A.locator('input[type=file]').setInputFiles('/tmp/v45.png');
  await A.waitForTimeout(2000);
  ok('رسالة الملف ظهرت (صورة مرفقة)', (await A.locator('.chat-msgs img.chat-file-img').count()) >= 1);

  /* ---- 10) بحث فوري ---- */
  await A.locator('input[placeholder*="ابحث في الغرفة"]').fill(MK + ' EDITED');
  await A.waitForTimeout(600);
  ok('البحث فلتّر الرسالة المطلوبة', (await A.locator('.chat-msgs').innerText()).includes(MK + ' EDITED') && !(await A.locator('.chat-msgs').innerText()).includes('v45.png'));
  await A.locator('input[placeholder*="ابحث في الغرفة"]').fill('');
  await A.waitForTimeout(400);

  /* ---- 11) كارت القرب 3D ---- */
  await A.goto(BASE + '/#/office');
  await D.goto(BASE + '/#/office');
  await A.waitForFunction(() => window.__of3d && window.__of3d.ready, null, { timeout: 40000 });
  await D.waitForFunction(() => window.__of3d && window.__of3d.ready, null, { timeout: 40000 });
  await A.evaluate(() => window.__of3d.setPos(50, 50));
  await D.evaluate(() => window.__of3d.setPos(53, 50));
  await A.waitForTimeout(2500);
  let pos = null;
  for (let i = 0; i < 10 && !pos; i++) { pos = await A.evaluate((uid) => window.__of3d.peerPos(uid), dTok.user.id); if (!pos) await A.waitForTimeout(600); }
  ok('الأفاتار التاني ظاهر في المشهد', !!pos);
  if (pos) {
    let opened = false;
    for (let i = 0; i < 4 && !opened; i++) {
      const pt = await A.evaluate((uid) => window.__of3d.peerPos(uid), dTok.user.id);
      await A.evaluate((q) => {
        const cv = window.__of3d.canvas();
        for (const type of ['pointerdown', 'pointerup']) cv.dispatchEvent(new PointerEvent(type, { clientX: q.x, clientY: q.y, pointerType: 'mouse', bubbles: true }));
      }, pt);
      await A.waitForTimeout(800);
      opened = (await A.locator('.modal-backdrop').count()) > 0;
    }
    const card = A.locator('.modal-backdrop');
    const cardTxt = (await card.innerText().catch(() => ''));
    ok('كارت القرب فتح (دردشة/بروفايل/دعوة)', cardTxt.includes('دردشة') && cardTxt.includes('البروفايل') && cardTxt.includes('دعوة'));
    /* دعوة → اجتماع + رسالة DM */
    await card.locator('button', { hasText: 'دعوة' }).click();
    await A.waitForTimeout(1500);
    const stA = await j('/api/state', { token: aT });
    const mt = ((stA.data.data || {}).meetings || []).find((m) => (m.title || '').includes('مكالمة سريعة') && (m.attendees || []).includes(dTok.user.id));
    ok('الدعوة عملت اجتماع حقيقي', !!mt);
    const h = await j('/api/chat-history?room=' + encodeURIComponent(dm) + '&limit=10', { token: aT });
    ok('رسالة الدعوة وصلت DM', (h.data.msgs || []).some((m) => (m.text || '').includes('دعاك')));
    if (mt) await j('/api/mutate', { method: 'POST', token: aT, body: { op: 'delete', collection: 'meetings', id: mt.id } });
  }

  /* ---- 12) لوحة الإشعارات ---- */
  await D.locator('.bell-btn').click();
  await D.waitForTimeout(500);
  ok('لوحة الإشعارات فتحت وفيها صفوف', (await D.locator('.note-row').count()) >= 1);
  await D.locator('button', { hasText: 'تعليم الكل كمقروء' }).click();
  await D.waitForTimeout(500);
  ok('الشارة اختفت بعد التعليم', (await D.locator('.bell-badge').isVisible().catch(() => false)) === false);

  /* ---- 13) تنظيف ---- */
  const hAll = await j('/api/chat-history?room=' + encodeURIComponent(dm) + '&limit=100', { token: aT });
  for (const m of (hAll.data.msgs || [])) if ((m.text || '').includes(MK) || (m.file && m.file.name === 'v45.png')) await j('/api/chat', { method: 'POST', token: aT, body: { room: dm, deleteId: m.id } });
  for (let round = 0; round < 5; round++) {
    const hGen = await j('/api/chat-history?room=general&limit=100', { token: aT });
    const targets = (hGen.data.msgs || []).filter((m) => (m.text || '').includes(MK));
    if (!targets.length) break;
    for (const m of targets) await j('/api/chat', { method: 'POST', token: aT, body: { room: 'general', deleteId: m.id } });
  }
  const hG2 = await j('/api/chat-history?room=general&limit=100', { token: aT });
  const hD2 = await j('/api/chat-history?room=' + encodeURIComponent(dm) + '&limit=100', { token: aT });
  ok('تنظيف الرسائل', !(hG2.data.msgs || []).some((m) => (m.text || '').includes(MK)) && !(hD2.data.msgs || []).some((m) => (m.text || '').includes(MK)));

  ok('مفيش pageerrors', errs.length === 0);
  if (errs.length) console.log('ERRS:', errs.slice(0, 6));

  const pass = R.filter(Boolean).length;
  console.log('\nV4-5 chat suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  await b.close();
  process.exit(pass === R.length ? 0 : 1);
})();
