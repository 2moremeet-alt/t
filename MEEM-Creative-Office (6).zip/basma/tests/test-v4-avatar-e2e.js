/* MEEM V4-2 E2E — تخصيص الأفاتار: محرر المظهر، الحفظ والثبات، صورة البروفايل، مظهر الزملاء، Onboarding */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];
const OB_EMAIL = 'ob' + Date.now() + '@meem.studio';
const GL = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];

async function mk(ctx, email) {
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(email + ' PE: ' + e.message.slice(0, 140)));
  await p.goto(BASE + '/?r=' + email + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', email);
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  const up = () => p.waitForFunction(() => (window.__of3d && window.__of3d.ready) || !!document.querySelector('.office-map'), null, { timeout: 40000 });
  await up().catch(async () => { await p.reload({ waitUntil: 'load' }); await up(); });
  await p.waitForTimeout(600);
  return p;
}

(async () => {
  const b = await chromium.launch({ args: GL });
  const c1 = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const A = await mk(c1, 'admin@meem.studio');

  /* ---- 1) محرر المظهر في البروفايل ---- */
  await A.locator('.user-chip').click();
  await A.waitForTimeout(500);
  ok('مودال البروفايل فيه محرر المظهر + معاينة SVG', (await A.locator('.look-editor').count()) === 1 && (await A.locator('.look-preview svg').count()) === 1);
  const sels = A.locator('.look-editor select');
  ok('اختيارات شعر/ملبس/إكسسوار (3 selects)', (await sels.count()) === 3);
  ok('swatches بشرة وشعر وملبس', (await A.locator('.look-sw .sw').count()) >= 18);
  await sels.nth(0).selectOption('bun');
  await sels.nth(2).selectOption('cap');
  await A.locator('.look-row').nth(5).locator('.sw').nth(1).click(); /* لون ملبس بنفسجي */
  await A.locator('.modal-backdrop button', { hasText: 'حفظ المظهر' }).click();
  await A.waitForTimeout(1200);
  const look = await A.evaluate(() => window.__of3d.myLook());
  ok('المظهر اتطبق على الأفاتار 3D (شعر كعكة + كاب + بنفسجي)', look.hair === 'bun' && look.accessory === 'cap' && look.outfitColor === '#8b5cf6');
  await A.keyboard.press('Escape');

  /* ---- 2) الثبات بعد إعادة التحميل ---- */
  await A.reload({ waitUntil: 'load' });
  await A.waitForFunction(() => window.__of3d && window.__of3d.ready, null, { timeout: 30000 });
  const look2 = await A.evaluate(() => window.__of3d.myLook());
  ok('المظهر محفوظ server-side (ثابت بعد reload)', look2.hair === 'bun' && look2.accessory === 'cap');

  /* ---- 3) صورة البروفايل ---- */
  await A.locator('.user-chip').click();
  await A.waitForTimeout(400);
  await A.locator('.modal-backdrop input[type=file]').setInputFiles('tests/fixtures/p5img.png');
  await A.waitForTimeout(1500);
  const photo = await A.evaluate(() => (window.__meem_state ? null : null) || null).catch(() => null);
  const hasPhoto = await A.locator('.modal-backdrop .avatar.photo img').count();
  ok('صورة البروفايل اتعرضت في البروفايل', hasPhoto === 1);
  await A.keyboard.press('Escape');
  await A.waitForTimeout(400);
  ok('صورة البروفايل في الـ topbar', (await A.locator('.user-chip .avatar.photo img, .topbar .avatar.photo img').count()) >= 1);

  /* ---- 4) مظهر الزميل يوصل لحظيًا ---- */
  const c2 = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const D = await mk(c2, 'designer@meem.studio');
  const dLookSet = await D.evaluate(async () => {
    const tk = localStorage.getItem('basma_token');
    const r = await fetch('/api/look', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tk }, body: JSON.stringify({ avatar: { gender: 'f', hair: 'long', hairColor: '#b33939', outfit: 'dress', outfitColor: '#ec4899', accessory: 'headset', skin: '#f1c27d' } }) });
    return (await r.json()).ok;
  });
  ok('المصمم حفظ مظهره (API /look لنفسه)', dLookSet === true);
  await A.waitForTimeout(2000);
  const dLookX = await A.evaluate(async () => {
    const tk = localStorage.getItem('basma_token');
    const st = await (await fetch('/api/state', { headers: { Authorization: 'Bearer ' + tk } })).json();
    const u = st.data.users.find((x) => x.email === 'designer@meem.studio');
    return u.avatar;
  });
  ok('مظهر المصمم وصل للأدمن عبر الحالة (فستان + سماعة)', dLookX && dLookX.outfit === 'dress' && dLookX.accessory === 'headset');
  ok('الأدمن شايف أفاتار المصمم في المشهد', (await A.evaluate(() => window.__of3d.peers())) >= 1);

  /* ---- 5) Onboarding لموظف جديد ---- */
  await D.close(); /* تخفيف حمل WebGL قبل فتح صفحة جديدة */
  await A.goto(BASE + '/#/team'); await A.waitForTimeout(900);
  await A.locator('button', { hasText: 'حساب جديد' }).click(); await A.waitForTimeout(500);
  await A.locator('.modal-backdrop input').first().fill('موظف أونبورد');
  await A.locator('.modal-backdrop input[type=email]').fill(OB_EMAIL);
  await A.locator('.modal-backdrop button', { hasText: 'إنشاء' }).click();
  await A.waitForTimeout(1200);
  const c3 = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const N = await c3.newPage();
  N.on('pageerror', (e) => errs.push('new PE: ' + e.message.slice(0, 120)));
  await N.goto(BASE + '/?r=ob' + Date.now(), { waitUntil: 'networkidle' });
  await N.waitForSelector('.login-card');
  await N.fill('input[type=email]', OB_EMAIL);
  await N.fill('input[type=password]', '123456');
  await N.click('.login-card .btn.primary');
  await N.waitForSelector('.modal-backdrop', { timeout: 30000 }).catch(async () => {
    await N.evaluate(() => sessionStorage.removeItem('meem_ob'));
    await N.reload({ waitUntil: 'load' });
    await N.waitForSelector('.modal-backdrop', { timeout: 20000 });
  });
  const obTxt = await N.locator('.modal-backdrop').first().innerText();
  ok('Onboarding ظهر للموظف الجديد (شاشة ترحيب)', obTxt.includes('أول يوم') || obTxt.includes('أهلًا'));
  await N.locator('.modal-backdrop button', { hasText: 'التالي' }).click();
  await N.waitForSelector('.modal-backdrop .look-editor', { timeout: 8000 });
  ok('الخطوة الثانية فيها محرر المظهر (selects=3)', (await N.locator('.modal-backdrop select').count()) === 3);
  await N.locator('.modal-backdrop button', { hasText: 'يلا نبدأ' }).click();
  await N.waitForTimeout(1200);
  ok('بعد الإكمال المودال اختفى', (await N.locator('.modal-backdrop .look-editor').count()) === 0);
  await N.reload({ waitUntil: 'load' });
  await N.waitForTimeout(2500);
  ok('بعد reload مفيش Onboarding تاني (العلم محفوظ)', (await N.locator('.modal-backdrop .look-editor').count()) === 0);

  /* ---- 6) حراسة: /look للغير مرفوض (نفس الحساب فقط بالتصميم) ---- */
  const guard = await A.evaluate(async () => {
    /* الراوت بيعدّل حساب المستخدم الموثّق فقط — مفيش أي حقل لتعديل الغير؛ نتأكد إن الاستجابة ترجع بياناتي أنا */
    const tk = localStorage.getItem('basma_token');
    const r = await fetch('/api/look', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tk }, body: JSON.stringify({ avatar: { hair: 'curly' } }) });
    const j = await r.json();
    return j.ok === true && j.user.email === 'admin@meem.studio';
  });
  ok('حراسة: /look يعدّل حساب الموثّق فقط', guard === true);

  /* ---- 7) تنظيف: رجّع مظهر الأدمن الافتراضي وشيل الصورة + عطّل حساب الأونبوردنج ---- */
  await A.evaluate(async (em) => {
    const tk = localStorage.getItem('basma_token');
    const H = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tk };
    await fetch('/api/look', { method: 'POST', headers: H, body: JSON.stringify({ avatar: { gender: 'm', skin: '#ffd9b3', hair: 'short', hairColor: '#1b1b1b', outfit: 'tshirt', outfitColor: '#3d8bff', accessory: 'none' }, photo: '' }) });
    const st = await (await fetch('/api/state', { headers: H })).json();
    const ob = st.data.users.find((u) => u.email === em);
    if (ob) await fetch('/api/user', { method: 'POST', headers: H, body: JSON.stringify({ id: ob.id, active: false }) });
  }, OB_EMAIL);
  await A.waitForTimeout(800);
  const resetLook = await A.evaluate(async () => {
    const tk = localStorage.getItem('basma_token');
    const j = await (await fetch('/api/me', { headers: { Authorization: 'Bearer ' + tk } })).json();
    return j.user.avatar || {};
  });
  ok('تنظيف: مظهر الأدمن رجع افتراضي', resetLook.hair === 'short' && resetLook.accessory === 'none');

  ok('مفيش pageerrors', errs.length === 0);
  if (errs.length) console.log('ERRS:', errs.slice(0, 6));

  const pass = R.filter(Boolean).length;
  console.log('\nV4-2 avatar suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  await b.close();
  process.exit(pass === R.length ? 0 : 1);
})();
