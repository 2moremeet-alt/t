/* MEEM V4-6 E2E — مركز تحكم المالك: هوية + مصفوفة صلاحيات + Ctrl+K + ثيم */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];
const GL = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];

async function j(path, { method = 'GET', token, body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null; try { data = await res.json(); } catch (e) {}
  return { status: res.status, data };
}

(async () => {
  const b = await chromium.launch({ args: GL });
  const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push('PE: ' + e.message.slice(0, 140)));
  await p.goto(BASE + '/?r=own' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', 'owner@meem.studio');
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.owner-head, .page-head', { timeout: 30000 });
  await p.waitForTimeout(900);

  /* ---- 1) تبويب الإعدادات فيه فورم الهوية ---- */
  await p.locator('.owner-tab', { hasText: 'Settings' }).click();
  await p.waitForTimeout(600);
  ok('فورم الهوية في تبويب الإعدادات', (await p.locator('input', { hasText: '' }).count()) >= 4 && (await p.locator('text=هوية الموقع').count()) >= 1);

  /* ---- 2) تغيير الاسم واللون ---- */
  const siteInp = p.locator('.field', { hasText: 'اسم الموقع' }).locator('input');
  await siteInp.fill('MEE M E2E TEST');
  await p.locator('input[type=color]').fill('#ff0000');
  await p.locator('button', { hasText: 'حفظ الهوية' }).click();
  await p.waitForTimeout(1300);
  const sideTxt = await p.locator('.side-title').innerText().catch(() => '');
  const brandVar = await p.evaluate(() => getComputedStyle(document.documentElement).getPropertyValue('--brand').trim());
  ok('اسم الموقع اتحدث في السايدبار', sideTxt.includes('MEE M E2E TEST'));
  ok('اللون الأساسي اتطبق (CSS var)', brandVar.toLowerCase() === '#ff0000');

  /* ---- 3) تبويب الصلاحيات ---- */
  await p.locator('.owner-tab', { hasText: 'Perms' }).click();
  await p.waitForTimeout(600);
  ok('مصفوفة الصلاحيات رسمت (جدول + أدوار)', (await p.locator('.perm-table').count()) === 1 && (await p.locator('.perm-table tr').count()) >= 7);
  const cb = p.locator('.perm-table tr', { hasText: 'مصمم' }).locator('input[type=checkbox]').first();
  await cb.uncheck();
  await p.locator('button', { hasText: 'حفظ المصفوفة' }).click();
  await p.waitForTimeout(900);
  const aT = (await j('/api/login', { method: 'POST', body: { email: 'admin@meem.studio', password: '123456' } })).data.token;
  const st = await j('/api/state', { token: aT });
  const permsDoc = (st.data.data.settings || []).find((x) => x.id === 'perms');
  ok('المصفوفة اتحفظة في السيرفر', !!permsDoc && permsDoc.matrix && permsDoc.matrix.designer && permsDoc.matrix.designer.tasks === false);
  await p.locator('button', { hasText: 'إرجاع الافتراضي' }).click();
  await p.waitForTimeout(800);

  /* ---- 4) Ctrl+K ---- */
  await p.keyboard.press('Control+k');
  await p.waitForTimeout(500);
  ok('مركز الأوامر فتح', (await p.locator('.cmdk-back').count()) === 1);
  await p.locator('.cmdk-input').fill('لوحة');
  await p.waitForTimeout(400);
  ok('البحث بيفلتر النتائج', (await p.locator('.cmdk-item').count()) >= 1);
  await p.keyboard.press('Enter');
  await p.waitForTimeout(700);
  ok('Enter نقلنا للوحة المالك', p.url().includes('#/owner'));

  /* ---- 5) الثيم ---- */
  await p.goto(BASE + '/#/owner');
  await p.waitForTimeout(800);
  await p.locator('.owner-tab', { hasText: 'Settings' }).click();
  await p.waitForTimeout(500);
  await p.locator('.field', { hasText: 'ثيم المكتب' }).locator('select').selectOption('neon');
  await p.locator('button', { hasText: 'حفظ الهوية' }).click();
  await p.waitForTimeout(1000);
  const st2 = await j('/api/state', { token: aT });
  const brand2 = (st2.data.data.settings || []).find((x) => x.id === 'brand');
  ok('ثيم المكتب اتحفظ (neon)', brand2 && brand2.officeTheme === 'neon');

  /* ---- 6) إرجاع الهوية الأصلية ---- */
  await p.locator('.field', { hasText: 'اسم الموقع' }).locator('input').fill('MEE M — Creative Office');
  await p.locator('input[type=color]').fill('#0066ff');
  await p.locator('.field', { hasText: 'ثيم المكتب' }).locator('select').selectOption('default');
  await p.locator('button', { hasText: 'حفظ الهوية' }).click();
  await p.waitForTimeout(900);
  const st3 = await j('/api/state', { token: aT });
  const brand3 = (st3.data.data.settings || []).find((x) => x.id === 'brand');
  ok('إرجاع الهوية الأصلية', brand3.siteName === 'MEE M — Creative Office' && brand3.officeTheme === 'default' && brand3.primary === '#0066ff');

  ok('مفيش pageerrors', errs.length === 0);
  if (errs.length) console.log('ERRS:', errs.slice(0, 6));

  const pass = R.filter(Boolean).length;
  console.log('\nV4-6 owner suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  await b.close();
  process.exit(pass === R.length ? 0 : 1);
})();
