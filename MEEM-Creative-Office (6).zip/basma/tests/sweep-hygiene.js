/* MEEM sweep hygiene — يشيل أي صفوف أنشأتها السويتات بين الجولات
   أول تشغيل: يبني snapshot. كل تشغيل بعدها: يحذف الجديد خارج الـ snapshot. */
const fs = require('fs');
const BASE = 'http://localhost:3000';
const SNAP = '/tmp/meem-hygiene-snapshot.json';
const COLS = ['invoices', 'payments', 'expenses', 'timeentries', 'designs'];
const ROOMS = ['general', 'design', 'dev', 'prj:prj_5', 'cli:cli_nile', 'cli:cli_zahra',
  'dm:usr_design:usr_content', 'dm:usr_content:usr_design', 'dm:usr_admin:usr_design', 'dm:usr_design:usr_admin',
  'dm:usr_karim:usr_design', 'dm:usr_design:usr_karim'];

async function j(path, { method = 'GET', token, body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  try { return { status: res.status, data: await res.json() }; } catch (e) { return { status: res.status, data: null }; }
}

(async () => {
  const tok = (await j('/api/login', { method: 'POST', body: { email: 'admin@meem.studio', password: '123456' } })).data.token;
  const dTok = (await j('/api/login', { method: 'POST', body: { email: 'designer@meem.studio', password: '123456' } })).data.token;
  const st = (await j('/api/state', { token: tok })).data.data;

  const cur = {};
  for (const c of COLS) cur[c] = (st[c] || []).map((x) => x.id);
  /* كل الشات من chat-history (state فيه أحدث 100 بس) */
  const chats = {};
  for (const room of ROOMS) {
    const seen = new Map();
    for (const t of [tok, dTok]) { /* الأدمن مش شايف DMs — نجرب بالتوكنين */
      const h = await j('/api/chat-history?room=' + encodeURIComponent(room) + '&limit=500', { token: t });
      for (const m of ((h.data && (h.data.msgs || h.data.messages)) || [])) seen.set(m.id, m);
    }
    chats[room] = [...seen.values()].map((m) => ({ id: m.id, by: m.by }));
  }

  if (!fs.existsSync(SNAP)) {
    fs.writeFileSync(SNAP, JSON.stringify({ cols: cur, chats }));
    console.log('hygiene: snapshot built');
    return;
  }
  const snap = JSON.parse(fs.readFileSync(SNAP, 'utf8'));
  let n = 0;
  for (const c of COLS) {
    const keep = new Set(snap.cols[c] || []);
    for (const id of cur[c]) {
      if (keep.has(id)) continue;
      const r = await j('/api/mutate', { method: 'POST', token: tok, body: { op: 'delete', collection: c, id } });
      if (r.status === 200) n++;
    }
  }
  for (const room of Object.keys(chats)) {
    const keep = new Set((snap.chats[room] || []).map((m) => m.id));
    for (const m of chats[room]) {
      if (keep.has(m.id) || String(m.id).startsWith('cha_')) continue; /* رسائل الديمو مقدسة */
      const tk = m.by === 'usr_design' ? dTok : tok;
      const r = await j('/api/chat', { method: 'POST', token: tk, body: { room, deleteId: m.id } });
      if (r.data && r.data.ok) n++;
    }
  }
  console.log('hygiene: deleted ' + n);
})().catch((e) => { console.log('hygiene err', e.message); });
