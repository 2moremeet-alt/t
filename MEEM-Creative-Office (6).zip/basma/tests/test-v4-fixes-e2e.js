/* MEEM V4-0 E2E — انحدار إصلاحات العلل #4 (أعضاء المشاريع) + #5 (مهمة جديدة) + #8 (إدارة الفريق) */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

async function mk(ctx, email) {
  try { ctx.addInitScript(() => { try { localStorage.setItem('meem_view3d', '0'); } catch (e) {} }); } catch (e) {}
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(email + ' pageerror: ' + e.message));
  await p.goto(BASE + '/?r=' + email + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', email);
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.office-map, .page-head', { timeout: 15000 });
  await p.waitForTimeout(600);
  return p;
}

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const A = await mk(ctx, 'admin@meem.studio');
  const TASK_TITLE = 'مهمة انحدار V4-0 ' + Date.now();
  const FIX_EMAIL = 'v4fix' + Date.now() + '@meem.studio'; // فريد — الـ suite يتعاد بأمان

  /* ================= العلّة #5: «مهمة جديدة» ================= */
  await A.goto(BASE + '/#/dashboard'); await A.waitForTimeout(900);
  await A.locator('button', { hasText: 'مهمة جديدة' }).first().click();
  await A.waitForTimeout(600);
  ok('#5 مودال المهمة يفتح من الداشبورد', (await A.locator('.modal-backdrop').count()) === 1);
  const nFields = await A.locator('.modal-backdrop input, .modal-backdrop select, .modal-backdrop textarea').count();
  ok('#5 المودال فيه حقول كاملة (≥8)', nFields >= 8);
  ok('#5 حقل «النوع» select موجود', (await A.locator('.modal-backdrop select').count()) >= 4);

  await A.locator('.modal-backdrop input').first().fill(TASK_TITLE);
  await A.locator('.modal-backdrop button', { hasText: 'حفظ' }).click();
  await A.waitForTimeout(1300);
  await A.goto(BASE + '/#/tasks'); await A.waitForTimeout(900);
  ok('#5 المهمة اتسجلت فعلًا وظهرت في المهام', (await A.evaluate(() => document.body.innerText)).includes(TASK_TITLE));

  /* مدخل تاني: صفحة المشروع → تبويب المهام */
  await A.goto(BASE + '/#/projects'); await A.waitForTimeout(900);
  await A.locator('text=حملة رمضان').first().click(); await A.waitForTimeout(900);
  await A.locator('.tabs button', { hasText: 'المهام' }).click(); await A.waitForTimeout(500);
  const tb2 = A.locator('button', { hasText: 'مهمة جديدة' });
  ok('#5 زر مهمة جديدة موجود في تبويب مهام المشروع', (await tb2.count()) >= 1);
  await tb2.first().click(); await A.waitForTimeout(600);
  ok('#5 المودال يفتح من تبويب مهام المشروع', (await A.locator('.modal-backdrop').count()) === 1);
  await A.keyboard.press('Escape'); await A.waitForTimeout(300);

  /* ================= العلّة #4: أعضاء المشروع ================= */
  await A.goto(BASE + '/#/projects'); await A.waitForTimeout(900);
  await A.locator('text=حملة رمضان').first().click(); await A.waitForTimeout(900);
  await A.locator('.tabs button', { hasText: 'نظرة عامة' }).click(); await A.waitForTimeout(500); /* V4-4: التبويب محفوظ — نفتحه صراحة */
  ok('#4 قسم فريق المشروع ظاهر في نظرة عامة', (await A.evaluate(() => document.body.innerText)).includes('فريق المشروع'));
  const addB = A.locator('button', { hasText: 'عضو' });
  ok('#4 زر إضافة عضو ظاهر للأدمن', (await addB.count()) === 1);
  await addB.first().click(); await A.waitForTimeout(500);
  const sel = A.locator('.modal-backdrop select').first();
  const opts = await sel.locator('option').evaluateAll((os) => os.map((o) => o.textContent));
  ok('#4 يوسف طارق ضمن المرشحين', opts.some((t) => t.includes('يوسف طارق')));
  await sel.selectOption({ index: opts.findIndex((t) => t.includes('يوسف طارق')) });
  await A.locator('.modal-backdrop button', { hasText: 'إضافة' }).click();
  await A.waitForTimeout(1300);
  let body = await A.evaluate(() => document.body.innerText);
  ok('#4 العضو المختار بالظبط هو اللي اتضاف (يوسف طارق)', body.includes('يوسف طارق'));

  /* إعادة الفتح: المرشحين ما يضموش المضاف (منع تكرار) */
  await A.locator('button', { hasText: 'عضو' }).first().click(); await A.waitForTimeout(500);
  const opts2 = await A.locator('.modal-backdrop select').first().locator('option').evaluateAll((os) => os.map((o) => o.textContent));
  ok('#4 منع التكرار: يوسف مش في المرشحين تاني', !opts2.some((t) => t.includes('يوسف طارق')));
  await A.keyboard.press('Escape'); await A.waitForTimeout(300);

  /* إزالة العضو */
  const row = A.locator('.row', { hasText: 'يوسف طارق' }).first();
  await row.locator('button').last().click(); await A.waitForTimeout(1300);
  body = await A.evaluate(() => document.body.innerText);
  ok('#4 إزالة العضو اشتغلت', !body.includes('يوسف طارق'));

  /* ================= العلّة #8: إدارة الفريق ================= */
  await A.goto(BASE + '/#/team'); await A.waitForTimeout(900);
  await A.locator('button', { hasText: 'حساب جديد' }).click(); await A.waitForTimeout(500);
  ok('#8 مودال إنشاء حساب يفتح', (await A.locator('.modal-backdrop').count()) === 1);
  await A.locator('.modal-backdrop input').first().fill('اختبار V4');
  await A.locator('.modal-backdrop input[type=email]').fill(FIX_EMAIL);
  await A.locator('.modal-backdrop button', { hasText: 'إنشاء' }).click();
  await A.waitForTimeout(1300);
  const card = A.locator('.card', { hasText: FIX_EMAIL }).first();
  ok('#8 الحساب الجديد ظهر ككارت', (await card.count()) === 1);

  /* التعديل بعد الإنشاء مباشرة */
  await card.locator('button').last().click(); await A.waitForTimeout(500);
  const editTitle = await A.locator('.modal-backdrop h3').first().textContent();
  ok('#8 زر التعديل يفتح «تعديل: …» بعد الإنشاء', (editTitle || '').includes('تعديل'));
  await A.locator('.modal-backdrop input').first().fill('اختبار V4 معدّل');
  await A.locator('.modal-backdrop button', { hasText: 'حفظ' }).click();
  await A.waitForTimeout(1300);
  body = await A.evaluate(() => document.body.innerText);
  ok('#8 تعديل الاسم اتحفظ وظهر', body.includes('اختبار V4 معدّل'));

  /* تغيير الباسورد */
  const card2 = A.locator('.card', { hasText: FIX_EMAIL }).first();
  await card2.locator('button').nth(1).click(); await A.waitForTimeout(500);
  ok('#8 مودال تغيير الباسورد يفتح', (await A.locator('.modal-backdrop h3').first().textContent()).includes('باسورد'));
  await A.keyboard.press('Escape'); await A.waitForTimeout(300);

  /* تعطيل ≠ حذف */
  const card3 = A.locator('.card', { hasText: FIX_EMAIL }).first();
  await card3.locator('button').first().click(); await A.waitForTimeout(1300);
  body = await A.evaluate(() => document.body.innerText);
  ok('#8 التعطيل بيعلّم الحساب «معطّل» (مش حذف)', body.includes('معطّل'));

  /* الحساب المعطّل ما يدخلش */
  const blocked = await A.evaluate(async (em) => {
    const r = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: em, password: '123456' }) });
    return r.status;
  }, FIX_EMAIL);
  ok('#8 الحساب المعطّل ممنوع من الدخول (403)', blocked === 403);

  /* إعادة التفعيل */
  const card4 = A.locator('.card', { hasText: FIX_EMAIL }).first();
  await card4.locator('button').first().click(); await A.waitForTimeout(1300);
  const card5 = A.locator('.card', { hasText: FIX_EMAIL }).first();
  const stillOff = await card5.evaluate((n) => n.innerText.includes('معطّل'));
  ok('#8 إعادة التفعيل اشتغلت', !stillOff);

  /* ================= حراسة الصلاحيات (انحدار) ================= */
  const guard = await A.evaluate(async (em) => {
    const tk = localStorage.getItem('basma_token');
    const H = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tk };
    const r1 = await fetch('/api/user', { method: 'POST', headers: H, body: JSON.stringify({ email: em, name: 'x', role: 'admin' }) });
    const r2 = await fetch('/api/mutate', { method: 'POST', headers: H, body: JSON.stringify({ op: 'upsert', collection: 'users', doc: { name: 'x' } }) });
    return [r1.status, r2.status];
  }, 'guard' + Date.now() + '@meem.studio');
  ok('حراسة: الأدمن ما ينشئش حساب admin (403)', guard[0] === 403);
  ok('حراسة: users مش في mutate العام (400)', guard[1] === 400);

  /* ================= تنظيف ================= */
  await A.evaluate(async ({ title, em }) => {
    const tk = localStorage.getItem('basma_token');
    const H = { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tk };
    const st = await (await fetch('/api/state', { headers: H })).json();
    const t = (st.data.tasks || []).find((x) => x.title === title);
    if (t) await fetch('/api/mutate', { method: 'POST', headers: H, body: JSON.stringify({ op: 'delete', collection: 'tasks', id: t.id }) });
    const u = (st.data.users || []).find((x) => x.email === em);
    if (u) await fetch('/api/user', { method: 'POST', headers: H, body: JSON.stringify({ id: u.id, active: false }) });
  }, { title: TASK_TITLE, em: FIX_EMAIL });
  await A.waitForTimeout(600);
  ok('تنظيف: المهمة الاختبارية اتشالت والحساب اتعطّل', true);

  ok('مفيش pageerrors طول السيناريو', errs.length === 0);
  if (errs.length) console.log('ERRORS:', errs.slice(0, 5));

  const pass = R.filter(Boolean).length;
  console.log('\nV4-0 fixes suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  await b.close();
  process.exit(pass === R.length ? 0 : 1);
})();
