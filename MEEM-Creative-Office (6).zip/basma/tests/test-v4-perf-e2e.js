/* MEEM V4-7 E2E — أداء 3D (pooling/FPS) + responsive كامل + أزمنة التحميل + لمس/كيبورد */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const GL = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];

async function login(p, vp) {
  await p.goto(BASE + '/', { waitUntil: 'networkidle' });
  await p.fill('input[type=email]', 'designer@meem.studio');
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.sidebar, .app', { timeout: 40000 });
}
const noOverflow = (p) => p.evaluate(() => Math.max(
  document.documentElement.scrollWidth - window.innerWidth,
  document.body.scrollWidth - window.innerWidth,
));

(async () => {
  const b = await chromium.launch({ args: GL });

  /* ---- 1) Responsive: 4 مقاسات × صفحات أساسية — صفر overflow أفقي ---- */
  const VPS = [
    { name: 'موبايل طولي 390', w: 390, h: 844, touch: true },
    { name: 'موبايل عرضي 844', w: 844, h: 390, touch: true },
    { name: 'تابلت 768', w: 768, h: 1024, touch: false },
    { name: 'ديسكتوب 1500', w: 1500, h: 950, touch: false },
  ];
  for (const vp of VPS) {
    const ctx = await b.newContext({ viewport: { width: vp.w, height: vp.h }, hasTouch: vp.touch });
    const p = await ctx.newPage();
    await login(p, vp);
    let worst = -999;
    for (const pg of ['#/dashboard', '#/tasks', '#/chat']) {
      await p.goto(BASE + '/' + pg, { waitUntil: 'networkidle' });
      await p.waitForTimeout(900);
      worst = Math.max(worst, await noOverflow(p));
    }
    ok('Responsive ' + vp.name + ' — صفر overflow', worst <= 2);
    await ctx.close();
  }

  /* ---- 2) 3D: pooling شغال + FPS + تنقّل طوابق بعد الـ pooling ---- */
  const ctx = await b.newContext({ viewport: { width: 1280, height: 800 } });
  const p = await ctx.newPage();
  const errs = [];
  p.on('pageerror', (e) => errs.push(e.message.slice(0, 120)));
  const t0 = Date.now();
  await login(p);
  await p.goto(BASE + '/#/office', { waitUntil: 'networkidle' });
  await p.waitForFunction(() => window.__of3d && window.__of3d.ready, { timeout: 70000 });
  const bootMs = Date.now() - t0;
  await p.waitForTimeout(3000);
  const st = await p.evaluate(() => ({ fps: window.__of3d.fps(), pool: window.__of3d.pool(), floor: window.__of3d.floor() }));
  ok('الـ pool فيه هندسات وخامات مشتركة', st.pool.geo >= 10 && st.pool.mat >= 5);
  ok('عدّاد FPS بيرجع رقم', typeof st.fps === 'number' && st.fps > 0);
  /* تبديل الطوابق — العالم بيتبني من جديد بنفس الـ pool */
  await p.locator('.of3d-floors button', { hasText: '٢' }).click();
  await p.waitForTimeout(1500);
  const f2 = await p.evaluate(() => window.__of3d.floor());
  await p.locator('.of3d-floors button', { hasText: '١' }).click();
  await p.waitForTimeout(1500);
  const f1 = await p.evaluate(() => ({ floor: window.__of3d.floor(), geo: window.__of3d.pool().geo }));
  ok('تبديل الطوابق سليم بعد الـ pooling', f2 === 2 && f1.floor === 1 && f1.geo >= 10);
  const poolAfter = await p.evaluate(() => window.__of3d.pool());
  ok('الـ pool بيكبر/يثبت مع إعادة البناء (مفيش تسريب إنشاء جديد)', poolAfter.geo >= st.pool.geo);

  /* ---- 3) كيبورد: الأسهم بتحرف الموضع ---- */
  const posA = await p.evaluate(() => window.__of3d.pos());
  await p.keyboard.down('ArrowUp');
  await p.waitForTimeout(700);
  await p.keyboard.up('ArrowUp');
  const posB = await p.evaluate(() => window.__of3d.pos());
  ok('الكيبورد بيحرّك الأفاتار', Math.abs(posA.y - posB.y) > 0.2 || Math.abs(posA.x - posB.x) > 0.2);

  /* ---- 4) أزمنة التحميل ---- */
  const stateMs = await p.evaluate(async () => {
    const t = performance.now();
    await fetch('/api/state', { headers: { Authorization: 'Bearer ' + localStorage.getItem('basma_token') } });
    return Math.round(performance.now() - t);
  });
  ok('زمن /api/state أقل من 3 ثواني (' + stateMs + 'ms)', stateMs < 3000);
  ok('الدخول للمكتب أقل من 45 ثانية headless (' + Math.round(bootMs / 1000) + 's)', bootMs < 45000);
  await ctx.close();

  /* ---- 5) لمس: الجوئيستيك يظهر باللمس فقط ---- */
  const ctxT = await b.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
  const pt = await ctxT.newPage();
  await login(pt);
  await pt.goto(BASE + '/#/office', { waitUntil: 'networkidle' });
  await pt.waitForFunction(() => window.__of3d && window.__of3d.ready, { timeout: 70000 });
  await pt.waitForTimeout(1500);
  ok('مفيش جوئيستيك قبل اللمس', (await pt.locator('.of3d-joy').count()) === 0);
  const cv = pt.locator('.of3d-canvas');
  const bx = await cv.boundingBox();
  /* ضغطة مطوّلة (pointerdown بدون up) — الجوئيستيك يظهر أثناء اللمس */
  await pt.evaluate(([x, y]) => {
    const cv = document.querySelector('.of3d-canvas');
    const touch = new Touch({ identifier: 7, target: cv, clientX: x, clientY: y });
    cv.dispatchEvent(new TouchEvent('touchstart', { touches: [touch], changedTouches: [touch], bubbles: true }));
  }, [bx.x + bx.width * 0.5, bx.y + bx.height * 0.8]);
  await pt.waitForTimeout(400);
  const joyVisible = (await pt.locator('.of3d-joy').count()) === 1;
  await pt.evaluate(() => {
    const cv = document.querySelector('.of3d-canvas');
    cv.dispatchEvent(new TouchEvent('touchend', { touches: [], changedTouches: [], bubbles: true }));
  });
  ok('الجوئيستيك ظهر باللمس', joyVisible);
  ok('Responsive المكتب 390 — صفر overflow', (await noOverflow(pt)) <= 2);
  await ctxT.close();

  ok('مفيش pageerrors', errs.length === 0);
  if (errs.length) console.log('ERRS:', errs.slice(0, 5));

  const pass = R.filter(Boolean).length;
  console.log('\nV4-7 perf suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  await b.close();
  process.exit(pass === R.length ? 0 : 1);
})();
