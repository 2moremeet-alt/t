/* MEEM V2-14 E2E — i18n: تبديل AR/EN · RTL/LTR · كانبان/سايدبار/صفحات عامة بلغتين */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const FORCE2D = (b) => { const orig = b.newContext.bind(b); b.newContext = async (opts) => { const ctx = await orig(opts); try { ctx.addInitScript(() => { try { localStorage.setItem('meem_view3d', '0'); } catch (e) {} }); } catch (e) {} return ctx; }; return b; };
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = FORCE2D(await chromium.launch({ args: ['--no-sandbox'] }));
  const ctx = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(e.message));
  p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(m.text()); });
  await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', 'designer@meem.studio');
  await p.click('.login-card .btn.primary');
  await p.waitForSelector('.sidebar .nav-item');

  /* ---- 1) الوضع العربي الافتراضي ---- */
  ok('dir=rtl افتراضيًا', (await p.evaluate(() => document.documentElement.dir)) === 'rtl');
  ok('المكتب في السايدبار (عربي)', (await p.locator('.sidebar .nav-item', { hasText: 'المكتب' }).count()) >= 1);
  await p.goto(BASE + '/#/tasks', { waitUntil: 'networkidle' });
  await p.waitForSelector('.kb-col-head');
  ok('أعمدة الكانبان عربي (جديدة)', (await p.locator('.kb-col-head', { hasText: 'جديدة' }).count()) === 1);

  /* ---- 2) التبديل لإنجليزي ---- */
  await p.click('.topbar button[data-act="lang"]');
  await p.waitForTimeout(900);
  ok('dir=ltr بعد التبديل', (await p.evaluate(() => document.documentElement.dir)) === 'ltr');
  const navEn = (await p.locator('.sidebar .nav-item').allInnerTexts()).map((x) => x.trim());
  ok('السايدبار إنجليزي (Office + Tasks)', navEn.some((x) => x.includes('Office')) && navEn.some((x) => x.includes('Tasks')));
  ok('أعمدة الكانبان إنجليزي (New/In Progress)', (await p.locator('.kb-col-head', { hasText: 'New' }).count()) === 1 && (await p.locator('.kb-col-head', { hasText: 'In Progress' }).count()) === 1);
  ok('الفلاتر إنجليزية (My tasks)', (await p.locator('.page-head button', { hasText: 'My tasks' }).count()) === 1);

  /* ---- 3) البروفايل بالإنجليزي ---- */
  await p.locator('.user-chip').click();
  await p.waitForSelector('.modal');
  ok('مودال البروفايل EN (Change Password)', (await p.locator('.modal', { hasText: 'Change Password' }).count()) === 1);
  await p.keyboard.press('Escape');
  await p.waitForTimeout(300);

  /* ---- 4) صفحة الطلب العامة بالإنجليزي ---- */
  await p.goto(BASE + '/request', { waitUntil: 'networkidle' });
  await p.waitForSelector('.pr-svc');
  ok('/request ورث اللغة (Request a Project)', (await p.locator('text=Request a Project').count()) >= 1);
  ok('الخدمات بالإنجليزي (Voice Over)', (await p.locator('.pr-svc b', { hasText: 'Voice Over' }).count()) === 1);
  await p.locator('.pr-svc', { hasText: 'Graphic Design' }).click();
  await p.waitForSelector('#prf_designType');
  ok('الفورم labels إنجليزية (Design type)', (await p.locator('.pr-label', { hasText: 'Design type' }).count()) === 1);
  await p.locator('.pr-lang').click(); // ارجع عربي
  await p.waitForTimeout(600);
  ok('زر اللغة في الصفحة العامة رجّع العربي', (await p.locator('text=اطلب مشروعك').count()) >= 1);

  /* ---- 5) نرجع للتطبيق — اللغة محفوظة ---- */
  await p.goto(BASE + '/#/office', { waitUntil: 'networkidle' });
  await p.waitForSelector('.office-map');
  ok('اللغة محفوظة بعد التنقل (rtl)', (await p.evaluate(() => document.documentElement.dir)) === 'rtl');
  ok('المكتب رجع عربي', (await p.locator('.sidebar .nav-item', { hasText: 'المكتب' }).count()) >= 1);

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
