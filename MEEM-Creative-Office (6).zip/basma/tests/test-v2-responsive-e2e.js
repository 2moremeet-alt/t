/* MEEM V2-15 E2E — Responsive: joystick اللمس · درج السايدبار · الكانبان · الصفحات العامة · تابلت */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const FORCE2D = (b) => { const orig = b.newContext.bind(b); b.newContext = async (opts) => { const ctx = await orig(opts); try { ctx.addInitScript(() => { try { localStorage.setItem('meem_view3d', '0'); } catch (e) {} }); } catch (e) {} return ctx; }; return b; };
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = FORCE2D(await chromium.launch({ args: ['--no-sandbox'] }));

  /* ---- 1) موبايل: المكتب + الـ joystick ---- */
  const mctx = await b.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true });
  const m = await mctx.newPage();
  m.on('pageerror', (e) => errs.push('mobile: ' + e.message));
  m.on('console', (x) => { if (x.type() === 'error' && !/Failed to load resource/.test(x.text())) errs.push('mobile: ' + x.text()); });
  await m.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await m.waitForSelector('.login-card');
  await m.fill('input[type=email]', 'designer@meem.studio');
  await m.click('.login-card .btn.primary');
  await m.waitForSelector('.office-map');
  ok('الموبايل هبط في المكتب', true);
  ok('الـ joystick ظاهر', (await m.locator('.of-joy').count()) === 1);

  const avBefore = await m.evaluate(() => { const a = document.querySelector('.of-av.me'); return { l: a.style.left, t: a.style.top }; });
  await m.evaluate(async () => {
    const base = document.querySelector('.of-joy');
    const r = base.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const mk = (x, y) => new Touch({ identifier: 1, target: base, clientX: x, clientY: y });
    base.dispatchEvent(new TouchEvent('touchstart', { touches: [mk(cx, cy)], bubbles: true, cancelable: true }));
    base.dispatchEvent(new TouchEvent('touchmove', { touches: [mk(r.right - 4, cy)], bubbles: true, cancelable: true }));
    await new Promise((res) => setTimeout(res, 900));
    base.dispatchEvent(new TouchEvent('touchend', { touches: [], bubbles: true, cancelable: true }));
  });
  await m.waitForTimeout(500);
  const avAfter = await m.evaluate(() => { const a = document.querySelector('.of-av.me'); return { l: a.style.left, t: a.style.top }; });
  ok('الـ joystick حرّك الأفاتار (' + avBefore.l + ' → ' + avAfter.l + ')', avBefore.l !== avAfter.l || avBefore.t !== avAfter.t);
  const joyReset = await m.evaluate(() => document.querySelector('.of-joy-knob').style.transform === '');
  ok('الـ knob رجع مكانه بعد الإفلات', joyReset);

  /* ---- 2) درج السايدبار ---- */
  await m.locator('.topbar .mobile-only').tap();
  await m.waitForTimeout(400);
  ok('زر المنيو فتح الدرج', await m.evaluate(() => document.querySelector('.sidebar').classList.contains('open')));
  await m.locator('.side-scrim').tap({ force: true }).catch(() => {});
  await m.waitForTimeout(300);

  /* ---- 3) الكانبان على الموبايل ---- */
  await m.goto(BASE + '/#/tasks', { waitUntil: 'networkidle' });
  await m.waitForSelector('.kb-board');
  ok('الكانبان ظاهر وبيتمرر أفقيًا', await m.evaluate(() => { const b = document.querySelector('.kb-board'); return b.scrollWidth >= b.clientWidth && getComputedStyle(b).overflowX === 'auto'; }));
  ok('7 أعمدة على الموبايل (V4-3: +متوقفة)', (await m.locator('.kb-col').count()) === 7);

  /* ---- 4) صفحة الطلب العامة على الموبايل ---- */
  await m.goto(BASE + '/request', { waitUntil: 'networkidle' });
  await m.waitForSelector('.pr-svc');
  ok('/request على الموبايل: 5 خدمات', (await m.locator('.pr-svc').count()) === 5);
  await m.locator('.pr-svc').first().tap();
  await m.waitForSelector('#prf_designType');
  ok('الفورم فتح على الموبايل', true);

  /* ---- 5) مودال على شاشة صغيرة ---- */
  await m.goto(BASE + '/#/office', { waitUntil: 'networkidle' });
  await m.waitForSelector('.office-map');
  const noHScroll = await m.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 2);
  ok('مفيش scroll أفقي مكسور في المكتب', noHScroll);

  /* ---- 6) تابلت ---- */
  const tctx = await b.newContext({ viewport: { width: 768, height: 1024 } });
  const tp = await tctx.newPage();
  tp.on('pageerror', (e) => errs.push('tablet: ' + e.message));
  tp.on('console', (x) => { if (x.type() === 'error' && !/Failed to load resource/.test(x.text())) errs.push('tablet: ' + x.text()); });
  await tp.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
  await tp.waitForSelector('.login-card');
  await tp.fill('input[type=email]', 'content@meem.studio');
  await tp.click('.login-card .btn.primary');
  await tp.waitForSelector('.office-map');
  ok('التابلت: المكتب ظاهر (6 أقسام بالطابق ١)', (await tp.locator('.office-room').count()) === 6);
  ok('التابلت: مفيش joystick (مش جهاز لمس)', (await tp.locator('.of-joy').count()) === 0);

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
