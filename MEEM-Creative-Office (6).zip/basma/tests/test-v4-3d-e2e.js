/* MEEM V4-1 E2E — المكتب ثلاثي الأبعاد: رندر WebGL، حركة، تصادم، أبواب، طوابق، تبديل 2D، جويستيك لمس، مزامنة */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];
const GL = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];

async function mk(ctx, email) {
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(email + ' PE: ' + e.message.slice(0, 140)));
  await p.goto(BASE + '/?r=' + email + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', email);
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  /* يتسامح مع رجوع آمن لـ2D تحت حمل عالي (فقد سياق WebGL) — المزامنة تُختبر في الحالتين */
  const up = () => p.waitForFunction(() => (window.__of3d && window.__of3d.ready) || !!document.querySelector('.office-map'), null, { timeout: 40000 });
  await up().catch(async () => { await p.reload({ waitUntil: 'load' }); await up(); });
  await p.waitForTimeout(600);
  return p;
}

(async () => {
  const b = await chromium.launch({ args: GL });
  const c1 = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const c2 = await b.newContext({ viewport: { width: 1500, height: 950 } });
  const A = await mk(c1, 'admin@meem.studio');

  /* ---- 1) الافتراضي 3D ---- */
  ok('3D هو العرض الافتراضي (canvas + __of3d جاهز)', (await A.locator('canvas.of3d-canvas').count()) === 1);
  const info = await A.evaluate(() => ({ rooms: window.__of3d.rooms().length, colliders: window.__of3d.colliders(), floor: window.__of3d.floor() }));
  ok('الطابق ١ فيه 6 أقسام', info.rooms === 6 && info.floor === 1);
  ok('تصادمات مبنية (جدران + أثاث > 40)', info.colliders > 40);
  const names = await A.evaluate(() => window.__of3d.rooms().map((r) => r.ar).join('،'));
  ok('لافتات الأقسام موجودة (تصميم/محتوى/تسليمات)', names.includes('التصميم') && names.includes('المحتوى') && names.includes('التسليمات'));

  /* ---- 2) حركة WASD ---- */
  await A.evaluate(() => window.__of3d.setPos(50, 92));
  const p0 = await A.evaluate(() => window.__of3d.pos());
  await A.keyboard.down('ArrowRight'); await A.waitForTimeout(600); await A.keyboard.up('ArrowRight');
  const p1 = await A.evaluate(() => window.__of3d.pos());
  ok('الأسهم تحرّك الأفاتار', Math.abs(p1.x - p0.x) > 1);
  await A.keyboard.down('w'); await A.waitForTimeout(500); await A.keyboard.up('w');
  const p2 = await A.evaluate(() => window.__of3d.pos());
  ok('حرف W يحرّك للأمام', Math.abs(p2.y - p1.y) > 0.5);

  /* ---- 3) تصادم الحدود ---- */
  await A.evaluate(() => window.__of3d.setPos(98, 50));
  await A.keyboard.down('ArrowRight'); await A.waitForTimeout(600); await A.keyboard.up('ArrowRight');
  const pe = await A.evaluate(() => window.__of3d.pos());
  ok('تصادم حدود العالم (x ≤ 99)', pe.x <= 99.1);

  /* ---- 4) جدار يسدّ + باب يفتح ---- */
  /* جدار الاستقبال الجنوبي عند y=17 — بعيدًا عن الباب (x=35) */
  await A.evaluate(() => window.__of3d.setPos(35, 16));
  await A.keyboard.down('ArrowDown'); await A.waitForTimeout(700); await A.keyboard.up('ArrowDown');
  const wallP = await A.evaluate(() => window.__of3d.pos());
  ok('الجدار يسدّ الحركة (ما عدّاش y=17)', wallP.y < 17.6);
  /* من منتصف الباب (x=50) */
  await A.evaluate(() => window.__of3d.setPos(50, 16));
  await A.keyboard.down('ArrowDown'); await A.waitForTimeout(900); await A.keyboard.up('ArrowDown');
  const doorP = await A.evaluate(() => window.__of3d.pos());
  ok('فتحة الباب تسمح بالعبور (y > 17.6)', doorP.y > 17.6);

  /* ---- 5) تبديل الطوابق ---- */
  await A.locator('.of3d-btn.fl', { hasText: '٢' }).click();
  await A.waitForTimeout(800);
  const f2 = await A.evaluate(() => ({ floor: window.__of3d.floor(), rooms: window.__of3d.rooms().map((r) => r.id) }));
  ok('الطابق ٢ فيه البرمجة/الفويس/الإدارة', f2.floor === 2 && f2.rooms.includes('dev') && f2.rooms.includes('voice') && f2.rooms.includes('management'));
  await A.locator('.of3d-btn.fl', { hasText: '١' }).click();
  await A.waitForTimeout(700);
  ok('الرجوع للطابق ١', (await A.evaluate(() => window.__of3d.floor())) === 1);

  /* ---- 6) برومبت دخول قسم + Enter ---- */
  await A.evaluate(() => window.__of3d.setPos(48, 34));
  await A.waitForTimeout(600);
  ok('برومبت «ادخل المحتوى» ظاهر داخل القسم', (await A.locator('.of3d-prompt').innerText()).includes('المحتوى'));
  await A.keyboard.press('Enter');
  await A.waitForTimeout(900);
  ok('Enter يفتح لوحة المحتوى (#/content)', (await A.evaluate(() => location.hash)).includes('content'));

  /* ---- رجوع للمكتب + 7) تبديل 2D والعودة ---- */
  await A.goto(BASE + '/#/office');
  await A.waitForSelector('canvas.of3d-canvas', { timeout: 15000 });
  await A.waitForTimeout(600);
  await A.locator('.of3d-btn', { hasText: '2D' }).click();
  await A.waitForSelector('.office-map', { timeout: 8000 });
  ok('التبديل لـ2D بيظهر الخريطة القديمة', (await A.locator('.office-map').count()) === 1);
  await A.locator('.of3d-btn.to3d').click();
  await A.waitForSelector('canvas.of3d-canvas', { timeout: 15000 });
  await A.waitForFunction(() => window.__of3d && window.__of3d.ready, null, { timeout: 15000 });
  await A.waitForTimeout(700);
  ok('الرجوع لـ3D', (await A.locator('canvas.of3d-canvas').count()) === 1);

  /* ---- 8) جويستيك اللمس يظهر فقط أثناء اللمس ---- */
  const joyShown = await A.evaluate(async () => {
    const cv = document.querySelector('canvas.of3d-canvas');
    const t = (type, x, y) => cv.dispatchEvent(new TouchEvent(type, { bubbles: true, cancelable: true, touches: type === 'touchend' ? [] : [new Touch({ identifier: 1, target: cv, clientX: x, clientY: y })], targetTouches: type === 'touchend' ? [] : [new Touch({ identifier: 1, target: cv, clientX: x, clientY: y })] }));
    t('touchstart', 400, 800);
    await new Promise((r2) => setTimeout(r2, 150));
    const shown = !!document.querySelector('.of3d-joy');
    t('touchmove', 430, 780);
    await new Promise((r2) => setTimeout(r2, 250));
    const moved = !!document.querySelector('.of3d-joy');
    t('touchend', 430, 780);
    await new Promise((r2) => setTimeout(r2, 150));
    const hidden = !document.querySelector('.of3d-joy');
    return { shown, moved, hidden };
  });
  ok('الجويستيك يظهر أثناء اللمس فقط ويختفي بعده', joyShown.shown && joyShown.moved && joyShown.hidden);

  /* ---- 9) مزامنة متعددة المستخدمين ---- */
  const D = await mk(c2, 'designer@meem.studio');
  const dIs3D = await D.evaluate(() => !!(window.__of3d && window.__of3d.ready));
  if (dIs3D) {
    await D.evaluate(() => window.__of3d.setPos(60, 40));
    await D.keyboard.down('ArrowLeft'); await D.waitForTimeout(500); await D.keyboard.up('ArrowLeft');
  }
  await A.waitForTimeout(2500);
  ok('الأدمن شايف أفاتار المصمم (مزامنة حية)', (await A.evaluate(() => window.__of3d.peers())) >= 1);

  /* ---- 10) شريحة الحالة ---- */
  await A.locator('.of3d-btn.st', { hasText: 'مشغول' }).click();
  await A.waitForTimeout(300);
  ok('تغيير الحالة من HUD ثلاثي الأبعاد', await A.evaluate(() => localStorage.getItem('office_status')) === 'busy');
  await A.locator('.of3d-btn.st', { hasText: 'متاح' }).click();

  ok('مفيش pageerrors', errs.length === 0);
  if (errs.length) console.log('ERRS:', errs.slice(0, 5));

  const pass = R.filter(Boolean).length;
  console.log('\nV4-1 3D suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  await b.close();
  process.exit(pass === R.length ? 0 : 1);
})();
