/* MEEM V4-4 API — بوابة طلبات العميل: إنشاء/تصفية/رفض/صلاحيات */
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };

async function j(path, { method = 'GET', token, body } = {}) {
  const res = await fetch(BASE + path, {
    method,
    headers: Object.assign({ 'Content-Type': 'application/json' }, token ? { Authorization: 'Bearer ' + token } : {}),
    body: body ? JSON.stringify(body) : undefined,
  });
  let data = null; try { data = await res.json(); } catch (e) {}
  return { status: res.status, data };
}

(async () => {
  const aT = (await j('/api/login', { method: 'POST', body: { email: 'admin@meem.studio', password: '123456' } })).data.token;
  const cT = (await j('/api/login', { method: 'POST', body: { email: 'client@meem.studio', password: '123456' } })).data.token;
  const dT = (await j('/api/login', { method: 'POST', body: { email: 'designer@meem.studio', password: '123456' } })).data.token;
  ok('تسجيل الدخول (أدمن/عميل/مصمم)', !!(aT && cT && dT));

  /* ---- 1) العميل ينشئ طلب من البوابة ---- */
  const mk = 'API V44 ' + Date.now();
  const r1 = await j('/api/portal/request', { method: 'POST', token: cT, body: { service: 'design', details: 'طلب API — ' + mk, phone: '01000000000', priority: 'high' } });
  ok('العميل أنشأ طلب (channel=portal)', r1.status === 200 && r1.data.ok && !!r1.data.id);

  /* ---- 2) التحقق من الحقول ---- */
  const bad1 = await j('/api/portal/request', { method: 'POST', token: cT, body: { service: 'design', details: '' } });
  const bad2 = await j('/api/portal/request', { method: 'POST', token: cT, body: { service: 'hacking', details: 'x' } });
  ok('تفاصيل فاضية → 400 وخدمة مجهولة → 400', bad1.status === 400 && bad2.status === 400);

  /* ---- 3) غير العميل مرفوض ---- */
  const bad3 = await j('/api/portal/request', { method: 'POST', token: dT, body: { service: 'design', details: 'x' } });
  const bad4 = await j('/api/portal/request', { method: 'POST', body: { service: 'design', details: 'x' } });
  ok('المصمم 403 وبدون جلسة 401', bad3.status === 403 && bad4.status === 401);

  /* ---- 4) العميل يشوف طلباته فقط بحقول محدودة ---- */
  const stC = await j('/api/state', { token: cT });
  const mine = (stC.data.data.requests || []);
  const myReq = mine.find((r) => r.id === r1.data.id);
  ok('العميل شايف طلبه', !!myReq && myReq.status === 'new' && myReq.priority === 'high');
  ok('الحقول محدودة (مفيش form/notes/assignee)', myReq && !('form' in myReq) && !('notes' in myReq) && !('assignee' in myReq));
  /* طلب داخلي لعميل تاني */
  const other = await j('/api/mutate', { method: 'POST', token: aT, body: { collection: 'requests', doc: { title: 'طلب داخلي', clientId: 'cl_other', status: 'new', notes: 'داخلي', contact: { email: 'other@x.com' } } } });
  const stC2 = await j('/api/state', { token: cT });
  ok('طلب عميل تاني مش ظاهر', other.status === 200 && !(stC2.data.data.requests || []).some((r) => r.title === 'طلب داخلي'));

  /* ---- 5) الإدارة ترفض → السبب يوصل العميل ---- */
  const upd = await j('/api/mutate', { method: 'POST', token: aT, body: { collection: 'requests', doc: Object.assign({}, myReq, { status: 'rejected', rejectReason: 'خارج النطاق' }) } });
  const stC3 = await j('/api/state', { token: cT });
  const rej = (stC3.data.data.requests || []).find((r) => r.id === r1.data.id);
  ok('الرفض + السبب وصلوا العميل', upd.status === 200 && rej && rej.status === 'rejected' && rej.rejectReason === 'خارج النطاق');

  /* ---- 6) العميل مش قادر يغيّر حالة طلبه مباشرة ---- */
  const hack = await j('/api/mutate', { method: 'POST', token: cT, body: { collection: 'requests', doc: Object.assign({}, rej, { status: 'converted' }) } });
  ok('محاولة العميل تعديل الطلب → 403', hack.status === 403);

  /* ---- 7) تنظيف ---- */
  await j('/api/mutate', { method: 'POST', token: aT, body: { op: 'delete', collection: 'requests', id: r1.data.id } });
  const oid = ((await j('/api/state', { token: aT })).data.data.requests || []).find((r) => r.title === 'طلب داخلي');
  if (oid) await j('/api/mutate', { method: 'POST', token: aT, body: { op: 'delete', collection: 'requests', id: oid.id } });
  const stF = await j('/api/state', { token: aT });
  ok('تنظيف الطلبات', !(stF.data.data.requests || []).some((r) => r.id === r1.data.id || r.title === 'طلب داخلي'));

  const pass = R.filter(Boolean).length;
  console.log('\nV4-4 API suite: ' + pass + '/' + R.length + (pass === R.length ? ' ✅ ALL PASS' : ' ❌'));
  process.exit(pass === R.length ? 0 : 1);
})();
