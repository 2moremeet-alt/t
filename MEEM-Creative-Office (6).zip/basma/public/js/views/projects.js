/* ============================================================
   MEEM | Creative Office — Phase 3: وحدة المشاريع الكاملة
   ============================================================ */
import { t, getLang } from '../i18n.js';
import { state, save, remove, userById, clientById, STATUS_COLOR, isOverdue } from '../store.js';
import { el, icon, clear, avatarHTML, timeAgo, escapeHTML, toast, modal, confirmDialog, statusBadge, formatDate } from '../ui.js';
import { api } from '../api.js';
import { openTaskModal, openTaskDetails } from '../taskform.js';

const PROJ_STATUS = { new: 'جديد', progress: 'جاري التنفيذ', review: 'في المراجعة', client: 'عند العميل', revision: 'تعديلات', delivered: 'مُسلّم', done: 'منتهي' };
const lastTab = {}; /* V4-4: آخر تبويب مفتوح لكل مشروع */

export function renderProjects(host, { param } = {}) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  if (param) return renderProjectDetail(host, param);
  renderProjectsList(host);
}

/* ---------------- القائمة ---------------- */
function renderProjectsList(host) {
  const list = state.projects || [];
  const open = list.filter((p) => !['done', 'delivered'].includes(p.status));
  const overdue = open.filter((p) => p.due && p.due < new Date().toISOString().slice(0, 10));
  const budget = open.reduce((s, p) => s + (p.budget || 0), 0);

  host.append(
    el('div', { class: 'page-head' }, [
      el('div', {}, [
        el('h1', { html: icon('kanban') + ' المشاريع', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
        el('div', { class: 'ph-sub', text: 'كل مشروع: مهامه وتصاميمه وملفاته ونشاطه — الطلب → مشروع → اعتماد → تسليم' }),
      ]),
      el('button', { class: 'btn primary', html: icon('plus') + `<span>مشروع جديد</span>`, onclick: () => openProjectModal(null, () => renderProjects(host)) }),
    ]),
    el('div', { class: 'kpis' }, [
      kpi('مشاريع نشطة', open.length, 'brand'),
      kpi('متأخرة', overdue.length, overdue.length ? 'danger' : ''),
      kpi('قيمتها المفتوحة', budget ? budget.toLocaleString('ar-EG') + ' ج.م' : '—', ''),
      kpi('العملاء', (state.clients || []).length, ''),
    ]),
  );

  const grid = el('div', { class: 'cards-grid' });
  [...list].sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || '')).forEach((p) => {
    const client = clientById(p.clientId);
    const tasks = state.tasks.filter((x) => x.projectId === p.id);
    const done = tasks.filter((x) => ['done', 'delivered'].includes(x.status)).length;
    const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
    const designs = state.designs.filter((d) => d.projectId === p.id);
    const team = [...new Set(tasks.map((x) => x.assignee).filter(Boolean))].map(userById).filter(Boolean);
    grid.appendChild(el('div', {
      class: 'dcard',
      onclick: () => { location.hash = '#/projects/' + p.id; },
    }, [
      el('div', { class: 'dc-body', style: { padding: '14px 14px 12px' } }, [
        el('div', { class: 'row', style: { gap: '8px', marginBottom: '6px' } }, [
          el('div', { class: 'dc-title grow', text: p.title }),
          el('span', { class: 'badge ' + (STATUS_COLOR[p.status] || ''), text: PROJ_STATUS[p.status] || p.status }),
        ]),
        el('div', { class: 'dc-sub', text: `${client ? (getLang() === 'ar' ? client.name : client.nameEn) : '—'} · تسليم ${p.due || '—'}${p.due && isOverdue({ due: p.due, status: p.status }) ? ' ⚠ متأخر' : ''}` }),
        el('div', { class: 'pbar', style: { margin: '10px 0 8px' } }, [el('i', { style: { width: pct + '%' } })]),
        el('div', { class: 'row', style: { gap: '6px', fontSize: '11.5px' } }, [
          el('span', { class: 'dim', text: `${done}/${tasks.length} مهمة` }),
          el('span', { class: 'dim', text: `· ${designs.length} تصميم` }),
          el('div', { class: 'grow' }),
          el('div', { class: 'avatar-stack' }, (projectTeam(p).length ? projectTeam(p) : team).slice(0, 4).map((u) => el('span', { html: avatarHTML(u.user || u, 'sm') }))),
        ]),
      ]),
    ]));
  });
  if (!list.length) grid.appendChild(el('div', { class: 'empty', text: 'لا توجد مشاريع — أنشئ أول مشروع أو حوّل طلبًا من شاشة الطلبات' }));
  host.appendChild(grid);
}

function kpi(label, value, color) {
  return el('div', { class: 'kpi' }, [
    el('div', { class: 'k-label', text: label }),
    el('div', { class: 'k-value num', text: String(value), style: color ? { color: `var(--${color})` } : {} }),
  ]);
}

/* ---------------- V2-6: فريق المشروع ---------------- */
const PROJ_ROLE_AR = { design: 'تصميم', content: 'محتوى', voice: 'فويس', dev: 'برمجة', cs: 'خدمة عملاء' };
function projectTeam(p) {
  return (p.members || []).map((m) => { const u = userById(m.userId); return u ? { user: u, role: m.role } : null; }).filter(Boolean);
}

function canEditTeam() {
  return ['admin', 'superadmin', 'cs'].includes(state.user.role);
}

function teamSection(p, refresh) {
  const online = new Set(state.online || []);
  const box = el('div', { class: 'card', style: { padding: '14px' } });
  const head = el('div', { class: 'between', style: { marginBottom: '10px' } }, [
    el('div', { class: 'ed-sec-title', style: { margin: '0' }, text: getLang() === 'ar' ? '👥 فريق المشروع' : '👥 Project Team' }),
    canEditTeam() ? el('button', { class: 'btn sm', html: icon('plus') + '<span>' + (getLang() === 'ar' ? 'عضو' : 'Member') + '</span>', onclick: () => addMemberModal(p, refresh) }) : null,
  ]);
  box.appendChild(head);
  const team = projectTeam(p);
  if (!team.length) box.appendChild(el('div', { class: 'dim', style: { fontSize: '12.5px' }, text: 'لسه مفيش أعضاء — ضيف فريق المشروع' }));
  team.forEach((m) => {
    box.appendChild(el('div', { class: 'row', style: { gap: '10px', padding: '7px 2px', borderTop: '1px solid var(--line)' } }, [
      el('div', { style: { position: 'relative' } }, [
        el('div', { html: avatarHTML(m.user, 'sm') }),
        el('span', { class: 'pt-dot ' + (online.has(m.user.id) ? 'on' : ''), title: online.has(m.user.id) ? 'متصل الآن' : 'غير متصل' }),
      ]),
      el('div', { class: 'grow' }, [
        el('div', { style: { fontWeight: '700', fontSize: '13px' }, text: getLang() === 'ar' ? m.user.name : (m.user.nameEn || m.user.name) }),
        el('div', { class: 'dim', style: { fontSize: '11.5px' }, text: (PROJ_ROLE_AR[m.role] || m.role) + ' · ' + (m.user.title || '') }),
      ]),
      canEditTeam() ? el('button', { class: 'btn ghost icon sm', html: icon('trash'), title: 'إزالة من المشروع', onclick: async () => {
        p.members = (p.members || []).filter((x) => x.userId !== m.user.id);
        await save('projects', { id: p.id, members: p.members });
        toast('اتشال من الفريق', 'ok');
        refresh();
      } }) : null,
    ]));
  });
  return box;
}

function addMemberModal(p, refresh) {
  const current = new Set((p.members || []).map((m) => m.userId));
  const candidates = (state.users || []).filter((u) => u.role !== 'client' && u.role !== 'superadmin' && !current.has(u.id) && u.active !== false);
  let selUser = null; let selRole = 'design';
  const us = el('select', { class: 'select', onchange: (e) => { selUser = e.target.value; } },
    [el('option', { value: '', text: '— اختار موظف —' })].concat(candidates.map((u) => el('option', { value: u.id, text: u.name + ' (' + (u.title || u.role) + ')' }))));
  const rs = el('select', { class: 'select', onchange: (e) => { selRole = e.target.value; } },
    Object.entries(PROJ_ROLE_AR).map(([k, v]) => el('option', { value: k, text: v })));
  const m = modal({
    title: 'إضافة عضو لفريق المشروع',
    body: el('div', { class: 'col', style: { gap: '10px' } }, [
      el('label', { class: 'fld' }, [el('span', { text: 'الموظف' }), us]),
      el('label', { class: 'fld' }, [el('span', { text: 'دوره في المشروع' }), rs]),
    ]),
    footer: [
      el('button', { class: 'btn', text: 'إلغاء', onclick: () => m.close() }),
      el('button', { class: 'btn primary', text: 'إضافة', onclick: async () => {
        if (!selUser) { toast('اختار موظف', 'err'); return; }
        /* V4-0: قراءة أحدث نسخة من الـ state + منع التكرار —
           ضمان إن العضو المُضاف هو نفسه المُختار بالـ id (مش نسخة قديمة مقفولة) */
        const cur = (state.projects || []).find((x) => x.id === p.id) || p;
        if ((cur.members || []).some((mm) => mm.userId === selUser)) { toast('العضو ده في الفريق أصلًا', 'warn'); return; }
        cur.members = (cur.members || []).concat([{ userId: selUser, role: selRole }]);
        await save('projects', { id: p.id, members: cur.members });
        m.close();
        toast('اتضاف للفريق ✓', 'ok');
        refresh();
      } }),
    ],
  });
}

/* ---------------- تفاصيل المشروع (تبويبات) ---------------- */
function renderProjectDetail(host, id) {
  host.innerHTML = ''; // V2-8: re-render اللحظي كان بيراكم الأقسام
  const p = (state.projects || []).find((x) => x.id === id);
  if (!p) { host.appendChild(el('div', { class: 'empty', text: 'المشروع غير موجود' })); return; }
  const client = clientById(p.clientId);
  const tasks = state.tasks.filter((x) => x.projectId === p.id);
  const designs = state.designs.filter((d) => d.projectId === p.id);
  const files = (state.assets || []).filter((a) => a.projectId === p.id);
  const deliveries = state.deliveries.filter((d) => d.projectId === p.id);

  host.append(el('div', { class: 'page-head' }, [
    ['admin', 'superadmin', 'cs'].includes(state.user.role) ? el('button', {
      class: 'btn sm', html: '🔗<span>' + (getLang() === 'ar' ? 'لينك العميل' : 'Client Link') + '</span>',
      onclick: async () => {
        try {
          const j = await api.clientLink(p.id);
          const full = location.origin + j.url;
          const inp = el('input', { class: 'input', value: full, readonly: true, onclick: (e) => e.target.select() });
          const m2 = modal({
            title: '🔗 لينك العميل الآمن',
            body: el('div', { class: 'col', style: { gap: '10px' } }, [
              el('div', { class: 'dim', style: { fontSize: '12.5px' }, text: 'ابعت اللينك ده للعميل — يفتح صفحة مشروعه من غير تسجيل دخول.' }),
              inp,
            ]),
            footer: [
              el('button', { class: 'btn', text: 'توليد جديد', onclick: async () => {
                const j2 = await api.clientLink(p.id, true);
                inp.value = location.origin + j2.url;
                toast('لينك جديد اتولد (القديم وقف)', 'ok');
              } }),
              el('button', { class: 'btn primary', text: 'نسخ', onclick: async () => {
                try { await navigator.clipboard.writeText(inp.value); } catch (e) { inp.select(); document.execCommand('copy'); }
                toast('اتنسخ ✓', 'ok');
              } }),
            ],
          });
        } catch (e) { toast(e.message || 'مفش', 'err'); }
      },
    }) : null,
    el('div', { class: 'row', style: { gap: '10px' } }, [
      el('button', { class: 'btn ghost icon', html: icon('chevronRight'), title: 'رجوع', onclick: () => { location.hash = '#/projects'; } }),
      el('div', {}, [
        el('h1', { text: p.title, style: { fontSize: '19px' } }),
        el('div', { class: 'ph-sub', html: escapeHTML(`${client ? client.name : ''} · ${PROJ_STATUS[p.status] || p.status} · تسليم ${p.due || '—'}`) + (p.repo ? ` · <a href="${escapeHTML(p.repo)}" target="_blank" rel="noopener" style="direction:ltr;display:inline-block">GitHub ↗</a>` : '') }),
      ]),
    ]),
    el('div', { class: 'row', style: { gap: '7px' } }, [
      el('button', { class: 'btn sm', html: icon('edit') + `<span>تعديل</span>`, onclick: () => openProjectModal(p, () => renderProjects(host, { param: id })) }),
      el('button', { class: 'btn sm primary', html: icon('plus') + `<span>مهمة</span>`, onclick: () => openTaskModal({ projectId: p.id }, () => renderProjects(host, { param: id })) }),
    ]),
  ]));

  const tabs = ['نظرة عامة', 'المهام', 'التصاميم', 'الملفات', 'التسليمات', 'النشاط'];
  let active = lastTab[id] || 0; /* V4-4: التبويب يفضل محفوظ بعد إعادة الرسم الحية */
  const tabBar = el('div', { class: 'tabs' });
  const area = el('div');
  tabBar.append(...tabs.map((tb, i) => el('button', {
    class: i === active ? 'active' : '',
    text: tb + (i === 1 ? ` (${tasks.length})` : i === 2 ? ` (${designs.length})` : i === 3 ? ` (${files.length})` : ''),
    onclick: (e) => { active = i; lastTab[id] = i; tabBar.querySelectorAll('button').forEach((b, j) => b.classList.toggle('active', j === i)); draw(); },
  })));
  host.append(tabBar, area);

  function draw() {
    clear(area);
    [tabOverview, tabTasks, tabDesigns, tabFiles, tabDeliveries, tabActivity][active](area);
  }

  /* ---- نظرة عامة ---- */
  function tabOverview(hh) {
    const team = [...new Set(tasks.map((x) => x.assignee).filter(Boolean))].map(userById).filter(Boolean);
    const done = tasks.filter((x) => ['done', 'delivered'].includes(x.status)).length;
    const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
    const bk = client && client.brandKit;
    const bv = client && client.brandVoice;
    hh.appendChild(el('div', { class: 'grid2', style: { alignItems: 'start' } }, [
      el('div', { class: 'card', style: { padding: '16px' } }, [
        el('div', { class: 'ed-sec-title', text: 'التقدّم' }),
        el('div', { class: 'pbar big', style: { margin: '8px 0' } }, [el('i', { style: { width: pct + '%' } })]),
        el('div', { class: 'dim', style: { fontSize: '12.5px', marginBottom: '12px' }, text: `${done} من ${tasks.length} مهمة (${pct}%)` }),
        el('div', { class: 'ed-sec-title', text: 'بيانات المشروع' }),
        el('div', { class: 'kv' }, [
          ['العميل', client ? client.name : '—'],
          ['جهة التواصل', client ? (client.contact || '') + ' ' + (client.phone || '') : '—'],
          ['الميزانية', (p.budget || 0).toLocaleString('ar-EG') + ' ج.م'],
          ['الأولوية', p.priority || '—'],
          ['التسليم', p.due ? formatDate(p.due) : '—'],
          ['وسوم', (p.tags || []).join('، ') || '—'],
          ['GitHub', p.repo || '—'],
        ].map(([k, v]) => el('div', { class: 'kv-row' }, [el('b', { text: k }), el('span', { class: 'dim', text: v })]))),
        el('div', { class: 'ed-sec-title', style: { marginTop: '12px' }, text: getLang() === 'ar' ? 'التعديلات والاعتمادات' : 'Revisions & Approvals' }),
        (() => {
          const rev = designs.filter((d) => d.status === 'changes').length;
          const revQ = designs.filter((d) => d.status === 'review' || d.status === 'client').length;
          const appr = designs.filter((d) => ['approved', 'client_approved'].includes(d.status)).length;
          const wait = deliveries.filter((d) => d.status === 'waiting_client').length;
          return el('div', { class: 'kv' }, [
            ['تعديلات مطلوبة', String(rev)],
            ['في المراجعة/عند العميل', String(revQ)],
            ['معتمد', String(appr)],
            ['تسليمات بانتظار رد العميل', String(wait)],
          ].map(([k, v]) => el('div', { class: 'kv-row' }, [el('b', { text: k }), el('span', { class: 'dim num', text: v })])));
        })(),
      ]),
      el('div', { class: 'card', style: { padding: '16px' } }, [
        el('div', { class: 'ed-sec-title', text: '🎨 هوية العميل (Brand Kit)' }),
        bk ? el('div', { class: 'row wrap', style: { gap: '7px', margin: '8px 0' } }, (bk.colors || []).map((c) => el('span', { class: 'swatch-view', style: { background: c }, title: c }))) : el('div', { class: 'dim', text: 'لا توجد هوية مسجلة' }),
        bk && (bk.fonts || []).length ? el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'الخطوط: ' + bk.fonts.join('، ') }) : null,
        el('div', { class: 'ed-sec-title', style: { marginTop: '12px' }, text: '✍️ صوت البراند (Brand Voice)' }),
        bv ? el('div', { class: 'kv' }, [
          ['النبرة', bv.tone || '—'],
          ['كلمات مفتاحية', bv.keywords || '—'],
          ['ممنوع', bv.donts || '—'],
          ['مثال', bv.sample || '—'],
        ].map(([k, v]) => el('div', { class: 'kv-row' }, [el('b', { text: k }), el('span', { class: 'dim', text: v })]))) : el('div', { class: 'dim', text: '—' }),
        el('div', { class: 'dim', style: { fontSize: '11.5px', marginTop: '10px' }, text: 'تُعدَّل من شاشة العملاء (CRM).' }),
      ]),
    ]));
    hh.appendChild(el('div', { style: { marginTop: '12px' } }, [teamSection(p, () => renderProjectDetail(host, p.id))]));
  }

  /* ---- المهام ---- */
  function tabTasks(hh) {
    if (!tasks.length) hh.appendChild(el('div', { class: 'empty card', style: { padding: '30px' }, text: 'لا مهام بعد — أضف أول مهمة' }));
    ['new', 'progress', 'review', 'revision', 'done', 'delivered'].forEach((st) => {
      const group = tasks.filter((x) => x.status === st);
      if (!group.length) return;
      hh.appendChild(el('h4', { class: 'col-title', text: t('st_' + st) || st }));
      group.forEach((tk) => {
        const a = userById(tk.assignee);
        hh.appendChild(el('div', { class: 'card row', style: { padding: '10px 12px', gap: '10px', marginBottom: '7px', cursor: 'pointer' }, onclick: () => openTaskDetails(tk, () => renderProjects(host, { param: id })) }, [
          el('div', { html: avatarHTML(a, 'sm') }),
          el('div', { class: 'grow', style: { minWidth: 0 } }, [
            el('div', { style: { fontWeight: '700', fontSize: '13.5px' }, text: tk.title }),
            el('div', { class: 'dim', style: { fontSize: '11.5px' }, text: `${t('dept_' + tk.dept) || tk.dept} · ${tk.type || ''} · تسليم ${tk.due || '—'}` }),
          ]),
          el('span', { class: 'badge ' + (STATUS_COLOR[tk.status] || ''), text: t('st_' + tk.status) || tk.status }),
        ]));
      });
    });
  }

  /* ---- التصاميم ---- */
  function tabDesigns(hh) {
    hh.appendChild(el('div', { class: 'row', style: { marginBottom: '12px' } }, [
      el('button', {
        class: 'btn sm primary', html: icon('design') + `<span>تصميم جديد للمشروع</span>`,
        onclick: async () => {
          const { openEditor } = await import('../editor/index.js');
          const { makeDoc } = await import('../editor/model.js');
          const doc = makeDoc(p.title + ' — تصميم', 1080, 1080, { type: 'color', color: '#ffffff' });
          doc.projectId = p.id;
          doc.clientId = p.clientId;
          openEditor(null, { doc });
        },
      }),
    ]));
    const grid = el('div', { class: 'cards-grid' });
    designs.forEach((d) => {
      grid.appendChild(el('div', { class: 'dcard', onclick: async () => { const { openEditor } = await import('../editor/index.js'); openEditor(d.id); } }, [
        el('div', { class: 'dc-thumb' }, d.thumb ? el('img', { src: d.thumb }) : el('div', { class: 'dim', html: icon('image') })),
        el('div', { class: 'dc-body' }, [
          el('div', { class: 'dc-title', text: d.title }),
          el('div', { class: 'row', style: { marginTop: '6px', gap: '5px' } }, [
            el('span', { class: 'badge ' + (d.status === 'review' ? 'warn' : d.status === 'client_approved' ? 'ok' : d.status === 'changes' ? 'danger' : ''), text: d.status === 'client_approved' ? 'اعتمده العميل' : d.status === 'review' ? 'في المراجعة' : d.status === 'changes' ? 'تعديلات' : d.status === 'client' ? 'عند العميل' : 'مسودة' }),
            el('span', { class: 'dim', style: { fontSize: '11px' }, text: timeAgo(d.updatedAt || d.createdAt) }),
          ]),
        ]),
      ]));
    });
    if (!designs.length) grid.appendChild(el('div', { class: 'empty', style: { gridColumn: '1/-1' }, text: 'لا تصاميم مربوطة بعد' }));
    hh.appendChild(grid);
  }

  /* ---- الملفات (V4-4: مدير ملفات كامل بتحديث في المكان) ---- */
  function tabFiles(hh) {
    const projFiles = () => (state.assets || []).filter((a) => a.projectId === p.id);
    const up = el('input', {
      type: 'file', multiple: true, style: { display: 'none' },
      onchange: async (e) => {
        const { readFileAsDataURL } = await import('../api.js');
        for (const f of [...e.target.files]) {
          const data = await readFileAsDataURL(f);
          await save('assets', { name: f.name, type: f.type.startsWith('image') ? 'image' : 'file', data, size: f.size, projectId: p.id, tags: [], createdBy: state.user.id });
        }
        toast('اترفعت الملفات ✓', 'ok');
        up.value = '';
        await new Promise((r) => setTimeout(r, 300));
        drawFiles();
      },
    });
    hh.append(up, el('button', { class: 'btn sm', html: icon('upload') + `<span>ارفع ملف للمشروع</span>`, onclick: () => up.click(), style: { marginBottom: '12px' } }));
    const search = el('input', { class: 'input', placeholder: '🔍 ابحث في ملفات المشروع…', style: { marginBottom: '12px' } });
    const listBox = el('div');
    function drawFiles() {
      clear(listBox);
      const q = search.value.trim().toLowerCase();
      const all = projFiles();
      const shown = all.filter((f) => !q || (f.name || '').toLowerCase().includes(q));
      if (!all.length) listBox.appendChild(el('div', { class: 'empty', text: 'لا ملفات بعد' }));
      else if (!shown.length) listBox.appendChild(el('div', { class: 'empty', text: 'مفيش نتائج للبحث' }));
      shown.forEach((f) => {
        const upl = userById(f.createdBy);
        listBox.appendChild(el('div', { class: 'card row', style: { padding: '10px 12px', gap: '10px', marginBottom: '7px' } }, [
          el('span', { html: icon(f.type === 'image' ? 'image' : 'file'), style: { color: 'var(--brand)' } }),
          el('div', { class: 'grow' }, [
            el('div', { style: { fontWeight: '700', fontSize: '13px' }, text: f.name }),
            el('div', { class: 'dim', style: { fontSize: '11px' }, text: timeAgo(f.createdAt) + (upl ? ' · رفعه ' + upl.name : '') + (f.size ? ' · ' + Math.max(1, Math.round(f.size / 1024)) + 'KB' : '') }),
          ]),
          f.data ? el('a', { class: 'btn ghost icon sm', html: icon('download'), href: f.data, download: f.name, title: 'تحميل' }) : null,
          el('button', {
            class: 'btn ghost icon sm', html: icon('edit'), title: 'إعادة تسمية',
            onclick: () => {
              const inp = el('input', { class: 'input' }); inp.value = f.name;
              const m = modal({
                title: 'إعادة تسمية الملف',
                body: [inp],
                footer: [
                  el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
                  el('button', { class: 'btn primary', text: t('save'), onclick: async () => {
                    const v = inp.value.trim();
                    if (!v) { toast('الاسم فاضي', 'err'); return; }
                    f.name = v.slice(0, 120);
                    await save('assets', f); m.close(); toast('اتغيّر الاسم ✓', 'ok');
                    await new Promise((r) => setTimeout(r, 250));
                    drawFiles();
                  } }),
                ],
              });
            },
          }),
          el('button', {
            class: 'btn ghost icon sm', html: icon('trash'), title: 'حذف',
            onclick: async () => {
              if (!await confirmDialog('حذف «' + f.name + '» من المشروع؟', { danger: true })) return;
              await api.remove('assets', f.id);
              toast('اتحذف الملف', 'ok');
              await new Promise((r) => setTimeout(r, 250));
              drawFiles();
            },
          }),
        ]));
      });
    }
    search.addEventListener('input', drawFiles);
    drawFiles();
    hh.append(search, listBox);
  }

  /* ---- التسليمات ---- */
  function tabDeliveries(hh) {
    if (!deliveries.length) hh.appendChild(el('div', { class: 'empty', text: 'لا تسليمات — الأتمتة تنشئ تسليمًا تلقائيًا عند اعتماد العميل' }));
    deliveries.forEach((d) => {
      hh.appendChild(el('div', { class: 'card row', style: { padding: '12px', gap: '10px', marginBottom: '8px' } }, [
        el('span', { html: icon('delivery'), style: { color: 'var(--brand)' } }),
        el('div', { class: 'grow' }, [
          el('div', { style: { fontWeight: '700' }, text: d.title }),
          el('div', { class: 'dim', style: { fontSize: '12px' }, text: d.status === 'approved' ? 'معتمد ✓' : d.status === 'revision' ? 'تعديلات مطلوبة' : d.status === 'waiting_client' ? 'بانتظار العميل' : 'قيد التجهيز' }),
        ]),
        el('button', { class: 'btn sm', text: 'فتح', onclick: () => { location.hash = '#/delivery'; } }),
      ]));
    });
  }

  /* ---- النشاط ---- */
  function tabActivity(hh) {
    const acts = (state.activity || []).slice(0, 30);
    acts.forEach((a) => {
      const u = userById(a.userId);
      hh.appendChild(el('div', { class: 'act-row' }, [
        el('div', { html: avatarHTML(u, 'sm') }),
        el('div', { class: 'grow' }, [el('div', { style: { fontSize: '13px' }, text: getLang() === 'ar' ? a.text : (a.textEn || a.text) })]),
        el('span', { class: 'dim', style: { fontSize: '11px' }, text: timeAgo(a.at) }),
      ]));
    });
    if (!acts.length) hh.appendChild(el('div', { class: 'empty', text: 'لا نشاط بعد' }));
  }

  draw();
}

/* ---------------- نموذج مشروع ---------------- */
export function openProjectModal(p, onDone) {
  const doc = Object.assign({ title: '', clientId: (state.clients[0] || {}).id || '', status: 'progress', priority: 'medium', due: '', budget: 0, tags: [], dept: 'design' }, p || {});
  const f = (label, key, extra = {}) => el('div', { class: 'field' }, [el('label', { text: label }), el('input', Object.assign({ class: 'input', value: doc[key] || '', oninput: (e) => doc[key] = e.target.value }, extra))]);
  const clientSel = el('select', { class: 'select', html: (state.clients || []).map((c) => `<option value="${c.id}" ${c.id === doc.clientId ? 'selected' : ''}>${escapeHTML(c.name)}</option>`).join(''), onchange: (e) => doc.clientId = e.target.value });
  const stSel = el('select', { class: 'select', html: Object.entries(PROJ_STATUS).map(([k, v]) => `<option value="${k}" ${k === doc.status ? 'selected' : ''}>${v}</option>`).join(''), onchange: (e) => doc.status = e.target.value });
  const prSel = el('select', { class: 'select', html: ['low', 'medium', 'high', 'urgent'].map((k) => `<option value="${k}" ${k === doc.priority ? 'selected' : ''}>${k}</option>`).join(''), onchange: (e) => doc.priority = e.target.value });

  const m = modal({
    title: p ? 'تعديل المشروع' : 'مشروع جديد',
    size: 'wide',
    body: [
      el('div', { class: 'field' }, [el('label', { text: 'اسم المشروع *' }), el('input', { class: 'input', value: doc.title, oninput: (e) => doc.title = e.target.value })]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: t('client') }), clientSel]),
        el('div', { class: 'field' }, [el('label', { text: t('status') }), stSel]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'تاريخ التسليم' }), el('input', { class: 'input', type: 'date', value: doc.due || '', oninput: (e) => doc.due = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'الأولوية' }), prSel]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'الميزانية (ج.م)' }), el('input', { class: 'input num', type: 'number', value: doc.budget || 0, oninput: (e) => doc.budget = +e.target.value || 0 })]),
        el('div', { class: 'field' }, [el('label', { text: 'وسوم (مفصولة بفواصل)' }), el('input', { class: 'input', value: (doc.tags || []).join('، '), oninput: (e) => doc.tags = e.target.value.split(/[،,]/).map((s) => s.trim()).filter(Boolean) })]),
      ]),
      el('div', { class: 'field' }, [el('label', { text: '🔗 GitHub Repo' }), el('input', { class: 'input', style: { direction: 'ltr', textAlign: 'left' }, placeholder: 'https://github.com/…', value: doc.repo || '', oninput: (e) => doc.repo = e.target.value })]),
    ],
    footer: [
      p ? el('button', {
        class: 'btn danger ghost', text: t('delete'),
        onclick: async () => {
          if (!await confirmDialog('حذف المشروع؟ المهام والتصاميم المرتبطة تبقى لكنها تصبح بلا مشروع.', { danger: true })) return;
          await remove('projects', p.id);
          m.close(); onDone && onDone();
        },
      }) : null,
      el('div', { class: 'grow' }),
      el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: t('save'),
        onclick: async () => {
          if (!doc.title.trim()) { toast(t('required'), 'warn'); return; }
          await save('projects', doc);
          m.close(); toast(t('saved'), 'ok'); onDone && onDone();
        },
      }),
    ],
  });
}
