/* ============================================================
   MEEM | Creative Office — Phase 3: بورتال العميل
   العميل يشوف مشاريعه وتصاميمه، يعتمد أو يطلب تعديل، ويحمّل النهائي
   ============================================================ */
import { getLang } from '../i18n.js';
import { state, clientById, projectById } from '../store.js';
import { el, icon, clear, escapeHTML, toast, modal, timeAgo } from '../ui.js';
import { api } from '../api.js';

export function renderPortal(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  const me = clientById(state.user.clientId);
  const designs = state.designs || [];
  const waiting = designs.filter((d) => ['client', 'approved'].includes(d.status));
  const approved = designs.filter((d) => d.status === 'client_approved');
  const inWork = designs.filter((d) => ['progress', 'review', 'changes', 'draft'].includes(d.status));

  host.append(
    el('div', { class: 'page-head' }, [
      el('div', {}, [
        el('h1', { text: 'أهلًا، ' + state.user.name + ' 👋', style: { fontSize: '20px' } }),
        el('div', { class: 'ph-sub', text: (me ? me.name : '') + ' — تابع شغلك مع MEEM: عاين، اعتمد، أو اطلب تعديل، وحمّل نسخك النهائية' }),
          el('div', { class: 'row wrap', style: { gap: '8px', marginTop: '8px' } }, [
            el('button', { class: 'btn primary', text: '📝 اطلب مشروع جديد', onclick: () => openNewRequestModal() }),
            el('button', { class: 'btn', text: '🏢 زور المكتب الافتراضي', onclick: () => { location.hash = '#/office'; } }),
          ]),
      ]),
    ]),
    el('div', { class: 'kpis' }, [
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'بانتظار قرارك' }), el('div', { class: 'k-value num', style: { color: 'var(--warn, #f59e0b)' }, text: String(waiting.length) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'معتمد ليك' }), el('div', { class: 'k-value num', style: { color: 'var(--ok)' }, text: String(approved.length) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'شغّالين عليه' }), el('div', { class: 'k-value num', text: String(inWork.length) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'مشاريعك' }), el('div', { class: 'k-value num', text: String((state.projects || []).length) })]),
    ]),
  );

  /* ---- بانتظار الاعتماد ---- */
  host.appendChild(el('h3', { text: '🕐 بانتظار قرارك', style: { fontSize: '16px', margin: '6px 0 10px' } }));
  const g1 = el('div', { class: 'cards-grid' });
  if (!waiting.length) g1.appendChild(el('div', { class: 'empty', style: { gridColumn: '1/-1' }, text: 'مفيش حاجة مستنياك دلوقتي — أول ما يجهز تصميم هتلاقيه هنا' }));
  waiting.forEach((d) => g1.appendChild(clientCard(d, true)));
  host.appendChild(g1);

  /* ---- المعتمد ---- */
  host.appendChild(el('h3', { text: '✅ نسخك المعتمدة (تحميل)', style: { fontSize: '16px', margin: '20px 0 10px' } }));
  const g2 = el('div', { class: 'cards-grid' });
  if (!approved.length) g2.appendChild(el('div', { class: 'empty', style: { gridColumn: '1/-1' }, text: 'لسه مفيش نسخ معتمدة' }));
  approved.forEach((d) => g2.appendChild(clientCard(d, false)));
  host.appendChild(g2);

  /* ---- مشاريعي ---- */
  host.appendChild(el('h3', { text: '📁 مشاريعك الجارية', style: { fontSize: '16px', margin: '20px 0 10px' } }));
  const g3 = el('div', { class: 'cards-grid' });
  (state.projects || []).filter((p) => !['done', 'delivered'].includes(p.status)).forEach((p) => {
    const n = designs.filter((d) => d.projectId === p.id).length;
    g3.appendChild(el('div', { class: 'card', style: { padding: '14px' } }, [
      el('div', { style: { fontWeight: '800', fontSize: '14.5px', marginBottom: '4px' }, text: p.title }),
      el('div', { class: 'dim', style: { fontSize: '12px', marginBottom: '8px' }, text: `${n} تصميم · تسليم ${p.due || '—'}` }),
      el('div', { class: 'pbar' }, [el('i', { style: { width: (p.status === 'client' ? 80 : p.status === 'review' ? 60 : 35) + '%' } })]),
    ]));
  });
  if (!(state.projects || []).length) g3.appendChild(el('div', { class: 'empty', style: { gridColumn: '1/-1' }, text: 'لا مشاريع' }));
  host.appendChild(g3);

  /* ---- V4-4: طلباتي ---- */
  const myReqs = (state.requests || []).slice().sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  host.appendChild(el('h3', { text: '📋 طلباتي', style: { fontSize: '16px', margin: '20px 0 10px' } }));
  if (!myReqs.length) host.appendChild(el('div', { class: 'empty', text: 'مفيش طلبات لسه — اطلب مشروعك الأول من الزر فوق' }));
  const RQ = { new: ['قيد الاستلام', 'info'], assigned: ['جاري تجهيزه', 'warn'], converted: ['بدأنا فيه ✓', 'ok'], rejected: ['مرفوض', 'danger'], closed: ['مغلق', ''] };
  myReqs.forEach((r) => {
    const [lb, cl] = RQ[r.status] || [r.status, ''];
    host.appendChild(el('div', { class: 'card row', style: { padding: '12px 14px', gap: '10px', marginBottom: '8px' } }, [
      el('span', { html: icon('bell'), style: { color: 'var(--brand)' } }),
      el('div', { class: 'grow' }, [
        el('div', { style: { fontWeight: '700', fontSize: '13.5px' }, text: r.title }),
        el('div', { class: 'dim', style: { fontSize: '12px' }, text: timeAgo(r.createdAt) }),
        r.status === 'rejected' && r.rejectReason ? el('div', { style: { fontSize: '12px', color: 'var(--danger)', marginTop: '4px' }, text: 'سبب الرفض: ' + r.rejectReason }) : null,
      ]),
      el('span', { class: 'badge ' + cl, text: lb }),
    ]));
  });

  /* ---- تسليماتي ---- */
  const dlvs = state.deliveries || [];
  if (dlvs.length) {
    host.appendChild(el('h3', { text: '🚚 تسليماتك', style: { fontSize: '16px', margin: '20px 0 10px' } }));
    dlvs.forEach((d) => {
      host.appendChild(el('div', { class: 'card row', style: { padding: '12px 14px', gap: '10px', marginBottom: '8px' } }, [
        el('span', { html: icon('delivery'), style: { color: 'var(--brand)' } }),
        el('div', { class: 'grow' }, [
          el('div', { style: { fontWeight: '700', fontSize: '13.5px' }, text: d.title }),
          el('div', { class: 'dim', style: { fontSize: '12px' }, text: (d.items || []).join('، ') || '—' }),
        ]),
        el('span', { class: 'badge ' + (d.status === 'approved' ? 'ok' : d.status === 'revision' ? 'danger' : 'warn'), text: d.status === 'approved' ? 'معتمد ✓' : d.status === 'revision' ? 'جاري التعديل' : 'بانتظارك' }),
      ]));
    });
  }

  /* ---------------- V4-4: مودال طلب مشروع جديد ---------------- */
  function openNewRequestModal() {
    const SVCS = [['design', 'تصميم جرافيك'], ['content', 'كتابة محتوى'], ['voice', 'فويس أوفر'], ['dev', 'موقع/تطبيق'], ['social', 'إدارة سوشيال ميديا']];
    const svc = el('select', { class: 'select', html: SVCS.map(([v, l]) => `<option value="${v}">${l}</option>`).join('') });
    const det = el('textarea', { class: 'textarea', placeholder: 'اكتب تفاصيل مشروعك: الهدف، المقاسات، الموعد المطلوب…' });
    const ph = el('input', { class: 'input', placeholder: 'موبايل للتواصل' });
    ph.value = (me && me.phone) || '';
    const pr = el('select', { class: 'select', html: '<option value="low">عادية</option><option value="medium" selected>متوسطة</option><option value="high">عاجلة</option>' });
    const m = modal({
      title: '📝 طلب مشروع جديد',
      body: [
        el('div', { class: 'grid2' }, [
          el('div', { class: 'field' }, [el('label', { text: 'نوع الخدمة' }), svc]),
          el('div', { class: 'field' }, [el('label', { text: 'الأولوية' }), pr]),
        ]),
        el('div', { class: 'field' }, [el('label', { text: 'التفاصيل' }), det]),
        el('div', { class: 'field' }, [el('label', { text: 'موبايل' }), ph]),
      ],
      footer: [
        el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
        el('button', { class: 'btn primary', text: 'إرسال الطلب 🚀', onclick: async () => {
          if (!det.value.trim()) { toast('اكتب تفاصيل الطلب', 'err'); return; }
          try {
            const token = localStorage.getItem('basma_token');
            const res = await fetch('/api/portal/request', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token }, body: JSON.stringify({ service: svc.value, details: det.value.trim(), phone: ph.value.trim(), priority: pr.value }) });
            const j = await res.json();
            if (!j.ok) throw new Error(j.error || 'حصل خطأ');
            m.close();
            toast('طلبك وصل الفريق ✓', 'ok');
            await new Promise((r) => setTimeout(r, 600)); /* نستنى broadcast يحدّث الحالة */
            renderPortal(host);
          } catch (e) { toast(e.message, 'err'); }
        } }),
      ],
    });
  }

  /* ---------------- بطاقة تصميم للعميل ---------------- */
  function clientCard(d, actionable) {
    const proj = projectById(d.projectId);
    return el('div', { class: 'dcard' }, [
      el('div', { class: 'dc-thumb' }, d.thumb ? el('img', { src: d.thumb }) : el('div', { class: 'dim', html: icon('image') })),
      el('div', { class: 'dc-body' }, [
        el('div', { class: 'dc-title', text: d.title }),
        el('div', { class: 'dc-sub', text: (proj ? proj.title + ' · ' : '') + timeAgo(d.updatedAt || d.createdAt) }),
        el('div', { class: 'row wrap', style: { gap: '6px', marginTop: '9px' } }, [
          el('button', { class: 'btn sm', html: icon('eye') + `<span>معاينة</span>`, onclick: () => previewModal(d) }),
          actionable ? el('button', { class: 'btn sm ok', html: icon('check') + `<span>اعتماد</span>`, onclick: () => decide(d, 'approve') }) : null,
          actionable ? el('button', { class: 'btn sm danger ghost', html: icon('edit') + `<span>تعديل</span>`, onclick: () => decide(d, 'changes') }) : null,
          !actionable ? el('button', { class: 'btn sm primary', html: icon('download') + `<span>تحميل PNG</span>`, onclick: () => downloadFinal(d) }) : null,
        ]),
        d.client && d.client.decision === 'changes' ? el('div', { class: 'dim', style: { fontSize: '11.5px', marginTop: '6px' }, text: 'ملاحظاتك: ' + (d.client.note || '') }) : null,
      ]),
    ]);
  }

  async function previewModal(d) {
    const full = await api.design(d.id);
    const page = (full.design.pages || [])[0];
    const body = el('div', { class: 'portal-preview' }, [el('div', { class: 'dim', text: 'جارٍ الرسم…' })]);
    modal({ title: d.title, size: 'wide', body: [body] });
    try {
      const { renderPage } = await import('../editor/render.js');
      const { ensureFonts } = await import('../editor/fonts.js');
      await ensureFonts(page.layers);
      const c = document.createElement('canvas');
      await renderPage(c, page, Math.min(1.5, 1100 / Math.max(page.w, page.h)));
      clear(body);
      body.appendChild(c);
    } catch (e) { clear(body); body.appendChild(el('div', { class: 'dim', text: 'تعذّر الرسم' })); }
  }

  function decide(d, decision) {
    const note = el('textarea', { class: 'textarea', rows: 3, placeholder: decision === 'changes' ? 'اكتب اللي عايز تتعدّل…' : 'كلمة اختيارية مع الاعتماد…' });
    const m = modal({
      title: decision === 'approve' ? '✓ اعتماد التصميم' : '✏️ طلب تعديل',
      body: [note],
      footer: [
        el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
        el('button', {
          class: 'btn ' + (decision === 'approve' ? 'ok' : 'danger'),
          text: decision === 'approve' ? 'اعتماد' : 'إرسال الملاحظات',
          onclick: async () => {
            const n = note.value.trim();
            if (decision === 'changes' && !n) { toast('اكتب ملاحظاتك الأول', 'warn'); return; }
            m.close();
            try {
              await api.designDecision(d.id, decision, n);
              toast(decision === 'approve' ? 'شكرًا! تم الاعتماد وهتلاقي التحميل متاح ✓' : 'وصلتنا ملاحظاتك والفريق شغّال عليها 📨', 'ok', 4200);
            } catch (e) { toast('تعذّر الإرسال: ' + e.message, 'err'); }
          },
        }),
      ],
    });
  }

  async function downloadFinal(d) {
    try {
      toast('جاري تجهيز التحميل…', 'info', 1500);
      const full = await api.design(d.id);
      const page = (full.design.pages || [])[0];
      const { exportPage } = await import('../editor/export.js');
      await exportPage(page, { format: 'png', scale: 1, filename: (d.title || 'design').replace(/[^\p{L}\p{N}._-]/gu, '-') });
      toast('اتحمّل ✓', 'ok');
    } catch (e) { toast('تعذّر التحميل: ' + e.message, 'err'); }
  }
}
