/* ============================================================
   MEE M — Tasks Kanban (V2-10)
   لوحة مهام بأعمدة الحالات: سحب وإفلات + أسهم للموبايل + مرفقات
   ============================================================ */
import { state, save, userById, projectById, isOverdue } from '../store.js';
import { el, icon, avatarHTML, toast, priorityBadge } from '../ui.js';
import { openTaskDetails } from '../taskform.js';
import { getLang } from '../i18n.js';

export const KCOLS = [
  { st: 'new', ar: 'جديدة', en: 'New', color: '#64748b' },
  { st: 'progress', ar: 'شغل مستمر', en: 'In Progress', color: '#2f7bff' },
  { st: 'review', ar: 'مراجعة', en: 'Review', color: '#f59e0b' },
  { st: 'blocked', ar: 'متوقفة 🚫', en: 'Blocked', color: '#b91c1c' },
  { st: 'client', ar: 'عند العميل', en: 'With Client', color: '#8b5cf6' },
  { st: 'revision', ar: 'تعديلات', en: 'Revisions', color: '#ef4444' },
  { st: 'done', ar: 'تم ✓', en: 'Done ✓', color: '#22c55e', has: ['done', 'delivered'] },
];
const colLabel = (c) => (getLang() === 'ar' ? c.ar : c.en);
const DEPT_OF_ROLE = { designer: 'design', content: 'content', voice: 'voice', dev: 'dev', cs: 'delivery' };

let fMine = false;
let fDept = '';
let fPrj = '';

const colHas = (c, st) => (c.has || [c.st]).includes(st);
const colOf = (st) => KCOLS.find((c) => colHas(c, st)) || KCOLS[0];

export function renderTasks(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');

  const me = state.user;
  const isAdm = me.role === 'admin' || me.role === 'superadmin';

  /* ---- الفلاتر ---- */
  const tasks0 = state.tasks || [];
  const AR = getLang() === 'ar';
  const deptSel = el('select', { class: 'select', style: { maxWidth: '150px' }, onchange: (e) => { fDept = e.target.value; renderTasks(host); } },
    [el('option', { value: '', text: AR ? 'كل الأقسام' : 'All departments' })].concat(
      ['design', 'content', 'voice', 'dev', 'delivery'].map((d) => el('option', { value: d, text: AR ? { design: 'تصميم', content: 'محتوى', voice: 'فويس', dev: 'برمجة', delivery: 'تسليمات' }[d] : { design: 'Design', content: 'Content', voice: 'Voice', dev: 'Dev', delivery: 'Delivery' }[d], selected: fDept === d }))));
  const prjSel = el('select', { class: 'select', style: { maxWidth: '180px' }, onchange: (e) => { fPrj = e.target.value; renderTasks(host); } },
    [el('option', { value: '', text: AR ? 'كل المشاريع' : 'All projects' })].concat(
      (state.projects || []).map((p) => el('option', { value: p.id, text: AR ? p.title : (p.titleEn || p.title), selected: fPrj === p.id }))));
  const mineBtn = el('button', {
    class: 'btn sm' + (fMine ? ' primary' : ''),
    text: fMine ? (AR ? '✓ مهامي' : '✓ My tasks') : (AR ? 'مهامي' : 'My tasks'),
    onclick: () => { fMine = !fMine; renderTasks(host); },
  });

  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('kanban') + (AR ? ' المهام' : ' Tasks'), style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: AR ? 'اسحب الكارت للعمود التالي — أو استخدم الأسهم ◀ ▶' : 'Drag a card to the next column — or use the ◀ ▶ arrows' }),
    ]),
    el('div', { class: 'row', style: { gap: '8px' } }, [mineBtn, deptSel, prjSel]),
  ]));

  let list = tasks0;
  if (fMine) list = list.filter((x) => x.assignee === me.id || (x.assignees || []).includes(me.id)); /* V4-3 */
  if (fDept) list = list.filter((x) => x.dept === fDept);
  if (fPrj) list = list.filter((x) => x.projectId === fPrj);

  /* ---- النقل بين الأعمدة ---- */
  async function move(task, st) {
    if (task.status === st) return;
    const old = task.status;
    task.status = st;
    try {
      await save('tasks', task);
      toast((getLang() === 'ar' ? 'نقلت لـ «' : 'Moved to ') + colLabel(colOf(st)) + (getLang() === 'ar' ? '»' : ''), 'ok');
    } catch (e) {
      task.status = old;
      toast('ماقدرتش: ' + (e.message || ''), 'err');
    }
    renderTasks(host);
  }
  const shift = (task, dir) => {
    const i = KCOLS.indexOf(colOf(task.status));
    const j = Math.max(0, Math.min(KCOLS.length - 1, i + dir));
    move(task, KCOLS[j].st);
  };

  /* ---- اللوحة ---- */
  const board = el('div', { class: 'kb-board' });
  KCOLS.forEach((col) => {
    const items = list.filter((x) => colHas(col, x.status));
    const colEl = el('div', { class: 'kb-col', style: { '--kc': col.color } });
    colEl.addEventListener('dragover', (e) => { e.preventDefault(); colEl.classList.add('over'); });
    colEl.addEventListener('dragleave', () => colEl.classList.remove('over'));
    colEl.addEventListener('drop', (e) => {
      e.preventDefault();
      colEl.classList.remove('over');
      const id = e.dataTransfer.getData('text/plain');
      const task = state.tasks.find((x) => x.id === id);
      if (task) move(task, col.st);
    });
    colEl.appendChild(el('div', { class: 'kb-col-head' }, [
      el('span', { class: 'kb-dot' }),
      el('b', { text: colLabel(col) }),
      el('span', { class: 'kb-count num', text: String(items.length) }),
    ]));
    items.forEach((task) => {
      const assignee = userById(task.assignee);
      const prj = projectById(task.projectId);
      const card = el('div', { class: 'kb-card' + (task.status === 'blocked' ? ' blocked' : ''), draggable: 'true', dataset: { task: task.id } }, [
        el('div', { class: 'row', style: { gap: '6px', alignItems: 'flex-start' } }, [
          el('span', { class: 'grow', style: { fontWeight: '700', fontSize: '13px' }, text: getLang() === 'ar' ? task.title : (task.titleEn || task.title) }),
          el('span', { html: priorityBadge(task.priority) }),
        ]),
        el('div', { class: 'row', style: { gap: '5px', marginTop: '4px' } }, [
          el('span', { class: 'badge', style: { fontSize: '10px' }, text: task.type || '' }),
          prj ? el('span', { class: 'dim', style: { fontSize: '10.5px' }, text: prj.title }) : null,
        ]),
        el('div', { class: 'row', style: { gap: '6px', marginTop: '8px' } }, [
          el('span', { html: avatarHTML(assignee, 'sm') }),
          task.due ? el('span', { class: 'num', style: { fontSize: '11px', color: isOverdue(task) ? 'var(--danger)' : 'var(--dim)' }, text: task.due }) : null,
          (task.comments || []).length ? el('span', { class: 'dim', style: { fontSize: '11px' }, text: '💬' + (task.comments || []).length }) : null,
          (task.files || []).length ? el('span', { class: 'kb-clip', style: { fontSize: '11px' }, text: '📎' + (task.files || []).length }) : null,
          /* V4-3: مؤشرات الخطوات والساعات والمنفذين */
          (task.subtasks || []).length ? el('span', { class: 'dim num', style: { fontSize: '11px' }, text: '☑' + task.subtasks.filter((s) => s.done).length + '/' + task.subtasks.length }) : null,
          task.est ? el('span', { class: 'dim num', style: { fontSize: '11px' }, text: '⏱' + task.est + 'س' }) : null,
          (task.assignees || []).length > 1 ? el('span', { class: 'dim num', style: { fontSize: '11px' }, text: '👥' + task.assignees.length }) : null,
          el('div', { class: 'grow' }),
          el('button', { class: 'btn ghost icon sm kb-mv', html: icon('undo'), title: 'رجوع', onclick: (e) => { e.stopPropagation(); shift(task, -1); } }),
          el('button', { class: 'btn ghost icon sm kb-mv', html: icon('send'), title: 'تقدم', onclick: (e) => { e.stopPropagation(); shift(task, 1); } }),
        ]),
      ]);
      card.addEventListener('dragstart', (e) => e.dataTransfer.setData('text/plain', task.id));
      card.addEventListener('click', () => openTaskDetails(task.id, () => renderTasks(host)));
      colEl.appendChild(card);
    });
    if (!items.length) colEl.appendChild(el('div', { class: 'kb-empty', text: '—' }));
    board.appendChild(colEl);
  });
  host.appendChild(board);
}
