/* ============================================================
   MEE M — Owner Control (V2-3)
   لوحة المالك المخفي: منفصلة بصريًا ووظيفيًا عن Workspace الفريق
   الهوية الجديدة: أسود / فضي / أزرق كهربائي — Futuristic Minimal
   ============================================================ */
import { state, save, applyBrand } from '../store.js';
import { el, icon, clear, escapeHTML, toast, modal } from '../ui.js';
import { api } from '../api.js';

let ownerTab = 'overview'; // يتحمل إعادة التصيير

const TABS = [
  ['overview', 'dashboard', 'Overview', 'نظرة عامة'],
  ['team', 'users', 'Team', 'الفريق'],
  ['projects', 'kanban', 'Projects', 'المشاريع'],
  ['tasks', 'check', 'Tasks', 'المهام'],
  ['clients', 'clients', 'Clients', 'العملاء'],
  ['files', 'folder', 'Files', 'الملفات'],
  ['requests', 'bell', 'Requests', 'الطلبات'],
  ['tools', 'layers', 'Tools', 'الأدوات'],
  ['perms', 'lock', 'Perms', 'الصلاحيات'],
  ['settings', 'settings', 'Settings', 'الإعدادات'],
];

const ROLE_AR = { superadmin: 'مالك', admin: 'مدير عام', designer: 'مصمم', content: 'كاتب محتوى', voice: 'فويس أوفر', dev: 'مطور', cs: 'خدمة عملاء', editor: 'محرر', client: 'عميل' };

function toolsDoc() { return (state.settings || []).find((s) => s.id === 'tools') || { id: 'tools', video: false, ai: false }; }

export function renderOwner(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  host.classList.add('owner-scope');

  const online = new Set(state.online || []);
  const users = (state.users || []).filter((u) => u.role !== 'client');

  /* ---- Header ---- */
  host.appendChild(el('div', { class: 'owner-head' }, [
    el('div', { class: 'owner-brand' }, [
      el('div', { class: 'owner-logo', html: 'MEE<i>M</i>' }),
      el('div', {}, [
        el('div', { class: 'owner-title', text: 'OWNER CONTROL' }),
        el('div', { class: 'owner-sub', text: 'لوحة المالك — أعلى مستوى صلاحية في النظام' }),
      ]),
    ]),
    el('div', { class: 'owner-live' }, [
      el('span', { class: 'owner-dot' }),
      el('span', { class: 'num', text: String(online.size) }),
      el('span', { text: 'متصل الآن' }),
    ]),
  ]));

  /* ---- Tabs ---- */
  const tabBar = el('div', { class: 'owner-tabs' });
  TABS.forEach(([k, ic, en, ar]) => {
    tabBar.appendChild(el('button', {
      class: 'owner-tab' + (ownerTab === k ? ' active' : ''),
      html: icon(ic) + `<span>${en}</span><small>${ar}</small>`,
      onclick: () => { ownerTab = k; renderOwner(host); },
    }));
  });
  host.appendChild(tabBar);

  const body = el('div', { class: 'owner-body' });
  host.appendChild(body);

  /* ================= OVERVIEW ================= */
  if (ownerTab === 'overview') {
    const tasks = state.tasks || [];
    const projects = state.projects || [];
    const late = (arr) => arr.filter((t) => t.deadline && new Date(t.deadline) < new Date() && !['done', 'delivered', 'approved'].includes(t.status));
    const kpis = [
      ['الموظفون', 'Team', users.length, ''],
      ['المتصلون', 'Online', online.size, 'blue'],
      ['مشاريع نشطة', 'Active Projects', projects.filter((p) => !['done', 'archived'].includes(p.status)).length, ''],
      ['مشاريع/مهام متأخرة', 'Overdue', late(tasks).length + late(projects).length, late(tasks).length + late(projects).length ? 'red' : ''],
      ['مهام جديدة', 'New Tasks', tasks.filter((t) => t.status === 'todo' || t.status === 'new').length, ''],
      ['قيد التنفيذ', 'In Progress', tasks.filter((t) => t.status === 'progress' || t.status === 'inprogress').length, 'blue'],
      ['مهام مكتملة', 'Completed', tasks.filter((t) => ['done', 'delivered'].includes(t.status)).length, 'green'],
      ['طلبات تعديل', 'Revisions', (state.requests || []).filter((r) => r.status === 'new' || r.status === 'open').length, ''],
      ['بانتظار الاعتماد', 'Pending Approval', (state.designs || []).filter((d) => ['review', 'client'].includes(d.status)).length + (state.deliveries || []).filter((d) => d.status === 'waiting_client').length, ''],
    ];
    body.appendChild(el('div', { class: 'owner-kpis' }, kpis.map(([ar, en, n, c]) => el('div', { class: 'owner-kpi ' + c }, [
      el('div', { class: 'ok-v num', text: String(n) }),
      el('div', { class: 'ok-l', text: ar }),
      el('div', { class: 'ok-en', text: en }),
    ]))));

    const lastD = (state.deliveries || []).slice(-5).reverse();
    body.appendChild(el('div', { class: 'owner-card' }, [
      el('div', { class: 'oc-title', html: icon('delivery') + ' آخر التسليمات <small>Latest Deliveries</small>' }),
      ...lastD.map((d) => el('div', { class: 'oc-row' }, [
        el('span', { text: d.title || d.id }),
        el('span', { class: 'oc-badge', text: d.status }),
        el('span', { class: 'oc-dim', text: (d.deliveredAt || d.updatedAt || '').slice(0, 10) }),
      ])),
      ...(lastD.length ? [] : [el('div', { class: 'oc-empty', text: 'لا توجد تسليمات بعد' })]),
    ]));
  }

  /* ================= TEAM ================= */
  if (ownerTab === 'team') {
    const wrap = el('div', { class: 'owner-card' });
    wrap.appendChild(el('div', { class: 'oc-head' }, [
      el('div', { class: 'oc-title', html: icon('users') + ' إدارة الفريق <small>Team Management</small>' }),
      el('button', { class: 'btn primary', html: icon('plus') + '<span>حساب جديد</span>', onclick: () => userModal(null, host) }),
    ]));
    users.forEach((u) => {
      const isSelf = u.id === state.user.id;
      wrap.appendChild(el('div', { class: 'oc-row team-row' }, [
        el('span', { class: 'team-av', style: { background: u.avatarColor || '#2f7bff' }, text: u.initials || (u.name || '?').slice(0, 1) }),
        el('div', { class: 'team-info' }, [
          el('div', { text: u.name + (isSelf ? ' (أنت)' : '') + (u.active === false ? ' — معطّل' : '') }),
          el('div', { class: 'oc-dim', text: `${u.email} · ${ROLE_AR[u.role] || u.role}${u.title ? ' · ' + u.title : ''}` }),
        ]),
        el('span', { class: 'owner-dot ' + (online.has(u.id) ? '' : 'off'), title: online.has(u.id) ? 'متصل' : 'غير متصل' }),
        el('button', { class: 'btn sm', text: u.active === false ? 'تفعيل' : 'تعطيل', onclick: async () => {
          await api.user({ id: u.id, active: u.active === false });
          toast(u.active === false ? 'تم التفعيل ✓' : 'تم التعطيل', 'ok');
        } }),
        el('button', { class: 'btn sm', html: icon('lock') + '<span>باسورد</span>', onclick: () => passModal(u, host) }),
        el('button', { class: 'btn sm', html: icon('edit'), onclick: () => userModal(u, host) }),
      ]));
    });
    body.appendChild(wrap);
  }

  /* ================= PROJECTS / TASKS / CLIENTS / FILES / REQUESTS ================= */
  const listers = {
    projects: { title: 'المشاريع', en: 'Projects', ic: 'kanban', rows: (state.projects || []).map((p) => [p.title, p.status, p.deadline || '—']) },
    tasks: { title: 'المهام', en: 'Tasks', ic: 'check', rows: (state.tasks || []).slice(-40).reverse().map((t) => [t.title, t.status, t.deadline || '—']) },
    clients: { title: 'العملاء', en: 'Clients', ic: 'clients', rows: (state.clients || []).map((c) => [c.name, c.industry || c.type || '—', c.phone || c.email || '—']) },
    files: { title: 'الملفات', en: 'Files', ic: 'folder', rows: (state.assets || []).slice(-40).reverse().map((a) => [a.name, a.type, (a.createdAt || '').slice(0, 10)]) },
    requests: { title: 'الطلبات', en: 'Requests', ic: 'bell', rows: (state.requests || []).slice().reverse().map((r) => [r.title, r.status, r.priority || '—']) },
  };
  if (listers[ownerTab]) {
    const L = listers[ownerTab];
    body.appendChild(el('div', { class: 'owner-card' }, [
      el('div', { class: 'oc-title', html: icon(L.ic) + ` ${L.title} <small>${L.en} · ${L.rows.length}</small>` }),
      ...L.rows.map((r) => el('div', { class: 'oc-row' }, [
        el('span', { class: 'grow', text: String(r[0] ?? '') }),
        el('span', { class: 'oc-badge', text: String(r[1] ?? '') }),
        el('span', { class: 'oc-dim', text: String(r[2] ?? '') }),
      ])),
      ...(L.rows.length ? [] : [el('div', { class: 'oc-empty', text: 'لا يوجد' })]),
    ]));
  }

  /* ================= TOOLS ================= */
  if (ownerTab === 'tools') {
    const td = toolsDoc();
    const toolRow = (key, ar, en, desc) => el('div', { class: 'oc-row tool-row' }, [
      el('div', { class: 'grow' }, [
        el('div', { text: ar + ' — ' + en }),
        el('div', { class: 'oc-dim', text: desc }),
      ]),
      el('button', {
        class: 'owner-switch' + (td[key] ? ' on' : ''),
        html: `<span></span>`,
        onclick: async () => {
          await save('settings', { id: 'tools', video: key === 'video' ? !td[key] : td.video, ai: key === 'ai' ? !td[key] : td.ai });
          toast(td[key] ? 'تم الإخفاء عن الفريق' : 'تم الإتاحة للفريق', 'ok');
        },
      }),
      el('span', { class: 'oc-badge ' + (td[key] ? 'ok' : ''), text: td[key] ? 'مُتاح' : 'مخفي' }),
    ]);
    body.appendChild(el('div', { class: 'owner-card' }, [
      el('div', { class: 'oc-title', html: icon('layers') + ' الأدوات والخدمات <small>Tools & Services</small>' }),
      toolRow('video', 'غرف الاجتماعات والفيديو', 'Meetings & Video', 'WebRTC — جاهز لكن مخفي عن واجهة الفريق حاليًا'),
      toolRow('ai', 'أدوات الذكاء الاصطناعي', 'AI Tools', 'لوحة AI في المحرر + توليد المحتوى — مخفية عن الفريق حاليًا'),
      el('div', { class: 'oc-note', text: 'الإتاحة هنا تظهر الأداة فورًا لكل الفريق — والإخفاء فوري بنفس السرعة. البنية كاملة وجاهزة.' }),
    ]));
  }

  /* ================= SETTINGS ================= */
  if (ownerTab === 'settings') {
    const db = state;
    const stats = [
      ['المستخدمون', (db.users || []).length], ['العملاء', (db.clients || []).length], ['المشاريع', (db.projects || []).length],
      ['المهام', (db.tasks || []).length], ['التصاميم', (db.designs || []).length], ['الملفات', (db.assets || []).length],
      ['التسليمات', (db.deliveries || []).length], ['الرسائل', (db.chats || []).length],
    ];
    body.appendChild(el('div', { class: 'owner-card' }, [
      el('div', { class: 'oc-title', html: icon('settings') + ' إعدادات النظام <small>System Settings</small>' }),
      el('div', { class: 'owner-kpis' }, stats.map(([k, n]) => el('div', { class: 'owner-kpi' }, [
        el('div', { class: 'ok-v num', text: String(n) }),
        el('div', { class: 'ok-l', text: k }),
      ]))),
      el('div', { class: 'oc-note', text: 'اللغة والثيم من الشريط العلوي (عربي/English · فاتح/داكن) — إدارة الحسابات والأدوات من تبويبات هذه اللوحة. نسخة النظام: MEE M 2.0 (V2-3).' }),
    ]));

    /* ---- V4-6: هوية الموقع + ثيم المكتب ---- */
    const brand = (state.settings || []).find((x) => x.id === 'brand') || { id: 'brand' };
    const fSite = el('input', { class: 'input' }); fSite.value = brand.siteName || '';
    const fTag = el('input', { class: 'input' }); fTag.value = brand.tagline || '';
    const fCol = el('input', { type: 'color', value: brand.primary || '#0066ff', style: { width: '60px', height: '34px', border: '0', background: 'none' } });
    const fLt = el('input', { class: 'input' }); fLt.value = brand.loginTitle || '';
    const fLs = el('input', { class: 'input' }); fLs.value = brand.loginSub || '';
    const fTheme = el('select', { class: 'select', html: ['default', 'neon', 'warm', 'dark'].map((x) => `<option value="${x}" ${brand.officeTheme === x ? 'selected' : ''}>${x}</option>`).join('') });
    body.appendChild(el('div', { class: 'owner-card' }, [
      el('div', { class: 'oc-title', html: icon('star') + ' هوية الموقع <small>Branding</small>' }),
      el('div', { class: 'row wrap', style: { gap: '10px', alignItems: 'flex-end' } }, [
        el('div', { class: 'field', style: { flex: '2', minWidth: '220px' } }, [el('label', { text: 'اسم الموقع' }), fSite]),
        el('div', { class: 'field', style: { flex: '2', minWidth: '220px' } }, [el('label', { text: 'الوصف (Tagline)' }), fTag]),
        el('div', { class: 'field' }, [el('label', { text: 'اللون الأساسي' }), fCol]),
        el('div', { class: 'field', style: { flex: '1', minWidth: '160px' } }, [el('label', { text: 'ثيم المكتب 3D' }), fTheme]),
      ]),
      el('div', { class: 'row wrap', style: { gap: '10px', alignItems: 'flex-end' } }, [
        el('div', { class: 'field', style: { flex: '1', minWidth: '220px' } }, [el('label', { text: 'عنوان صفحة الدخول' }), fLt]),
        el('div', { class: 'field', style: { flex: '1', minWidth: '220px' } }, [el('label', { text: 'وصف صفحة الدخول' }), fLs]),
      ]),
      el('button', {
        class: 'btn primary', text: 'حفظ الهوية',
        onclick: async () => {
          await save('settings', { id: 'brand', siteName: fSite.value.trim() || 'MEE M', tagline: fTag.value.trim(), primary: fCol.value, loginTitle: fLt.value.trim(), loginSub: fLs.value.trim(), officeTheme: fTheme.value });
          applyBrand();
          toast('الهوية اتحفظة ✓ — صفحة الدخول والثيم اتحدثوا', 'ok');
          renderOwner(host);
        },
      }),
    ]));
  }

  /* ---- V4-6: مصفوفة الصلاحيات (تُفرض backend) ---- */
  if (ownerTab === 'perms') {
    const permsDoc = (state.settings || []).find((x) => x.id === 'perms') || { id: 'perms', matrix: {} };
    const matrix = Object.assign({}, permsDoc.matrix || {});
    const ROLES_M = ['designer', 'content', 'voice', 'dev', 'cs', 'editor'];
    const COLS_M = ['tasks', 'projects', 'designs', 'clients', 'requests', 'deliveries', 'assets', 'meetings', 'timeentries', 'contents', 'voices', 'videos', 'invoices', 'payments', 'expenses', 'campaigns'];
    const DEFAULTS = {
      designer: ['designs', 'shoots', 'videos', 'assets', 'tasks', 'meetings', 'templates', 'timeentries'],
      content: ['contents', 'prompts', 'articles', 'assets', 'tasks', 'meetings', 'timeentries'],
      voice: ['voices', 'assets', 'tasks', 'meetings', 'timeentries'],
      dev: ['bugs', 'videos', 'assets', 'tasks', 'meetings', 'timeentries'],
      cs: ['clients', 'requests', 'projects', 'tasks', 'deliveries', 'assets', 'meetings', 'timeentries'],
      editor: ['contents', 'voices', 'videos', 'assets', 'tasks', 'meetings', 'timeentries'],
    };
    const table = el('table', { class: 'perm-table' });
    const thead = el('tr', {}, [el('th', { text: 'الدور \\ المجموعة' }), ...COLS_M.map((c) => el('th', { text: c }))]);
    table.appendChild(thead);
    const boxes = {};
    ROLES_M.forEach((r) => {
      const tr = el('tr', {}, [el('td', { text: ROLE_AR[r] || r, style: { fontWeight: '700' } })]);
      COLS_M.forEach((c) => {
        const cur = matrix[r] && typeof matrix[r][c] === 'boolean' ? matrix[r][c] : (DEFAULTS[r] || []).includes(c);
        const cb = el('input', { type: 'checkbox', checked: cur });
        boxes[r + ':' + c] = cb;
        tr.appendChild(el('td', {}, [cb]));
      });
      table.appendChild(tr);
    });
    body.appendChild(el('div', { class: 'owner-card' }, [
      el('div', { class: 'oc-title', html: icon('lock') + ' مصفوفة الصلاحيات <small>Permissions Matrix</small>' }),
      el('div', { class: 'oc-note', text: 'كل علامة تُفرض في السيرفر نفسه (مش إخفاء واجهة) — الإدارة العليا خارج المصفوفة (كل شيء)، والعميل قراءة فقط. مجموعات الإعدادات/السجل/الحسابات/الشات مستثناة دائمًا.' }),
      el('div', { style: { overflowX: 'auto' } }, [table]),
      el('div', { class: 'row', style: { gap: '8px', marginTop: '12px' } }, [
        el('button', {
          class: 'btn primary', text: 'حفظ المصفوفة',
          onclick: async () => {
            const m = {};
            ROLES_M.forEach((r) => {
              m[r] = {};
              COLS_M.forEach((c) => { m[r][c] = !!boxes[r + ':' + c].checked; });
            });
            await save('settings', { id: 'perms', matrix: m });
            toast('المصفوفة اتحفظة — سارية فورًا في السيرفر ✓', 'ok');
          },
        }),
        el('button', {
          class: 'btn ghost', text: 'إرجاع الافتراضي',
          onclick: async () => {
            await save('settings', { id: 'perms', matrix: {} });
            toast('رجعنا للافتراضي', 'ok');
            renderOwner(host);
          },
        }),
      ]),
    ]));
  }
}

/* ---- مودال إنشاء/تعديل حساب ---- */
function userModal(u, host) {
  const isNew = !u;
  const f = {};
  const inp = (k, label, val, type = 'text') => {
    const i = el('input', { class: 'input', type, value: val || '', placeholder: label });
    f[k] = i;
    return el('label', { class: 'fld' }, [el('span', { text: label }), i]);
  };
  const m = modal({
    title: isNew ? 'حساب موظف جديد' : 'تعديل: ' + u.name,
    body: el('div', { class: 'col', style: { gap: '10px' } }, [
      inp('name', 'الاسم', u && u.name),
      inp('nameEn', 'الاسم (إنجليزي)', u && u.nameEn),
      inp('email', 'البريد الإلكتروني', u && u.email, 'email'),
      inp('title', 'الوظيفة', u && u.title),
      (() => {
        const sel = el('select', { class: 'select' }, null);
        ['designer', 'content', 'voice', 'dev', 'cs', 'admin', 'editor'].forEach((r) => {
          const o = el('option', { value: r, text: ROLE_AR[r] || r });
          if (u && u.role === r) o.selected = true;
          sel.appendChild(o);
        });
        f.role = sel;
        return el('label', { class: 'fld' }, [el('span', { text: 'الدور' }), sel]);
      })(),
      ...(isNew ? [inp('password', 'كلمة المرور المؤقتة', '123456')] : []),
    ]),
    footer: [
      el('button', { class: 'btn', text: 'إلغاء', onclick: () => m.close() }),
      el('button', { class: 'btn primary', text: isNew ? 'إنشاء الحساب' : 'حفظ', onclick: async () => {
        const payload = { name: f.name.value.trim(), nameEn: f.nameEn.value.trim(), email: f.email.value.trim(), title: f.title.value.trim(), role: f.role.value };
        if (!payload.name || !payload.email) { toast('الاسم والإيميل مطلوبين', 'err'); return; }
        if (isNew) payload.password = f.password.value || '123456';
        if (u) payload.id = u.id;
        await api.user(payload);
        m.close();
        toast(isNew ? 'تم إنشاء الحساب ✓' : 'تم الحفظ ✓', 'ok');
      } }),
    ],
  });
}

function passModal(u, host) {
  const i = el('input', { class: 'input', type: 'password', placeholder: 'كلمة المرور الجديدة' });
  const m = modal({
    title: 'تغيير باسورد: ' + u.name,
    body: el('div', { class: 'col', style: { gap: '10px' } }, [i]),
    footer: [
      el('button', { class: 'btn', text: 'إلغاء', onclick: () => m.close() }),
      el('button', { class: 'btn primary', text: 'تغيير', onclick: async () => {
        if (String(i.value).length < 6) { toast('6 حروف على الأقل', 'err'); return; }
        await api.user({ id: u.id, password: i.value });
        m.close();
        toast('تم تغيير كلمة المرور ✓', 'ok');
      } }),
    ],
  });
}
