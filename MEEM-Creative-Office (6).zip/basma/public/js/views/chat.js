/* ============================================================
   MEEM | Creative Office — Phase 7 + V4-5: MEEM Chat المتقدم
   غرف فريق + مشاريع + عملاء + DM — unread/typing/read/reply/edit/delete/ملفات/إيموجي/بحث/تحميل أقدم
   ============================================================ */
import { state, userById, notify, markNotesRead } from '../store.js';
import { el, icon, clear, escapeHTML, toast, avatarHTML, modal, confirmDialog } from '../ui.js';
import { api, socket } from '../api.js';
import { getLang } from '../i18n.js';

/* V2-9: الرسائل المباشرة — مفتاح غرفة ثابت للطرفين */
export const dmKey = (a, b) => 'dm:' + [a, b].sort().join(':');
export function openDM(uid) {
  if (!uid || uid === state.user.id) return;
  curRoom = dmKey(state.user.id, uid);
  if (location.hash.startsWith('#/chat')) notify('chats');
  else location.hash = '#/chat';
}

let curRoom = 'general'; // يعيش بعد إعادة التصيير (رسالة واردة = re-render)
const drafts = {};       // مسودة كل غرفة
let replyTo = null;      // V4-5: الرسالة الجاري الرد عليها
let searchQ = '';        // V4-5: البحث الفوري
let typingIv = null;     // V4-5: مؤقت مؤشر الكتابة
let emojiOpen = false;   // V4-5: حالة popover الإيموجي (تصمد لإعادة الرسم)

const TEAM_ROOMS = [
  ['general', '🌐 العام'],
  ['design', '🎨 فريق التصميم'],
  ['content', '✍️ فريق المحتوى'],
  ['dev', '💻 فريق التطوير'],
];

function roomsFor(user) {
  const rooms = [];
  if (user.role === 'client') {
    rooms.push(['cli:' + user.clientId, '💬 دردشتي مع ميم']);
    (state.projects || []).forEach((p) => rooms.push(['prj:' + p.id, '📁 ' + p.title]));
  } else {
    const dmRooms = [...new Set((state.chats || []).map((m) => m.room).filter((r) => r.startsWith('dm:') && r.includes(user.id)))];
    if (curRoom.startsWith('dm:') && !dmRooms.includes(curRoom)) dmRooms.unshift(curRoom);
    dmRooms.forEach((k) => {
      const other = k.split(':').slice(1).find((id) => id !== user.id);
      const u = userById(other);
      rooms.push([k, '💬 ' + (u ? (getLang() === 'ar' ? u.name : (u.nameEn || u.name)) : (getLang() === 'ar' ? 'محادثة' : 'Chat'))]);
    });
    TEAM_ROOMS.forEach((r) => rooms.push(r));
    (state.projects || []).forEach((p) => rooms.push(['prj:' + p.id, '📁 ' + p.title]));
    (state.clients || []).forEach((c) => rooms.push(['cli:' + c.id, '👨‍💼 ' + c.name]));
  }
  return rooms;
}

const fmtTime = (iso) => { const d = new Date(iso); return d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }); };
const fmtDay = (iso) => new Date(iso).toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'long' });

/* ---- V4-5: مقروء/غير مقروء ---- */
const readKey = (room) => 'meem_chatread_' + room;
const getRead = (room) => localStorage.getItem(readKey(room)) || '';
function markRoomRead(room) {
  const now = new Date().toISOString();
  localStorage.setItem(readKey(room), now);
  if (room.startsWith('dm:')) socket.send({ type: 'cread', room });
  markNotesRead(room);
}
function unreadCount(room) {
  const rd = getRead(room);
  return (state.chats || []).filter((m) => m.room === room && m.by !== state.user.id && (!rd || (m.at || '') > rd)).length;
}

const EMOJIS = ['😀', '😂', '😍', '👍', '🙏', '🔥', '🎉', '❤️', '😎', '🤔', '😅', '👏', '💪', '✅', '⭐', '🚀', '😢', '😡', '👌', '🤝', '☕', '🎨', '📎', '⏰'];

export function renderChat(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('chat') + ' MEE M Chat', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'غرف الفريق · شات المشاريع · شات العملاء — كله لحظي' }),
    ]),
  ]));

  const rooms = roomsFor(state.user);
  if (!rooms.find(([k]) => k === curRoom)) curRoom = rooms[0][0];
  markRoomRead(curRoom); /* V4-5: فتح الغرفة = مقروء */

  /* ---- قائمة الغرف ---- */
  const list = el('div', { class: 'chat-rooms' });
  if (state.user.role !== 'client') {
    list.appendChild(el('button', {
      class: 'chat-room chat-new',
      onclick: () => {
        const team = (state.users || []).filter((u) => u.role !== 'client' && u.role !== 'superadmin' && u.id !== state.user.id && u.active !== false);
        const on = new Set(state.online || []);
        team.sort((a, b) => (on.has(b.id) ? 1 : 0) - (on.has(a.id) ? 1 : 0));
        const m = modal({
          title: getLang() === 'ar' ? '💬 رسالة مباشرة جديدة' : '💬 New Direct Message',
          body: el('div', { class: 'col', style: { gap: '6px' } }, team.map((u) => el('button', {
            class: 'dm-pick',
            onclick: () => { m.close(); openDM(u.id); },
          }, [
            el('span', { html: avatarHTML(u, 'sm') }),
            el('span', { class: 'grow', style: { textAlign: 'start' }, text: u.name }),
            el('span', { class: 'dm-dot' + (on.has(u.id) ? ' on' : '') }),
          ]))),
        });
      },
    }, [el('span', { style: { fontWeight: '800', fontSize: '13px' }, text: getLang() === 'ar' ? '＋ رسالة مباشرة جديدة' : '＋ New Direct Message' })]));
  }
  rooms.forEach(([key, label]) => {
    const msgs = (state.chats || []).filter((m) => m.room === key);
    const last = msgs[msgs.length - 1];
    const un = key === curRoom ? 0 : unreadCount(key);
    list.appendChild(el('button', {
      class: 'chat-room' + (key === curRoom ? ' active' : ''),
      onclick: () => { curRoom = key; replyTo = null; searchQ = ''; renderChat(host); },
    }, [
      el('div', { class: 'row', style: { gap: '6px' } }, [
        key.startsWith('dm:') ? el('span', { class: 'dm-dot' + ((state.online || []).includes(key.split(':').slice(1).find((id) => id !== state.user.id)) ? ' on' : '') }) : null,
        el('span', { class: 'grow', style: { fontWeight: '700', fontSize: '13px', textAlign: 'start' }, text: label }),
        un ? el('span', { class: 'room-badge num', text: String(un) }) : null,
        last ? el('span', { class: 'dim num', style: { fontSize: '10px' }, text: fmtTime(last.at) }) : null,
      ]),
      last ? el('div', { class: 'dim', style: { fontSize: '11.5px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', textAlign: 'start' }, text: last.byName + ': ' + (last.text || '📎 ' + ((last.file || {}).name || '')) }) : el('div', { class: 'dim', style: { fontSize: '11.5px' }, text: 'لسه مفيش رسائل' }),
    ]));
  });

  /* ---- الرسائل ---- */
  const msgsBox = el('div', { class: 'chat-msgs' });
  const all = (state.chats || []).filter((m) => m.room === curRoom);
  const q = searchQ.trim().toLowerCase();
  const msgs = q ? all.filter((m) => (m.text || '').toLowerCase().includes(q) || (m.byName || '').toLowerCase().includes(q)) : all;

  /* V4-5: تحميل الأقدم */
  if (!q && all.length) {
    msgsBox.appendChild(el('button', {
      class: 'btn ghost sm', text: '⬆ تحميل رسائل أقدم', style: { margin: '6px auto', display: 'block' },
      onclick: async (e) => {
        e.target.disabled = true;
        try {
          const oldest = all[0];
          const r = await api.chatHistory(curRoom, oldest.at, 50);
          const have = new Set((state.chats || []).map((m) => m.id));
          const add = (r.msgs || []).filter((m) => !have.has(m.id));
          if (!add.length) { toast('مفيش رسائل أقدم', 'ok'); return; }
          state.chats = add.concat(state.chats);
          renderChat(host);
        } catch (er) { toast('مقدرش يحمّل: ' + er.message, 'err'); }
      },
    }));
  }

  let lastDay = '';
  msgs.forEach((m) => {
    const day = (m.at || '').slice(0, 10);
    if (day !== lastDay) {
      lastDay = day;
      msgsBox.appendChild(el('div', { class: 'chat-day', text: fmtDay(m.at) }));
    }
    const mine = m.by === state.user.id;
    const u = userById(m.by);
    const isImg = m.file && /\.(png|jpe?g|gif|webp)(\?|$)/i.test(m.file.url || '');
    const dmReadAt = state.dmRead && state.dmRead[curRoom];
    msgsBox.appendChild(el('div', { class: 'chat-msg' + (mine ? ' mine' : '') }, [
      !mine ? el('div', { class: 'chat-av', html: u ? avatarHTML(u, 'sm') : '', title: m.byName }) : null,
      el('div', { class: 'chat-bub' }, [
        !mine ? el('div', { class: 'chat-who', text: m.byName }) : null,
        m.reply ? el('div', { class: 'chat-quote', html: `<b>↩ ${escapeHTML(m.reply.name || '')}</b><br>${escapeHTML(m.reply.snippet || '')}` }) : null,
        m.text ? el('div', { class: 'chat-txt', text: m.text }) : null,
        m.file ? (isImg
          ? el('a', { href: m.file.url, target: '_blank', rel: 'noopener' }, [el('img', { class: 'chat-file-img', src: m.file.url, alt: m.file.name })])
          : el('a', { class: 'btn ghost sm', style: { marginTop: '4px' }, html: '📎<span>' + escapeHTML(m.file.name) + '</span>', href: m.file.url, target: '_blank', rel: 'noopener' })) : null,
        el('div', { class: 'chat-time num', text: fmtTime(m.at) + (m.edited ? ' · عُدّلت' : '') + (mine && curRoom.startsWith('dm:') && dmReadAt && (m.at || '') <= dmReadAt ? ' · ✓✓' : '') }),
      ]),
      el('div', { class: 'chat-acts' }, [
        el('button', { title: 'رد', text: '↩', onclick: () => { replyTo = { id: m.id, name: m.byName, snippet: (m.text || (m.file ? '📎 ' + m.file.name : '')).slice(0, 140) }; renderChat(host); } }),
        mine ? el('button', { title: 'تعديل', text: '✎', onclick: () => {
          const inp = el('input', { class: 'input' }); inp.value = m.text || '';
          const mm = modal({
            title: 'تعديل الرسالة',
            body: [inp],
            footer: [
              el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => mm.close() }),
              el('button', { class: 'btn primary', text: 'حفظ', onclick: async () => {
                const v = inp.value.trim();
                if (!v) { toast('رسالة فاضية', 'err'); return; }
                try { await api.chatEdit(curRoom, m.id, v); mm.close(); } catch (e) { toast(e.message, 'err'); }
              } }),
            ],
          });
        } }) : null,
        mine ? el('button', { title: 'حذف', text: '🗑', onclick: async () => {
          if (!await confirmDialog('حذف الرسالة دي؟', { danger: true })) return;
          try { await api.chatDelete(curRoom, m.id); } catch (e) { toast(e.message, 'err'); }
        } }) : null,
      ]),
    ]));
  });
  if (!msgs.length) msgsBox.appendChild(el('div', { class: 'empty', style: { padding: '40px' }, text: q ? 'مفيش نتائج للبحث' : 'ابدأ المحادثة 👋' }));

  /* ---- typing indicator ---- */
  const typingRow = el('div', { class: 'chat-typing' });
  const drawTyping = () => {
    const ty = state.typing && state.typing[curRoom];
    typingRow.textContent = ty && Date.now() - ty.at < 2500 ? (ty.name + ' بيكتب…') : '';
  };
  drawTyping();
  if (typingIv) clearInterval(typingIv);
  typingIv = setInterval(drawTyping, 900);

  /* ---- الإدخال ---- */
  const input = el('input', { class: 'input chat-input', placeholder: 'اكتب رسالة…', value: drafts[curRoom] || '' });
  let lastTyp = 0;
  input.oninput = () => {
    drafts[curRoom] = input.value;
    /* V3-2 typing للمكتب + V4-5 typing للشات */
    if (input.value && Date.now() - lastTyp > 900) {
      lastTyp = Date.now();
      socket.send({ type: 'ctyping', room: curRoom });
      if (curRoom.startsWith('dm:')) {
        const other = curRoom.split(':').slice(1).find((id) => id !== state.user.id);
        if (other) socket.send({ type: 'otyping', to: other });
      }
    }
  };
  const send = async () => {
    const text = input.value.trim();
    if (!text) return;
    input.value = '';
    drafts[curRoom] = '';
    const extra = replyTo ? { reply: replyTo } : null;
    replyTo = null;
    try {
      await api.chatSend(curRoom, text, extra);
      renderChat(host);
    } catch (e) { toast('مبعتتش: ' + e.message, 'err'); input.value = text; drafts[curRoom] = text; }
  };
  input.onkeydown = (e) => { if (e.key === 'Enter') send(); };

  /* ---- رد جاري ---- */
  const replyBar = replyTo ? el('div', { class: 'chat-reply-bar' }, [
    el('span', { class: 'grow', text: '↩ رد على ' + replyTo.name + ': ' + replyTo.snippet.slice(0, 60) }),
    el('button', { class: 'btn ghost sm', text: '✕', onclick: () => { replyTo = null; renderChat(host); } }),
  ]) : null;

  /* ---- ملفات ---- */
  const fileIn = el('input', {
    type: 'file', style: { display: 'none' },
    onchange: async (e) => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      try {
        toast('جاري الرفع…', 'ok');
        const up = await api.uploadFile(f.name, f);
        await api.chatSend(curRoom, '', { file: { name: f.name, url: up.url } });
        renderChat(host);
      } catch (er) { toast('مرفعتش: ' + er.message, 'err'); }
      fileIn.value = '';
    },
  });

  /* ---- إيموجي ---- */
  const emojiPop = el('div', { class: 'chat-emoji-pop' });
  emojiPop.style.display = emojiOpen ? 'grid' : 'none';
  EMOJIS.forEach((em) => emojiPop.appendChild(el('button', { text: em, onclick: () => { input.value += em; drafts[curRoom] = input.value; emojiOpen = false; renderChat(host); input.focus(); } })));

  /* ---- بحث فوري ---- */
  const searchIn = el('input', { class: 'input', placeholder: '🔍 ابحث في الغرفة…', value: searchQ, style: { marginBottom: '8px' } });
  searchIn.addEventListener('input', () => { searchQ = searchIn.value; renderChat(host); });

  const pane = el('div', { class: 'chat-pane' }, [
    searchIn,
    msgsBox,
    typingRow,
    el('div', { class: 'chat-compose' }, [
      replyBar,
      emojiPop,
      el('div', { class: 'row', style: { gap: '6px' } }, [
        el('button', { class: 'btn ghost icon', title: 'إيموجي', text: '😀', onclick: () => { emojiOpen = !emojiOpen; renderChat(host); } }),
        el('button', { class: 'btn ghost icon', title: 'إرفاق ملف', html: '📎', onclick: () => fileIn.click() }),
        input,
        el('button', { class: 'btn primary', html: icon('send') + `<span>إرسال</span>`, onclick: send }),
      ]),
      fileIn,
    ]),
  ]);

  host.appendChild(el('div', { class: 'chat-wrap' }, [list, pane]));
  requestAnimationFrame(() => { msgsBox.scrollTop = msgsBox.scrollHeight; });
}
