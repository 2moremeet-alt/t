/* ============================================================
   MEEM | Creative Office — Phase 3: الطلبات (استقبال + إسناد + تحويل لمشروع)
   ============================================================ */
import { t, getLang } from '../i18n.js';
import { state, save, userById, clientById } from '../store.js';
import { el, icon, clear, avatarHTML, timeAgo, escapeHTML, toast, modal } from '../ui.js';
import { openTaskModal } from '../taskform.js';

const RSTATUS = { new: ['جديد', 'info'], assigned: ['تم الإسناد', 'warn'], converted: ['تحول لمشروع', 'ok'], rejected: ['مرفوض', 'danger'], closed: ['مغلق', ''] };
const CHANNELS = [['whatsapp', 'واتساب'], ['email', 'بريد'], ['phone', 'مكالمة'], ['walkin', 'حضوري'], ['web', 'الموقع'], ['portal', 'بوابة العميل']];

export function renderRequests(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  const list = state.requests || [];

  host.append(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('bell') + ' الطلبات', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'كل طلب وارد من عميل: سنده لمسؤول، حوّله لمشروع، أو اقفلوه' }),
    ]),
    el('button', { class: 'btn primary', html: icon('plus') + `<span>طلب جديد</span>`, onclick: () => openRequestModal(null, refresh) }),
  ]));

  const counts = Object.keys(RSTATUS).map((k) => ({ k, n: list.filter((r) => r.status === k).length }));
  host.appendChild(el('div', { class: 'kpis' }, counts.map((c) => el('div', { class: 'kpi' }, [
    el('div', { class: 'k-label', text: RSTATUS[c.k][0] }),
    el('div', { class: 'k-value num', text: String(c.n), style: { color: `var(--${RSTATUS[c.k][1] || 'text-2'})` } }),
  ]))));

  const grid = el('div', { class: 'col', style: { gap: '10px' } });
  if (!list.length) grid.appendChild(el('div', { class: 'empty card', style: { padding: '40px' }, text: 'لا طلبات — سجّل أول طلب وارد' }));
  [...list].sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || '')).forEach((r) => {
    const client = clientById(r.clientId);
    const asg = userById(r.assignee);
    const [lb, cl] = RSTATUS[r.status] || ['', ''];
    grid.appendChild(el('div', { class: 'card', style: { padding: '14px 16px' } }, [
      el('div', { class: 'between wrap', style: { gap: '8px', marginBottom: '6px' } }, [
        el('div', { class: 'row', style: { gap: '10px' } }, [
          el('div', { style: { width: '38px', height: '38px', borderRadius: '10px', background: 'var(--brand-soft)', color: 'var(--brand)', display: 'grid', placeItems: 'center' }, html: icon((CHANNELS.find((c) => c[0] === r.channel) || ['bell'])[0] === 'whatsapp' ? 'whatsapp' : 'bell') }),
          el('div', {}, [
            el('div', { style: { fontWeight: '800', fontSize: '14.5px' }, text: r.title }),
            el('div', { class: 'dim', style: { fontSize: '12px' }, text: `${client ? client.name : (r.contact ? r.contact.name : '—')} · ${(CHANNELS.find((c) => c[0] === r.channel) || ['', r.channel || ''])[1]} · ${timeAgo(r.createdAt)}` }),
            r.contact ? el('div', { class: 'dim', style: { fontSize: '11.5px' }, text: (r.channel === 'portal' ? '🏢 من البوابة: ' : '🌐 من الموقع: ') + r.contact.email + (r.contact.phone ? ' · ' + r.contact.phone : '') }) : null,
            r.form ? el('div', { class: 'row wrap', style: { gap: '4px', marginTop: '4px' } }, Object.entries(r.form).filter(([k]) => !['name', 'email', 'phone', 'company', 'details'].includes(k) && r.form[k]).map(([k, v]) => el('span', { class: 'badge', style: { fontSize: '10px' }, text: k + ': ' + String(v).slice(0, 40) }))) : null,
          ]),
        ]),
        el('div', { class: 'row', style: { gap: '6px' } }, [
          el('span', { class: 'badge ' + cl, text: lb }),
          el('span', { class: 'badge ' + ({ high: 'warn', urgent: 'danger', medium: 'info', low: '' }[r.priority] || ''), text: r.priority || '' }),
        ]),
      ]),
      r.notes ? el('div', { class: 'dim', style: { fontSize: '13px', margin: '4px 0 10px', lineHeight: 1.7 }, text: r.notes }) : null,
      r.status === 'rejected' && r.rejectReason ? el('div', { class: 'badge danger', style: { marginBottom: '8px' }, text: 'سبب الرفض: ' + r.rejectReason }) : null,
      el('div', { class: 'row wrap', style: { gap: '7px' } }, [
        asg ? el('span', { class: 'badge', html: avatarHTML(asg, 'sm') + `<span>${escapeHTML(asg.name)}</span>` }) : null,
        el('div', { class: 'grow' }),
        r.status !== 'converted' && r.status !== 'closed' ? el('button', {
          class: 'btn sm', html: icon('users') + `<span>إسناد</span>`,
          onclick: async () => {
            const opts = (state.users || []).filter((u) => u.role !== 'client');
            const sel = el('select', { class: 'select', html: opts.map((u) => `<option value="${u.id}">${escapeHTML(u.name)}</option>`).join('') });
            const m = modal({
              title: 'إسناد الطلب',
              body: [sel],
              footer: [
                el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
                el('button', { class: 'btn primary', text: 'إسناد', onclick: async () => { r.assignee = sel.value; r.status = 'assigned'; await save('requests', r); m.close(); toast('تم الإسناد ✓', 'ok'); refresh(); } }),
              ],
            });
          },
        }) : null,
        r.status !== 'converted' ? el('button', {
          class: 'btn sm primary', html: icon('kanban') + `<span>تحويل لمشروع</span>`,
          onclick: async () => {
            /* V2-13: طلب من الموقع من غير عميل مسجل — نطابق بالإيميل أو ننشئ عميل */
            let cid = r.clientId;
            if (!cid && r.contact && r.contact.email) {
              const existing = (state.clients || []).find((c) => (c.email || '').toLowerCase() === r.contact.email.toLowerCase());
              if (existing) cid = existing.id;
              else {
                const nc = await save('clients', { name: r.contact.company || r.contact.name, nameEn: '', email: r.contact.email, phone: r.contact.phone || '', type: 'lead', notes: 'من طلب الموقع' });
                cid = nc.id;
              }
              r.clientId = cid;
            }
            const prj = await save('projects', {
              title: r.title, clientId: cid, status: 'progress',
              priority: r.priority || 'medium', due: '', budget: 0, tags: ['من طلب'],
              fromRequest: r.id,
            });
            await save('tasks', {
              dept: 'design', type: 'سوشيال', title: r.title, desc: r.notes || '',
              assignee: r.assignee || state.user.id, status: 'new', priority: r.priority || 'medium',
              due: new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10), projectId: prj.id, comments: [], files: [],
            });
            r.status = 'converted'; r.projectId = prj.id;
            await save('requests', r);
            toast('اتحوّل لمشروع ومهمة ✓', 'ok', 3200);
            location.hash = '#/projects/' + prj.id;
          },
        }) : null,
        r.projectId ? el('button', { class: 'btn sm ghost', text: 'فتح المشروع', onclick: () => { location.hash = '#/projects/' + r.projectId; } }) : null,
        r.status === 'new' || r.status === 'assigned' ? el('button', {
          class: 'btn sm ghost', text: 'رفض',
          onclick: () => {
            const ta = el('textarea', { class: 'textarea', placeholder: 'سبب الرفض (يظهر للعميل في البوابة)…' });
            const m = modal({
              title: 'رفض الطلب',
              body: [ta],
              footer: [
                el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
                el('button', { class: 'btn danger', text: 'تأكيد الرفض', onclick: async () => {
                  if (!ta.value.trim()) { toast('اكتب سبب الرفض', 'err'); return; }
                  r.status = 'rejected'; r.rejectReason = ta.value.trim().slice(0, 300);
                  await save('requests', r); m.close(); toast('اترفض الطلب', 'ok'); refresh();
                } }),
              ],
            });
          },
        }) : null,
        r.status === 'new' || r.status === 'assigned' ? el('button', {
          class: 'btn sm ghost', text: 'إغلاق',
          onclick: async () => { r.status = 'closed'; await save('requests', r); refresh(); },
        }) : null,
      ]),
    ]));
  });
  host.appendChild(grid);

  function refresh() { renderRequests(host); }
}

export function openRequestModal(r, onDone) {
  const doc = Object.assign({ title: '', clientId: (state.clients[0] || {}).id || '', channel: 'whatsapp', notes: '', priority: 'medium', status: 'new', assignee: '' }, r || {});
  const m = modal({
    title: 'طلب جديد',
    size: 'wide',
    body: [
      el('div', { class: 'field' }, [el('label', { text: 'عنوان الطلب *' }), el('input', { class: 'input', value: doc.title, oninput: (e) => doc.title = e.target.value })]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: t('client') }), el('select', { class: 'select', html: (state.clients || []).map((c) => `<option value="${c.id}" ${c.id === doc.clientId ? 'selected' : ''}>${escapeHTML(c.name)}</option>`).join(''), onchange: (e) => doc.clientId = e.target.value })]),
        el('div', { class: 'field' }, [el('label', { text: 'القناة' }), el('select', { class: 'select', html: CHANNELS.map(([k, v]) => `<option value="${k}" ${k === doc.channel ? 'selected' : ''}>${v}</option>`).join(''), onchange: (e) => doc.channel = e.target.value })]),
      ]),
      el('div', { class: 'field' }, [el('label', { text: 'الأولوية' }), el('select', { class: 'select', html: ['low', 'medium', 'high', 'urgent'].map((k) => `<option value="${k}" ${k === doc.priority ? 'selected' : ''}>${k}</option>`).join(''), onchange: (e) => doc.priority = e.target.value })]),
      (() => { const ta = el('textarea', { class: 'textarea', oninput: (e) => doc.notes = e.target.value }); ta.value = doc.notes || ''; return el('div', { class: 'field' }, [el('label', { text: 'تفاصيل الطلب' }), ta]); })(),
    ],
    footer: [
      el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: t('save'),
        onclick: async () => {
          if (!doc.title.trim()) { toast(t('required'), 'warn'); return; }
          await save('requests', doc);
          m.close(); toast('سُجّل الطلب ✓', 'ok'); onDone && onDone();
        },
      }),
    ],
  });
}
