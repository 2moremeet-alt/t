/* ============================================================
   MEE M — V4-1: المقر ثلاثي الأبعاد (3D Creative Headquarters)
   مشهد WebGL حقيقي (three.js vendor محلي) مبني من نفس تخطيط المكتب
   الحي (بنّاء V3-3) — غرف بلافتات، جدران بتصادم، أفاتار بفيزياء،
   تحكم WASD/أسهم + جويستيك لمس يظهر فقط أثناء اللمس، كاميرا متابعة
   (drag دوران + wheel زووم)، مزامنة لحظية عبر نفس بروتوكول pos.
   ============================================================ */
import { state, userById, subscribe, save } from './store.js';
import { el, toast, modal, avatarHTML } from './ui.js';
import { getLang } from './i18n.js';
import { openDM, dmKey } from './views/chat.js';
import { api } from './api.js';
import { office3dBridge } from './views/office.js';

/* أبعاد العالم ثلاثي الأبعاد (وحدات) — نفس نسبة خريطة 2D (2400×1700) */
const WX = 96, WZ = 68;
const U = WX / 2400; /* px عالم 2D → وحدة 3D */
const PLAYER_R = 0.55;

/* إحداثيات ٪ ↔ وحدات العالم */
const toX = (px) => (px / 100) * WX - WX / 2;
const toZ = (py) => (py / 100) * WZ - WZ / 2;
const toPctX = (x) => ((x + WX / 2) / WX) * 100;

/* V4-7: Pool للهندسات والخامات — مشاركة بين كل الأجسام (ذاكرة أقل + بناء أسرع) */
const GEOC = new Map(), MATC = new Map();
function poolGeo(key, make) { let g = GEOC.get(key); if (!g) { g = make(); g.userData.cached = 1; GEOC.set(key, g); } return g; }
function poolMat(key, make) { let m = MATC.get(key); if (!m) { m = make(); m.userData.cached = 1; MATC.set(key, m); } return m; }
const geoBox = (w, h, d) => poolGeo('b' + w + '|' + h + '|' + d, () => new THREE.BoxGeometry(w, h, d));
const geoPlane = (w, d) => poolGeo('p' + w + '|' + d, () => new THREE.PlaneGeometry(w, d));
const geoCyl = (rt, rb, h, seg, open) => poolGeo('c' + rt + '|' + rb + '|' + h + '|' + seg + '|' + (open ? 1 : 0), () => new THREE.CylinderGeometry(rt, rb, h, seg, 1, !!open));
const geoSphere = (r, ws, hs, a, b, c2, d2) => poolGeo('s' + r + '|' + ws + '|' + hs + '|' + a + '|' + b + '|' + c2 + '|' + d2, () => new THREE.SphereGeometry(r, ws, hs, a, b, c2, d2));
const geoCone = (r, h, seg) => poolGeo('n' + r + '|' + h + '|' + seg, () => new THREE.ConeGeometry(r, h, seg));
const geoCapsule = (r, l, cs, rs) => poolGeo('k' + r + '|' + l + '|' + cs + '|' + rs, () => new THREE.CapsuleGeometry(r, l, cs, rs));
const matLamb = (c, opts) => poolMat('L' + c + '|' + (opts ? JSON.stringify(opts) : ''), () => new THREE.MeshLambertMaterial(Object.assign({ color: new THREE.Color(c) }, opts || {})));
const toPctZ = (z) => ((z + WZ / 2) / WZ) * 100;

const STATUSES = [
  { id: 'available', ar: 'متاح', en: 'Available', ic: '🟢' },
  { id: 'busy', ar: 'مشغول', en: 'Busy', ic: '🔴' },
  { id: 'meeting', ar: 'في اجتماع', en: 'In Meeting', ic: '🟡' },
];
const STATUS_COLOR = { available: '#22c55e', busy: '#ef4444', meeting: '#f59e0b' };
let prjLabGlobal = null; /* V4-4: مرجع لافتة المشاريع لخطاف الاختبار */
const DEPT_OF_ROLE = { designer: 'design', content: 'content', voice: 'voice', dev: 'dev', cs: 'cs', admin: 'management', superadmin: 'management', editor: 'content' };

function loadThree() {
  return new Promise((res) => {
    if (window.THREE) return res(window.THREE);
    const s = document.createElement('script');
    s.src = 'js/vendor/three.min.js';
    s.onload = () => res(window.THREE);
    s.onerror = () => res(null);
    document.head.appendChild(s);
  });
}

/* ---------------- لافتة نصية (Sprite) ---------------- */
function makeLabel(THREE, text, sub, color) {
  const cv = document.createElement('canvas');
  cv.width = 512; cv.height = 160;
  const g = cv.getContext('2d');
  g.fillStyle = 'rgba(10,14,24,0.82)';
  const rr = 34;
  g.beginPath();
  g.moveTo(rr, 8); g.arcTo(504, 8, 504, 152, rr); g.arcTo(504, 152, 8, 152, rr); g.arcTo(8, 152, 8, 8, rr); g.arcTo(8, 8, 504, 8, rr); g.closePath(); g.fill();
  g.strokeStyle = color || '#3d8bff'; g.lineWidth = 6; g.stroke();
  g.fillStyle = '#fff';
  g.font = 'bold 64px "Segoe UI", Tahoma, sans-serif';
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, 256, sub ? 62 : 80);
  if (sub) { g.fillStyle = '#9fb2d8'; g.font = '34px "Segoe UI", Tahoma, sans-serif'; g.fillText(sub, 256, 118); }
  const tex = new THREE.CanvasTexture(cv);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
  spr.scale.set(9, 2.8, 1);
  spr.renderOrder = 10;
  return spr;
}

function makeNameTag(THREE, text, color) {
  const cv = document.createElement('canvas');
  cv.width = 256; cv.height = 64;
  const g = cv.getContext('2d');
  g.fillStyle = 'rgba(10,14,24,0.75)';
  g.beginPath(); g.roundRect ? g.roundRect(4, 8, 248, 48, 20) : g.rect(4, 8, 248, 48); g.fill();
  g.fillStyle = color || '#7dd8ff';
  g.beginPath(); g.arc(30, 32, 10, 0, Math.PI * 2); g.fill();
  g.fillStyle = '#fff'; g.font = 'bold 30px "Segoe UI", Tahoma, sans-serif';
  g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, 148, 33);
  const tex = new THREE.CanvasTexture(cv);
  const spr = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false }));
  spr.scale.set(4.6, 1.15, 1);
  spr.renderOrder = 11;
  return spr;
}

/* ---------------- أفاتار بالمظهر الكامل (V4-2) ---------------- */
function makeAvatar(THREE, user) {
  const grp = new THREE.Group();
  const look = (user && user.avatar) || {};
  const skin = look.skin || '#ffd9b3';
  const outfitC = look.outfitColor || (user && user.avatarColor) || '#3d8bff';
  const hairC = look.hairColor || '#1b1b1b';
  const fem = look.gender === 'f';
  const lamb = (c) => matLamb(c); /* V4-7 pooled */

  /* الجسم حسب الملبس */
  let body;
  if (look.outfit === 'dress') {
    body = new THREE.Mesh(geoCone(0.52, 1.05, 14), lamb(outfitC));
    body.position.y = 0.92;
  } else {
    body = new THREE.Mesh(
      new THREE.CapsuleGeometry ? geoCapsule(fem ? 0.34 : 0.38, fem ? 0.68 : 0.75, 6, 12) : geoCyl(0.38, 0.38, 1.1, 12),
      lamb(outfitC),
    );
    body.position.y = 0.95;
    if (look.outfit === 'hoodie') {
      const hood = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.09, 8, 16), lamb(outfitC));
      hood.rotation.x = Math.PI / 2;
      hood.position.y = 1.55;
      grp.add(hood);
    } else if (look.outfit === 'suit') {
      const tie = new THREE.Mesh(geoBox(0.1, 0.5, 0.05), lamb('#f5f7fb'));
      tie.position.set(0, 1.15, 0.36);
      grp.add(tie);
    }
  }
  const head = new THREE.Mesh(geoSphere(fem ? 0.28 : 0.3, 14, 12), lamb(skin));
  head.position.y = 1.85;
  grp.add(body, head);

  /* الشعر */
  const hy = 1.85;
  if (look.hair === 'short' || look.hair === 'buzz') {
    const h = new THREE.Mesh(geoSphere(0.31, 14, 10, 0, Math.PI * 2, 0, Math.PI / 2), lamb(hairC));
    h.position.y = hy + (look.hair === 'buzz' ? 0.02 : 0.05);
    h.scale.y = look.hair === 'buzz' ? 0.6 : 0.9;
    grp.add(h);
  } else if (look.hair === 'long') {
    const h = new THREE.Mesh(geoSphere(0.32, 14, 10, 0, Math.PI * 2, 0, Math.PI / 2), lamb(hairC));
    h.position.y = hy + 0.05;
    const back = new THREE.Mesh(geoBox(0.5, 0.7, 0.16), lamb(hairC));
    back.position.set(0, hy - 0.15, -0.24);
    grp.add(h, back);
  } else if (look.hair === 'bun') {
    const h = new THREE.Mesh(geoSphere(0.31, 14, 10, 0, Math.PI * 2, 0, Math.PI / 2), lamb(hairC));
    h.position.y = hy + 0.05;
    const bun = new THREE.Mesh(new THREE.SphereGeometry(0.13, 10, 8), lamb(hairC));
    bun.position.y = hy + 0.38;
    grp.add(h, bun);
  } else if (look.hair === 'curly') {
    [[0, 0.3, 0], [-0.2, 0.22, 0.1], [0.2, 0.22, 0.1], [-0.15, 0.25, -0.15], [0.15, 0.25, -0.15]].forEach(([x, y, z]) => {
      const s = new THREE.Mesh(geoSphere(0.13, 8, 8), lamb(hairC));
      s.position.set(x, hy + y, z);
      grp.add(s);
    });
  }

  /* الإكسسوار */
  if (look.accessory === 'glasses') {
    const g = new THREE.Mesh(geoBox(0.44, 0.09, 0.06), lamb('#111111'));
    g.position.set(0, hy, 0.27);
    grp.add(g);
  } else if (look.accessory === 'cap') {
    const c1 = new THREE.Mesh(geoSphere(0.32, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), lamb('#b33939'));
    c1.position.y = hy + 0.06;
    const brim = new THREE.Mesh(geoBox(0.3, 0.04, 0.24), lamb('#b33939'));
    brim.position.set(0, hy + 0.08, 0.34);
    grp.add(c1, brim);
  } else if (look.accessory === 'headset') {
    const band = new THREE.Mesh(new THREE.TorusGeometry(0.31, 0.035, 8, 20), lamb('#222222'));
    band.position.y = hy + 0.05;
    const earL = new THREE.Mesh(geoBox(0.07, 0.16, 0.12), lamb('#222222'));
    earL.position.set(-0.3, hy, 0);
    const earR = earL.clone();
    earR.position.x = 0.3;
    const mic = new THREE.Mesh(geoBox(0.04, 0.04, 0.2), lamb('#222222'));
    mic.position.set(0.22, hy - 0.14, 0.22);
    grp.add(band, earL, earR, mic);
  }
  return grp;
}

/* ============================ المشهد ============================ */
export async function mountOffice3D(host) {
  const THREE = await loadThree();
  if (!THREE) { /* لا WebGL/مكتبة → رجوع آمن لـ 2D */ try { localStorage.setItem('meem_view3d', '0'); } catch (e) {} location.reload(); return; }
  if (!host.isConnected) return;

  const br = office3dBridge();
  const isClient = state.user.role === 'client';
  let curFloor = isClient ? 1 : br.floor();
  const rooms = () => br.rooms().filter((r) => (r.floor || 1) === curFloor);
  const booths = () => br.booths(curFloor);

  /* موضع محفوظ لكل طابق */
  let my = br.myPos(curFloor) || spawnDefault();
  function spawnDefault() {
    const dept = br.rooms().find((r) => r.id === DEPT_OF_ROLE[state.user.role]);
    if (dept) return { x: dept.x + dept.w / 2, y: dept.y + dept.h / 2 };
    return isClient ? { x: 83, y: 40 } : { x: 50, y: 92 };
  }
  let px = toX(my.x), pz = toZ(my.y);

  /* ---- DOM ---- */
  host.innerHTML = '';
  host.classList.add('office-scope');
  const wrap = el('div', { class: 'of3d-wrap' });
  host.appendChild(wrap);

  const hud = el('div', { class: 'of3d-hud' }, [
    el('button', {
      class: 'of3d-btn', text: '2D', title: getLang() === 'ar' ? 'العرض ثنائي الأبعاد' : '2D view',
      onclick: () => { localStorage.setItem('meem_view3d', '0'); renderOffice2D(host); },
    }),
    el('div', { class: 'of3d-floors' }, [1, 2].filter((f) => !isClient || f === 1).map((f) => el('button', {
      class: 'of3d-btn fl' + (f === curFloor ? ' on' : ''), text: f === 1 ? '١' : '٢',
      onclick: () => { if (f !== curFloor) { br.savePos(curFloor, { x: toPctX(px), y: toPctZ(pz) }); curFloor = f; br.setFloor(f); const p = br.myPos(f) || spawnDefault(); my = p; px = toX(p.x); pz = toZ(p.y); rebuild(); } },
    }))),
    el('div', { class: 'of3d-status' }, STATUSES.map((st) => el('button', {
      class: 'of3d-btn st' + (st.id === br.status() ? ' on' : ''), style: { '--sc': STATUS_COLOR[st.id] },
      text: st.ic + ' ' + (getLang() === 'ar' ? st.ar : st.en),
      onclick: () => { br.setStatus(st.id); try { localStorage.setItem('office_status', st.id); } catch (e) {} br.sendStatus(st.id); sendPosNow(); rebuildHudStates(); },
    }))),
    el('div', { class: 'of3d-live' }),
    el('div', { class: 'of3d-fps', style: { opacity: '.55', fontSize: '11px' } }),
  ]);
  const prompt = el('div', { class: 'of3d-prompt', hidden: true });
  wrap.append(hud, prompt);

  function rebuildHudStates() {
    hud.querySelectorAll('.of3d-btn.st').forEach((b, i) => b.classList.toggle('on', STATUSES[i].id === br.status()));
  }

  /* ---- three.js أساسيات ---- */
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.domElement.className = 'of3d-canvas';
  wrap.appendChild(renderer.domElement);
  /* V4-6: ثيمات المكتب من إعدادات الهوية */
  const THEMES3D = {
    default: { bg: 0x0b0f1a, ground: 0x141a2a, wall: 0x232c44 },
    neon: { bg: 0x0d0221, ground: 0x1a0940, wall: 0x3d1d8f },
    warm: { bg: 0x1a120b, ground: 0x2a1d10, wall: 0x44301c },
    dark: { bg: 0x05070a, ground: 0x0a0d12, wall: 0x151b26 },
  };
  const bTheme = (((state.settings || []).find((x) => x.id === 'brand') || {}).officeTheme) || 'default';
  const TH = THEMES3D[bTheme] || THEMES3D.default;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(TH.bg);
  scene.fog = new THREE.Fog(TH.bg, 70, 160);
  const camera = new THREE.PerspectiveCamera(55, 1, 0.1, 300);

  const hemi = new THREE.HemisphereLight(0xdfe9ff, 0x1a2233, 0.95);
  const dir = new THREE.DirectionalLight(0xffffff, 0.75);
  dir.position.set(30, 60, 20);
  scene.add(hemi, dir);

  /* ---- عالم قابل لإعادة البناء لكل طابق ---- */
  let world = null; /* Group */
  let colliders = []; /* AABB list */
  let roomMeshes = [];
  let labelSprites = [];
  let roomOfMesh = new Map();

  function disposeWorld() {
    if (!world) return;
    world.traverse((o) => {
      if (o.geometry && !o.geometry.userData.cached) o.geometry.dispose(); /* V4-7: pooled stays */
      if (o.material) { if (o.material.map) o.material.map.dispose(); if (!o.material.userData.cached) o.material.dispose(); }
    });
    scene.remove(world);
    world = null; colliders = []; roomMeshes = []; labelSprites = []; roomOfMesh = new Map();
  }

  function addBox(parent, w, h, d, x, y, z, color, collide) {
    const m = new THREE.Mesh(geoBox(w, h, d), matLamb(color));
    m.position.set(x, y, z);
    parent.add(m);
    if (collide) colliders.push({ x0: x - w / 2, x1: x + w / 2, z0: z - d / 2, z1: z + d / 2 });
    return m;
  }

  function wall(parent, x0, z0, x1, z1, gapFrac, color) {
    /* جدار من (x0,z0) إلى (x1,z1) بفتحة باب في المنتصف */
    const H = 2.4, T = 0.35;
    const dx = x1 - x0, dz = z1 - z0;
    const len = Math.hypot(dx, dz);
    const gap = len * (gapFrac || 0.22);
    const ux = dx / len, uz = dz / len;
    const seg = (t0, t1) => {
      const cx = x0 + ux * ((t0 + t1) / 2), cz = z0 + uz * ((t0 + t1) / 2);
      const l = t1 - t0;
      if (l <= 0.05) return;
      if (Math.abs(dx) >= Math.abs(dz)) addBox(parent, l, H, T, cx, H / 2, cz, color, true);
      else addBox(parent, T, H, l, cx, H / 2, cz, color, true);
    };
    seg(0, (len - gap) / 2);
    seg((len + gap) / 2, len);
  }

  function buildWorld() {
    disposeWorld();
    world = new THREE.Group();
    scene.add(world);

    /* أرضية عامة */
    const ground = new THREE.Mesh(geoPlane(WX + 8, WZ + 8), matLamb(TH.ground));
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.02;
    world.add(ground);

    /* سور المحيط */
    const C = TH.wall;
    wall(world, -WX / 2, -WZ / 2, WX / 2, -WZ / 2, 0, C);
    wall(world, WX / 2, -WZ / 2, WX / 2, WZ / 2, 0, C);
    wall(world, WX / 2, WZ / 2, -WX / 2, WZ / 2, 0, C);
    wall(world, -WX / 2, WZ / 2, -WX / 2, -WZ / 2, 0, C);

    const cx = toX(50), cz = toZ(50);
    let recCx = 0, recCz = 0; /* V4-4 */
    rooms().forEach((r) => {
      const rx0 = toX(r.x), rz0 = toZ(r.y), rx1 = toX(r.x + r.w), rz1 = toZ(r.y + r.h);
      const rcx = (rx0 + rx1) / 2, rcz = (rz0 + rz1) / 2;
      /* أرضية الغرفة */
      const fl = new THREE.Mesh(geoPlane(rx1 - rx0, rz1 - rz0), matLamb('#' + new THREE.Color(r.color || '#3d8bff').multiplyScalar(0.28).getHexString()));
      fl.rotation.x = -Math.PI / 2;
      fl.position.set(rcx, 0.02, rcz);
      fl.userData.room = r.id;
      world.add(fl);
      roomMeshes.push(fl);
      roomOfMesh.set(fl, r);
      /* حدود شفافة */
      const edge = new THREE.Mesh(geoPlane(rx1 - rx0, rz1 - rz0), poolMat('edge' + (r.color || '#3d8bff'), () => new THREE.MeshBasicMaterial({ color: r.color || '#3d8bff', transparent: true, opacity: 0.1, depthWrite: false })));
      edge.rotation.x = -Math.PI / 2;
      edge.position.set(rcx, 0.04, rcz);
      world.add(edge);
      /* جدران بفتحة باب في الضلع الأقرب لمركز العالم */
      const sides = [
        { ax: rx0, az: rz0, bx: rx1, bz: rz0, d: Math.abs(rz0 - cz) },
        { ax: rx0, az: rz1, bx: rx1, bz: rz1, d: Math.abs(rz1 - cz) },
        { ax: rx0, az: rz0, bx: rx0, bz: rz1, d: Math.abs(rx0 - cx) },
        { ax: rx1, az: rz0, bx: rx1, bz: rz1, d: Math.abs(rx1 - cx) },
      ].sort((a, b) => a.d - b.d);
      const wallCol = new THREE.Color(r.color || '#3d8bff').multiplyScalar(0.55).getHex();
      sides.forEach((s, i) => wall(world, s.ax, s.az, s.bx, s.bz, i === 0 ? 0.24 : 0, wallCol));
      /* لافتة */
      const lab = makeLabel(THREE, getLang() === 'ar' ? r.ar : r.en, (getLang() === 'ar' ? r.en : r.ar) || '', r.color);
      lab.position.set(rcx, 3.6, rcz);
      lab.userData.room = r.id;
      world.add(lab);
      labelSprites.push(lab);
      roomOfMesh.set(lab, r);
      if (r.id === 'reception') { recCx = rcx; recCz = rcz; } /* V4-4 */
    });

    /* V4-4: لوحة المشاريع — لافتة تفاعلية في الريسبشن تفتح وحدة المشاريع */
    const prjLab = makeLabel(THREE, getLang() === 'ar' ? 'المشاريع' : 'Projects', getLang() === 'ar' ? 'Projects' : 'المشاريع', '#f59e0b');
    prjLab.position.set(recCx + 9, 3.0, recCz);
    prjLab.userData.room = '__projects';
    world.add(prjLab);
    labelSprites.push(prjLab);
    prjLabGlobal = prjLab;

    /* أثاث من التخطيط الحي */
    const LAY = br.furn() || {};
    const FS = br.furnSize() || {};
    rooms().forEach((r) => {
      (LAY[r.id] || []).forEach(([type, fxp, fyp]) => {
        const sz = FS[type] || [90, 70];
        const w = sz[0] * U, d = sz[1] * U;
        const x = toX(fxp + (sz[0] / 2400) * 50), z = toZ(fyp + (sz[1] / 1700) * 50);
        if (type === 'plant' || type === 'plant2' || type === 'lamp' || type === 'cooler' || type === 'coffee') {
          const cyl = new THREE.Mesh(geoCyl(Math.min(w, d) / 2, Math.min(w, d) / 2.4, 1.3, 10), matLamb(0x2f9e57));
          cyl.position.set(x, 0.65, z);
          world.add(cyl);
          colliders.push({ x0: x - w / 2, x1: x + w / 2, z0: z - d / 2, z1: z + d / 2 });
        } else if (type === 'rug') {
          const rug = new THREE.Mesh(geoPlane(w, d), matLamb(0x5b6579));
          rug.rotation.x = -Math.PI / 2;
          rug.position.set(x, 0.05, z);
          world.add(rug); /* بلا تصادم */
        } else {
          const h = type === 'board' || type === 'tv' ? 1.9 : 0.95;
          addBox(world, w, h, d, x, h / 2, z, type === 'sofa' ? 0xd98a4b : 0x39435a, true);
        }
      });
    });

    /* بوكسات الاجتماع */
    booths().forEach((b) => {
      const bx = toX(b.x + b.w / 2), bz = toZ(b.y + b.h / 2);
      const pod = new THREE.Mesh(geoCyl(1.7, 1.7, 2.6, 14, true), poolMat('pod', () => new THREE.MeshLambertMaterial({ color: 0x2f7bff, side: THREE.DoubleSide, transparent: true, opacity: 0.4 })));
      pod.position.set(bx, 1.3, bz);
      world.add(pod);
      colliders.push({ x0: bx - 1.9, x1: bx + 1.9, z0: bz - 1.9, z1: bz + 1.9 });
      const lab = makeLabel(THREE, getLang() === 'ar' ? b.ar : b.en, '', '#2f7bff');
      lab.position.set(bx, 3.4, bz);
      lab.scale.set(6, 1.9, 1);
      world.add(lab);
    });
  }

  /* ---- الأفاتارات ---- */
  let meAv = makeAvatar(THREE, state.user);
  const meTag = makeNameTag(THREE, getLang() === 'ar' ? 'أنت' : 'You', STATUS_COLOR[br.status()] || '#22c55e');
  meTag.position.y = 2.6;
  meAv.add(meTag);
  scene.add(meAv);
  /* V4-2: إعادة بناء أفاتاري لما تتحدث الحالة (حفظ المظهر) */
  function rebuildMe() {
    scene.remove(meAv);
    const fresh = makeAvatar(THREE, state.user);
    fresh.add(meTag);
    meAv = fresh;
    scene.add(meAv);
  }

  const peerGrp = new THREE.Group();
  scene.add(peerGrp);
  const peerMeshes = new Map();
  const peerTarget = new Map();

  function paintPeers() {
    const seen = new Set();
    for (const [uid, p] of Object.entries(state.pos || {})) {
      if (uid === state.user.id) continue;
      if ((p.floor || 1) !== curFloor) continue;
      const u = userById(uid);
      if (!u) continue;
      seen.add(uid);
      let m = peerMeshes.get(uid);
      if (!m) {
        m = makeAvatar(THREE, u);
        const tag = makeNameTag(THREE, getLang() === 'ar' ? u.name : (u.nameEn || u.name), STATUS_COLOR[p.status] || '#22c55e');
        tag.position.y = 2.6;
        m.add(tag);
        m.userData.uid = uid;
        m.position.set(toX(p.x), 0, toZ(p.y));
        peerGrp.add(m);
        peerMeshes.set(uid, m);
      }
      peerTarget.set(uid, { x: toX(p.x), z: toZ(p.y) });
    }
    for (const [uid, m] of [...peerMeshes]) {
      if (!seen.has(uid)) { peerGrp.remove(m); peerMeshes.delete(uid); peerTarget.delete(uid); }
    }
  }

  /* ---- كاميرا ---- */
  let camYaw = 0, camDist = 16, camPitch = 0.62;
  function applyCam() {
    const tx = px + Math.sin(camYaw) * camDist * Math.cos(camPitch);
    const tz = pz + Math.cos(camYaw) * camDist * Math.cos(camPitch);
    const ty = Math.sin(camPitch) * camDist + 1.5;
    camera.position.lerp(new THREE.Vector3(tx, ty, tz), 0.18);
    camera.lookAt(px, 1.2, pz);
  }

  /* ---- تحكم لوحة المفاتيح ---- */
  const KEYS = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right', w: 'up', s: 'down', a: 'left', d: 'right', W: 'up', S: 'down', A: 'left', D: 'right' };
  const keys = new Set();
  const kd = (e) => {
    const tg = e.target;
    if (tg && (tg.tagName === 'INPUT' || tg.tagName === 'TEXTAREA' || tg.isContentEditable)) return;
    if (KEYS[e.key]) { keys.add(KEYS[e.key]); if (e.key.startsWith('Arrow')) e.preventDefault(); }
    if ((e.key === 'Enter' || e.key === 'e' || e.key === 'E' || e.key === 'ء') && enterTarget) enterRoom(enterTarget);
  };
  const ku = (e) => { if (KEYS[e.key]) keys.delete(KEYS[e.key]); };
  window.addEventListener('keydown', kd);
  window.addEventListener('keyup', ku);

  /* ---- لمس: جويستيك يظهر فقط أثناء اللمس + سحب لتدوير الكاميرا ---- */
  let joyVec = null;
  let joyEl = null, joyKnob = null, joyOrigin = null;
  const isTouch = ('ontouchstart' in window) || window.matchMedia('(pointer: coarse)').matches;
  let dragLast = null;

  function showJoy(cx, cy) {
    if (joyEl) return;
    joyOrigin = { x: cx, y: cy };
    joyKnob = el('div', { class: 'of3d-joy-knob' });
    joyEl = el('div', { class: 'of3d-joy' }, [joyKnob]);
    joyEl.style.left = (cx - 55) + 'px';
    joyEl.style.top = (cy - 55) + 'px';
    document.body.appendChild(joyEl);
  }
  function moveJoy(cx, cy) {
    if (!joyEl || !joyOrigin) return;
    const dx = cx - joyOrigin.x, dy = cy - joyOrigin.y;
    const d = Math.hypot(dx, dy) || 1;
    const cl = Math.min(d, 48);
    joyKnob.style.transform = `translate(${(dx / d) * cl}px, ${(dy / d) * cl}px)`;
    joyVec = { x: dx / d, y: dy / d };
  }
  function hideJoy() { if (joyEl) { joyEl.remove(); joyEl = null; joyKnob = null; joyOrigin = null; } joyVec = null; }

  renderer.domElement.addEventListener('touchstart', (e) => {
    const t = e.touches[0];
    if (t.clientY > window.innerHeight * 0.45) showJoy(t.clientX, t.clientY);
    else dragLast = { x: t.clientX, y: t.clientY };
  }, { passive: true });
  renderer.domElement.addEventListener('touchmove', (e) => {
    const t = e.touches[0];
    if (joyEl) { moveJoy(t.clientX, t.clientY); e.preventDefault(); }
    else if (dragLast) { camYaw -= (t.clientX - dragLast.x) * 0.008; dragLast = { x: t.clientX, y: t.clientY }; }
  }, { passive: false });
  const tend = () => { hideJoy(); dragLast = null; };
  renderer.domElement.addEventListener('touchend', tend);
  renderer.domElement.addEventListener('touchcancel', tend);

  /* ماوس: سحب دوران + wheel زووم + كليك على لافتة/أفاتار */
  let mDown = null;
  renderer.domElement.addEventListener('pointerdown', (e) => { if (e.pointerType === 'mouse') mDown = { x: e.clientX, y: e.clientY, moved: false }; });
  renderer.domElement.addEventListener('wheel', (e) => {
    e.preventDefault();
    camDist = Math.max(6, Math.min(40, camDist * (e.deltaY > 0 ? 1.1 : 0.9)));
  }, { passive: false });

/* ---------------- V4-5: كارت القرب + دعوة ---------------- */
const ROLE_AR = { admin: 'المدير العام', designer: 'مصمم', content: 'كاتب محتوى', voice: 'فويس أوفر', dev: 'مطور', cs: 'خدمة عملاء', editor: 'مونتير', client: 'عميل', superadmin: 'المالك' };
async function inviteToCall(u) {
  try {
    const mt = await save('meetings', {
      title: 'مكالمة سريعة — ' + state.user.name + ' و' + u.name,
      titleEn: '', room: 'quick-' + Date.now().toString(36),
      scheduledAt: new Date().toISOString(), durationMin: 30,
      attendees: [state.user.id, u.id], notes: 'دعوة من المكتب الافتراضي',
    });
    await api.chatSend(dmKey(state.user.id, u.id), '📞 دعاك/دعتك لمكالمة سريعة: «' + mt.title + '» — افتحها من صفحة الاجتماعات');
    toast('اتبعتت الدعوة ✓', 'ok');
  } catch (e) { toast('مبعتتش الدعوة: ' + e.message, 'err'); }
}
function openProxCard(uid) {
  const u = userById(uid);
  if (!u) return;
  const st = (state.pos && state.pos[uid] && state.pos[uid].status) || 'متاح';
  const m = modal({
    title: getLang() === 'ar' ? 'كارت الزميل' : 'Peer card',
    body: el('div', { class: 'col', style: { textAlign: 'center', gap: '5px' } }, [
      el('div', { class: 'prox-card-av', html: avatarHTML(u) }),
      el('b', { style: { fontSize: '16px' }, text: getLang() === 'ar' ? u.name : (u.nameEn || u.name) }),
      el('div', { class: 'dim', style: { fontSize: '12.5px' }, text: [u.title || ROLE_AR[u.role] || u.role, u.deptName || ''].filter(Boolean).join(' · ') }),
      el('span', { class: 'badge info', text: 'الحالة: ' + st }),
    ]),
    footer: [
      el('button', { class: 'btn primary', text: '💬 دردشة', onclick: () => { m.close(); openDM(uid); } }),
      el('button', { class: 'btn', text: '👤 البروفايل', onclick: () => { m.close(); location.hash = '#/team'; } }),
      el('button', { class: 'btn', text: '📞 دعوة', onclick: () => { m.close(); inviteToCall(u); } }),
    ],
  });
}

  /* ---- نقر: لافتة غرفة → دخول | أفاتار → محادثة ---- */
  const ray = new THREE.Raycaster();
  function pick(e) {
    const rect = renderer.domElement.getBoundingClientRect();
    const v = new THREE.Vector2(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
    ray.setFromCamera(v, camera);
    const hits = ray.intersectObjects([...labelSprites, ...peerGrp.children], true);
    for (const h of hits) {
      let o = h.object;
      while (o && !o.userData.room && !o.userData.uid) o = o.parent;
      if (o && o.userData.room === '__projects') { location.hash = '#/projects'; return; } /* V4-4 */
      if (o && o.userData.room) { const r = rooms().find((x) => x.id === o.userData.room); if (r) { tryEnter(r); return; } }
      if (o && o.userData.uid) { openProxCard(o.userData.uid); return; } /* V4-5: كارت القرب */
    }
  }

  /* ---- دخول الغرف ---- */
  let enterTarget = null;
  function roomAllowed(r) {
    if (isClient && !['clounge', 'reception'].includes(r.id)) return false;
    if (r.roles && !r.roles.includes(state.user.role)) return false;
    return true;
  }
  function tryEnter(r) {
    if (r.id === 'reception') { location.hash = '#/dashboard'; return; }
    if (!roomAllowed(r)) { toast(getLang() === 'ar' ? '🔒 القسم ده مش متاح ليك' : '🔒 Restricted area', 'err'); return; }
    if (r.route) location.hash = r.route;
  }
  function enterRoom(r) { tryEnter(r); }

  function roomAt(px2, py2) {
    const bs = booths().find((b) => px2 >= b.x && px2 <= b.x + b.w && py2 >= b.y && py2 <= b.y + b.h);
    if (bs) return bs.id;
    const r = rooms().find((r2) => px2 >= r2.x && px2 <= r2.x + r2.w && py2 >= r2.y && py2 <= r2.y + r2.h);
    return r ? r.id : 'floor';
  }

  /* ---- تصادم ---- */
  function collide(nx, nz) {
    let x = nx, z = nz;
    for (let it = 0; it < 3; it++) {
      for (const c of colliders) {
        const cxp = Math.max(c.x0, Math.min(x, c.x1));
        const czp = Math.max(c.z0, Math.min(z, c.z1));
        const dx = x - cxp, dz = z - czp;
        const d2 = dx * dx + dz * dz;
        if (d2 < PLAYER_R * PLAYER_R) {
          const d = Math.sqrt(d2) || 0.0001;
          if (d2 > 0.00001) { x = cxp + (dx / d) * PLAYER_R; z = czp + (dz / d) * PLAYER_R; }
          else { /* داخل الصندوق تمامًا — ادفع لأقرب ضلع */
            const l = x - c.x0, r2 = c.x1 - x, t = z - c.z0, b = c.z1 - z;
            const mn = Math.min(l, r2, t, b);
            if (mn === l) x = c.x0 - PLAYER_R; else if (mn === r2) x = c.x1 + PLAYER_R;
            else if (mn === t) z = c.z0 - PLAYER_R; else z = c.z1 + PLAYER_R;
          }
        }
      }
    }
    x = Math.max(-WX / 2 + 1, Math.min(WX / 2 - 1, x));
    z = Math.max(-WZ / 2 + 1, Math.min(WZ / 2 - 1, z));
    return { x, z };
  }

  /* ---- بث الموضع (نفس بروتوكول 2D) ---- */
  let lastSend = 0, settle = null;
  function sendPosNow() {
    const p = { x: toPctX(px), y: toPctZ(pz) };
    br.savePos(curFloor, p);
    br.sendPos(Math.round(p.x * 10) / 10, Math.round(p.y * 10) / 10, roomAt(p.x, p.y), curFloor);
    clearTimeout(settle);
    settle = setTimeout(() => sendPosNow(), 250);
  }
  function sendPos() {
    const now = Date.now();
    if (now - lastSend < 120) return;
    lastSend = now;
    sendPosNow();
  }

  /* ---- الحلقة ---- */
  function resize() {
    const w = wrap.clientWidth || window.innerWidth, h = wrap.clientHeight || window.innerHeight;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);

  function rebuild() {
    buildWorld();
    hud.querySelectorAll('.of3d-btn.fl').forEach((b, i) => b.classList.toggle('on', [1, 2][i] === curFloor));
    peerMeshes.forEach((m) => peerGrp.remove(m));
    peerMeshes.clear(); peerTarget.clear();
    paintPeers();
  }

  let lastT = performance.now();
  let running = true;
  /* V4-7: قياس FPS + جودة تكيفية */
  let fFrames = 0, fT = 0, lastFps = 0, lowStreak = 0, downgraded = false;
  const pm = (e) => {
    if (mDown) {
      const dx = e.clientX - mDown.x, dy = e.clientY - mDown.y;
      if (Math.abs(dx) + Math.abs(dy) > 3) mDown.moved = true;
      if (mDown.moved) { camYaw -= dx * 0.006; camPitch = Math.max(0.15, Math.min(1.2, camPitch + dy * 0.003)); mDown.x = e.clientX; mDown.y = e.clientY; }
    }
  };
  const pu = (e) => {
    if (mDown && !mDown.moved && e.target === renderer.domElement) pick(e);
    mDown = null;
  };
  window.addEventListener('pointermove', pm);
  window.addEventListener('pointerup', pu);
  function tick(t) {
    if (!host.isConnected || !wrap.isConnected || !running) {
      running = false;
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', pm);
      window.removeEventListener('pointerup', pu);
      clearTimeout(settle);
      hideJoy();
      disposeWorld();
      renderer.dispose();
      renderer.domElement.remove();
      wrap.remove();
      return;
    }
    const dt = Math.min(50, t - lastT); lastT = t;
    const sp = 0.0115 * dt; /* ≈ 11 وحدة/ث */
    let mx = 0, mz = 0;
    if (keys.has('up')) mz -= 1;
    if (keys.has('down')) mz += 1;
    if (keys.has('left')) mx -= 1;
    if (keys.has('right')) mx += 1;
    if (joyVec) { mx = joyVec.x; mz = joyVec.y; }
    if (mx || mz) {
      const l = Math.hypot(mx, mz) || 1;
      /* الحركة نسبية لاتجاه الكاميرا */
      const fx = -Math.sin(camYaw), fz = -Math.cos(camYaw);
      const rx2 = Math.cos(camYaw), rz2 = -Math.sin(camYaw);
      let nx = px + (fx * (-mz) + rx2 * mx) / l * sp;
      let nz = pz + (fz * (-mz) + rz2 * mx) / l * sp;
      const c = collide(nx, nz);
      px = c.x; pz = c.z;
      meAv.rotation.y = Math.atan2(fx * (-mz) + rx2 * mx, fz * (-mz) + rz2 * mx);
      sendPos();
    }
    meAv.position.set(px, 0, pz);
    /* LOD: اللافتات تتناسب مع المسافة — لا تصبح عملاقة قرب الكاميرا */
    for (const lb of labelSprites) {
      const k = lb.userData.ratio || (lb.userData.ratio = lb.scale.y / lb.scale.x);
      const d = camera.position.distanceTo(lb.position);
      const s = Math.max(5, Math.min(11, d * 0.32));
      lb.scale.set(s, s * k, 1);
    }
    /* نعومة للزملاء */
    for (const [uid, m] of peerMeshes) {
      const tg = peerTarget.get(uid);
      if (tg) { m.position.x += (tg.x - m.position.x) * 0.15; m.position.z += (tg.z - m.position.z) * 0.15; }
    }
    /* برومبت أقرب غرفة */
    const myPct = { x: toPctX(px), y: toPctZ(pz) };
    const here = rooms().find((r) => myPct.x >= r.x && myPct.x <= r.x + r.w && myPct.y >= r.y && myPct.y <= r.y + r.h);
    if (here && here.id !== 'reception' && here.route) {
      enterTarget = here;
      prompt.hidden = false;
      prompt.textContent = (getLang() === 'ar' ? '⏎ ادخل ' : '⏎ Enter ') + (getLang() === 'ar' ? here.ar : here.en);
      prompt.onclick = () => enterRoom(here);
    } else if (here && here.id === 'reception') {
      enterTarget = here;
      prompt.hidden = false;
      prompt.textContent = getLang() === 'ar' ? '⏎ لوحة التحكم' : '⏎ Dashboard';
      prompt.onclick = () => enterRoom(here);
    } else { enterTarget = null; prompt.hidden = true; prompt.onclick = null; }
    /* عدّاد المتصلين */
    const on = new Set(state.online || []);
    const live = hud.querySelector('.of3d-live');
    if (live) live.textContent = '🟢 ' + (state.users || []).filter((u) => u.role !== 'client' && u.role !== 'superadmin' && on.has(u.id)).length;
    /* V4-7: FPS + خفض الجودة التكيفي لو الأداء ضعيف */
    fFrames++;
    if (t - fT >= 1000) {
      lastFps = Math.round((fFrames * 1000) / (t - fT)); fFrames = 0; fT = t;
      const fe = hud.querySelector('.of3d-fps');
      if (fe) fe.textContent = lastFps + ' FPS';
      if (lastFps > 0 && lastFps < 28) { lowStreak++; if (lowStreak >= 2 && !downgraded) { downgraded = true; renderer.setPixelRatio(1); } }
      else lowStreak = 0;
    }
    applyCam();
    renderer.render(scene, camera);
    requestAnimationFrame(tick);
  }

  buildWorld();
  resize();
  applyCam();
  paintPeers();
  requestAnimationFrame(tick);
  sendPosNow();

  const unsub = subscribe((what) => {
    if (!host.isConnected) { unsub(); return; }
    if (what === 'pos' || what === 'presence') paintPeers();
    if (what === 'settings') { br.reload(); rebuild(); } /* تحديث تخطيط البنّاء لحظيًا في 3D */
    if (what === 'state') { /* V4-2: مظهر جديد لي أو لزميل */
      rebuildMe();
      peerMeshes.forEach((mm) => peerGrp.remove(mm));
      peerMeshes.clear(); peerTarget.clear();
      paintPeers();
    }
  });

  /* خطاف اختبار/تصحيح */
  window.__of3d = {
    ready: true,
    pos: () => ({ x: toPctX(px), y: toPctZ(pz) }),
    setPos: (x, y) => { const c = collide(toX(x), toZ(y)); px = c.x; pz = c.z; },
    roomAt,
    rooms: () => rooms().map((r) => ({ id: r.id, ar: r.ar })),
    peers: () => peerMeshes.size,
    myLook: () => Object.assign({}, state.user.avatar || {}),
    peerLook: (uid) => Object.assign({}, ((state.users || []).find((x) => x.id === uid) || {}).avatar || {}),
    floor: () => curFloor,
    fps: () => lastFps,
    pool: () => ({ geo: GEOC.size, mat: MATC.size }),
    colliders: () => colliders.length,
    canvas: () => renderer.domElement,
    yaw: () => camYaw,
    /* V4-4: موقع لافتة المشاريع على الشاشة — لاختبار النقر الحقيقي */
    signPos: () => {
      if (!prjLabGlobal) return { x: -100, y: -100 };
      const v = prjLabGlobal.position.clone().project(camera);
      const rect = renderer.domElement.getBoundingClientRect();
      return { x: rect.left + ((v.x + 1) / 2) * rect.width, y: rect.top + ((1 - v.y) / 2) * rect.height };
    },
    /* V4-5: موقع أفاتار زميل على الشاشة — لاختبار كارت القرب */
    peerPos: (uid) => {
      const m = peerMeshes.get(uid);
      if (!m) return null;
      const v = new THREE.Vector3();
      m.getWorldPosition(v); v.y += 1.7;
      v.project(camera);
      const rect = renderer.domElement.getBoundingClientRect();
      return { x: rect.left + ((v.x + 1) / 2) * rect.width, y: rect.top + ((1 - v.y) / 2) * rect.height };
    },
  };
}

/* رجوع لـ 2D بدون reload */
async function renderOffice2D(host) {
  const m = await import('./views/office.js');
  m.renderOffice2D(host);
}
