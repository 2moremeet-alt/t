/* ============================================================
   MEE M — V4-2: الهوية والأفاتار
   خيارات المظهر + محرر مشترك (بروفايل + Onboarding) + معاينة SVG.
   ============================================================ */
import { el, toast, modal } from './ui.js';
import { state } from './store.js';
import { api } from './api.js';
import { getLang } from './i18n.js';

export const SKINS = ['#ffe0bd', '#ffd9b3', '#f1c27d', '#e0ac69', '#c68642', '#8d5524'];
export const HAIRS = [
  { id: 'short', ar: 'قصير', en: 'Short' },
  { id: 'long', ar: 'طويل', en: 'Long' },
  { id: 'bun', ar: 'كعكة', en: 'Bun' },
  { id: 'buzz', ar: 'حليق', en: 'Buzz' },
  { id: 'curly', ar: 'كيرلي', en: 'Curly' },
  { id: 'none', ar: 'بدون', en: 'None' },
];
export const HAIR_COLORS = ['#1b1b1b', '#4a2c17', '#7b4a21', '#c98a3d', '#d9d9d9', '#b33939', '#3d6dff', '#7c3aed'];
export const OUTFITS = [
  { id: 'tshirt', ar: 'تيشيرت', en: 'T-Shirt' },
  { id: 'hoodie', ar: 'هودي', en: 'Hoodie' },
  { id: 'suit', ar: 'بدلة', en: 'Suit' },
  { id: 'dress', ar: 'فستان', en: 'Dress' },
];
export const OUTFIT_COLORS = ['#3d8bff', '#8b5cf6', '#ef4444', '#22c55e', '#f59e0b', '#ec4899', '#14b8a6', '#334155'];
export const ACCESSORIES = [
  { id: 'none', ar: 'بدون', en: 'None' },
  { id: 'glasses', ar: 'نضارة', en: 'Glasses' },
  { id: 'cap', ar: 'كاب', en: 'Cap' },
  { id: 'headset', ar: 'سماعة', en: 'Headset' },
];

export function defaultLook(u) {
  return Object.assign({
    gender: 'm', skin: SKINS[1], hair: 'short', hairColor: HAIR_COLORS[0],
    outfit: 'tshirt', outfitColor: (u && u.avatarColor) || OUTFIT_COLORS[0], accessory: 'none',
  }, (u && u.avatar) || {});
}

/* ---------------- معاينة SVG ---------------- */
export function lookSVG(look, size = 96) {
  const L = look;
  const hair = L.hairColor, skin = L.skin, out = L.outfitColor;
  let hairEl = '';
  if (L.hair === 'short') hairEl = `<path d="M20 20 a12 12 0 0 1 24 0 l-2 4 a10 8 0 0 0 -20 0 Z" fill="${hair}"/>`;
  else if (L.hair === 'long') hairEl = `<path d="M20 20 a12 12 0 0 1 24 0 v18 h-5 v-14 a9 8 0 0 0 -14 0 v14 h-5 Z" fill="${hair}"/>`;
  else if (L.hair === 'bun') hairEl = `<path d="M20 20 a12 12 0 0 1 24 0 l-2 3 a10 7 0 0 0 -20 0 Z" fill="${hair}"/><circle cx="32" cy="8" r="5" fill="${hair}"/>`;
  else if (L.hair === 'buzz') hairEl = `<path d="M21 18 a11 10 0 0 1 22 0 l-1 3 a10 6 0 0 0 -20 0 Z" fill="${hair}" opacity=".75"/>`;
  else if (L.hair === 'curly') hairEl = `<circle cx="24" cy="14" r="5" fill="${hair}"/><circle cx="32" cy="11" r="6" fill="${hair}"/><circle cx="40" cy="14" r="5" fill="${hair}"/>`;
  let bodyEl = '';
  if (L.outfit === 'dress') bodyEl = `<path d="M24 34 h16 l6 26 h-28 Z" fill="${out}"/>`;
  else if (L.outfit === 'hoodie') bodyEl = `<rect x="22" y="33" width="20" height="26" rx="7" fill="${out}"/><path d="M24 34 a8 6 0 0 1 16 0 Z" fill="${out}" stroke="rgba(0,0,0,.25)"/><rect x="28" y="44" width="8" height="7" rx="2" fill="rgba(0,0,0,.22)"/>`;
  else if (L.outfit === 'suit') bodyEl = `<rect x="22" y="33" width="20" height="26" rx="5" fill="${out}"/><path d="M30 34 l2 8 2-8 Z" fill="#f5f7fb"/><path d="M22 34 l6 6 -6 3 Z M42 34 l-6 6 6 3 Z" fill="rgba(0,0,0,.28)"/>`;
  else bodyEl = `<rect x="22" y="33" width="20" height="26" rx="6" fill="${out}"/><path d="M27 33 a5 4 0 0 0 10 0 Z" fill="${skin}"/>`;
  let accEl = '';
  if (L.accessory === 'glasses') accEl = `<circle cx="27" cy="22" r="4" fill="none" stroke="#111" stroke-width="1.6"/><circle cx="37" cy="22" r="4" fill="none" stroke="#111" stroke-width="1.6"/><line x1="31" y1="22" x2="33" y2="22" stroke="#111" stroke-width="1.6"/>`;
  else if (L.accessory === 'cap') accEl = `<path d="M20 16 a12 10 0 0 1 24 0 Z" fill="${hair === '#1b1b1b' ? '#b33939' : '#1b1b1b'}"/><rect x="18" y="15" width="20" height="3" rx="1.5" fill="#1b1b1b"/>`;
  else if (L.accessory === 'headset') accEl = `<path d="M19 20 a13 13 0 0 1 26 0" fill="none" stroke="#222" stroke-width="2.5"/><rect x="17" y="19" width="4" height="8" rx="2" fill="#222"/><rect x="43" y="19" width="4" height="8" rx="2" fill="#222"/><path d="M45 27 q-4 8 -12 8" stroke="#222" stroke-width="1.6" fill="none"/>`;
  return `<svg viewBox="0 0 64 80" width="${size}" height="${size * 1.25}" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="32" cy="74" rx="16" ry="4" fill="rgba(0,0,0,.25)"/>
    <rect x="26" y="58" width="6" height="14" rx="3" fill="#232a38"/><rect x="33" y="58" width="6" height="14" rx="3" fill="#232a38"/>
    ${bodyEl}
    <rect x="17" y="36" width="5" height="14" rx="2.5" fill="${out}"/><rect x="42" y="36" width="5" height="14" rx="2.5" fill="${out}"/>
    <circle cx="32" cy="21" r="11" fill="${skin}"/>
    ${hairEl}${accEl}
    <circle cx="28" cy="22" r="1.4" fill="#20242e"/><circle cx="36" cy="22" r="1.4" fill="#20242e"/>
    <path d="M29 27 q3 2 6 0" stroke="#20242e" stroke-width="1.3" fill="none" stroke-linecap="round"/>
  </svg>`;
}

/* ---------------- محرر المظهر ---------------- */
export function lookEditor(look) {
  const AR = getLang() === 'ar';
  const doc = Object.assign({}, look);
  const preview = el('div', { class: 'look-preview', html: lookSVG(doc) });
  const swatches = (list, key, label) => el('div', { class: 'look-row' }, [
    el('span', { class: 'look-lbl', text: label }),
    el('div', { class: 'look-sw' }, list.map((c) => el('button', {
      class: 'sw' + (doc[key] === c ? ' on' : ''), style: { background: c }, title: c,
      onclick: (e) => { doc[key] = c; e.currentTarget.parentNode.querySelectorAll('.sw').forEach((x) => x.classList.remove('on')); e.currentTarget.classList.add('on'); preview.innerHTML = lookSVG(doc); },
    }))),
  ]);
  const sel = (list, key, label) => el('div', { class: 'look-row' }, [
    el('span', { class: 'look-lbl', text: label }),
    el('select', {
      class: 'select', html: list.map((o) => `<option value="${o.id}" ${o.id === doc[key] ? 'selected' : ''}>${AR ? o.ar : o.en}</option>`).join(''),
      onchange: (e) => { doc[key] = e.target.value; preview.innerHTML = lookSVG(doc); },
    }),
  ]);
  const node = el('div', { class: 'look-editor col', style: { gap: '10px' } }, [
    preview,
    el('div', { class: 'look-row' }, [
      el('span', { class: 'look-lbl', text: AR ? 'النوع' : 'Gender' }),
      el('div', { class: 'look-sw' }, ['m', 'f'].map((g) => el('button', {
        class: 'btn sm' + (doc.gender === g ? ' primary' : ''), text: g === 'm' ? (AR ? 'رجل' : 'Male') : (AR ? 'امرأة' : 'Female'),
        onclick: (e) => { doc.gender = g; e.currentTarget.parentNode.querySelectorAll('button').forEach((x) => x.classList.remove('primary')); e.currentTarget.classList.add('primary'); preview.innerHTML = lookSVG(doc); },
      }))),
    ]),
    swatches(SKINS, 'skin', AR ? 'البشرة' : 'Skin'),
    sel(HAIRS, 'hair', AR ? 'الشعر' : 'Hair'),
    swatches(HAIR_COLORS, 'hairColor', AR ? 'لون الشعر' : 'Hair color'),
    sel(OUTFITS, 'outfit', AR ? 'الملبس' : 'Outfit'),
    swatches(OUTFIT_COLORS, 'outfitColor', AR ? 'لون الملبس' : 'Outfit color'),
    sel(ACCESSORIES, 'accessory', AR ? 'الإكسسوار' : 'Accessory'),
  ]);
  return { node, get: () => Object.assign({}, doc), preview };
}

/* ---------------- صورة البروفايل ---------------- */
export function photoPicker(onPicked) {
  const AR = getLang() === 'ar';
  const inp = el('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', style: { display: 'none' } });
  inp.addEventListener('change', async () => {
    const f = inp.files && inp.files[0];
    if (!f) return;
    if (f.size > 2 * 1024 * 1024) { toast(AR ? 'الصورة كبيرة (٢MB كحد أقصى)' : 'Image too large (2MB max)', 'err'); return; }
    try {
      const r = await api.uploadFile(f.name, f);
      onPicked(r.url);
      toast(AR ? 'الصورة اتحفّظت ✓' : 'Photo saved ✓', 'ok');
    } catch (e) { toast(e.message || 'upload failed', 'err'); }
  });
  return { inp, btn: el('button', { class: 'btn sm', text: AR ? '📷 صورة بروفايل' : '📷 Profile photo', onclick: () => inp.click() }) };
}

/* ---------------- Onboarding للموظف الجديد ---------------- */
export function openOnboarding() {
  const AR = getLang() === 'ar';
  const u = state.user;
  const ed = lookEditor(defaultLook(u));
  let step = 0;
  const body = el('div', { class: 'col', style: { gap: '14px' } });
  const steps = [
    el('div', { class: 'col', style: { gap: '10px' } }, [
      el('div', { style: { fontSize: '40px', textAlign: 'center' }, text: '👋' }),
      el('div', { style: { fontWeight: '800', fontSize: '17px', textAlign: 'center' }, text: (AR ? 'أهلًا يا ' : 'Welcome, ') + u.name + '!' }),
      el('div', { class: 'dim', style: { textAlign: 'center', lineHeight: 1.8 }, text: AR
        ? `انت انضممت لاستوديو MEE M بدور «${u.title || u.role}». مكتبك الافتراضي ثلاثي الأبعاد فيه أقسام لكل فريق — اتحرك بـ WASD أو الأسهم، وقِف جوّه قسم عشان تفتح لوحته، وكلم زمايلك بالدردشة أو بالضغط على أفاتارهم.`
        : `You joined MEE M studio as "${u.title || u.role}". Your 3D virtual office has a room per team — move with WASD/arrows, stand inside a room to open its board, and chat with teammates by clicking their avatar.` }),
    ]),
    el('div', { class: 'col', style: { gap: '10px' } }, [
      el('div', { style: { fontWeight: '800', textAlign: 'center' }, text: AR ? 'اختار شكلك في المكتب 🎨' : 'Pick your office look 🎨' }),
      ed.node,
    ]),
  ];
  const next = el('button', { class: 'btn primary', text: AR ? 'التالي ←' : 'Next →' });
  const skip = el('button', { class: 'btn ghost', text: AR ? 'خلاص بعدين' : 'Later' });
  function draw() {
    body.innerHTML = '';
    body.appendChild(steps[step]);
    if (step === 0) next.textContent = AR ? 'التالي ←' : 'Next →';
    else next.textContent = AR ? 'يلا نبدأ 🚀' : "Let's go 🚀";
  }
  next.onclick = async () => {
    if (step === 0) { step = 1; draw(); return; }
    try {
      await api.saveLook({ avatar: ed.get(), onboarded: true });
      toast(AR ? 'يلا بينا! مكتبك مستنيك 🏢' : 'Enjoy your office! 🏢', 'ok');
    } catch (e) { toast(e.message || 'save failed', 'err'); }
    m.close();
  };
  skip.onclick = async () => { try { await api.saveLook({ onboarded: true }); } catch (e) { /* ignore */ } m.close(); };
  draw();
  const m = modal({
    title: AR ? '🎉 أول يوم ليك في MEE M' : '🎉 Your first day at MEE M',
    body,
    footer: [skip, el('div', { class: 'grow' }), next],
  });
}
