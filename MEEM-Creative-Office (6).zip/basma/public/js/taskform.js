/* ============================================================
   MEEM | Creative Office — نموذج المهمة + بطاقة المهمة (تفاصيل)
   ============================================================ */
import { t, getLang } from './i18n.js';
import { state, save, remove, STATUS, PRIORITIES, DEPTS, STATUS_COLOR, userById, projectById, clientById, todayStr } from './store.js';
import { el, icon, modal, toast, statusBadge, priorityBadge, avatarHTML, formatDate, timeAgo, escapeHTML, confirmDialog, clear } from './ui.js';
import { uid, api } from './api.js';

export const DEPT_TYPES = {
  content: ['سكربت إعلان', 'كابشن', 'محتوى موقع', 'مقال', 'بريف', 'ترجمة', 'أفكار/عصف ذهني'],
  voice: ['إعلان إذاعي', 'فيديو', 'بودكاست', 'IVR/رد آلي', 'دبلجة', 'موشن'],
  design: ['سوشيال', 'مطبوعات', 'براندينج', 'موشن', 'تغليف', 'واجهات UI/UX', 'رسم توضيحي', 'فيديو'],
  delivery: ['تسليم', 'متابعة', 'اعتماد', 'جدولة نشر', 'شكوى عميل'],
  dev: ['واجهة', 'باك-إند', 'خلل', 'ميزة', 'نشر', 'اختبارات', 'توثيق'],
};

export const DESIGN_SUBS = {
  'سوشيال': [
    { id: 'post_1x1', label: 'بوست مربع 1080×1080', w: 1080, h: 1080 },
    { id: 'post_4x5', label: 'بوست عمودي 1080×1350', w: 1080, h: 1350 },
    { id: 'story_9x16', label: 'ستوري 1080×1920', w: 1080, h: 1920 },
    { id: 'cover_fb', label: 'غلاف فيسبوك 820×312', w: 820, h: 312 },
    { id: 'cover_li', label: 'غلاف لينكدإن 1584×396', w: 1584, h: 396 },
    { id: 'yt_thumb', label: 'غلاف يوتيوب 1280×720', w: 1280, h: 720 },
    { id: 'x_post', label: 'بوست X 1600×900', w: 1600, h: 900 },
    { id: 'pin', label: 'بينترست 1000×1500', w: 1000, h: 1500 },
  ],
  'مطبوعات': [
    { id: 'flyer_a5', label: 'فلاير A5 (300dpi)', w: 1748, h: 2480 },
    { id: 'flyer_a4', label: 'فلاير A4 (300dpi)', w: 2480, h: 3508 },
    { id: 'poster_a3', label: 'بوستر A3', w: 3508, h: 4961 },
    { id: 'card', label: 'كارت شخصي 90×50mm', w: 1063, h: 591 },
    { id: 'menu', label: 'منيو A4', w: 2480, h: 3508 },
    { id: 'banner_roll', label: 'رول أب 80×200cm', w: 9449, h: 23622 },
    { id: 'booklet', label: 'بروشور مطوي A4', w: 4961, h: 3508 },
    { id: 'sticker', label: 'ستيكر دائري 10cm', w: 1181, h: 1181 },
  ],
  'براندينج': [
    { id: 'logo', label: 'شعار (1200×1200)', w: 1200, h: 1200 },
    { id: 'brand_guide', label: 'صفحة دليل الهوية A4', w: 2480, h: 3508 },
    { id: 'stationery', label: 'قرطاسية كاملة', w: 2480, h: 3508 },
  ],
  'موشن': [
    { id: 'motion_1x1', label: 'موشن مربع 1080×1080', w: 1080, h: 1080 },
    { id: 'motion_9x16', label: 'موشن عمودي 1080×1920', w: 1080, h: 1920 },
    { id: 'motion_16x9', label: 'موشن عريض 1920×1080', w: 1920, h: 1080 },
  ],
  'تغليف': [
    { id: 'packaging_box', label: 'علبة —ダイ cut', w: 3543, h: 2480 },
    { id: 'packaging_bag', label: 'كيس ورقي', w: 2362, h: 3543 },
    { id: 'label', label: 'ليبل منتج', w: 1181, h: 1772 },
  ],
  'واجهات UI/UX': [
    { id: 'ui_web', label: 'شاشة ويب 1440×900', w: 1440, h: 900 },
    { id: 'ui_mobile', label: 'شاشة موبايل 390×844', w: 390, h: 844 },
    { id: 'ui_tablet', label: 'تابلت 834×1112', w: 834, h: 1112 },
  ],
  'رسم توضيحي': [{ id: 'illus', label: 'رسم 2000×2000', w: 2000, h: 2000 }],
  'فيديو': [
    { id: 'video_16x9', label: 'فيديو 1920×1080', w: 1920, h: 1080 },
    { id: 'video_9x16', label: 'ريلز 1080×1920', w: 1080, h: 1920 },
  ],
};

/* ============================ نموذج مهمة ============================ */

export function openTaskModal(task, onDone) {
  const isNew = !task;
  const doc = Object.assign({
    id: null,
    dept: 'design',
    type: '',
    sub: '',
    title: '',
    desc: '',
    assignee: state.user.id,
    status: 'new',
    priority: 'medium',
    due: todayStr(3),
    projectId: state.projects[0] ? state.projects[0].id : '',
    comments: [],
    files: [],
  }, task || {});

  const f = {
    dept: selectEl(t('department'), DEPTS.map((d) => [d, t('dept_' + d)]), doc.dept, (v) => { doc.dept = v; refreshTypes(); }),
    type: selectEl('النوع', [['', '—']], doc.type, (v) => { doc.type = v; refreshSubs(); }),
    title: inputEl('العنوان *', doc.title, (v) => { doc.title = v; }),
    project: selectEl(t('project'), [['', '—']].concat(state.projects.map((p) => [p.id, p.title])), doc.projectId, (v) => { doc.projectId = v; }),
    assignee: selectEl(t('assignee'), state.users.map((u) => [u.id, getLang() === 'ar' ? u.name : (u.nameEn || u.name)]), doc.assignee, (v) => { doc.assignee = v; }),
    status: selectEl(t('status'), STATUS.map((s) => [s, t('st_' + s)]), doc.status, (v) => { doc.status = v; }),
    priority: selectEl(t('priority'), PRIORITIES.map((p) => [p, t(p)]), doc.priority, (v) => { doc.priority = v; }),
    due: dateEl(t('due'), doc.due, (v) => { doc.due = v; }),
    desc: areaEl(t('notes') + ' / الوصف', doc.desc, (v) => { doc.desc = v; }),
  };

  const typeWrap = el('div', { class: 'field' }, [el('label', { text: 'النوع' }), f.type.node]);
  const subWrap = el('div', { class: 'field hide' });

  function refreshTypes() {
    const list = DEPT_TYPES[doc.dept] || [];
    const opts = list.map((x) => `<option ${x === doc.type ? 'selected' : ''}>${escapeHTML(x)}</option>`).join('');
    f.type.node.innerHTML = `<option value=""></option>` + opts;
    refreshSubs();
  }
  function refreshSubs() {
    const subs = (DESIGN_SUBS[doc.type] || []);
    if (!subs.length || doc.dept !== 'design') { subWrap.classList.add('hide'); return; }
    subWrap.classList.remove('hide');
    subWrap.innerHTML = '';
    subWrap.append(
      el('label', { text: 'المقاس' }),
      el('select', {
        class: 'select',
        onchange: (e) => { doc.sub = e.target.value.split('|')[0]; },
        html: `<option value="">—</option>` + subs.map((s) => `<option value="${s.id}|${s.w}x${s.h}" ${s.id === doc.sub ? 'selected' : ''}>${escapeHTML(s.label)}</option>`).join(''),
      }),
    );
  }
  refreshTypes();

  /* ============ V4-3: منفذون متعددون + خطوات فرعية + ساعات + مرفقات ============ */
  const usersList = (state.users || []).filter((u) => u.role !== 'client' && u.role !== 'superadmin' && u.active !== false);
  doc.assignees = Array.isArray(doc.assignees) && doc.assignees.length ? doc.assignees : (doc.assignee ? [doc.assignee] : [state.user.id]);
  const assignBox = el('div', { class: 'col', style: { gap: '4px', maxHeight: '130px', overflow: 'auto' } }, usersList.map((u) => el('label', { class: 'row', style: { gap: '8px', fontSize: '12.5px', cursor: 'pointer' } }, [
    el('input', { type: 'checkbox', checked: doc.assignees.includes(u.id), onchange: (e) => {
      doc.assignees = e.target.checked ? [...new Set([...doc.assignees, u.id])] : doc.assignees.filter((x) => x !== u.id);
      doc.assignee = doc.assignees[0] || '';
    } }),
    el('span', { text: getLang() === 'ar' ? u.name : (u.nameEn || u.name) }),
  ])));

  doc.subtasks = Array.isArray(doc.subtasks) ? doc.subtasks : [];
  const subBox = el('div', { class: 'col', style: { gap: '5px' } });
  const subInput = el('input', { class: 'input', placeholder: getLang() === 'ar' ? 'خطوة فرعية جديدة…' : 'New subtask…' });
  function drawSubs() {
    clear(subBox);
    doc.subtasks.forEach((s, i) => subBox.appendChild(el('div', { class: 'row', style: { gap: '8px' } }, [
      el('input', { type: 'checkbox', checked: !!s.done, onchange: (e) => { s.done = e.target.checked; } }),
      el('span', { class: 'grow', style: { fontSize: '12.5px', textDecoration: s.done ? 'line-through' : 'none' }, text: s.text }),
      el('button', { class: 'btn ghost icon sm', html: icon('trash'), onclick: () => { doc.subtasks.splice(i, 1); drawSubs(); } }),
    ])));
  }
  drawSubs();
  const addSubBtn = el('button', { class: 'btn sm', text: getLang() === 'ar' ? '＋ خطوة' : '+ step', onclick: () => {
    if (!subInput.value.trim()) return;
    doc.subtasks.push({ id: 's' + Date.now(), text: subInput.value.trim().slice(0, 140), done: false });
    subInput.value = '';
    drawSubs();
  } });

  doc.files = Array.isArray(doc.files) ? doc.files : [];
  const filesList = el('div', { class: 'col', style: { gap: '4px' } });
  function drawMFiles() {
    clear(filesList);
    doc.files.forEach((ff, i) => filesList.appendChild(el('div', { class: 'row', style: { gap: '6px', fontSize: '12px' } }, [
      el('span', { class: 'grow', text: '📎 ' + (ff.name || ff.url) }),
      el('button', { class: 'btn ghost icon sm', html: icon('trash'), onclick: () => { doc.files.splice(i, 1); drawMFiles(); } }),
    ])));
  }
  drawMFiles();
  const mFileInput = el('input', { type: 'file', style: { display: 'none' } });
  mFileInput.onchange = async () => {
    const ff = mFileInput.files[0];
    if (!ff) return;
    try {
      const j = await api.uploadFile(ff.name, ff);
      doc.files.push({ name: ff.name, url: j.url, size: j.size || ff.size, at: new Date().toISOString(), by: state.user.id });
      drawMFiles();
    } catch (e) { toast(e.message || 'upload failed', 'err'); }
    mFileInput.value = '';
  };

  const startWrap = el('div', { class: 'field' }, [el('label', { text: getLang() === 'ar' ? 'تاريخ البدء' : 'Start date' }), el('input', { class: 'input', type: 'date', value: doc.start || '', oninput: (e) => { doc.start = e.target.value; } })]);
  const estWrap = el('div', { class: 'field' }, [el('label', { text: getLang() === 'ar' ? 'ساعات تقديرية' : 'Estimated hours' }), el('input', { class: 'input num', type: 'number', min: 0, step: 0.5, value: doc.est || 0, oninput: (e) => { doc.est = +e.target.value || 0; } })]);

  const m = modal({
    title: isNew ? t('newTask') : t('edit'),
    size: 'wide',
    body: [
      el('div', { class: 'grid2' }, [f.dept.wrap, typeWrap]),
      f.title.wrap,
      subWrap,
      el('div', { class: 'grid3' }, [f.project.wrap, f.status.wrap, f.priority.wrap]),
      el('div', { class: 'grid3' }, [f.due.wrap, startWrap, estWrap]),
      el('div', { class: 'field' }, [el('label', { text: getLang() === 'ar' ? 'المنفذون (متعدد)' : 'Assignees (multi)' }), assignBox]),
      el('div', { class: 'field' }, [el('label', { text: getLang() === 'ar' ? 'خطوات فرعية' : 'Subtasks' }), el('div', { class: 'col', style: { gap: '6px' } }, [subBox, el('div', { class: 'row', style: { gap: '6px' } }, [subInput, addSubBtn])])]),
      el('div', { class: 'field' }, [el('label', { text: getLang() === 'ar' ? 'مرفقات' : 'Attachments' }), el('div', { class: 'col', style: { gap: '6px' } }, [filesList, el('button', { class: 'btn sm', text: getLang() === 'ar' ? '📎 إرفاق ملف' : '📎 attach', onclick: () => mFileInput.click() }), mFileInput])]),
      f.desc.wrap,
    ],
    footer: [
      isNew ? null : el('button', {
        class: 'btn danger ghost', html: icon('trash') + `<span>${t('delete')}</span>`,
        onclick: async () => {
          if (!await confirmDialog(t('cantUndo'), { danger: true, okLabel: t('delete') })) return;
          await remove('tasks', doc.id);
          m.close();
          toast(t('delete') + ' ✓', 'ok');
          onDone && onDone();
        },
      }),
      el('div', { class: 'grow' }),
      el('button', { class: 'btn ghost', text: t('cancel'), onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', html: icon('check') + `<span>${t('save')}</span>`,
        onclick: async () => {
          if (!doc.title.trim()) { toast(t('required'), 'warn'); f.title.node.focus(); return; }
          /* V4-3: توافق قديم + سجل حركة */
          doc.assignee = doc.assignees && doc.assignees.length ? doc.assignees[0] : (doc.assignee || '');
          doc.history = (doc.history || []).concat([{ at: new Date().toISOString(), userId: state.user.id, text: isNew ? 'أنشأ المهمة' : 'عدّل المهمة' }]);
          await save('tasks', doc);
          m.close();
          toast(t('saved'), 'ok');
          onDone && onDone();
        },
      }),
    ],
  });
  return m;
}

/* ============================ تفاصيل المهمة ============================ */

export function openTaskDetails(taskId, onDone) {
  const task = state.tasks.find((x) => x.id === taskId);
  if (!task) return;
  const project = projectById(task.projectId);
  const client = project ? clientById(project.clientId) : null;
  const assignee = userById(task.assignee);

  const commentInput = el('textarea', { class: 'textarea', placeholder: t('comments') + '…', rows: 2 });

  const commentsBox = el('div', { class: 'col', style: { gap: '8px' } });
  function drawComments() {
    clear(commentsBox);
    (task.comments || []).forEach((c) => {
      const u = userById(c.userId);
      commentsBox.appendChild(el('div', { class: 'row', style: { alignItems: 'flex-start' } }, [
        el('div', { html: avatarHTML(u, 'sm') }),
        el('div', { class: 'grow' }, [
          el('div', { class: 'row', style: { gap: '6px' } }, [
            el('b', { text: u ? (getLang() === 'ar' ? u.name : u.nameEn) : '—', style: { fontSize: '13px' } }),
            el('span', { class: 'dim', text: timeAgo(c.at), style: { fontSize: '11px' } }),
          ]),
          el('div', { text: c.text, style: { fontSize: '13.5px' } }),
        ]),
      ]));
    });
    if (!(task.comments || []).length) commentsBox.appendChild(el('div', { class: 'dim', text: t('noData'), style: { fontSize: '13px' } }));
  }
  drawComments();

  const statusSel = el('select', {
    class: 'select',
    onchange: async (e) => {
      task.status = e.target.value;
      task.history = (task.history || []).concat([{ at: new Date().toISOString(), userId: state.user.id, text: 'غيّر الحالة لـ«' + t('st_' + task.status) + '»' }]);
      await save('tasks', task);
      toast(t('saved'), 'ok');
      updateReview(); /* V4-3 */
      onDone && onDone();
    },
    html: STATUS.map((s) => `<option value="${s}" ${s === task.status ? 'selected' : ''}>${t('st_' + s)}</option>`).join(''),
  });

  /* V2-10: المرفقات */
  const filesBox = el('div', { class: 'col', style: { gap: '6px' } });
  function drawFiles() {
    clear(filesBox);
    (task.files || []).forEach((f, i) => {
      const isImg = /\.(png|jpe?g|webp|gif)$/i.test(f.name || f.url || '');
      filesBox.appendChild(el('div', { class: 'tf-file row' }, [
        isImg ? el('img', { class: 'tf-thumb', src: f.url, alt: '' }) : el('span', { html: icon('folder'), style: { display: 'grid', placeItems: 'center', width: '34px' } }),
        el('div', { class: 'grow' }, [
          el('a', { href: f.url, target: '_blank', rel: 'noopener', style: { fontWeight: '700', fontSize: '12.5px' }, text: f.name || f.url }),
          el('div', { class: 'dim num', style: { fontSize: '10.5px' }, text: ((f.size || 0) / 1024).toFixed(0) + ' KB · ' + new Date(f.at || Date.now()).toLocaleDateString('ar-EG') }),
        ]),
        el('button', { class: 'btn ghost icon sm', html: icon('trash'), title: 'حذف المرفق', onclick: async () => {
          task.files.splice(i, 1);
          await save('tasks', task);
          drawFiles();
          toast('اتحذف', 'ok');
        } }),
      ]));
    });
    if (!(task.files || []).length) filesBox.appendChild(el('div', { class: 'dim', style: { fontSize: '12.5px' }, text: 'لسه مفيش مرفقات' }));
  }
  drawFiles();
  const fileInput = el('input', { type: 'file', style: { display: 'none' } });
  fileInput.onchange = async () => {
    const f = fileInput.files[0];
    if (!f) return;
    if (f.size > 40 * 1024 * 1024) { toast('الملف كبير (الحد 40MB)', 'err'); return; }
    try {
      const j = await api.uploadFile(f.name, f);
      task.files = task.files || [];
      task.files.push({ name: f.name, url: j.url, size: j.size || f.size, at: new Date().toISOString(), by: state.user.id });
      await save('tasks', task);
      drawFiles();
      toast('اترفع ✓', 'ok');
      onDone && onDone();
    } catch (e) { toast('الرفع فشل: ' + (e.message || ''), 'err'); }
    fileInput.value = '';
  };

  /* ============ V4-3: منفذون + خطوات + سجل عمل + اعتماد + خط زمني ============ */
  const assignees = (Array.isArray(task.assignees) && task.assignees.length ? task.assignees : (task.assignee ? [task.assignee] : [])).map(userById).filter(Boolean);
  const assignChips = el('div', { class: 'row wrap', style: { gap: '8px' } }, assignees.length ? assignees.map((u) => el('span', { class: 'row', style: { gap: '5px', fontSize: '12px' } }, [el('span', { html: avatarHTML(u, 'sm') }), el('span', { text: getLang() === 'ar' ? u.name : (u.nameEn || u.name) })])) : [el('span', { class: 'dim', text: '—' })]);

  task.subtasks = Array.isArray(task.subtasks) ? task.subtasks : [];
  const subList = el('div', { class: 'col', style: { gap: '5px' } });
  function drawSubTasks() {
    clear(subList);
    task.subtasks.forEach((s) => subList.appendChild(el('label', { class: 'row', style: { gap: '8px', fontSize: '12.5px', cursor: 'pointer' } }, [
      el('input', { type: 'checkbox', checked: !!s.done, onchange: async (e) => { s.done = e.target.checked; await save('tasks', task); drawSubTasks(); onDone && onDone(); } }),
      el('span', { style: { textDecoration: s.done ? 'line-through' : 'none' }, text: s.text }),
    ])));
    if (task.subtasks.length) subList.appendChild(el('div', { class: 'dim num', style: { fontSize: '11px' }, text: task.subtasks.filter((s) => s.done).length + '/' + task.subtasks.length }));
    else subList.appendChild(el('div', { class: 'dim', style: { fontSize: '12px' }, text: 'لا خطوات فرعية' }));
  }
  drawSubTasks();

  task.log = Array.isArray(task.log) ? task.log : [];
  const logBox = el('div', { class: 'col', style: { gap: '5px' } });
  const logH = el('input', { class: 'input num', type: 'number', min: 0.5, step: 0.5, placeholder: 'ساعات', style: { width: '86px' } });
  const logN = el('input', { class: 'input', placeholder: getLang() === 'ar' ? 'اشتغلت على إيه؟' : 'Work note' });
  function drawLog() {
    clear(logBox);
    task.log.forEach((L) => {
      const u = userById(L.userId);
      logBox.appendChild(el('div', { class: 'row', style: { gap: '6px', fontSize: '12px' } }, [
        el('span', { class: 'badge brand num', text: L.hours + 'س' }),
        el('span', { class: 'grow', text: (u ? (getLang() === 'ar' ? u.name : (u.nameEn || u.name)) : '—') + ': ' + (L.note || '') }),
        el('span', { class: 'dim', text: timeAgo(L.at) }),
      ]));
    });
    const act = task.log.reduce((a, b) => a + (+b.hours || 0), 0);
    logBox.appendChild(el('div', { class: 'dim num', style: { fontSize: '11.5px' }, text: (getLang() === 'ar' ? `الفعلي ${act}س / التقديري ${task.est || 0}س` : `actual ${act}h / est ${task.est || 0}h`) }));
  }
  drawLog();
  const addLogBtn = el('button', { class: 'btn sm', text: getLang() === 'ar' ? '＋ سجّل وقت' : '+ log', onclick: async () => {
    const h = +logH.value;
    if (!h || h <= 0) { toast(getLang() === 'ar' ? 'اكتب ساعات صحيحة' : 'Enter hours', 'warn'); return; }
    task.log.push({ id: uid('log'), userId: state.user.id, hours: h, note: logN.value.trim().slice(0, 140), at: new Date().toISOString() });
    task.history = (task.history || []).concat([{ at: new Date().toISOString(), userId: state.user.id, text: `سجّل ${h} ساعة عمل` }]);
    await save('tasks', task);
    logH.value = ''; logN.value = '';
    drawLog(); onDone && onDone();
  } });

  const canReview = ['admin', 'superadmin'].includes(state.user.role) || task.createdBy === state.user.id;
  /* V4-3: مراجعة + اعتماد — تتحدث لحظياً مع تغيير الحالة */
  const reviewWrap = el('div');
  function updateReview() {
    clear(reviewWrap);
    if (task.status !== 'review' || !canReview) return;
    reviewWrap.appendChild(el('div', { class: 'row', style: { gap: '8px' } }, [
      el('button', { class: 'btn primary', text: getLang() === 'ar' ? '✅ اعتماد' : '✅ Approve', onclick: async () => {
        task.status = 'done';
        task.history = (task.history || []).concat([{ at: new Date().toISOString(), userId: state.user.id, text: 'اعتمد المهمة ✅' }]);
        await save('tasks', task); toast(getLang() === 'ar' ? 'اتعمدت ✓' : 'Approved ✓', 'ok'); updateReview(); onDone && onDone(); m.close();
      } }),
      el('button', { class: 'btn outline', text: getLang() === 'ar' ? '↩ طلب تعديلات' : '↩ Request changes', onclick: async () => {
        task.status = 'revision';
        task.history = (task.history || []).concat([{ at: new Date().toISOString(), userId: state.user.id, text: 'طلب تعديلات ↩' }]);
        await save('tasks', task); toast(getLang() === 'ar' ? 'رجعت للتعديلات' : 'Sent to revision', 'ok'); updateReview(); onDone && onDone(); m.close();
      } }),
    ]));
  }
  updateReview();

  const timeline = el('div', { class: 'col', style: { gap: '4px' } });
  (task.history || []).slice(-8).reverse().forEach((h) => {
    const u = userById(h.userId);
    timeline.appendChild(el('div', { class: 'dim', style: { fontSize: '11.5px' }, text: `${u ? (getLang() === 'ar' ? u.name : (u.nameEn || u.name)) : '—'} — ${h.text} · ${timeAgo(h.at)}` }));
  });
  if (!(task.history || []).length) timeline.appendChild(el('div', { class: 'dim', style: { fontSize: '11.5px' }, text: getLang() === 'ar' ? 'لا أحداث بعد' : 'No events yet' }));

  const m = modal({
    title: getLang() === 'ar' ? task.title : (task.titleEn || task.title),
    size: 'wide',
    body: [
      el('div', { class: 'row wrap', style: { gap: '7px' } }, [
        el('span', { class: 'badge brand', text: t('dept_' + (task.dept || 'design')) }),
        el('span', { class: 'badge', text: task.type || '' }),
        statusBadge(task.status) && el('span', { html: statusBadge(task.status) }),
        el('span', { html: priorityBadge(task.priority) }),
        task.due ? el('span', { class: 'badge', html: icon('clock') + `<span>${formatDate(task.due)}</span>` }) : null,
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: t('project') }), el('div', { class: 'input', text: project ? project.title : '—', style: { background: 'transparent' } })]),
        el('div', { class: 'field' }, [el('label', { text: t('client') }), el('div', { class: 'input', text: client ? (getLang() === 'ar' ? client.name : client.nameEn) : '—', style: { background: 'transparent' } })]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [
          el('label', { text: t('assignee') }),
          el('div', { class: 'row' }, [el('div', { html: avatarHTML(assignee, 'sm') }), el('span', { text: assignee ? (getLang() === 'ar' ? assignee.name : assignee.nameEn) : '—' })]),
        ]),
        el('div', { class: 'field' }, [el('label', { text: t('status') }), statusSel]),
      ]),
      task.desc ? el('div', { class: 'card card-pad', style: { background: 'var(--panel-2)' } }, [
        el('b', { text: t('notes'), style: { fontSize: '12.5px' } }),
        el('p', { text: task.desc, style: { fontSize: '13.5px', whiteSpace: 'pre-wrap' } }),
      ]) : null,
      el('div', { class: 'field' }, [
        el('div', { class: 'between', style: { marginBottom: '6px' } }, [
          el('label', { text: '📎 المرفقات' }),
          el('button', { class: 'btn sm', html: icon('upload') + '<span>رفع ملف</span>', onclick: () => fileInput.click() }),
        ]),
        filesBox, fileInput,
      ]),
      el('div', { class: 'field' }, [el('label', { text: getLang() === 'ar' ? '👥 المنفذون' : '👥 Assignees' }), assignChips]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: getLang() === 'ar' ? '☑️ خطوات فرعية' : '☑️ Subtasks' }), subList]),
        el('div', { class: 'field' }, [
          el('label', { text: getLang() === 'ar' ? '⏱ سجل العمل اليدوي' : '⏱ Work log' }),
          logBox,
          el('div', { class: 'row', style: { gap: '6px', marginTop: '6px' } }, [logH, logN, addLogBtn]),
        ]),
      ]),
      reviewWrap,
      el('div', { class: 'field' }, [el('label', { text: getLang() === 'ar' ? '🕘 الخط الزمني' : '🕘 Timeline' }), timeline]),
      el('div', { class: 'field' }, [el('label', { text: t('comments') }), commentsBox]),
      el('div', { class: 'row' }, [
        commentInput,
        el('button', {
          class: 'btn primary', html: icon('send'),
          onclick: async () => {
            const text = commentInput.value.trim();
            if (!text) return;
            task.comments = task.comments || [];
            task.comments.push({ id: uid('cmt'), userId: state.user.id, text, at: new Date().toISOString() });
            await save('tasks', task);
            commentInput.value = '';
            drawComments();
            onDone && onDone();
          },
        }),
      ]),
    ],
    footer: [
      el('button', { class: 'btn ghost', text: t('close'), onclick: () => m.close() }),
      el('button', {
        class: 'btn outline', html: icon('edit') + `<span>${t('edit')}</span>`,
        onclick: () => { m.close(); openTaskModal(task, onDone); },
      }),
      task.dept === 'design' ? el('button', {
        class: 'btn primary', html: icon('design') + `<span>${t('openInEditor')}</span>`,
        onclick: async () => {
          m.close();
          const { openEditorForTask } = await import('./editor/index.js');
          openEditorForTask(task, onDone);
        },
      }) : null,
    ],
  });
}

/* ============================ helpers ============================ */

function inputEl(label, value, onChange, attrs = {}) {
  const node = el('input', Object.assign({ class: 'input', value: value || '', oninput: (e) => onChange(e.target.value) }, attrs));
  return { node, input: node, wrap: el('div', { class: 'field' }, [el('label', { text: label }), node]) };
}
function areaEl(label, value, onChange) {
  const node = el('textarea', { class: 'textarea', oninput: (e) => onChange(e.target.value) });
  node.value = value || '';
  return { node, wrap: el('div', { class: 'field' }, [el('label', { text: label }), node]) };
}
function dateEl(label, value, onChange) {
  const node = el('input', { class: 'input', type: 'date', value: value || '', oninput: (e) => onChange(e.target.value) });
  return { node, wrap: el('div', { class: 'field' }, [el('label', { text: label }), node]) };
}
function selectEl(label, options, value, onChange) {
  const node = el('select', { class: 'select', onchange: (e) => onChange(e.target.value) });
  node.innerHTML = options.map(([v, lab]) => `<option value="${escapeHTML(v)}" ${String(v) === String(value) ? 'selected' : ''}>${escapeHTML(lab)}</option>`).join('');
  return { node, wrap: el('div', { class: 'field' }, [el('label', { text: label }), node]) };
}
