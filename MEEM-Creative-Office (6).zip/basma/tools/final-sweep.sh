#!/bin/bash
# MEEM — الجولة الشاملة النهائية: كل سويت بلوج مستقل + retry واحد + كشف انحراف DB + hygiene بين السويتات
cd /home/user/basma
mkdir -p /tmp/s16
FAILED=""
snap() { python3 -c "import json;d=json.load(open('data/db.json'));print(','.join(str(len(d.get(c,[]))) for c in ['invoices','payments','expenses','timeentries','chats','designs']))"; }
run() {
  node tests/sweep-hygiene.js >> /tmp/s16/hygiene.log 2>&1
  f=$1; tmo=$2
  before=$(snap)
  if timeout $tmo node tests/$f.js > /tmp/s16/$f.log 2>&1; then
    echo "PASS $f"
  else
    echo "FAIL $f — retry in 8s"
    sleep 8
    if timeout $tmo node tests/$f.js > /tmp/s16/$f.retry.log 2>&1; then
      echo "PASS $f (retry)"
    else
      FAILED="$FAILED $f"; echo "FAIL $f (twice)"
    fi
  fi
  after=$(snap)
  [ "$before" != "$after" ] && echo "  DB-DRIFT $f: $before -> $after"
}
for f in test-phase2-e2e test-phase3-e2e test-phase4-e2e test-phase5-e2e test-phase6-e2e test-phase7-e2e test-v2-avatars-e2e test-v2-client-actions-e2e test-v2-client-link-e2e test-v2-dm-e2e test-v2-i18n-e2e test-v2-office-e2e test-v2-project-team-e2e test-v2-public-request-e2e test-v2-responsive-e2e test-v2-superadmin-e2e test-v2-tasks-e2e test-v2-team-e2e test-v2-workspace-e2e test-v2e1-editor-e2e test-v2e2-editor-e2e test-v2e3-identity-e2e test-v3-builder-e2e test-v3-office-art-e2e test-v3-proximity-e2e test-v4-3d-e2e test-v4-avatar-e2e test-v4-chat-e2e test-v4-fixes-e2e test-v4-owner-e2e test-v4-projects-e2e test-v4-tasks-e2e test-v4-perf-e2e; do
  run $f 420; sleep 3
done
for f in test-phase2-api test-phase3-api test-phase4-api test-phase5-api test-phase6-api test-phase7-api test-v2-perms-api test-v2-superadmin-api test-v2-team-api test-v4-chat-api test-v4-owner-api test-v4-projects-api test-v4-tasks-api; do
  run $f 240; sleep 1
done
[ -n "$FAILED" ] && echo "FAILED:$FAILED" || echo "ALL-GREEN"
echo ALLDONE
