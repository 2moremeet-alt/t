#!/bin/bash
cd /home/user/basma
CF=/tmp/tc/node_modules/cloudflared/bin/cloudflared
while true; do
  $CF tunnel --protocol http2 --url http://localhost:3000 --no-autoupdate > /tmp/cf.log 2>&1 &
  CFPID=$!
  for i in $(seq 1 60); do
    URL=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' /tmp/cf.log | head -1)
    [ -n "$URL" ] && break
    sleep 1
  done
  if [ -n "$URL" ]; then
    echo -n "$URL" > data/public-url.txt
    echo "tunnel up: $URL"
  fi
  wait $CFPID
  echo "cloudflared died — restarting in 3s"
  sleep 3
done
