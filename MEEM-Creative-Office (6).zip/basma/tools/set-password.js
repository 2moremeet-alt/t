#!/usr/bin/env node
/* MEEM — تغيير باسورد أي حساب قبل النشر على الإنترنت
 * الاستخدام:  node tools/set-password.js <email> <الباسورد-الجديد>
 * مثال:       node tools/set-password.js admin@meem.studio "MyStr0ng!Pass"
 * ملاحظة: شغّليها والسيرفر واقف (أو اعملي restart بعد التشغيل)
 */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DB = path.join(__dirname, '..', 'data', 'db.json');
const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

const [email, pass] = process.argv.slice(2);
if (!email || !pass) {
  console.log('الاستخدام: node tools/set-password.js <email> <الباسورد الجديد>');
  console.log('مثال:      node tools/set-password.js admin@meem.studio "MyStr0ng!Pass"');
  process.exit(1);
}
if (String(pass).length < 8) {
  console.log('⚠️  الباسورد قصير — استخدمي 8 حروف وأرقام ورموز على الأقل لموقع منشور على الإنترنت');
  process.exit(1);
}

const db = JSON.parse(fs.readFileSync(DB, 'utf8'));
const u = (db.users || []).find((x) => x.email === email);
if (!u) {
  console.log('❌ مفيش حساب بالإيميل ده. الحسابات الموجودة:');
  (db.users || []).forEach((x) => console.log('   - ' + x.email + ' (' + x.role + ')'));
  process.exit(1);
}

u.passwordHash = sha256(pass);
delete u.password;
fs.writeFileSync(DB, JSON.stringify(db, null, 2));
console.log('✅ تم تغيير باسورد: ' + u.name + ' <' + u.email + '>');
console.log('   لو السيرفر شغال اعملي له restart:  pm2 restart meem  (أو node server/server.js)');
