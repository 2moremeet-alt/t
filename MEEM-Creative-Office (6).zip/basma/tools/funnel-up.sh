#!/bin/bash
# MEE M — Tailscale Funnel (رابط دائم)
# الاستخدام: bash tools/funnel-up.sh
# المفتاح في data/ts-authkey (أول مرة فقط) — الحالة في data/ts-state فالرابط لا يتغير بعد الريسايكل
set -e
BASE=/home/user/basma
TS="$BASE/tools/tailscale --socket=/tmp/ts.sock"
TSD=$BASE/tools/tailscaled
STATE=$BASE/data/ts-state
mkdir -p "$STATE"

# 1) tailscaled (userspace — من غير root)
if ! pgrep tailscaled >/dev/null 2>&1; then
  setsid nohup "$TSD" --tun=userspace-networking --state="$STATE/state.json" --socket=/tmp/ts.sock > /tmp/tailscaled.log 2>&1 < /dev/null &
  for i in $(seq 1 20); do sleep 0.5; [ -S /tmp/ts.sock ] && break; done
fi

# 2) تسجيل الدخول للشبكة (أول مرة بالمفتاح — بعدها بالهوية المحفوظة)
if ! $TS status >/dev/null 2>&1; then
  KEY=$(cat "$BASE/data/ts-authkey" 2>/dev/null || true)
  if [ -z "$KEY" ]; then echo "ERROR: no auth key — ضع المفتاح في data/ts-authkey"; exit 1; fi
  $TS up --authkey="$KEY" --hostname=meem-studio
fi

# 3) Funnel على بورت 3000
$TS funnel --bg 3000
sleep 2
echo "---- حالة الـ Funnel ----"
$TS funnel status
echo "الرابط الدائم شكله: https://meem-studio.xxxx.ts.net"
