/* ============================================================
   MEEM | Creative Office — Phase 6: Time Tracker
   تايمر حي لكل مهمة + إدخال يدوي + مجاميع ساعات (عضو/مشروع)
   ============================================================ */
import { state, save, remove, userById } from '../store.js';
import { el, icon, clear, escapeHTML, toast, confirmDialog, modal } from '../ui.js';

const fmtDur = (mins) => {
  const h = Math.floor(mins / 60), m = Math.round(mins % 60);
  return h ? `${h}س ${m}د` : `${m}د`;
};
const fmtClock = (ms) => {
  const s = Math.floor(ms / 1000);
  return `${String(Math.floor(s / 3600)).padStart(2, '0')}:${String(Math.floor((s % 3600) / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
};
const startOfMonth = () => new Date().toISOString().slice(0, 7);
const startOfWeek = () => { const d = new Date(); const day = (d.getDay() + 1) % 7; d.setDate(d.getDate() - day); return d.toISOString().slice(0, 10); };

/* حالة التايمر على مستوى الموديول — تعيش بعد إعادة التصيير (أي حفظ بيعمل re-render) */
let run = null; // { taskId, startedAt }

export function renderTime(host) {
  host.innerHTML = '';
  host.setAttribute('data-live', '1');
  host.appendChild(el('div', { class: 'page-head' }, [
    el('div', {}, [
      el('h1', { html: icon('clock') + ' تتبع الوقت', style: { display: 'flex', alignItems: 'center', gap: '10px' } }),
      el('div', { class: 'ph-sub', text: 'شغّل تايمر على المهمة اللي شغال عليها — والساعات بتتجمع لكل عضو ومشروع' }),
    ]),
    el('button', { class: 'btn', html: icon('plus') + `<span>إدخال يدوي</span>`, onclick: () => openEntryModal(draw) }),
  ]));
  const area = el('div');
  host.appendChild(area);

  /* --------- التايمر الحي --------- */
  const openTasks = (state.tasks || []).filter((t) => !['done', 'delivered'].includes(t.status));
  const taskSel = el('select', { class: 'select', style: { maxWidth: '360px' }, html: openTasks.map((t) => { const p = (state.projects || []).find((x) => x.id === t.projectId); return `<option value="${t.id}">${escapeHTML(t.title)}${p ? ' — ' + escapeHTML(p.title) : ''}</option>`; }).join('') });
  const clock = el('div', { class: 'tt-clock num', text: '00:00:00' });
  let tick = null;
  const btn = el('button', { class: 'btn ok', style: { minWidth: '110px' }, html: icon('play') + `<span>ابدأ</span>` });
  function paintRunning() {
    if (run) {
      if (taskSel.querySelector(`option[value="${run.taskId}"]`)) taskSel.value = run.taskId;
      btn.className = 'btn danger';
      btn.innerHTML = icon('stop') + `<span>إنهاء وحفظ</span>`;
      clock.textContent = fmtClock(Date.now() - run.startedAt);
      clearInterval(tick);
      tick = setInterval(() => {
        if (!run || !document.contains(clock)) { clearInterval(tick); return; }
        clock.textContent = fmtClock(Date.now() - run.startedAt);
      }, 1000);
    }
  }
  btn.onclick = async () => {
    if (!run) {
      if (!taskSel.value) { toast('اختار مهمة', 'warn'); return; }
      run = { taskId: taskSel.value, startedAt: Date.now() };
      paintRunning();
    } else {
      clearInterval(tick);
      const mins = Math.max(1, Math.round((Date.now() - run.startedAt) / 60000));
      const t = (state.tasks || []).find((x) => x.id === run.taskId);
      const startedAt = run.startedAt;
      run = null;
      await save('timeentries', {
        taskId: t ? t.id : '', taskTitle: t ? t.title : '', projectId: t ? t.projectId : '',
        userId: state.user.id, start: new Date(startedAt).toISOString(), end: new Date().toISOString(), mins, note: 'تايمر',
      });
      clock.textContent = '00:00:00';
      btn.className = 'btn ok';
      btn.innerHTML = icon('play') + `<span>ابدأ</span>`;
      toast(`اتسجلت ${fmtDur(mins)} ✓`, 'ok');
      draw();
    }
  };
  paintRunning();

  function draw() {
    clear(area);
    area.appendChild(el('div', { class: 'card tt-timer', style: { marginBottom: '12px' } }, [
      el('div', {}, [el('div', { class: 'dim', style: { fontSize: '12px', marginBottom: '5px' }, text: 'المهمة' }), taskSel]),
      clock, btn,
    ]));

    const m = startOfMonth();
    const wk = startOfWeek();
    const mine = (state.timeentries || []).filter((e) => e.userId === state.user.id);
    const monthAll = (state.timeentries || []).filter((e) => (e.start || '').slice(0, 7) === m);
    const kpis = el('div', { class: 'kpis', style: { marginBottom: '12px' } }, [
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'ساعاتي (الأسبوع)' }), el('div', { class: 'k-value num', text: fmtDur(mine.filter((e) => (e.start || '').slice(0, 10) >= wk).reduce((s, e) => s + (+e.mins || 0), 0)) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'ساعاتي (الشهر)' }), el('div', { class: 'k-value num', text: fmtDur(mine.filter((e) => (e.start || '').slice(0, 7) === m).reduce((s, e) => s + (+e.mins || 0), 0)) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'ساعات الفريق (الشهر)' }), el('div', { class: 'k-value num', text: fmtDur(monthAll.reduce((s, e) => s + (+e.mins || 0), 0)) })]),
      el('div', { class: 'kpi' }, [el('div', { class: 'k-label', text: 'إدخالات (الشهر)' }), el('div', { class: 'k-value num', text: String(monthAll.length) })]),
    ]);
    area.appendChild(kpis);

    /* مجاميع لكل عضو */
    const byUser = {};
    monthAll.forEach((e) => { byUser[e.userId] = (byUser[e.userId] || 0) + (+e.mins || 0); });
    const rows = Object.entries(byUser).sort((a, b) => b[1] - a[1]);
    const maxM = Math.max(1, ...rows.map((r) => r[1]));
    const usersBox = el('div', { class: 'ct-panel', style: { marginBottom: '12px' } }, [el('div', { class: 'ct-panel-title', text: '👥 ساعات الفريق (الشهر)' })]);
    if (!rows.length) usersBox.appendChild(el('div', { class: 'dim', style: { fontSize: '12.5px' }, text: 'لسه مفيش ساعات مسجلة الشهر ده' }));
    rows.forEach(([uid, mins]) => {
      const u = userById(uid);
      usersBox.appendChild(el('div', { class: 'tt-row' }, [
        el('span', { style: { fontSize: '12.5px', minWidth: '120px' }, text: u ? u.name : uid }),
        el('div', { class: 'pbar grow' }, [el('i', { style: { width: Math.round((mins / maxM) * 100) + '%' } })]),
        el('span', { class: 'num dim', style: { fontSize: '12px', minWidth: '70px', textAlign: 'left' }, text: fmtDur(mins) }),
      ]));
    });
    area.appendChild(usersBox);

    /* الجدول */
    const list = [...(state.timeentries || [])].sort((a, b) => (b.start || '').localeCompare(a.start || ''));
    const tbl = el('div', { class: 'fin-table' });
    tbl.appendChild(el('div', { class: 'fin-tr fin-th' }, [el('span', { text: 'التاريخ' }), el('span', { text: 'المهمة' }), el('span', { text: 'العضو' }), el('span', { text: 'المدة' }), el('span', { text: '' })]));
    list.slice(0, 40).forEach((e) => {
      const u = userById(e.userId);
      tbl.appendChild(el('div', { class: 'fin-tr' }, [
        el('span', { class: 'num dim', text: e.start ? (e.start.slice(0, 16).replace('T', ' ') + (e.end ? ' ← ' + e.end.slice(11, 16) : '')) : ((e.date || '') + ' · سجل قديم') }), /* FIX-5 legacy */
        el('span', { text: e.taskTitle || '—' }),
        el('span', { class: 'dim', text: u ? u.name : '—' }),
        el('span', { class: 'num', style: { fontWeight: '700' }, text: fmtDur(e.mins) }),
        el('span', {}, [el('button', { class: 'btn ghost icon sm', html: icon('trash'), onclick: async () => { if (await confirmDialog('حذف الإدخال؟')) { await remove('timeentries', e.id); draw(); } } })]),
      ]));
    });
    area.appendChild(el('div', { class: 'ct-panel' }, [el('div', { class: 'ct-panel-title', text: '📋 الإدخالات' }), tbl]));
  }
  draw();
}

function openEntryModal(onDone) {
  /* FIX-5: إدخال يدوي كامل — مهمة/اسم/مشروع/قسم/تاريخ/بداية/نهاية/إجمالي(تلقائي)/ملاحظة */
  const tasks = state.tasks || [];
  const projects = state.projects || [];
  const DEPTS = [['design', 'التصميم'], ['content', 'المحتوى'], ['voice', 'الصوت'], ['dev', 'التطوير'], ['cs', 'خدمة العملاء'], ['other', 'أخرى']];
  const doc = { taskId: '', taskName: '', projectId: '', dept: '', userId: state.user.id, date: new Date().toISOString().slice(0, 10), startT: '', endT: '', mins: 0, note: '', manualMins: false };
  const taskSel = el('select', { class: 'select', html: '<option value="">— بدون مهمة (اسم يدوي) —</option>' + tasks.map((t) => `<option value="${t.id}">${escapeHTML(t.title)}</option>`).join('') });
  const nameIn = el('input', { class: 'input', placeholder: 'اسم المهمة يدويًا' });
  const prjSel = el('select', { class: 'select', html: '<option value="">—</option>' + projects.map((p2) => `<option value="${p2.id}">${escapeHTML(p2.title)}</option>`).join('') });
  const deptSel = el('select', { class: 'select', html: '<option value="">—</option>' + DEPTS.map(([v, l]) => `<option value="${v}">${l}</option>`).join('') });
  const dateIn = el('input', { class: 'input', type: 'date', value: doc.date });
  const startIn = el('input', { class: 'input', type: 'time' });
  const endIn = el('input', { class: 'input', type: 'time' });
  const minsIn = el('input', { class: 'input num', type: 'number', min: '0', placeholder: 'تلقائي من البداية/النهاية' });
  const noteIn = el('input', { class: 'input', placeholder: 'ملاحظة' });
  function recalc() {
    if (doc.manualMins) return;
    if (startIn.value && endIn.value) {
      let mins = (new Date('2000-01-01T' + endIn.value) - new Date('2000-01-01T' + startIn.value)) / 60000;
      if (mins < 0) mins += 24 * 60; /* عبر منتصف الليل */
      minsIn.value = Math.round(mins);
    }
  }
  taskSel.onchange = (e) => {
    doc.taskId = e.target.value;
    const t = tasks.find((x) => x.id === doc.taskId);
    if (t) { nameIn.value = t.title; prjSel.value = t.projectId || ''; doc.dept = t.dept || ''; deptSel.value = t.dept || ''; }
  };
  startIn.oninput = recalc; endIn.oninput = recalc;
  minsIn.oninput = () => { doc.manualMins = true; };
  const m = modal({
    title: '⏱ إدخال ساعات يدوي',
    body: [
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'المهمة' }), taskSel]),
        el('div', { class: 'field' }, [el('label', { text: 'اسم المهمة' }), nameIn]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'المشروع' }), prjSel]),
        el('div', { class: 'field' }, [el('label', { text: 'القسم' }), deptSel]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'التاريخ' }), dateIn]),
        el('div', { class: 'field' }, [el('label', { text: 'الملاحظة' }), noteIn]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'بداية (يدوي)' }), startIn]),
        el('div', { class: 'field' }, [el('label', { text: 'نهاية (يدوي)' }), endIn]),
      ]),
      el('div', { class: 'grid2' }, [
        el('div', { class: 'field' }, [el('label', { text: 'الإجمالي (دقائق) — تلقائي وقابل للتعديل' }), minsIn]),
        state.user.role === 'admin' ? el('div', { class: 'field' }, [el('label', { text: 'العضو' }), el('select', { class: 'select', html: (state.users || []).filter((u) => u.role !== 'client').map((u) => `<option value="${u.id}" ${u.id === doc.userId ? 'selected' : ''}>${escapeHTML(u.name)}</option>`).join(''), onchange: (e) => { doc.userId = e.target.value; } })]) : null,
      ].filter(Boolean)),
    ],
    footer: [
      el('button', { class: 'btn ghost', text: 'إلغاء', onclick: () => m.close() }),
      el('button', {
        class: 'btn primary', text: 'حفظ',
        onclick: async () => {
          const mins = +minsIn.value || 0;
          if (mins <= 0) { toast('اكتب مدة (أو بداية/نهاية)', 'warn'); return; }
          const name = (nameIn.value || '').trim() || 'بدون اسم'; /* FIX-5: اختياري زي السلوك القديم */
          /* FIX-5: start/end حقيقيين لو اتدخلوا — مفيش اختراع أوقات */
          const entry = {
            taskId: taskSel.value || '', taskTitle: name,
            projectId: prjSel.value || '', dept: deptSel.value || '',
            userId: doc.userId, date: dateIn.value, mins, note: noteIn.value,
          };
          if (startIn.value) entry.start = dateIn.value + 'T' + startIn.value + ':00.000Z';
          if (endIn.value) entry.end = dateIn.value + 'T' + endIn.value + ':00.000Z';
          await save('timeentries', entry);
          m.close(); toast('اتسجلت ✓', 'ok'); onDone();
        },
      }),
    ],
  });
}
