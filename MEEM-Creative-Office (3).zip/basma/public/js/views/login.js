/* ============================================================
   MEEM | Creative Office — شاشة الدخول
   ============================================================ */
import { t, getLang, setLang } from '../i18n.js';
import { login, state } from '../store.js';
import { rememberCreds } from '../api.js';
import { el, icon, clear, toast, avatarHTML } from '../ui.js';

const DEMO = [
  { email: 'admin@meem.studio', role: ['المدير العام', 'General Manager'], icon: 'star' },
  { email: 'designer@meem.studio', role: ['مصممة جرافيك (ميم)', 'Graphic Designer'], icon: 'design' },
  { email: 'content@meem.studio', role: ['كاتب محتوى', 'Copywriter'], icon: 'content' },
  { email: 'voice@meem.studio', role: ['فويس أوفر', 'Voice Over'], icon: 'voice' },
  { email: 'cs@meem.studio', role: ['خدمة عملاء وتسليمات', 'Client Success'], icon: 'delivery' },
  { email: 'dev@meem.studio', role: ['مطوّر', 'Developer'], icon: 'code' },
];

export function renderLogin() {
  const root = document.getElementById('app');
  root.hidden = false;
  clear(root);

  const email = el('input', { class: 'input', type: 'email', value: 'designer@meem.studio', autocomplete: 'username', placeholder: 'name@meem.studio' });
  const pass = el('input', { class: 'input', type: 'password', value: '123456', autocomplete: 'current-password', placeholder: '••••••' });
  const btn = el('button', { class: 'btn primary lg block', html: icon('logout') + `<span>${t('signIn')}</span>` });
  const errBox = el('div', { class: 'badge danger hide' });

  async function submit() {
    btn.disabled = true;
    btn.innerHTML = `<span class="spin">${icon('refresh')}</span>`;
    errBox.classList.add('hide');
    try {
      const user = await login(email.value.trim(), pass.value);
      rememberCreds(email.value.trim(), pass.value);
      toast(`${t('hi')} ${getLang() === 'ar' ? user.name : user.nameEn} 👋`, 'ok');
      location.hash = user.role === 'client' ? '#/portal' : user.role === 'superadmin' ? '#/owner' : '#/office';
      location.reload();
    } catch (e) {
      errBox.textContent = getLang() === 'ar' ? (e.message || 'خطأ') : (e.message || 'Error');
      errBox.classList.remove('hide');
    } finally {
      btn.disabled = false;
      btn.innerHTML = icon('logout') + `<span>${t('signIn')}</span>`;
    }
  }

  btn.addEventListener('click', submit);
  [email, pass].forEach((n) => n.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); }));

  const demoList = el('div', { class: 'demo-list' });
  DEMO.forEach((d) => {
    demoList.appendChild(el('button', {
      class: 'demo-item', type: 'button',
      onclick: () => { email.value = d.email; pass.value = '123456'; email.focus(); },
    }, [
      el('span', { style: { color: 'var(--brand)', display: 'grid' }, html: icon(d.icon) }),
      el('span', { class: 'grow' }, [
        el('div', { style: { fontSize: '13px', fontWeight: '600' }, text: d.email.replace('@meem.studio', '') }),
        el('div', { class: 'di-role', text: getLang() === 'ar' ? d.role[0] : d.role[1] }),
      ]),
      el('span', { class: 'kbd', text: '123456' }),
    ]));
  });

  /* V4-6: هوية الموقع من الإعدادات (راوت عام) */
  const titleH1 = el('h1', { text: t('loginTitle'), style: { fontSize: '24px', marginTop: '6px' } });
  const subP = el('p', { class: 'muted', text: t('loginSub'), style: { fontSize: '13.5px', marginBottom: '18px' } });
  fetch('/api/brand').then((r) => r.json()).then((j) => {
    const b = j.brand || {};
    if (b.logo && window.__loginLogo) { clear(window.__loginLogo); window.__loginLogo.appendChild(el('img', { src: b.logo, alt: '', style: { width: '100%', height: '100%', objectFit: 'contain', borderRadius: '10px' } })); } /* FIX-3 */
    if (b.loginTitle) titleH1.textContent = b.loginTitle;
    if (b.loginSub) subP.textContent = b.loginSub;
    if (b.primary) document.documentElement.style.setProperty('--brand', b.primary);
    if (b.browserTitle) document.title = b.browserTitle; /* FIX-3 */
    if (b.favicon) { let li = document.querySelector("link[rel~='icon']"); if (!li) { li = document.createElement('link'); li.rel = 'icon'; document.head.appendChild(li); } li.href = b.favicon; }
  }).catch(() => {});

  root.appendChild(el('div', { class: 'login-wrap' }, [
    el('div', { class: 'login-card' }, [
      el('div', { class: 'row', style: { justifyContent: 'space-between' } }, [
        (() => { const L = el('div', { class: 'login-logo', text: 'M' }); window.__loginLogo = L; return L; })(),
        el('button', {
          class: 'btn ghost sm', html: icon('globe') + `<span>${getLang() === 'ar' ? 'English' : 'عربي'}</span>`,
          onclick: () => setLang(getLang() === 'ar' ? 'en' : 'ar'),
        }),
      ]),
      titleH1,
      subP,
      el('div', { class: 'field', style: { marginBottom: '12px' } }, [el('label', { text: t('email') }), email]),
      el('div', { class: 'field', style: { marginBottom: '14px' } }, [el('label', { text: t('password') }), pass]),
      errBox,
      btn,
      el('hr', { class: 'divider' }),
      el('div', { class: 'dim', text: t('demoAccounts'), style: { fontSize: '12px', marginBottom: '9px' } }),
      demoList,
    ]),
  ]));
}
