/* ============================================================
   MEEM | Creative Office — الهيكل (Sidebar + Topbar)
   ============================================================ */
import { t, getLang, setLang, bi } from './i18n.js';
import { state, logout, deptStats, isOverdue, subscribe, userById, unreadNotes, markNotesRead, markOneNotifRead, brandDoc } from './store.js';
import { openDM } from './views/chat.js';
import { api } from './api.js';
import { el, icon, avatarHTML, clear, escapeHTML, toast, modal, timeAgo } from './ui.js';
import { openTaskModal } from './taskform.js';
import { lookEditor, defaultLook, photoPicker } from './look.js';
import { openNewMeetingModal } from './views/meetings.js';

const NAV = [
  { group: 'nav_workspace', items: [
    { key: 'office', title: 'المكتب', icon: 'grid' },
    { key: 'dashboard', title: 'nav_dashboard', icon: 'dashboard' },
  ] },
  {
    group: 'nav_workspace',
    items: [
      { key: 'projects', title: 'المشاريع', icon: 'kanban' },
      { key: 'tasks', title: 'المهام', icon: 'check' },
      { key: 'content', title: 'nav_content', icon: 'content', roles: ['content', 'editor', 'admin', 'superadmin'] },
      { key: 'voice', title: 'nav_voice', icon: 'voice', roles: ['voice', 'editor', 'admin', 'superadmin'] },
      { key: 'video', title: 'استوديو الفيديو', icon: 'code' },
      { key: 'photo', title: 'التصوير', icon: 'image', roles: ['designer', 'admin', 'superadmin'] },
      { key: 'design', title: 'nav_design', icon: 'design', roles: ['designer', 'admin', 'superadmin'] },
      { key: 'delivery', title: 'nav_delivery', icon: 'delivery' },
      { key: 'dev', title: 'nav_dev', icon: 'code', roles: ['dev', 'admin', 'superadmin'] },
    ],
  },
  {
    group: 'التنظيم',
    items: [
      { key: 'chat', title: 'الدردشة', icon: 'chat' },
      { key: 'requests', title: 'الطلبات', icon: 'bell', roles: ['cs', 'admin', 'superadmin'] },
      { key: 'calendar', title: 'التقويم', icon: 'calendar' },
      { key: 'activity', title: 'سجل النشاط', icon: 'clock', admin: true },
    ],
  },
  {
    group: 'الإدارة',
    items: [
      { key: 'reports', title: 'التقارير', icon: 'target', admin: true },
      { key: 'finance', title: 'المالية', icon: 'money', admin: true },
      { key: 'time', title: 'تتبع الوقت', icon: 'clock' },
      { key: 'marketing', title: 'التسويق', icon: 'sparkles', admin: true },
      { key: 'kb', title: 'المعرفة', icon: 'template' },
    ],
  },
  {
    group: 'nav_admin',
    items: [
      { key: 'meetings', title: 'nav_meet', icon: 'meet' },
      { key: 'clients', title: 'nav_clients', icon: 'clients', roles: ['cs', 'admin', 'superadmin'] },
      { key: 'assets', title: 'nav_files', icon: 'folder' },
      { key: 'automation', title: 'الأتمتة', icon: 'bolt', admin: true },
      { key: 'team', title: 'nav_team', icon: 'users', admin: true },
    ],
  },
];

/* V2-3: قائمة المالك المخفي — منفصلة تمامًا */
const NAV_OWNER = [
  { group: 'MEE M CONTROL', items: [{ key: 'owner', title: 'لوحة المالك', icon: 'lock' }] },
];

const NAV_CLIENT = [
  { group: 'مساحتك', items: [
    { key: 'portal', title: 'لوحتي', icon: 'dashboard' },
    { key: 'projects', title: 'مشاريعي', icon: 'kanban' },
    { key: 'chat', title: 'الدردشة', icon: 'chat' },
  ] },
];

function applyTheme() {
  const theme = localStorage.getItem('basma_theme') || 'dark';
  document.documentElement.dataset.theme = theme;
}

export function renderShell(root, { onNav }) {
  applyTheme();
  clear(root);

  const sidebar = el('aside', { class: 'sidebar', id: 'sidebar' });
  const content = el('main', { class: 'view' });
  const main = el('div', { class: 'main' });
  const topbar = el('header', { class: 'topbar' });
  main.append(topbar, content);

  const shellEl = el('div', { class: 'shell' }, [sidebar, main]);
  root.appendChild(shellEl);

  /* ---------- sidebar ---------- */
  const sideLogo = el('div', { class: 'side-logo', text: 'M' });
  const paintLogo = () => { /* FIX-3 */
    const lg = brandDoc().logo;
    clear(sideLogo);
    if (lg) sideLogo.appendChild(el('img', { src: lg, alt: '', style: { width: '100%', height: '100%', objectFit: 'contain', borderRadius: '8px' } }));
    else sideLogo.textContent = 'M';
  };
  paintLogo();
  const sideTitle = el('div', { class: 'side-title', text: brandDoc().siteName || (t('appName') + ' | Creative Office') });
  const sideSub = el('div', { class: 'side-sub', text: brandDoc().tagline || t('appSub') });
  subscribe((w) => { /* V4-6: الهوية الحية */
    if (w === 'state' || w === 'settings') {
      const b = brandDoc();
      sideTitle.textContent = b.siteName || (t('appName') + ' | Creative Office');
      sideSub.textContent = b.tagline || t('appSub');
      paintLogo();
    }
  });
  sidebar.appendChild(el('div', { class: 'side-head' }, [
    sideLogo,
    el('div', { class: 'grow' }, [
      sideTitle,
      sideSub,
    ]),
    el('button', {
      class: 'btn ghost icon sm mobile-only', onclick: () => sidebar.classList.remove('open'), html: icon('close'),
    }),
  ]));

  const nav = el('nav', { class: 'side-nav' });
  sidebar.appendChild(nav);

  /* V2-9: الرسائل المباشرة في السايدبار */
  const dmBox = el('div', { class: 'side-dms' });
  sidebar.appendChild(dmBox);
  function buildDMs() {
    clear(dmBox);
    if (!state.user || state.user.role === 'client' || state.user.role === 'superadmin') return;
    const on = new Set(state.online || []);
    const partners = [...new Set((state.chats || [])
      .filter((m) => m.room && m.room.startsWith('dm:') && m.room.includes(state.user.id))
      .map((m) => m.room.split(':').slice(1).find((id) => id !== state.user.id)))]
      .map((id) => userById(id)).filter(Boolean);
    if (!partners.length) return;
    dmBox.appendChild(el('div', { class: 'ng-title', text: getLang() === 'ar' ? 'رسائل مباشرة' : 'Direct Messages' }));
    partners.forEach((u) => {
      dmBox.appendChild(el('button', {
        class: 'dm-item',
        onclick: () => { sidebar.classList.remove('open'); document.querySelector('.side-scrim')?.remove(); openDM(u.id); },
      }, [
        el('span', { class: 'dm-av', html: avatarHTML(u, 'sm') }),
        el('span', { class: 'grow', text: u.name }),
        el('span', { class: 'dm-dot' + (on.has(u.id) ? ' on' : '') }),
      ]));
    });
  }
  buildDMs();
  subscribe((what) => { if (what === 'chats' || what === 'presence') buildDMs(); });

  const counts = () => {
    const ds = deptStats();
    return {
      content: ds.content.open,
      voice: ds.voice.open,
      design: ds.design.open,
      delivery: ds.delivery.open,
      dev: ds.dev.open,
      projects: (state.projects || []).filter((p) => !['done', 'delivered'].includes(p.status)).length,
      requests: (state.requests || []).filter((r) => r.status === 'new').length,
    };
  };

  function buildNav() {
    clear(nav);
    const c = counts();
    /* V2-2: فلترة القائمة حسب الدور (والحماية الحقيقية server-side في perms.js) */
    const me = state.user.role;
    const isAdm = me === 'admin' || me === 'superadmin';
    /* V2-3: الفيديو/الاجتماعات مخفية عن الفريق إلا لو المالك أتاحها من Tools */
    const td = (state.settings || []).find((x) => x.id === 'tools') || {};
    const toolsOn = (k) => me === 'superadmin' || td[k] !== false;
    const groups = (me === 'client' ? NAV_CLIENT : me === 'superadmin' ? NAV_OWNER : NAV)
      .map((g) => ({ group: g.group, items: g.items.filter((it) => (!it.admin || isAdm) && (!it.roles || it.roles.includes(me)) && ((it.key !== 'video' && it.key !== 'meetings') || toolsOn('video'))) }))
      .filter((g) => g.items.length);
    let title = '';
    groups.forEach((group) => {
      if (group.group !== title) {
        title = group.group;
        nav.appendChild(el('div', { class: 'ng-title', text: t(title) }, null));
        nav.lastChild.className = 'nav-group';
        clear(nav.lastChild);
        nav.lastChild.appendChild(el('div', { class: 'ng-title', text: t(title) }));
      }
      const wrap = nav.lastChild;
      group.items.forEach((item) => {
        const btn = el('button', {
          class: 'nav-item', dataset: { nav: item.key },
          onclick: () => {
            sidebar.classList.remove('open');
            document.querySelector('.side-scrim')?.remove();
            location.hash = '#/' + item.key;
          },
        }, [
          el('span', { html: icon(item.icon) }),
          el('span', { class: 'grow', text: t(item.title) }),
        ]);
        if (c[item.key]) btn.appendChild(el('span', { class: 'ni-count num', text: String(c[item.key]) }));
        wrap.appendChild(btn);
      });
    });
  }

  /* ---------- user chip ---------- */
  const user = state.user;
  const chipAv = el('div', { html: avatarHTML(user) });
  /* V4-2: الكيش يتحدث لما يتغير المظهر/الصورة */
  subscribe((w) => { if (w === 'state') chipAv.innerHTML = avatarHTML(state.user); });
  sidebar.appendChild(el('div', { class: 'side-foot' }, [
    el('div', { class: 'user-chip', title: 'البروفايل', onclick: () => openProfile() }, [
      chipAv,
      el('div', { class: 'grow' }, [
        el('div', { class: 'uc-name', text: getLang() === 'ar' ? user.name : (user.nameEn || user.name) }),
        el('div', { class: 'uc-role', text: getLang() === 'ar' ? user.title : (user.titleEn || user.title) }),
      ]),
      el('button', {
        class: 'btn ghost icon sm', title: t('logout'), html: icon('logout'),
        onclick: (e) => { e.stopPropagation(); logout(); },
      }),
    ]),
  ]));

  /* V2-9 + V4-2: بروفايل الموظف — كلمة المرور + المظهر والأفاتار */
  function openProfile() {
    const AR = getLang() === 'ar';
    const cur = el('input', { class: 'input', type: 'password', placeholder: AR ? 'كلمة المرور الحالية' : 'Current password' });
    const nxt = el('input', { class: 'input', type: 'password', placeholder: AR ? 'الجديدة (6 حروف على الأقل)' : 'New password (6+ chars)' });
    const rep = el('input', { class: 'input', type: 'password', placeholder: AR ? 'أكد الجديدة' : 'Confirm new password' });
    const headAv = el('div', { html: avatarHTML(state.user) });
    const lookEd = lookEditor(defaultLook(state.user));
    const pp = photoPicker(async (url) => {
      try {
        await api.saveLook({ photo: url });
        state.user.photo = url;
        headAv.innerHTML = avatarHTML(state.user);
      } catch (e) { toast(e.message || 'failed', 'err'); }
    });
    const m = modal({
      title: AR ? '👤 البروفايل' : '👤 Profile',
      size: 'wide',
      body: el('div', { class: 'col', style: { gap: '12px' } }, [
        el('div', { class: 'row', style: { gap: '12px', alignItems: 'center' } }, [
          headAv,
          el('div', { class: 'grow' }, [
            el('div', { style: { fontWeight: '800' }, text: state.user.name }),
            el('div', { class: 'dim', style: { fontSize: '12px' }, text: state.user.email }),
            el('div', { class: 'badge', style: { marginTop: '4px' }, text: state.user.title || state.user.role }),
          ]),
          pp.btn, pp.inp,
        ]),
        el('div', { class: 'ed-sec-title', style: { margin: '0' }, text: AR ? '🎨 مظهري في المكتب' : '🎨 My office look' }),
        lookEd.node,
        el('button', {
          class: 'btn primary sm', text: AR ? 'حفظ المظهر' : 'Save look',
          onclick: async () => {
            try {
              await api.saveLook({ avatar: lookEd.get() });
              toast(AR ? 'مظهرك اتحدّث في المكتب ✓' : 'Look updated ✓', 'ok');
            } catch (e) { toast(e.message || 'failed', 'err'); }
          },
        }),
        /* FIX-4: النبذة والمهارات — الموظف يعدّلهم بنفسه */
        el('div', { class: 'ed-sec-title', style: { margin: '0' }, text: AR ? '📝 النبذة والمهارات' : '📝 Bio & Skills' }),
        (() => {
          const bioIn = el('textarea', { class: 'input', rows: '2', placeholder: AR ? 'نبذة عنك (اختياري)' : 'Short bio (optional)' });
          bioIn.value = state.user.bio || '';
          const skIn = el('input', { class: 'input', placeholder: AR ? 'المهارات مفصولة بفواصل: Graphic Design, Video Editing…' : 'Skills, comma separated' });
          skIn.value = (state.user.skills || []).join(', ');
          const saveBtn = el('button', {
            class: 'btn sm', text: AR ? 'حفظ النبذة والمهارات' : 'Save bio & skills',
            onclick: async () => {
              try {
                const doc = await api.user({ id: state.user.id, bio: bioIn.value.trim(), skills: skIn.value.split(',').map((x) => x.trim()).filter(Boolean) });
                state.user.bio = doc.bio; state.user.skills = doc.skills;
                toast(AR ? 'البروفايل اتحدّث ✓' : 'Profile updated ✓', 'ok');
              } catch (e) { toast(e.message || 'failed', 'err'); }
            },
          });
          return el('div', { class: 'col', style: { gap: '8px' } }, [bioIn, skIn, el('div', {}, [saveBtn])]);
        })(),
        el('div', { class: 'ed-sec-title', style: { margin: '0' }, text: AR ? '🔑 تغيير كلمة المرور' : '🔑 Change Password' }),
        cur, nxt, rep,
      ]),
      footer: [
        el('button', { class: 'btn', text: AR ? 'إغلاق' : 'Close', onclick: () => m.close() }),
        el('button', { class: 'btn primary', text: AR ? 'حفظ' : 'Save', onclick: async () => {
          if (!cur.value || !nxt.value) { toast(AR ? 'كمل الخانات' : 'Fill all fields', 'err'); return; }
          if (nxt.value.length < 6) { toast(AR ? 'كلمة المرور قصيرة (6+)' : 'Password too short (6+)', 'err'); return; }
          if (nxt.value !== rep.value) { toast(AR ? 'التأكيد مش مطابق' : 'Passwords do not match', 'err'); return; }
          try {
            await api.changePassword(cur.value, nxt.value);
            m.close();
            toast(AR ? 'كلمة المرور اتغيرت ✓' : 'Password changed ✓', 'ok');
          } catch (e) { toast(e.message || (AR ? 'مفش' : 'Failed'), 'err'); }
        } }),
      ],
    });
  }

  /* ---------- V4-6: مركز أوامر Ctrl+K ---------- */
  let cmdkBack = null;
  function openCmdK() {
    if (cmdkBack) return;
    let sel = 0;
    let items = [];
    cmdkBack = el('div', { class: 'cmdk-back' });
    const inp = el('input', { class: 'cmdk-input', placeholder: 'ابحث: صفحات / مشاريع / مهام / فريق…' });
    const listBox = el('div', { class: 'cmdk-list' });
    const box = el('div', { class: 'cmdk-box' }, [inp, listBox]);
    cmdkBack.appendChild(box);
    cmdkBack.addEventListener('mousedown', (e) => { if (e.target === cmdkBack) closeCmdK(); });
    function closeCmdK() { if (cmdkBack) { cmdkBack.remove(); cmdkBack = null; } }
    function sources() {
      const out = [];
      const groups = state.user && state.user.role === 'client' ? NAV_CLIENT : (state.user && state.user.role === 'superadmin' ? NAV_OWNER : NAV);
      groups.forEach((g) => (g.items || []).forEach((it) => {
        if (it.roles && !it.roles.includes(state.user.role)) return;
        out.push({ icon: '📄', label: it.title, sub: 'صفحة', go: () => { location.hash = '#/' + it.key; } });
      }));
      (state.projects || []).forEach((pp) => out.push({ icon: '📁', label: pp.title, sub: 'مشروع', go: () => { location.hash = '#/projects/' + pp.id; } }));
      (state.tasks || []).slice(-60).reverse().forEach((tt) => out.push({ icon: '✅', label: tt.title, sub: 'مهمة', go: () => { location.hash = '#/tasks'; } }));
      (state.users || []).filter((u) => u.role !== 'superadmin').forEach((u) => out.push({ icon: '👤', label: u.name, sub: u.role, go: () => { openDM(u.id); } }));
      return out;
    }
    function draw() {
      const q = inp.value.trim().toLowerCase();
      items = sources().filter((x) => !q || x.label.toLowerCase().includes(q) || String(x.sub || '').toLowerCase().includes(q)).slice(0, 12);
      if (sel > items.length - 1) sel = Math.max(0, items.length - 1);
      clear(listBox);
      if (!items.length) listBox.appendChild(el('div', { class: 'dim', style: { padding: '14px' }, text: 'مفيش نتائج' }));
      items.forEach((x, idx) => listBox.appendChild(el('button', {
        class: 'cmdk-item' + (idx === sel ? ' sel' : ''),
        onclick: () => { closeCmdK(); x.go(); },
      }, [el('span', { text: x.icon }), el('span', { class: 'grow', text: x.label }), el('span', { class: 'dim', style: { fontSize: '11px' }, text: x.sub || '' })])));
    }
    inp.addEventListener('input', () => { sel = 0; draw(); });
    inp.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown') { sel = Math.min(sel + 1, items.length - 1); draw(); e.preventDefault(); }
      else if (e.key === 'ArrowUp') { sel = Math.max(sel - 1, 0); draw(); e.preventDefault(); }
      else if (e.key === 'Enter' && items[sel]) { closeCmdK(); items[sel].go(); }
      else if (e.key === 'Escape') closeCmdK();
    });
    draw();
    document.body.appendChild(cmdkBack);
    inp.focus();
  }
  window.addEventListener('cmdk', openCmdK);

  /* ---------- topbar ---------- */
  const tbTitle = el('div', { class: 'tb-title', text: '' });
  const tbSub = el('div', { class: 'tb-sub', text: '' });
  const connDot = el('span', { class: 'conn-dot', title: 'realtime' });

  const search = el('div', { class: 'tb-search' }, [
    el('span', { html: icon('search') }),
    el('input', {
      class: 'input', placeholder: t('search') + '  (Ctrl+K)',
      oninput: (e) => window.dispatchEvent(new CustomEvent('global-search', { detail: e.target.value })),
    }),
  ]);

  /* ---------- V4-5: مركز الإشعارات ---------- */
  const bellBadge = el('span', { class: 'bell-badge num', text: '' });
  const bellBtn = el('button', { class: 'btn ghost icon bell-btn', title: 'الإشعارات', html: icon('bell') }, [bellBadge]);
  const notesPanel = el('div', { class: 'notes-panel' });
  notesPanel.style.display = 'none';
  function updateBell() {
    const n = unreadNotes();
    bellBadge.textContent = n ? String(n) : '';
    bellBadge.style.display = n ? 'grid' : 'none';
  }
  function drawNotes() {
    clear(notesPanel);
    notesPanel.appendChild(el('div', { class: 'between', style: { padding: '8px 10px', borderBottom: '1px solid var(--line)' } }, [
      el('b', { text: '🔔 الإشعارات' }),
      el('button', { class: 'btn ghost sm', text: 'تعليم الكل كمقروء', onclick: () => { markNotesRead(); drawNotes(); updateBell(); } }),
    ]));
    /* FIX-7: من السيرفر (state.notifs) */
    if (!(state.notifs || []).length) notesPanel.appendChild(el('div', { class: 'dim', style: { padding: '14px', fontSize: '12.5px' }, text: 'مفيش إشعارات لسه' }));
    (state.notifs || []).slice(0, 30).forEach((n) => {
      notesPanel.appendChild(el('button', {
        class: 'note-row' + (n.read ? '' : ' unread'),
        onclick: () => {
          markOneNotifRead(n.id);
          notesPanel.style.display = 'none';
          updateBell();
          if (n.link) location.hash = n.link;
        },
      }, [
        el('span', { text: n.icon || '🔔' }),
        el('div', { class: 'grow', style: { textAlign: 'start' } }, [
          el('div', { style: { fontSize: '12.5px' }, text: n.text }),
          el('div', { class: 'dim num', style: { fontSize: '10.5px' }, text: timeAgo(n.at) }),
        ]),
      ]));
    });
  }
  bellBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    const show = notesPanel.style.display === 'none';
    if (show) drawNotes();
    notesPanel.style.display = show ? 'block' : 'none';
  });
  notesPanel.addEventListener('click', (e) => e.stopPropagation());
  document.addEventListener('click', () => { notesPanel.style.display = 'none'; });
  subscribe((w) => { if (w === 'notes') updateBell(); });
  updateBell();

  topbar.append(...[
    el('button', {
      class: 'btn ghost icon sm mobile-only', html: icon('menu'),
      onclick: () => {
        sidebar.classList.add('open');
        if (!document.querySelector('.side-scrim')) {
          const scrim = el('div', { class: 'side-scrim', onclick: () => { sidebar.classList.remove('open'); scrim.remove(); } });
          document.body.appendChild(scrim);
        }
      },
    }),
    el('div', { class: 'col', style: { gap: '0' } }, [tbTitle, tbSub]),
    el('div', { class: 'grow' }),
    search,
    connDot,
    bellBtn,
    el('button', {
      class: 'btn ghost icon', title: t('language'), dataset: { act: 'lang' },
      html: icon('globe'),
      onclick: () => setLang(getLang() === 'ar' ? 'en' : 'ar'),
    }),
    el('button', {
      class: 'btn ghost icon', title: t('theme'), dataset: { act: 'theme' },
      html: icon(localStorage.getItem('basma_theme') === 'light' ? 'moon' : 'sun'),
      onclick: (e) => {
        const next = (localStorage.getItem('basma_theme') || 'dark') === 'dark' ? 'light' : 'dark';
        localStorage.setItem('basma_theme', next);
        applyTheme();
        e.currentTarget.innerHTML = icon(next === 'dark' ? 'sun' : 'moon');
      },
    }),
    user.role === 'client' ? undefined : el('button', {
      class: 'btn primary sm', html: icon('plus') + `<span>${t('newTask')}</span>`,
      onclick: () => openTaskModal(null, () => onNav && onNav()),
    }),
  ].filter(Boolean));
  topbar.append(notesPanel); /* V4-5 */

  buildNav();

  return {
    content,
    setActive(key) {
      buildNav();
      nav.querySelectorAll('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.nav === key));
    },
    setTitle(title, sub) { tbTitle.textContent = title; tbSub.textContent = sub || ''; },
    setConnection(on) {
      connDot.classList.toggle('off', !on);
      connDot.title = on ? t('meet_connected') : 'offline';
    },
    refreshNav: buildNav,
  };
}
