# Tailscale Funnel — إعداد الرابط الدائم (FIX-13)

> **مبدأ أمان: لا يوجد أي سر (secret) داخل الكود أو المستودع.** المفتاح يُقرأ وقت التشغيل فقط من البيئة أو من ملف محلي خارج النسخ.

## المتغير المطلوب

| البند | القيمة |
|---|---|
| **اسم المتغير** | `TS_AUTHKEY` |
| **الغرض** | مفتاح مصادقة Tailscale (Auth Key) يُستخدم **مرة واحدة** لتسجيل الجهاز على شبكة الـ tailnet عند أول `tailscale up` — بعدها تُحفظ الهوية في `data/ts-state/` ولا يعود المفتاح مطلوبًا |
| **أين يوضع** | في بيئة التشغيل التي تشغّل `tools/funnel-up.sh` (export في الجلسة أو في خدمة systemd/Process Manager) — **لا يوضع في الكود ولا في git** |
| **المستهلك (Consumer)** | `tools/funnel-up.sh` — السطر: `KEY="${TS_AUTHKEY:-$(cat data/ts-authkey ...)}"` ثم `$TS up --authkey="$KEY" --hostname=meem-studio` |
| **بديل ملف (اختياري)** | `data/ts-authkey` (ملف محلي — `data/` لا تُرفع للمستودع) يُقرأ تلقائيًا لو المتغير غير مُصدَّر |

## طريقة التصدير

```bash
# في جلسة التشغيل فقط (تضيع بعد الخروج — آمن)
export TS_AUTHKEY='tskey-auth-XXXX…XXXX'
bash tools/funnel-up.sh
```

أو ملف محلي:
```bash
echo 'tskey-auth-XXXX…XXXX' > data/ts-authkey
chmod 600 data/ts-authkey
bash tools/funnel-up.sh
```

## كيف يُنشأ المفتاح

1. Tailscale Admin Console → **Settings → Keys → Generate auth key**.
2. النوع: **Ephemeral** أو عادي — مرة واحدة تكفي لأن الهوية تُحفظ محليًا بعد التسجيل.
3. الصلاحيات المطلوبة: تسجيل جهاز جديد فقط (بدون صلاحيات إضافية).

## ما يحدث بعد التشغيل

- `tailscaled` يعمل userspace (بدون root) والحالة في `data/ts-state/state.json` — **الرابط لا يتغير بعد إعادة التشغيل** لأن الهوية محفوظة.
- `tailscale funnel --bg 3000` يفتح نفق HTTPS دائم على شكل:
  `https://meem-studio.<tailnet>.ts.net`
- Funnel يتطلب تفعيله من Admin Console → **Settings → HTTPS Certificates → Enable Funnel** (مرة واحدة لكل tailnet).

## ملاحظات

- لو ظهر `ERROR: no auth key` → المتغير غير مُصدَّر والملف غير موجود.
- لتغيير اسم الجهاز: `tailscale up --hostname=...` ثم أعد `funnel`.
- لإيقاف الرابط: `tools/tailscale --socket=/tmp/ts.sock funnel 3000 off`.
