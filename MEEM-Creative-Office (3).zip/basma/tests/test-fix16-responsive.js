/* FIX-16 — انحدار الاستجابة: موبايل 390×844 / تابلت بورتريه 768×1024 / تابلت لاندسكيب 1024×768 / ديسكتوب 1440×900
   يفحص: لا overflow أفقي، الواجهات الجديدة (أقسام/براندينج/إدخال ساعات/جرس الإشعارات) سليمة، المكتب 3D والجويستيك */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const GL = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];

const VIEWS = [
  ['موبايل 390×844', { width: 390, height: 844 }, true],
  ['تابلت بورتريه 768×1024', { width: 768, height: 1024 }, true],
  ['تابلت لاندسكيب 1024×768', { width: 1024, height: 768 }, false],
  ['ديسكتوب 1440×900', { width: 1440, height: 900 }, false],
];

async function login(page, email) {
  await page.waitForSelector('.login-card');
  await page.fill('input[type=email]', email);
  await page.fill('input[type=password]', '123456');
  await page.click('.login-card .btn.primary');
  await page.waitForTimeout(1200);
}
async function noHOverflow(page) {
  return page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 2);
}

(async () => {
  const b = await chromium.launch({ args: GL });
  for (const [label, vp, touch] of VIEWS) {
    const ctx = await b.newContext({ viewport: vp, hasTouch: touch, isMobile: touch, deviceScaleFactor: touch ? 2 : 1 });
    const p = await ctx.newPage();
    const errs = [];
    p.on('pageerror', (e) => errs.push(e.message.slice(0, 100)));

    /* ---- لوحة المالك (superadmin فقط): الأقسام + البراندينج + الخصوصية ---- */
    await p.goto(BASE + '/?r=' + label + Date.now(), { waitUntil: 'networkidle' });
    await login(p, 'owner@meem.studio');
    await p.goto(BASE + '/#/owner?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForTimeout(900);
    await p.locator('.owner-tab', { hasText: 'الإعدادات' }).click().catch(() => {});
    await p.waitForTimeout(700);
    ok(label + ': صفحة المالك بلا overflow', await noHOverflow(p));
    ok(label + ': بطاقة الأقسام ظاهرة', (await p.locator('.owner-card:has-text("الأقسام")').count()) >= 1);
    ok(label + ': بطاقة الهوية ظاهرة', (await p.locator('.owner-card:has-text("هوية الموقع")').count()) >= 1);
    ok(label + ': بطاقة الخصوصية ظاهرة', (await p.locator('.owner-card:has-text("الخصوصية")').count()) >= 1);

    /* مودال إدخال ساعات (FIX-5) من صفحة الوقت */
    await p.goto(BASE + '/#/time?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForTimeout(800);
    await p.click('.page-head .btn:has-text("إدخال يدوي")');
    await p.waitForSelector('.modal:has-text("إدخال ساعات")', { timeout: 5000 });
    await p.waitForTimeout(400);
    const modalFits = await p.evaluate(() => {
      const m = document.querySelector('.modal');
      if (!m) return false;
      const r = m.getBoundingClientRect();
      /* CSS: max-height 88vh + overflow-y auto — الشرط: المربع المرئي داخل الشاشة */
      return r.width <= window.innerWidth + 2 && r.height <= window.innerHeight + 2;
    });
    ok(label + ': مودال الإدخال اليدوي داخل الشاشة', modalFits);
    await p.keyboard.press('Escape').catch(() => {});
    await p.evaluate(() => { const x = document.querySelector('.modal .btn.ghost'); if (x) x.click(); });
    await p.waitForTimeout(300);

    /* جرس الإشعارات (FIX-7) */
    await p.goto(BASE + '/#/dashboard?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForTimeout(700);
    const bell = p.locator('.bell-btn, .top-bell, [title*="إشعار"]').first();
    if (await bell.count()) {
      await bell.click().catch(() => {});
      await p.waitForTimeout(500);
      ok(label + ': لوحة الإشعارات بلا overflow', await noHOverflow(p));
    } else ok(label + ': جرس الإشعارات موجود', false);

    /* ---- المكتب 3D: رندر + جويستيك للمسات فقط ---- */
    await p.goto(BASE + '/#/office?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForFunction(() => (window.__of3d && window.__of3d.ready) || !!document.querySelector('.office-map'), null, { timeout: 45000 }).catch(() => {});
    await p.waitForTimeout(800);
    const is3d = await p.evaluate(() => !!(window.__of3d && window.__of3d.ready));
    if (is3d) {
      ok(label + ': 3D بلا overflow', await noHOverflow(p));
      if (touch) {
        const joy = await p.evaluate(async () => {
          const cv = document.querySelector('canvas.of3d-canvas');
          if (!cv) return { shown: false };
          const t = (type, x, y) => cv.dispatchEvent(new TouchEvent(type, { bubbles: true, cancelable: true, touches: type === 'touchend' ? [] : [new Touch({ identifier: 1, target: cv, clientX: x, clientY: y })], targetTouches: type === 'touchend' ? [] : [new Touch({ identifier: 1, target: cv, clientX: x, clientY: y })] }));
          t('touchstart', 120, 500);
          await new Promise((r2) => setTimeout(r2, 200));
          const shown = !!document.querySelector('.of3d-joy');
          t('touchend', 120, 500);
          await new Promise((r2) => setTimeout(r2, 200));
          const hidden = !document.querySelector('.of3d-joy');
          return { shown, hidden };
        });
        ok(label + ': الجويستيك يظهر باللمس ويختفي بعده', joy.shown && joy.hidden);
      }
    } else {
      ok(label + ': المكتب (2D fallback) بلا overflow', await noHOverflow(p));
    }

    ok(label + ': مفيش pageerrors', errs.length === 0);
    if (errs.length) console.log('  ERRS:', errs.slice(0, 3).join(' | '));
    await ctx.close();
  }
  await b.close();
  const pass = R.filter(Boolean).length;
  console.log(`\n=== FIX-16 RESPONSIVE: ${pass}/${R.length} ===`);
  process.exit(pass === R.length ? 0 : 1);
})();
