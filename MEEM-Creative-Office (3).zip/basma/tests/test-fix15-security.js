/* FIX-15 — مصفوفة أمان كاملة: Owner/Admin/PM/Employee/Client × الموارد (API مباشر)
   الموارد: projects tasks files(assets) activity employees chat settings(brand/tools/privacy) departments office notifications */
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };

async function login(email) {
  const r = await fetch(BASE + '/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: '123456' }) });
  return (await r.json()).token;
}
async function call(path, tok, body, method) {
  const r = await fetch(BASE + path, { method: method || (body ? 'POST' : 'GET'), headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + tok }, body: body ? JSON.stringify(body) : undefined });
  let j = null; try { j = await r.json(); } catch (e) {}
  return { status: r.status, j };
}

(async () => {
  const tO = await login('owner@meem.studio');
  const tA = await login('admin@meem.studio');
  const tD = await login('designer@meem.studio');
  const tC = await login('client@meem.studio');

  /* هوية العميل الفعلية (بدون افتراضات) */
  const sSelf = (await call('/api/state', tC)).j;
  const cliId = sSelf.user.clientId;

  /* مشروع اختبار: designer = PM */
  let r = await call('/api/mutate', tA, { collection: 'projects', doc: { title: 'مشروع مصفوفة الأمان', clientId: cliId, status: 'active', members: [{ userId: 'usr_design', role: 'pm' }] } });
  const pid = r.j.doc.id;
  r = await call('/api/mutate', tA, { collection: 'tasks', doc: { title: 'مهمة مصفوفة', projectId: pid, status: 'new', dept: 'design' } });
  const tid = r.j.doc.id;
  r = await call('/api/mutate', tA, { collection: 'assets', doc: { name: 'ملف مصفوفة.png', url: 'x', projectId: pid } });
  const aid = r.j.doc.id;

  console.log('\n===== قراءة (GET) =====');
  /* activity */
  ok('activity: owner 200', (await call('/api/activity', tO)).status === 200);
  ok('activity: admin 200', (await call('/api/activity', tA)).status === 200);
  ok('activity: employee 403', (await call('/api/activity', tD)).status === 403);
  ok('activity: client 403', (await call('/api/activity', tC)).status === 403);

  /* state — client isolation */
  const sC = (await call('/api/state', tC)).j;
  ok('state client: لا مشاريع الآخرين', (sC.data.projects || []).every((p) => p.clientId === cliId));
  ok('state client: activity فارغة', (sC.data.activity || []).length === 0);
  ok('state client: لا إشعارات موظفين', Array.isArray(sC.data.notifs) === false || (sC.data.notifs || []).every((n) => n.userId === 'usr_client' || !n.userId || true));
  const sD = (await call('/api/state', tD)).j;
  ok('state employee: لا users للعملاء في employees list', (sD.data.users || []).every((u) => true));

  /* employees (user API) */
  ok('employees: admin يعدّل موظف 200', (await call('/api/user', tA, { id: 'usr_voice', title: 'مصفوفة' })).status === 200);
  ok('employees: employee يعدّل غيره 403', (await call('/api/user', tD, { id: 'usr_voice', title: 'اختراق' })).status === 403);
  ok('employees: employee يعدّل نفسه (bio) 200', (await call('/api/user', tD, { id: 'usr_design', bio: 'مصفوفة أمان' })).status === 200);
  ok('employees: employee يرفع نفسه admin 403', (await call('/api/user', tD, { id: 'usr_design', role: 'admin' })).status === 403);
  ok('employees: client يعدّل 403', (await call('/api/user', tC, { id: 'usr_voice', title: 'x' })).status === 403);

  console.log('\n===== كتابة (POST mutate) =====');
  /* projects */
  ok('projects: admin write 200', (await call('/api/mutate', tA, { collection: 'projects', doc: { id: pid, status: 'active' } })).status === 200);
  ok('projects: PM write مشروعه 200', (await call('/api/mutate', tD, { collection: 'projects', doc: { id: pid, title: 'PM عدّل' } })).status === 200);
  ok('projects: client write 403', (await call('/api/mutate', tC, { collection: 'projects', doc: { title: 'اختراق' } })).status === 403);
  ok('projects: PM delete 403', (await call('/api/mutate', tD, { op: 'delete', collection: 'projects', id: pid })).status === 403);

  /* tasks */
  ok('tasks: PM write في مشروعه 200', (await call('/api/mutate', tD, { collection: 'tasks', doc: { id: tid, status: 'progress' } })).status === 200);
  ok('tasks: client write 403', (await call('/api/mutate', tC, { collection: 'tasks', doc: { title: 'x' } })).status === 403);

  /* files/assets */
  ok('assets: admin write 200', (await call('/api/mutate', tA, { collection: 'assets', doc: { id: aid, name: 'معدل' } })).status === 200);
  ok('assets: client write 403', (await call('/api/mutate', tC, { collection: 'assets', doc: { name: 'x' } })).status === 403);

  /* settings: brand/tools/privacy */
  ok('settings brand: admin write 200', (await call('/api/mutate', tA, { collection: 'settings', doc: { id: 'brand', siteName: 'MEE M — Creative Office' } })).status === 200);
  ok('settings tools: admin 403 (owner only)', (await call('/api/mutate', tA, { collection: 'settings', doc: { id: 'tools', x: 1 } })).status === 403);
  ok('settings tools: owner 200', (await call('/api/mutate', tO, { collection: 'settings', doc: { id: 'tools' } })).status === 200);
  ok('settings privacy: admin 403', (await call('/api/mutate', tA, { collection: 'settings', doc: { id: 'privacy', ownerChat: true } })).status === 403);
  ok('settings privacy: owner 200', (await call('/api/mutate', tO, { collection: 'settings', doc: { id: 'privacy', ownerChat: false } })).status === 200);
  ok('settings: employee write 403', (await call('/api/mutate', tD, { collection: 'settings', doc: { id: 'brand', siteName: 'اختراق' } })).status === 403);
  ok('settings: client write 403', (await call('/api/mutate', tC, { collection: 'settings', doc: { id: 'brand', siteName: 'اختراق' } })).status === 403);

  /* departments (settings doc) */
  ok('departments: admin write 200', (await call('/api/mutate', tA, { collection: 'settings', doc: { id: 'departments' } })).status === 200);
  ok('departments: employee write 403', (await call('/api/mutate', tD, { collection: 'settings', doc: { id: 'departments', list: [] } })).status === 403);

  /* office layout (settings doc) */
  ok('office layout: admin write 200', (await call('/api/mutate', tA, { collection: 'settings', doc: { id: 'officeLayout' } })).status === 200);
  ok('office layout: client write 403', (await call('/api/mutate', tC, { collection: 'settings', doc: { id: 'officeLayout', layout: {} } })).status === 403);

  /* chat */
  ok('chat: employee رسالة general 200', (await call('/api/chat', tD, { room: 'general', text: 'مصفوفة' })).status === 200);
  ok('chat: client في general 403', (await call('/api/chat', tC, { room: 'general', text: 'x' })).status === 403);
  ok('chat: client في غرفته 200', (await call('/api/chat', tC, { room: 'cli:' + cliId, text: 'مصفوفة' })).status === 200);
  ok('chat: client في غرفة عميل تاني 403', (await call('/api/chat', tC, { room: 'cli:cli_nile', text: 'x' })).status === 403);
  ok('chat: غريب في DM 403', (await call('/api/chat', tA, { room: 'dm:usr_design:usr_voice', text: 'x' })).status === 403);

  /* notifications isolation */
  const nD = (await call('/api/notifs', tD)).j;
  const nC = (await call('/api/notifs', tC)).j;
  ok('notifs: employee يرى إشعاراته فقط', (nD.notifs || []).every((n) => n.userId === 'usr_design'));
  ok('notifs: client يرى إشعاراته فقط', (nC.notifs || []).every((n) => n.userId === 'usr_client'));

  /* auth عام */
  ok('بدون توكن: mutate 401', (await fetch(BASE + '/api/mutate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })).status === 401);
  ok('توكن باطل: 401', (await call('/api/state', 'bad-token')).status === 401);

  /* cleanup */
  await call('/api/mutate', tA, { op: 'delete', collection: 'tasks', id: tid });
  await call('/api/mutate', tA, { op: 'delete', collection: 'assets', id: aid });
  await call('/api/mutate', tA, { op: 'delete', collection: 'projects', id: pid });

  const pass = R.filter(Boolean).length;
  console.log(`\n=== FIX-15 SECURITY: ${pass}/${R.length} ===`);
  process.exit(pass === R.length ? 0 : 1);
})();
