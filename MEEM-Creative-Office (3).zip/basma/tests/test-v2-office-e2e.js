/* MEEM V2-7 E2E — المكتب الافتراضي: الهبوط · الخريطة · الأقسام · التنقل · الإدارة المقفولة */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const FORCE2D = (b) => { const orig = b.newContext.bind(b); b.newContext = async (opts) => { const ctx = await orig(opts); try { ctx.addInitScript(() => { try { localStorage.setItem('meem_view3d', '0'); } catch (e) {} }); } catch (e) {} return ctx; }; return b; };
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];

(async () => {
  const b = FORCE2D(await chromium.launch({ args: ['--no-sandbox'] }));
  async function login(email, ctxOpts) {
    const ctx = await b.newContext(Object.assign({ viewport: { width: 1500, height: 950 } }, ctxOpts || {}));
    const p = await ctx.newPage();
    p.on('pageerror', (e) => errs.push(email + ': ' + e.message));
    p.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource/.test(m.text())) errs.push(email + ': ' + m.text()); });
    await p.goto(BASE + '/?r=' + Date.now(), { waitUntil: 'networkidle' });
    await p.waitForSelector('.login-card');
    await p.fill('input[type=email]', email);
    await p.click('.login-card .btn.primary');
    await p.waitForSelector('.sidebar .nav-item');
    return p;
  }

  /* ---- 1) الفريق يهبط في المكتب ---- */
  const d = await login('designer@meem.studio');
  ok('designer هبط على #/office', d.url().includes('#/office'));
  await d.waitForSelector('.office-map');
  ok('الخريطة ظاهرة', true);
  ok('الطابق ١ فيه 6 أقسام', (await d.locator('.office-room').count()) === 6);
  for (const room of ['الاستقبال', 'التصميم', 'المحتوى', 'صالة العملاء', 'كافيه ميم', 'التسليمات']) {
    if (!(await d.locator('.office-room', { hasText: room }).count())) { ok('قسم «' + room + '» في الطابق ١', false); }
  }
  ok('أقسام الطابق ١ مسماة', true);
  ok('قسم المصمم مميز (mine)', (await d.locator('.office-room.mine').count()) === 1);
  await d.locator('.of-flr').nth(1).click(); await d.waitForTimeout(600);
  ok('الطابق ٢ فيه 5 أقسام', (await d.locator('.office-room').count()) === 5);
  for (const room of ['البرمجة', 'الفويس أوفر', 'خدمة العملاء', 'الاجتماعات', 'الإدارة']) {
    if (!(await d.locator('.office-room', { hasText: room }).count())) { ok('قسم «' + room + '» في الطابق ٢', false); }
  }
  ok('الإدارة مقفولة لغير الأدمن (طابق ٢)', (await d.locator('.office-room.locked').count()) === 1);
  await d.locator('.of-flr').nth(0).click(); await d.waitForTimeout(600);

  /* ---- 2) التنقل من الغرفة ---- */
  await d.locator('.office-room', { hasText: 'التصميم' }).click();
  await d.waitForTimeout(700);
  ok('غرفة التصميم → #/design', d.url().includes('#/design'));
  await d.goto(BASE + '/#/office', { waitUntil: 'networkidle' });
  await d.waitForSelector('.office-map');
  await d.locator('.office-room', { hasText: 'كافيه ميم' }).click();
  await d.waitForTimeout(700);
  ok('كافيه ميم → الشات', d.url().includes('#/chat')); /* FIX-11: الاسم الجديد */

  /* ---- 3) الغرفة المقفولة: ما تفتحش لغير الإدارة ---- */
  await d.goto(BASE + '/#/office', { waitUntil: 'networkidle' });
  await d.waitForSelector('.office-map');
  await d.locator('.of-flr').nth(1).click(); await d.waitForTimeout(600);
  await d.locator('.office-room', { hasText: 'الإدارة' }).click();
  await d.waitForTimeout(700);
  ok('الإدارة ⛔ ما فتحتش للمصمم', d.url().includes('#/office'));

  /* ---- 4) الأدمن: الإدارة مش مقفولة + الاستقبال → My Desk ---- */
  const a = await login('admin@meem.studio');
  ok('admin هبط على #/office', a.url().includes('#/office'));
  await a.waitForSelector('.office-map');
  await a.locator('.of-flr').nth(1).click(); await a.waitForTimeout(600);
  ok('الإدارة مفتوحة للأدمن (مفيش locked بالطابق ٢)', (await a.locator('.office-room.locked').count()) === 0);
  await a.locator('.of-flr').nth(0).click(); await a.waitForTimeout(600);
  await a.locator('.office-room', { hasText: 'الاستقبال' }).click();
  await a.waitForTimeout(700);
  ok('الاستقبال → My Desk', a.url().includes('#/dashboard'));

  /* ---- 5) السايدبار فيه «المكتب» ---- */
  const nav = (await d.locator('.sidebar .nav-item').allInnerTexts()).map((x) => x.split('\n')[0].trim());
  ok('«المكتب» في السايدبار', nav.includes('المكتب'));

  /* ---- 6) الموبايل: الخريطة عمودية وتشتغل باللمس ---- */
  const m = await login('content@meem.studio', { viewport: { width: 390, height: 844 }, hasTouch: true });
  await m.waitForSelector('.office-map');
  ok('موبايل: الخريطة ظاهرة (6 أقسام بالطابق ١)', (await m.locator('.office-room').count()) === 6);
  await m.locator('.office-room', { hasText: 'المحتوى' }).tap();
  await m.waitForTimeout(700);
  ok('موبايل: tap على غرفة المحتوى → #/content', m.url().includes('#/content'));

  ok('صفر أخطاء console (' + errs.length + ')', errs.length === 0);
  if (errs.length) console.log(errs.slice(0, 4).join('\n'));
  await b.close();
  const failed = R.filter((x) => !x).length;
  console.log(`\nRESULT: ${R.length - failed} passed, ${failed} failed`);
  process.exit(failed ? 1 : 0);
})().catch((e) => { console.log('FATAL', e); process.exit(1); });
