/* FIX-9 — أنيميشن الأفاتار: مشي/جري/عمل/جلوس/idle + مزج + التصادم والمزامنة لا ينكسران */
const { chromium } = require('/tmp/tc/node_modules/playwright');
const BASE = 'http://localhost:3000';
const R = [];
const ok = (n, c) => { R.push(c); console.log((c ? 'PASS' : 'FAIL') + ' — ' + n); };
const errs = [];
const GL = ['--no-sandbox', '--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'];

async function mk(ctx, email) {
  const p = await ctx.newPage();
  p.on('pageerror', (e) => errs.push(email + ' PE: ' + e.message.slice(0, 140)));
  await p.goto(BASE + '/?r=' + email + Date.now(), { waitUntil: 'networkidle' });
  await p.waitForSelector('.login-card');
  await p.fill('input[type=email]', email);
  await p.fill('input[type=password]', '123456');
  await p.click('.login-card .btn.primary');
  await p.waitForFunction(() => window.__of3d && window.__of3d.ready, null, { timeout: 45000 });
  await p.waitForTimeout(500);
  return p;
}

(async () => {
  const b = await chromium.launch({ args: GL });
  const c1 = await b.newContext({ viewport: { width: 1400, height: 900 } });
  const c2 = await b.newContext({ viewport: { width: 1400, height: 900 } });
  const A = await mk(c1, 'designer@meem.studio');

  /* 1) الهيكل: أطراف موجودة */
  const has = await A.evaluate(() => {
    const a = window.__of3d.anim();
    return !!(a && a.armL && a.armR && a.legL && a.legR && a.torso && a.head && a.body);
  });
  ok('الأفاتار فيه أذرع وأرجل وجذع (anim refs)', has);

  /* 2) idle → amp منخفض */
  await A.evaluate(() => window.__of3d.setPos(50, 92));
  await A.waitForTimeout(1200);
  const idle = await A.evaluate(() => ({ st: window.__of3d.animState(), amp: window.__of3d.anim().amp }));
  ok('واقف = idle والمزج صفر تقريبًا', idle.st === 'idle' && idle.amp < 0.15);

  /* 3) مشي: سهم أعلى → walk و amp يرتفع */
  await A.keyboard.down('ArrowUp');
  await A.waitForTimeout(900);
  const walk = await A.evaluate(() => ({ st: window.__of3d.animState(), amp: window.__of3d.anim().amp, arm: window.__of3d.anim().armL.rotation.x }));
  await A.keyboard.up('ArrowUp');
  ok('حركة = walk والتأرجح شغال', walk.st === 'walk' && walk.amp > 0.3 && Math.abs(walk.arm) >= 0);

  /* 4) جري: Shift + سهم */
  await A.keyboard.down('Shift'); await A.keyboard.down('ArrowUp');
  await A.waitForTimeout(900);
  const run = await A.evaluate(() => ({ st: window.__of3d.animState(), amp: window.__of3d.anim().amp, lean: window.__of3d.anim().lean }));
  await A.keyboard.up('ArrowUp'); await A.keyboard.up('Shift');
  ok('Shift+حركة = run بميل أمامي', run.st === 'run' && run.amp > 0.5 && run.lean > 0.05);

  /* 5) المزج الناعم: بعد التوقف amp يهبط تدريجيًا (مش صدمة) */
  const mid = await A.evaluate(() => window.__of3d.anim().amp);
  await A.waitForTimeout(300);
  const after = await A.evaluate(() => window.__of3d.anim().amp);
  await A.waitForTimeout(1500);
  const settled = await A.evaluate(() => ({ st: window.__of3d.animState(), amp: window.__of3d.anim().amp }));
  ok('مزج ناعم: amp يهبط بالتدريج ثم idle', mid > after && settled.st === 'idle' && settled.amp < 0.15);

  /* 6) الجلوس في الاستراحة — نبحث عن نقطة داخل الغرفة لا يطردها التصادم */
  async function standIn(test, bounds, want) {
    for (let x = bounds.x0; x <= bounds.x1; x += 1.5) {
      for (let y = bounds.y0; y <= bounds.y1; y += 1.5) {
        const held = await test.evaluate(([xx, yy]) => {
          window.__of3d.setPos(xx, yy);
          const p = window.__of3d.pos();
          return window.__of3d.roomAt(p.x, p.y) === window.__of3d.roomAt(xx, yy);
        }, [x, y]);
        if (held) {
          const rid = await test.evaluate(([xx, yy]) => window.__of3d.roomAt(xx, yy), [x, y]);
          if (rid === want) { await test.waitForTimeout(1600); return test.evaluate(() => window.__of3d.animState()); }
        }
      }
    }
    return null;
  }
  const sitSt = await standIn(A, { x0: 1, x1: 29, y0: 59, y1: 99 }, 'lounge');
  const sit = await A.evaluate(() => ({ st: window.__of3d.animState(), sit: window.__of3d.anim().sit, leg: window.__of3d.anim().legL.rotation.x }));
  ok('الاستراحة = sit (أرجل مثنية + هبوط جذع)', sitSt === 'sit' && sit.sit > 0.8 && sit.leg < -1.0);

  /* 7) العمل في البوث */
  const workSt = await standIn(A, { x0: 45, x1: 55, y0: 49.5, y1: 57 }, 'booth1');
  const work = await A.evaluate(() => ({ st: window.__of3d.animState(), typing: window.__of3d.anim().typing }));
  ok('البوث = work (جلوس + طباعة)', workSt === 'work' && work.typing > 0.8);

  /* 8) التصادم لم ينكسر */
  const col = await A.evaluate(() => window.__of3d.colliders());
  ok('التصادمات سليمة (> 40)', col > 40);

  /* 9) مزامنة زميل + حالته */
  const B = await mk(c2, 'voice@meem.studio');
  await A.waitForTimeout(1200);
  await B.evaluate(() => window.__of3d.setPos(48, 90));
  await A.waitForTimeout(1500);
  const peers = await A.evaluate(() => window.__of3d.peers());
  ok('زميل ظاهر في المشهد', peers >= 1);

  /* الزميل يتحرك → حالته walk عندي */
  await B.keyboard.down('ArrowUp');
  await B.waitForTimeout(1200);
  const pst = await A.evaluate(() => {
    const st = [];
    for (const u of ['usr_voice']) st.push(window.__of3d.peerAnimState(u));
    return st;
  });
  await B.keyboard.up('ArrowUp');
  ok('حركة الزميل = walk عندي (مزامنة الأنيميشن)', pst.includes('walk') || pst.includes('run'));

  /* 10) لا أخطاء صفحات + FPS حي */
  const fps = await A.evaluate(() => window.__of3d.fps());
  ok('الرندر حي (FPS ≥ 1 حتى لو headless بطيء)', fps >= 1);
  ok('مفيش أخطاء صفحات', errs.length === 0 || errs.join('|').length === 0);
  if (errs.length) console.log('  ERRS:', errs.slice(0, 4).join('\n  '));

  await b.close();
  const pass = R.filter(Boolean).length;
  console.log(`\n=== FIX-9 ANIM: ${pass}/${R.length} ===`);
  process.exit(pass === R.length ? 0 : 1);
})();
